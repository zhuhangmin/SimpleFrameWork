local ProFi = require "ProFi"

function foo2()
	for i = 1, 100000000 do
		i = i + 1
	end
end


function foo1()
	for i = 1, 100000000 do
		i = i + 1
	end
	foo2()
end


ProFi:start()
ProFi:setInspect(foo1,3)
foo1()

ProFi:stop()
ProFi:writeReport('MyProfilingReport.txt')
