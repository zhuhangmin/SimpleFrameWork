local _convertTable = {
    [0] = "0",
    [1] = "1",
    [2] = "2",
    [3] = "3",
    [4] = "4",
    [5] = "5",
    [6] = "6",
    [7] = "7",
    [8] = "8",
    [9] = "9",
    [10] = "a",
    [11] = "b",
    [12] = "c",
    [13] = "d",
    [14] = "e",
    [15] = "f",
    [16] = "g",
    [17] = "h",
    [18] = "i",
    [19] = "j",
    [20] = "k",
    [21] = "l",
    [22] = "m",
    [23] = "n",
    [24] = "o",
    [25] = "p",
    [26] = "q",
    [27] = "r",
    [28] = "s",
    [29] = "t",
    [30] = "u",
    [31] = "v",
    [32] = "w",
    [33] = "x",
    [34] = "y",
    [35] = "z",
}



local function GetNumFromChar(char)
    for k, v in pairs(_convertTable) do
        if v == char then
            return k
        end
    end
    return 0
end

local function Convert(dec, x)
    local function fn(num, t)
        if(num < x) then
            table.insert(t, num)
        else
            fn( math.floor(num/x), t)
            table.insert(t, num%x)
        end
    end
    local x_t = {}
    fn(dec, x_t, x)
    return x_t
end

function ConvertDec2X(dec, x)
    local x_t = Convert(dec, x)
    local text = ""
    for k, v in ipairs(x_t) do
        text = text.._convertTable[v]
    end
    return text
end

function ConvertStr2Dec(text, x)
    local x_t = {}
    local len = string.len(text)
    local index = len
    while ( index > 0) do
        local char = string.sub(text, index, index)
        x_t[#x_t + 1] = GetNumFromChar(char)
        index = index - 1
    end
    local num = 0
    for k, v in ipairs(x_t) do
    -- num = num + v * math.pow(x, k - 1) 
        local powResult = math.ceil(x ^ (k-1))
        num = num + v * powResult
    end
    return num
end

-----------------
local DEBUG_CHECK = false
local GROUPINDEX = 9
local GROUPSLOT = 2
local INDEXSLOT = 9
local BASESLOT = 7
local RANDOMSLOT = 14
local CONVERT_BASE = 36

--CHECK
local checkGroupID = function(groupID)
    if DEBUG_CHECK then  print(groupID) assert(string.len(groupID) == GROUPSLOT) end
end

local checkIndex = function(index)
    if DEBUG_CHECK then  print(index) assert(string.len(index) == INDEXSLOT) end
end

local checkCombine = function(combine)
    if DEBUG_CHECK then print(combine) assert(string.len(combine) == (INDEXSLOT + GROUPSLOT)) end
end

local checkBase = function(baseStr)
    if DEBUG_CHECK then  print(baseStr) assert(string.len(baseStr) == BASESLOT) end
end

local checkRandom = function(randomStr)
    if DEBUG_CHECK then  print(randomStr) assert(string.len(randomStr) == RANDOMSLOT) end
end

--ENCODE
local encodeGroupIDWithIndex = function(index,groupID)
    local combine = index .. groupID
    return combine
end

local encodeBaseStr = function(combine, base)
    return ConvertDec2X(combine,base)
end

local encodeRandom = function(baseStr,base)
    local len = string.len(baseStr)
    local randomStr = ""
    for index = 1, len do
        local randomIndex = math.random(base-1)
        local randomNum = _convertTable[randomIndex]
        if randomNum == nil then print(randomIndex) assert() end
        randomStr = randomStr .. randomNum

        local subStr = string.sub(baseStr,index,index) 
        if subStr == nil then assert() end
        randomStr = randomStr .. subStr
    end 
    return randomStr
end

local encodeRedeem = function(index, groupID)
    checkIndex(index)
    checkGroupID(groupID)

    local combine = encodeGroupIDWithIndex(index, groupID)
    checkCombine(combine)

    local combineNum = tonumber(combine)
    local baseStr = encodeBaseStr(combineNum, CONVERT_BASE)
    checkBase(baseStr)

    local randomStr = encodeRandom(baseStr, CONVERT_BASE)
    checkRandom(randomStr)

    return randomStr
end

-------------

--DECODE
local decodeIndex = function(combine)
    return string.sub(combine, 1, GROUPINDEX)
end

local decodeGroup = function(combine)
    return string.sub(combine, GROUPINDEX + 1, GROUPINDEX + GROUPSLOT)
end

local decodeBaseStr = function(baseStr, base)
    return ConvertStr2Dec(baseStr,base)
end

local decodeRandom = function(randomStr)
    local len = string.len(randomStr)
    local baseStr = ""
    for index = 1, len do
        if index % 2 == 0 then
            local subStr = string.sub(randomStr,index,index) 
            baseStr = baseStr .. subStr
        end
    end 
    return baseStr
end

local decodeRedeem = function(code)
    checkRandom(code)

    local baseStr = decodeRandom(code)
    checkBase(baseStr)
    
    local combine = decodeBaseStr(baseStr, CONVERT_BASE)
    checkCombine(combine)

    local groupID = decodeGroup(combine)
    checkGroupID(groupID)

    local index = decodeIndex(combine)
    checkIndex(index)

    return index, groupID
end

--------test

local groupID = 11 
local init  = 100000001
local final = 100010000
local storeTbl = {}


local filename = "hehe.txt"
local file, err = io.open( filename, 'w' )
-- assert( file, err )
for index = init, final do
    local redeem = encodeRedeem(index, groupID) .. "\n"
    file:write(redeem)
    local decodeIndex, decodeGroupID = decodeRedeem(redeem)
    print(index, groupID, redeem, decodeIndex, decodeGroupID)
    if tostring(index) ~= tostring(decodeIndex) then print(index, groupID, redeem, decodeIndex, decodeGroupID) assert() end    
    if tostring(groupID) ~= tostring(decodeGroupID) then print(index, groupID, redeem, decodeIndex, decodeGroupID) assert() end    
end


-- local combine = encodeGroupIDWithIndex(final, groupID)
-- print("combine = " .. combine)

-- local index = decodeIndex(combine)
-- print("index = " .. index)

-- local groupID = decodeGroup(combine)
-- print("groupID = " .. groupID)

-- local combineNum = tonumber(combine)
-- local baseStr = encodeBaseStr(combineNum, CONVERT_BASE)
-- print("baseStr = " .. baseStr)

-- local decodeCombine = decodeBaseStr(baseStr, CONVERT_BASE)
-- print("decodeCombine = " .. decodeCombine)

-- local randomStr = encodeRandom(baseStr, CONVERT_BASE)
-- print("randomStr = " .. randomStr)

-- local decodeBaseStr = decodeRandom(randomStr)
-- print("decodeBaseStr = " .. decodeBaseStr)

-- checkGroupID("12")
-- checkIndex("123123432")
-- checkCombine("12123123432")
-- checkBase("1234567")
-- checkRandom("12345671234567")




