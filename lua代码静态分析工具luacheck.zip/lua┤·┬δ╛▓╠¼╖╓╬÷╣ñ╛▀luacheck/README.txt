lucheck 是静态分析工具. 用来验证lua文件的合法性和可能的编码错误
其中error错误必须修改, warning 为可能的逻辑错误

USEAGE:
luacheck.bat 文件夹/文件

EX:
luacheck.bat app
