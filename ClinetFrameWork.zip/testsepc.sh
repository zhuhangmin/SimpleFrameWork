testPath="./FrameWork/interface/?.lua;\
./FrameWork/common/?.lua;\
./FrameWork/base/?.lua;\
./FrameWork/base/define/?.lua;\
./FrameWork/base/utils/?.lua;\
./FrameWork/engine/?.lua;\
./FrameWork/engine/define/?.lua;\
./FrameWork/engine/utils/?.lua;\
./FrameWork/engine/cocos/?.lua;\
"

# sudo busted --coverage --lpath=$testPath ./spec
# sudo busted --coverage --lpath=$testPath ./spec/engine/EngineControlManager_spec.lua
# sudo busted --coverage --lpath=$testPath ./spec/base/BaseControlManager_spec.lua

# sudo busted --coverage --lpath=$testPath ./spec/engine/EngineModel_spec.lua
# sudo busted --coverage --lpath=$testPath ./spec/engine/EngineView_spec.lua

# sudo busted --coverage --lpath=$testPath ./spec/engine/EngineControl_spec.lua
# sudo busted --coverage --lpath=$testPath ./spec/base/utils/utils_spec.lua
sudo busted --coverage --lpath=$testPath ./spec/engine/EngineMessageManager_spec.lua
sudo luacov
