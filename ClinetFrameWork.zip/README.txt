目标： HOW TO DO -> WHAT TO DO 接近人类自然表述

设计原则：
0 用尽可能小的信息集合来定义框架功能
1 对象具有收发消息的能力
2 对象可以组装mixin来获得各种特定消息收发能力
2 模块尽量没有状态，每个方法类似数学函数
3 模块尽量保持少的状态，每个状态应该独立
5 父类和子群的二元信息结构表述所有数据结构

逻辑层MVC：
1 CONTROL 不应有状态维护, 如self.property
2 VIEW    不应有状态维护, 如self.property
3 MODEL   具有完备的MVC状态信息


框架主体分四层
1 interface 	定义基本对象行为
2 base 			定义基本对象数据
3 engine 		桥接具体引擎，提供引擎无关业务API
4 game 			业务层（考虑到引擎API较多,还是使用了而一些引擎相关API）

实现功能：
1,2 层实现通用软件的对象MVC管理，和基础的行为数据定义。 不限于游戏项目
3   层实现具体引擎桥接，把数据，控制，渲染API分类桥接即可。 不限于具体某个引擎
4   层实现具体业务，（核心业务和引擎无关，换第3层可实现不同引擎间的移植，如手游到端游）

1-2-3 层实现 HOW  TO DO
4     层实现 WHAT TO DO


│─FrameWork						框架
│  ├─common						Lua语言机制支持 
│  │
│  │
│  ├─interface					行为层（行为定义，引擎无关）
│  │
│  │
│  ├─base						核心层（数据定义，引擎无关）
│  │  ├─define					定义
│  │  │─utils					帮助函数
│  │  └─BaseXXX					MVC类，管理类，消息类
│  │
│  │
│  ├─engine						引擎桥接层 （耦合引擎，游戏逻辑无关）
│  │   │─define					定义
│  │   │─utils					帮助函数
│  │   └─EngineXXX				MVC类，管理类，消息类， 全局状态类
│  │
│  │
│  └─game						游戏逻辑层 （开发游戏逻辑，逐步脱离具体引擎API）
│      │─define					定义
│      │─utils					帮助函数
│      │─config					配置文件
│      │─data					用户全局数据
│      │─net					网络库，协议定义
│      │─netmsg					网络消息接收处理类
│      │─uicontrol				引擎复合控件MVC封装
│      └─XXXMVC					业务逻辑mvc类
│  
└─spec							对应框架测试
    

举例WHAT TO DO：
1 标准的消息收发功能 Message-Mixin
2 标准的三元配置数据功能 Config-Mixin
3 标准的定时器功能 Scheduler-Mixin
4 标准MVC结构功能划分 
5 所有MVC管理 ControlManager
6 抽象算法的支持 Abstract
7 份帧任务的支持 FrameTask
8 保存Model状态后,可根据Model还原MVC




