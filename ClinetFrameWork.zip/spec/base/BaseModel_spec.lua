local BaseModel = require "BaseModel"
require "utils"
describe('test BaseModel :', function()
	it('build path :', function()
		local expectedData = {}
		expectedData.name = "666"
		local model = BaseModel.new(expectedData)

		local value = model:getData()
		assert.same(expectedData, value)

		local fd = model:getFD()
		local expectedFD = fd + 1
		local model = BaseModel.new(expected)
		value = model:getFD()
		assert.same(expectedFD, value)



	end)

end)
    