local BaseMessageManager = require "BaseMessageManager"

local apiNames =  {"registerMsg", "unRegisterMsg", "dispatch"}

describe('test BaseMessageManager :', function()
	it('build path :', function()
		local mm1 = BaseMessageManager.getInstance()
		local mm2 = BaseMessageManager.getInstance()

		assert.same(mm1, mm2)
		
		local instance = BaseMessageManager.getInstance()
		for k, apiName in pairs(apiNames) do
			local method = instance[apiName]
			assert.is_not_nil(method)
			-- assert.has_error(method)
		end

	end)
end)
