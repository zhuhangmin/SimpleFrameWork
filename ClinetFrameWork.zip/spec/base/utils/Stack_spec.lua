local Stack = require "Stack"

describe('test Stack :', function()
  it('build path :', function()
    local stack = Stack.new()

    local expectedValue = true
    local value = stack:isEmpty()
    assert.same(expectedValue, value)

    local expectedLen = 0
    local value = stack:getLen()
    assert.same(expectedLen, value)

    local expectedValue = {x = 1}
    stack:push(expectedValue)

    local expectedValue = false
    local value = stack:isEmpty()
    assert.same(expectedValue, value)

    local expectedValue = {x = 1}
    local value = stack:top()
    assert.same(expectedValue, value)

    local value = stack:pop()
    assert.same(expectedValue, value)

    stack:push(expectedValue)
    local expectedLen = 1
    local value = stack:getLen()
    assert.same(expectedLen, value)

    stack:clean()
    local expectedLen = 0
    local value = stack:getLen()
    assert.same(expectedLen, value)

    stack:push({x=100})
    stack:push({x=200})
    stack:push({x=300})
    stack:popToRoot()
    local expectedLen = 1
    local value = stack:getLen()
    assert.same(expectedLen, value)
    local expectedValue = 100
    local value = stack:top().x
    assert.same(expectedValue,value)

    stack:desciption()
  end)
end)
