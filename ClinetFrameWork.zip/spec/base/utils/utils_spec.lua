require "utils"
local BaseModel = require "BaseModel"
local BaseView = require "BaseView"
local BaseControl = require "BaseControl"

describe('test base utils :', function(className)
	it('build path :', function()
		local className = className or "Foo"
		local classPath = buildClassPath(className,  CLASS_SUBFIX.MODEL)
		local expected = PROJECT_PATH .. className .. CLASS_SUBFIX.MODEL
		assert.same(expected, classPath)

		local classPath = buildClassPath(className, CLASS_SUBFIX.VIEW)
		local expected = PROJECT_PATH .. className .. CLASS_SUBFIX.VIEW
		assert.same(expected, classPath)

		local classPath = buildClassPath(className, CLASS_SUBFIX.CONTROL)
		local expected = PROJECT_PATH .. className .. CLASS_SUBFIX.CONTROL
		assert.same(expected, classPath)

	end)

	it('msg report' , function()
		local sourceStr = "source class"
		local reportStr = "report msg"
		report(sourceStr, reportStr)
	end)

	it('print address' , function()
		local data = {}
		local model = BaseModel:create(data)
		local node = {}
		local view = BaseView:create(node)
		local control = BaseControl:create(model, view)
		printAddress(control)
	end)

	it('build mvc info', function()
		local data = {}
		local node = {}
		local mvcInfo = buildMVCInfo(data, node)
		assert.is_not_same(data, node)
	end)

	it('test oop', function()
		local x = require()
	end)

end)
    