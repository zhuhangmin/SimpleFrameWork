
-- --[FRAMEWORK]-- BASE CONTROL , MODEL , VIEW
-- --BASE_MODEL
-- local ModelBase = class("ModelBase", ModelInterface)
-- function ModelBase:ctor(eid)
-- 	selfeid = eid
-- end

-- --BASE_VIEW
-- local ViewBase = class("ViewBase", ViewlInterface)
-- function ViewBase:ctor(node)
-- 	self:node = node
-- end

-- --BASE_CONTROL
-- local ControlBase = class("ControlBase", ControlInterface)
-- function ControlBase:ctor(model, view)
-- 	self:model = model
-- 	self:view = view
-- end

-- function ControlBase:register(msgs)
-- 	for k, name in pairs(msgs) do
-- 		MsgManager.getInstance:register(self, name, self:recv)
-- 	end
-- end

-- function ControlBase:send(name, msg)
-- 	MsgManager.getInstance:send(name, msg)
-- end

-- function ControlBase:onEnter(param)
-- end

-- --[FRAMEWORK]---EntityFactoryManager---

-- EntityControlFactory.instance = nil

-- function EntityControlFactory.getInstance()
--     if not EntityControlFactory.instance then
--         EntityControlFactory.instance = EntityControlFactory:create()
--     end
--     return EntityControlFactory.instance
-- end

-- function EntityControlFactory.create(msg)
-- 	local eid = msg.eid
-- 	local data = msg.data
-- 	local modelClassName = msg.modelName
-- 	local viewClassName = msg.viewName
-- 	local controlClassName = msg.controlName
	

-- 	local model = require(modelClassName):create(eid,data)
-- 	model:onCreate(param)
-- 	local view = require(viewClassName):create()
-- 	view:onCreate(param)
-- 	local control = require(controlClassName):create(model, view)
-- 	control:onCreate(param)

-- 	local modelParam = {}
-- 	model:onEnter(modelParam)
-- 	local viewParam = {}
-- 	view:onEnter(viewParam)
-- 	local controlParam = {}
-- 	control:onEnter(viewParam)
-- 	return control
-- end

-- function EntityControlFactory.destroy(entityControl, triggerType)
-- 	local param = {}

-- 	local model = entityControl:getModel()
-- 	if triggerType == BASE_TRIGGER.EXIT_BEFORE then
-- 		model:onDestroy(param)
-- 	else
-- 		model:onExit(param)
-- 	end
-- 	model:destroy()

-- 	local view = entityControl:getView()
-- 	if triggerType == BASE_TRIGGER.EXIT_BEFORE then
-- 		view:onDestroy(param)
-- 	else
-- 		view:onExit(param)
-- 	end
-- 	view:destroy()

-- 	local control = entityControl
-- 	if triggerType == BASE_TRIGGER.EXIT_BEFORE then
-- 		control:onExit(param)
-- 	else
-- 		control:onDestroy(param)
-- 	end
-- 	control:destroy()
-- end

-- --[FRAMEWORK]---EntityControlManager---
-- local EntityControlManager = class("EntityControlManager")

-- EntityControlManager.instance = nil

-- function EntityControlManager.getInstance()
--     if not EntityControlManager.instance then
--         EntityControlManager.instance = EntityControlManager:create()
--     end
--     return EntityControlManager.instance
-- end

-- function EntityControlManager:ctor() 
-- 	self:entityControlTbl = {} -- eid : entityControl
-- end

-- -- FirstLevel
-- function EntityControlManager:getControl(eid)
-- 	return entityControlTbl[eid]
-- end

-- function EntityControlManager:setControl(eid, control)
-- 	entityControlTbl[eid] = control
-- end

-- function EntityControlManager:getControl(eid)
-- 	return entityControlTbl[eid]
-- end

-- -- SecondLevel API INTERFACE (C -> M, V)
-- function EntityControlManager:setEntityControl(eid, control)
-- 	self:setControl(eid, control)
-- end

-- function EntityControlManager:getEntityControl(eid)
-- 	return self:getControl(eid)
-- end

-- function EntityControlManager:getModel(eid)
-- 	return self:getControl(eid):getModel()
-- end

-- function EntityControlManager:setModel(eid, model)
-- 	self:getControl(eid):setModel(model)
-- end

-- function EntityControlManager:getView(eid)
-- 	return self:getControl(eid):getView()
-- end

-- function EntityControlManager:setView(eid,view)
-- 	self:getControl(eid):setView(view)
-- end

-- -- ThirdLevel API 
-- function EntityControlManager:getData(eid)
-- 	self:getModel(eid):getData()
-- end

-- function EntityControlManager:setData(eid,data)
-- 	self:getModel(eid):setData(data)
-- end

-- function EntityControlManager:getNode(eid)
-- 	self:getModel(eid):getView().getNode()
-- end

-- function EntityControlManager:setNode(eid, node)
-- 	self:getModel(eid):getView().setNode(node)
-- end

-- --FouthLevel Life Cycle Control
-- --**NOTE only highLevel API can couple other modules
-- function EntityControlManager.addEntity(msg)
-- 	local eid = msg.eid
-- 	local ECF = EntityControlFactory.getInstance()
-- 	local entityControl = ECF:create(msg)
	
-- 	self:trigger(BASE_TRIGGER.ENTER_BEFORE, eid)
-- 	self:setEntityControl(eid, entityControl)
-- 	self:trigger(BASE_TRIGGER.ENTER_AFTER, eid)
-- end

-- function EntityControlManager:removeEntity(msg)
-- 	local eid = msg.eid
-- 	local entityControl = self:getControl(eid)
-- 	local ECF = EntityControlFactory.getInstance()
-- 	ECF:destroy(entityControl, BASE_TRIGGER.DESTROY_BEFORE)
	
-- 	self:trigger(BASE_TRIGGER.DESTROY_BEFORE, eid)
-- 	self:setEntityControl(eid, nil)
-- 	self:trigger(BASE_TRIGGER.DESTROY_AFTER, eid)
-- end

-- function EntityControlManager:updateEntity(msg)
-- 	local eid = msg.eid
-- 	local entityControl = self:getControl(msg)
	
-- 	self:trigger(BASE_TRIGGER.UPDATE_BEFOE, eid)
-- 	entityControl:onUpdate(msg)
-- 	self:trigger(BASE_TRIGGER.UPDATE_BEFOE, eid)
-- end

-- function EntityControlManager:leaveEntity(msg)
-- 	local eid = msg.eid
-- 	local entityControl = self:getEntityControl(eid)
-- 	local ECF = EntityControlFactory.getInstance()
-- 	ECF:destroy(entityControl, BASE_TRIGGER.EXIT_BEFORE)

-- 	self:trigger(BASE_TRIGGER.EXIT_BEFORE, eid)
-- 	self:setEntityControl(eid, nil)
-- 	self:trigger(BASE_TRIGGER.EXIT_AFTER, eid)
-- end

-- function EntityControlManager::trigger(name, eid)
-- 	local msg = {}
-- 	msg.eid = eid
-- 	MsgManager.getInstance.dispatch(name, msg)
-- end

-- function EntityControlManager:update( ... )
-- 	for eid, entityControl in pairs(self:entityControlTbl) do
-- 		entityControl.update()
-- 	end
-- end

-- return 
