require "define"
describe('test base define ', function()
	it('global define', function()
		assert.is_not_nil(PROJECT_PATH)
		assert.is_not_nil(CLASS_SUBFIX.MODEL)
		assert.is_not_nil(CLASS_SUBFIX.VIEW)
		assert.is_not_nil(CLASS_SUBFIX.CONTROL)
	end)

	it('msg type' , function()
		for index_one, v_one in pairs(BASE_TRIGGER) do
			for index_two, v_two in pairs(BASE_TRIGGER) do
				if index_one ~= index_two then
					assert.are_not.same(v_one, v_two)
				end
			end
		end
	end)
end)
    