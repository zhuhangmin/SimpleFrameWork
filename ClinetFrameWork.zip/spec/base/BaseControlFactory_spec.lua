require "utils"
local BaseControlFactory = require "BaseControlFactory"


describe('test BaseControlFactory :', function()
	it('build path :', function()
		local instance1 = BaseControlFactory.getInstance()
		local instance2 = BaseControlFactory.getInstance()

		assert.same(instance1, instance2)
	
		local instance = BaseControlFactory.getInstance()

		local className = "base.Base"
		local mid = 123123
		local expectedData = {["3333"] = "asdasdasd"}
		local expectedNode = {}
		local expectedModelName = buildClassPath(className, CLASS_SUBFIX.MODEL)
		local expectedViewName = buildClassPath(className, CLASS_SUBFIX.VIEW)
		local expectedControlName = buildClassPath(className, CLASS_SUBFIX.CONTROL)
		assert.is_not_same(nil, expectedModelName)

		local msg = {}
		msg.data = expectedData
		msg.node = expectedNode
		msg.modelName = expectedModelName
		msg.viewName = expectedViewName
		msg.controlName = expectedControlName

		local control = instance.create(msg)
		assert.is_not_same(nil, control)

		local model = control:getModel()
		assert.is_not_same(nil, model)

		local view = control:getView()
		assert.is_not_same(nil, view)

		local data = model:getData()
		assert.same(expectedData, data)

		local node = view:getNode()
		assert.same(expectedNode, node)
		

	end)
end)
