local BaseControl = require "BaseControl"
local BaseView = require "BaseView"
local BaseModel = require "BaseModel"
require "utils"
describe('test BaseControl :', function()
	it('build path :', function()
		local expectedData = {}
		local expectedModel = BaseModel:create(expectedData)
		local expectedNode = {}
		local expectedView = BaseView:create(expectedNode)
		local control = BaseControl:create(expectedModel, expectedView)
		assert.is_not_same(nil, control)

		local value = control:getView()
		assert.same(expectedView, value)

		control:setView(expectedView)
		local value = control:getView()
		assert.same(expectedView, value)
		
		local value = control:getModel()
		assert.same(expectedModel, value)

		control:setModel(expectedModel)
		local value = control:getModel()
		assert.same(expectedModel, value)


		local data1 = {}
		local model1 = BaseModel:create(data1)
		local node1 = {}
		local view1 = BaseView:create(node1)
		local control1 = BaseControl:create(model1, view1)

		local data2 = {}
		local model2 = BaseModel:create(data2)
		local node2 = {}
		local view2 = BaseView:create(node2)
		local control2 = BaseControl:create(model2, view2)

		local model1Address = tostring(control1:getModel())
		local model2Address = tostring(control2:getModel())
		local data1Address = tostring(control1:getModel():getData())
		local data2Address = tostring(control2:getModel():getData())
		local view1Address = tostring(control1:getView())
		local view2Address = tostring(control2:getView())
		local node1Address = tostring(control1:getView():getNode())
		local node2Address = tostring(control2:getView():getNode())

		assert.is_not_same(model1Address, model2Address)
		assert.is_not_same(data1Address, data2Address)
		assert.is_not_same(view1Address, view2Address)
		assert.is_not_same(node1Address, node2Address)

		local expectedChild = control2
		local fd = 123
		control1:setChild(fd, expectedChild)
		local child = control1:getChild(fd)
		assert.same(expectedChild, child)
		
		local expectedControl = control2
		control1:attach(expectedControl)
		local expectedControlFD = expectedControl:getModel():getFD()
		local value = control1:getChild(expectedControlFD)
		assert.same(expectedControl, value)

		control1:detachAllChilren()
		
		control1:setChildren({})
	end)

end)
    