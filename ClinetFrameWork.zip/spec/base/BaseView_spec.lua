local BaseView = require "BaseView"

describe('test BaseView :', function()
	it('build path :', function()
		local expectedNode = {}
		local view = BaseView.new(expectedNode)

		local value = view:getNode()
		assert.same(expectedNode, value)

		expectedNode = {["test"] = 11}
		view:setNode(expectedNode)
		value = view:getNode()
		assert.same(expectedNode, value)
	end)

end)
    