require "utils"
local BaseControlManager = require "BaseControlManager"
local BaseMessageManager = require "BaseMessageManager"
local Stack = require "Stack"


describe('test BaseControlManager :', function()
	it('build path :', function()
		-- local instance1 = BaseControlManager.getInstance()
		-- local instance2 = BaseControlManager.getInstance()
		-- local instance1Address =  tostring(instance1)
		-- local instance2Address =  tostring(instance2)

		-- assert.same(instance1Address, instance2Address)

		-- local expectedName = "base.Base"
		-- local expectedData = {name = expectedName}
		-- local expectedNode = {}
		-- local mvcInfo = buildMVCInfo(expectedData, expectedNode)

		-- local manager = BaseControlManager.getInstance()

		-- local expectedMessageManager = BaseMessageManager.getInstance()
		-- manager:setMessageManager(expectedMessageManager)
		-- local value = manager:getMessageManager()
		-- assert.same(expectedMessageManager, value)

		-- local expectedModelStack = Stack.create()
		-- manager:setModelStack(expectedModelStack)
		-- value = manager:getModelStack()
		-- assert.same(expectedModelStack, value)

		-- local expectedHomeName = "HomeControl"
		-- manager:setHomeName(expectedHomeName)
		-- value = manager:getHomeName()
		-- assert.same(expectedHomeName, value)

		-- local expectedControlMap = {}
		-- value = manager:getControlMap()
		-- assert.same(expectedControlMap, value)

		-- manager:setControlMap(expectedControlMap)
		-- value = manager:getControlMap()
		-- assert.same(expectedControlMap, value)

		-- local modelClass = require(mvcInfo.modelName)
		-- local model = modelClass:create(expectedData)

		-- local viewClass = require(mvcInfo.viewName)
		-- local view = viewClass:create(expectedNode)

		-- local controlClass = require(mvcInfo.controlName)
		-- local expectedControl = controlClass:create(model, view)

		-- local expectedFD = expectedControl:getModel():getFD()
		-- manager:setControl(expectedFD, expectedControl)
		-- local value = manager:getControl(expectedFD)
		-- assert.same(expectedControl, value)

		-- local expectedModel = expectedControl:getModel()
		-- manager:setModel(expectedFD, expectedModel)
		-- local model = manager:getModel(expectedFD)
		-- assert.is_not_same(nil, model)
		-- assert.same(expectedModel, model)

		-- local expectedView = expectedControl:getView()
		-- manager:setView(expectedFD, expectedView)
		-- local view = manager:getView(expectedFD)
		-- assert.is_not_same(nil, view)
		-- assert.same(expectedView, view)

		-- manager:setNode(expectedFD, expectedNode)
		-- local node = manager:getNode(expectedFD)
		-- assert.is_not_same(nil, node)
		-- assert.same(expectedNode, node)

		-- manager:setData(expectedFD, expectedData)
		-- local data = manager:getData(expectedFD)
		-- assert.is_not_same(nil, data)
		-- assert.same(expectedData, data)

		-- local modelClass = require(mvcInfo.modelName)
		-- local model = modelClass:create(expectedData)

		-- local viewClass = require(mvcInfo.viewName)
		-- local view = viewClass:create(expectedNode)

		-- local controlClass = require(mvcInfo.controlName)
		-- local expectedRootControl = controlClass:create(model, view)

		-- manager:setRootControl(expectedRootControl)
		-- local value = manager:getRootControl()
		-- assert.same(expectedRootControl, value)
		
		-- local modelClass = require(mvcInfo.modelName)
		-- local model = modelClass:create(expectedData)

		-- local viewClass = require(mvcInfo.viewName)
		-- local view = viewClass:create(expectedNode)

		-- local controlClass = require(mvcInfo.controlName)
		-- local expectedRearControl = controlClass:create(model, view)

		-- manager:setRearControl(expectedRearControl)
		-- local value = manager:getRearControl()
		-- assert.same(expectedRearControl, value)

		-- local modelClass = require(mvcInfo.modelName)
		-- local model = modelClass:create(expectedData)

		-- local viewClass = require(mvcInfo.viewName)
		-- local view = viewClass:create(expectedNode)

		-- local controlClass = require(mvcInfo.controlName)
		-- local expectedFrontControl = controlClass:create(model, view)

		-- manager:setFrontControl(expectedFrontControl)
		-- local value = manager:getFrontControl()
		-- assert.same(expectedFrontControl, value)

		-- local expectedRootView = expectedRootControl:getView()
		-- manager:setRootView(expectedRootView)
		-- local value = manager:getRootView()
		-- assert.same(expectedRootView, value)
		
		-- local expectedRearView = expectedRearControl:getView()
		-- manager:setRearView(expectedRearView)
		-- local value = manager:getRearView()
		-- assert.same(expectedRearView, value)

		-- local expectedFrontView = expectedFrontControl:getView()
		-- manager:setFrontView(expectedFrontView)
		-- local value = manager:getFrontView()
		-- assert.same(expectedFrontView, value)


		-- local modelClass = require(mvcInfo.modelName)
		-- local model = modelClass:create(expectedData)

		-- local viewClass = require(mvcInfo.viewName)
		-- local view = viewClass:create(expectedNode)

		-- local controlClass = require(mvcInfo.controlName)
		-- local expectedControl = controlClass:create(model, view)

		-- local expectedFD = expectedControl:getModel():getFD()

		-- manager:rearAttach(expectedControl)
		-- manager:rearDetach(expectedControl)

		-- local modelClass = require(mvcInfo.modelName)
		-- local model = modelClass:create(expectedData)

		-- local viewClass = require(mvcInfo.viewName)
		-- local view = viewClass:create(expectedNode)

		-- local controlClass = require(mvcInfo.controlName)
		-- local expectedControl = controlClass:create(model, view)

		-- local expectedFD = expectedControl:getModel():getFD()

		-- manager:frontAttach(expectedControl)
		-- manager:frontDetach(expectedControl)

		-- manager:pushModel(expectedModel)
		-- manager:popModel()

		-- manager:register({})
		-- manager:unRegister()
		
		-- local control = manager:createWithMVCInfo(mvcInfo, {modelParam = {}, viewParam = {}, controlParam = {}})
		-- assert.is_not_same(nil, control)

		-- local expectedFD = expectedControl:getModel():getFD()

		-- manager:addControl(expectedControl)
		-- local control = manager:getControl(expectedFD)
		-- assert.same(expectedControl, control)

		-- manager:updateControl(expectedFD, {})
		-- manager:leaveControl(expectedFD)

		-- manager:addControl(expectedControl)
		-- manager:removeControl(expectedFD)

		-- local modelClass = require(mvcInfo.modelName)
		-- local model = modelClass:create(expectedData)

		-- local viewClass = require(mvcInfo.viewName)
		-- local view = viewClass:create(expectedNode)

		-- local controlClass = require(mvcInfo.controlName)
		-- local expectedControl = controlClass:create(model, view)

		-- manager:push(expectedControl)
		-- local modelStack = manager:getModelStack()
		-- local expectedLen = 1
		-- local len = modelStack:getLen()
		-- assert.same(expectedLen, len)

		-- manager:push(expectedControl)

		-- manager:pop()
		-- local expectedLen = 1
		-- local len = modelStack:getLen()
		-- assert.same(expectedLen, len)

		-- manager:push(expectedControl)
		-- manager:replace(expectedControl)
		-- local expectedLen = 2
		-- local len = modelStack:getLen()
		-- assert.same(expectedLen, len)

		-- manager:goHome()
		-- local expectedLen = 1
		-- local len = modelStack:getLen()
		-- assert.same(expectedLen, len)
		
		-- local event = {}
		-- event.msg = {}
		-- event.msg.name = "testEventName"
		-- event.msg.data = "testEventData"
		-- manager:recv(event)
		-- manager:update(1)

		-- local fd = expectedControl:getModel():getFD()
		-- manager:addControl(expectedControl)
		-- manager:removeControl(fd)

		-- manager:createWithModel(model, {modelParam = {}, viewParam = {}, controlParam = {}})

	end)

	it('interesting case:', function()
		  local manager = BaseControlManager.getInstance()
  
        local messageManager = BaseMessageManager.getInstance()
        if isNil(messageManager) then printStack() return end
        manager:setMessageManager(messageManager)

        local modelStack = Stack.create()
        if isNil(modelStack) then printStack() return end       
        manager:setModelStack(modelStack)

        local data = {}
        data.name = "base.Base"
        local sceneNode = {}
        local rootMVCInfo = buildMVCInfo(data, sceneNode)
        local rootControl = manager:createWithMVCInfo(rootMVCInfo,{}) 
        if isNil(rootControl) then printStack() return end
        manager:setRootControl(rootControl)
        
        print("") 
        printAddress(manager:getRootControl()) 
        print("-----------------")

        local rearData = {}
        rearData.name = "base.Base"
        local rearLayerNode = {}
        local rearMVCInfo = buildMVCInfo(rearData, rearLayerNode)
        local rearControl = manager:createWithMVCInfo(rearMVCInfo)

        print("")
        printAddress(manager:getRootControl())




	end)

end)
