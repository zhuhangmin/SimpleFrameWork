local EngineControlManager = require "EngineControlManager"
local EngineMessageManager = require "EngineMessageManager"
local Stack = require "Stack"
local BaseControlManager = require "BaseControlManager"

describe('test EngineControlManager :', function()
    it('build path :', function()

        print("test EngineControlManager")
        local manager = EngineControlManager.getInstance()
        
        local data = {}
        data.name = "engine.Engine"
        local sceneNode = {}
        local rootMVCInfo = buildMVCInfo(data, sceneNode)
        local rootControl = manager:createWithMVCInfo(rootMVCInfo,{}) 
        if isNil(rootControl) then printStack() return end
        manager:setRootControl(rootControl)
        
        print("") 
        printAddress(manager:getRootControl()) 
        print("-----------------")

        local rearData = {}
        rearData.name = "engine.Engine"
        local rearLayerNode = {}
        local rearMVCInfo = buildMVCInfo(rearData, rearLayerNode)
        local rearControl = manager:createWithMVCInfo(rearMVCInfo)

        print("")
        printAddress(manager:getRootControl())
    end)
end)

