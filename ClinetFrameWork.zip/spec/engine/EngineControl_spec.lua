local EngineControl = require "EngineControl"
local EngineView = require "EngineView"
local EngineModel = require "EngineModel"
require "utils"
describe('test EngineControl :', function()
	it('build path :', function()
		
		print("EngineControl test")

		local data = {}
		local model = EngineModel.new(data)

		local node = {}
		local view = EngineView.new(node)

		local control = EngineControl.new(model, view)
		
		print(control)
		print(control.model)

		print("-------------")

		local data1 = {}
		local model1 = EngineModel.new(data1)

		local node1 = {}
		local view1 = EngineView.new(node1)

		local control1 = EngineControl.new(model1, view1)
		
		print(control1)
		print(control1.model)

		print("------------")
		print(control)
		print(control.model)


	end)
end)
    