
local BaseMessageManager = require "BaseMessageManager"

describe('test BaseMessageManager :', function()
	it('build path :', function()
		local instance1 = BaseMessageManager.getInstance()
		local instance2 = BaseMessageManager.getInstance()
		assert.same(instance1, instance2)

		local expectedTarget = 667676767
		local expectedName = "name"
		local expectedCallback = function(name, data)
							 		print("BaseMessageManager expectedCallback test cb name = " .. name .. " , data = " .. data["testData"])
							 end
		local expectedData = {["testData"] = 8888}
		local expectedNameAndFunc = {[expectedName] = expectedCallback}
		local expected = {[expectedTarget] = expectedNameAndFunc}
		
		local instance = BaseMessageManager.getInstance()
		instance:registerMsg(expectedTarget, expectedName, expectedCallback)
		instance:dispatch(expectedName, expectedData)
		instance:unRegisterMsg(expectedTarget, expectedName)
		instance:dispatch(expectedName, expectedData)
	end)
end)
