local EngineModel = require "EngineModel"
require "utils"
describe('test EngineModel :', function()
	it('build path :', function()
		print("EngineModel test")
		local data = {}
		local model = EngineModel.new(data)
		print(tostring(model))
		print("-------------")

		local data1 = {}
		local model1 = EngineModel.new(data1)
		print(tostring(model))
	end)
end)
    