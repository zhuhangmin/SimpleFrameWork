local EngineView = require "EngineView"
describe('test EngineView :', function()
	it('build path :', function()
		print("EngineView test")
		local node = {}
		local view = EngineView.new(node)
		print(tostring(view))
		print("-------------")

		local node1 = {}
		local view1 = EngineView.new(node1)
		print(tostring(view))
	end)
end)
    