local ModelInterface = require "ModelInterface"
local apiNames =  {"setData", "getData","getFD"}

describe('test interface ModelInterface: ', function()
    local instance = ModelInterface.new()
      for k, apiName in pairs(apiNames) do
        local method = instance[apiName]

        local str = 'test api exist : ' .. apiName
        it(str, function()
          assert.is_not_nil(method)
          end)

        local strRet = 'test ' .. apiName .. " abstract"
        it(strRet, function()
          assert.has_error(method)
          end)
      end
end)
    