local ViewInterface = require "ViewInterface"
local apiNames =  {"getNode", "setNode", "attach", "detach"}

describe('test interface ViewInterface: ', function()
    local instance = ViewInterface.new()
      for k, apiName in pairs(apiNames) do
        local method = instance[apiName]
        local str = 'test api exist : ' .. apiName
        it(str, function()
          assert.is_not_nil(method)
          end)

        local strRet = 'test ' .. apiName .. " abstract"
        it(strRet, function()
          assert.has_error(method)
          end)
      end
end)
    