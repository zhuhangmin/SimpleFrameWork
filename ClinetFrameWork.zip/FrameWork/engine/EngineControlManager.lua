local GlobalStatus = require "GlobalStatus"
local BaseControlManager = require "BaseControlManager"
local EngineControlManager = class("EngineControlManager", BaseControlManager)
EngineControlManager.instance = nil

function EngineControlManager.getInstance()
    if not EngineControlManager.instance then
        EngineControlManager.instance = EngineControlManager.new()
    end
    return EngineControlManager.instance
end

function EngineControlManager:ctor()
	EngineControlManager.super.ctor(self)
end

function EngineControlManager:createControlWithName(name, param, alias, pop)
	if isNil(name) then return printStack() end
	local data = {}
	data.name = name
    data.alias = alias

    local node = nil
    if pop == true then
        node = cc.LayerColor:create(cc.c4b(0, 0, 0, 100))
        node:setPosition(cc.p(0, gScreenSize.height))
        SwallowTouch:startWithTarget(node)
        data.action = pop
    else
        node = cc.Layer:create()
    end
    
	local mvcInfo = buildMVCInfo(data, node)
	local control = EngineControlManager.super.createWithMVCInfo(self, mvcInfo, param)
	return control
end

function EngineControlManager:createWithModel(model, param)
	if isNil(model) then return printStack() end
	local className = model:getName()
	local viewName = buildClassPath(className, CLASS_SUBFIX.VIEW)
	local controlName = buildClassPath(className, CLASS_SUBFIX.CONTROL)

	local node = cc.Node:create()

	local modelParam = {}
	local viewParam = {}
	local controlParam = {}
	if param then
		if param.modelParam then
			modelParam = param.modelParam
		end

		if param.viewParam then
			viewParam = param.viewParam
		end

		if param.controlParam then
			controlParam = param.controlParam
		end
	end

    local view = self:createView(viewName, node)
    if isNil(view) then printStack() return nil end 
    view:onCreate(viewParam)

    local control = self:createControl(controlName, model, view)
    if isNil(control) then printStack() return nil end 
    control:onCreate(controlParam)

	model:onEnter(modelParam)
	view:onEnter(viewParam)
	control:onEnter(controlParam)

    self:addControl(control)

	return control
end

function EngineControlManager:openMVC(parentControl, name, param, alias, pop)
    if isNil(parentControl) then printStack() return end
    if isNil(name) then printStack() return end

    local control = self:createControlWithName(name, param, alias, pop)
    parentControl:attach(control)
    return control
end

function EngineControlManager:openItemMVC(parentControl, name, param, alias, pop)
    if isNil(parentControl) then printStack() return end
    if isNil(name) then printStack() return end

    local control = self:createControlWithName(name, param, alias, pop)
    parentControl:attachItem(control)
    return control
end

function EngineControlManager:freeMemory()
    if TEXTURE_MEMORY_RELEASE then
        -- printTextureInfo("BEFORE freeMemory")
        gFrameCache:removeUnusedSpriteFrames()
        gTextureCache:removeUnusedTextures()
        -- printTextureInfo("AFTER freeMemory")
    end
end

function EngineControlManager:freeAllMemory()
	cc.SpriteFrameCache:getInstance():removeSpriteFrames();
	CCTextureCache:sharedTextureCache():removeAllTextures();
end

function EngineControlManager:start()
    EngineControlManager.super.start(self)

    --ACCOUNT
    self:register(GameMsg.MSG_LOGOUT_SDK_ACCOUNT)
    self:register(GameMsg.MSG_EXIT_GAME_RET)
    self:register(GameMsg.MSG_TRY_EXIT_GAME)
    
    --SOUND
    self:register(BASE_MSG.PLAY_SOUND)
    self:register(BASE_MSG.PLAY_DEFAULT_BUTTON_SOUND)
    self:register(BASE_MSG.PAUSE_SOUND_MUSIC)
    self:register(BASE_MSG.RESUME_SOUND_MUSIC)

    --NET
    self:register(BASE_MSG.NET)

    --USER BEHAVIOUR
    self:register(ENGINE_MSG.UPLOAD_USER_BEHAVIOUR)

    print("[MVC] 设置控制器：主ROOT, 后REAR, 前FRONT")
    local rootData = {}
    rootData.name = "game.Root"
    local sceneNode = cc.Scene:create()
    local rootMVCInfo = buildMVCInfo(rootData, sceneNode)
    if isNil(rootMVCInfo) then printStack() return end
    local param = {}
    local rootControl = self:createWithMVCInfo(rootMVCInfo,param) 
    if isNil(rootControl) then printStack() return end
    self:setRootControl(rootControl)

    local mvcRearName = "game.Rear"
    local rearControl = self:createControlWithName(mvcRearName)    
    if isNil(rearControl) then printStack() return end
    self:setRearControl(rearControl)

    local mvcFrontName = "game.Front"
    local frontControl = self:createControlWithName(mvcFrontName)    
    if isNil(frontControl) then printStack() return end
    self:setFrontControl(frontControl)

    local mvcGMName = "game.GM"
    local gmControl = self:createControlWithName(mvcGMName)    
    if isNil(gmControl) then printStack() return end
    self:setGMControl(gmControl)

    self:setTipMVCName("game.Tip")
    self:setWaitingMVCName("game.Waiting")
    self:setMsgBoxMVCName("game.PopUp")

    
    print("[MVC] 设置控制器关系")
    rootControl:attach(rearControl)
    rootControl:attach(frontControl)
    rootControl:attach(gmControl)


    print("[MVC] 初始化mvc框架 完毕")

    print("[MVC] 切换场景")
    local scene = self:getRootView():getNode()
    if isNil(scene) then return printStack() end	
    gDirector:replaceScene(scene)
end

function EngineControlManager:recv(event)
    if isNil(event) then printStack() return end
    if isNil(event.name) then printStack() return end

    EngineControlManager.super.recv(self, event)

    local name = event.name
    local data = event.data

    if name == BASE_MSG.PAUSE_SOUND_MUSIC then
        SoundManager:pauseMusic()
        SoundManager:pauseAllEffects()
    end

    if name == BASE_MSG.RESUME_SOUND_MUSIC then
        SoundManager:resumeMusic()
        SoundManager:resumeAllEffects()
    end

    if name == BASE_MSG.PLAY_DEFAULT_BUTTON_SOUND then
        SoundManager:playEffect(DEFAULT_BUTTON_SOUND)
    end

    if name == BASE_MSG.PLAY_SOUND then
        local soundName = data
        SoundManager:playEffect(soundName)
    end

     if name == GameMsg.MSG_LOGOUT_SDK_ACCOUNT then
        LoginManager:exit()
    end

    if name == GameMsg.MSG_EXIT_GAME_RET then
        local contentStr = self:FIELD("tips", "QUIT_GAME", "content")
        local cancelCB = function() end
        local confirmCB = function()
            NetFunc:disconnectNet()
            SDKFunc.state:unregister()
            MCAgent:getInstance():endToLua()
        end

        local data = {}
        data.param = {}
        data.param.modelParam = {}
        data.param.modelParam.priority = POP_PRIORITY.NONPREEMPTIVE
        data.param.modelParam.contentStr = contentStr
        data.param.modelParam.confirmCB = confirmCB
        data.param.modelParam.cancelCB = cancelCB
        self:send(BASE_MSG.OPEN_MSGBOX_MVC, data)

    end

    if name == GameMsg.MSG_TRY_EXIT_GAME then
        if device.platform == "windows" then
            local data = {}
            self:send(GameMsg.MSG_EXIT_GAME_RET, data)
        else
            LoginManager:exit()
        end
    end


    if name == GameMsg.MSG_NET then
        print("RECV NET MSG")
        print(data)
    end

    if name == BASE_MSG.NET_RESP_ERROR then
        local code = data.code
        local errMsg = data.msg
        if notNumber(code) then printStack() return end
        if notString(errMsg) then printStack() return end
        -- local str = "错误 code = "  .. tostring(code) .. " , " .. errMsg
        local tblName = "errno"
        local field = "content"
        local index = "code"
        local indexValue = code
        local tip_str = self:FIELD_INDEX(tblName, field, index, indexValue)
        if isNil(tip_str) then return end
        self:addTip(tip_str)
    end

    if name == ENGINE_MSG.UPLOAD_USER_BEHAVIOUR then
        local sender = data
        local senderParent = sender:getParent()
        if isNil(senderParent) then return end

        local name = getNodeFullPathName(sender)
        local func = "uploadUserBehavior" 
        local params = {
                name = name
        }
        self:submitForm(func, params)

        GlobalStatus.getInstance():setLastestTouch(name)
    end


end

return EngineControlManager
