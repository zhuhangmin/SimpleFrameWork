local EngineGlobalStatus = class("EngineGlobalStatus")

function EngineGlobalStatus.getInstance()
    if not EngineGlobalStatus.instance then
        EngineGlobalStatus.instance = EngineGlobalStatus.new()
    end
    return EngineGlobalStatus.instance
end

function EngineGlobalStatus:ctor()
	self.backEventEnable = true
end

function EngineGlobalStatus:getBackEventEnable()
	return self.backEventEnable
end

function EngineGlobalStatus:setBackEventEnable(backEventEnable)
	self.backEventEnable = backEventEnable
end

return EngineGlobalStatus

