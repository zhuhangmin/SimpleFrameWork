require "function"
require "utils"
local BaseMessageManager = require "BaseMessageManager"
local EngineMessageManager = class("EngineMessageManager", BaseMessageManager)
EngineMessageManager.instance = nil

function EngineMessageManager.getInstance()
    if not EngineMessageManager.instance then
        EngineMessageManager.instance = EngineMessageManager.new()
    end
    return EngineMessageManager.instance
end

function EngineMessageManager:ctor()
	EngineMessageManager.super.ctor(self)
end

-- --@target: 监听者
-- --@name：注册消息
-- --@callBack:回调方法
-- function EngineMessageManager:registerMsg(target, name, callBack)
-- 	if isNil(target) then return end
-- 	if notString(name) then return end
-- 	if notFunction(callBack) then return end
    
--     local listener = cc.EventListenerCustom:create(name, callBack)
--     print("registerMsg=======name : " .. tostring(name))
--     print("className = " .. tostring(target.__cname))
--     print(" ")

-- 	if isCCNodeObj(target) then
-- 		   print("1 ")
-- 		gEventDispatcher:addEventListenerWithSceneGraphPriority(listener, target)
-- 	else
-- 		   print("2 ")
-- 		gEventDispatcher:addEventListenerWithFixedPriority(listener, 1)
-- 	end
-- end

-- ----TODO 2dx issue, no method to remove specific msg
-- function EngineMessageManager:unRegisterMsg(target, name)
-- 	if isNil(target) then return end
-- 	gEventDispatcher:removeEventListenersForTarget(target)
-- end

-- function EngineMessageManager:dispatch(name,data)
-- 	print("dispatch name = " .. tostring(name))
-- 	if notString(name) then return end
-- 	if notTable(data) then return end

-- 	local event = cc.EventCustom:new(name)
-- 	event.msg = {}
-- 	event.msg.name = name
-- 	event.msg.data = data
-- 	gEventDispatcher:dispatchEvent(event)
-- end

-- function EngineMessageManager:unRegisterAllMsg(target)
-- 	if isNil(target) then return end
-- 	gEventDispatcher:removeEventListenersForTarget(target)
-- end

return EngineMessageManager
