local GlobalStatus = require "GlobalStatus"
local SchedulerMixin = require "SchedulerMixin"
local FrameTaskMixin = require "FrameTaskMixin"
local BaseControl = require  "BaseControl"
local EngineControl = class("EngineControl", BaseControl)
EngineControl:include(SchedulerMixin)
EngineControl:include(FrameTaskMixin)

function EngineControl:ctor(model, view, LUA_MSGS, SYSTEM_MSGS)
	if isNil(model) then printStack() return end 	
	if isNil(view) then printStack() return end 	
	EngineControl.super.ctor(self, model, view)
	self:getModel():setLuaMsgs(LUA_MSGS)
	self:getModel():setSystemMsgs(SYSTEM_MSGS) -- 引擎消息
end

function EngineControl:onCreate(param)
	EngineControl.super.onCreate(self, param)
	self:registerSystemMsgs()
	self:runRootNodeAction()
	self:setRootNodeName()
end

function EngineControl:registerSystemMsgs()
	local systemMsgs = self:getModel():getSystemMsgs()
	if isNil(systemMsgs) then return end
	for k , nodeName in pairs(systemMsgs) do
		local node = self:getChildNode(nodeName)
		if node then
			traceInfo(self.__cname .. ", NODE = " .. nodeName)
			node:addTouchEventListener(handler(self, self.touchCB))
			node:setEnabled(true)
			node:setTouchEnabled(true)
		else
			printStack("no node with name = " .. nodeName)
		end
	end
end

function EngineControl:touchCB(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.began then
		--track all touches state
	   	GlobalStatus.getInstance():setTouchState(sender, TOUCH_ABLE)
	   	GlobalStatus.getInstance():printAllTouchesState()
	end

	if touchEventType == ccui.TouchEventType.ended then
		local triggerAble = GlobalStatus.getInstance():getTouchState(sender)
		if triggerAble then
			if triggerAble == TOUCH_ABLE then
			    --only one touch trigger, other mute
				GlobalStatus.getInstance():setAllTouchMute()
				GlobalStatus.getInstance():printAllTouchesState()

				self:send(ENGINE_MSG.UPLOAD_USER_BEHAVIOUR,sender)
				self:send(BASE_MSG.PLAY_DEFAULT_BUTTON_SOUND)
				self:sendTarget(BASE_MSG.NODE_TOUCH, sender, self)
				self:send(BASE_MSG.GET_BUTTON_INFO,sender:getName())
			end
		end
	end
end

function EngineControl:getChildNode(key)
	if isNil(key) then return printStack() end
	local node = self:getNode()
	local childNode = getNodeHelper(node, key)
	return childNode
end

function EngineControl:runRootNodeAction()
	local action = self:getModel():getAction()
	if action == true then
		local move = cc.MoveBy:create(0.15, cc.p(0, -gScreenSize.height))
		local node = self:getNode()
		node:runAction(move)
	end
end

function EngineControl:setRootNodeName()
	local name = self:getModel():getName()
	self:getNode():setName(name)	
end

function EngineControl:destroy()
	EngineControl.super.destroy(self)
	self:cancelScheduler()
	self:cancelFrameTask()
end

return EngineControl