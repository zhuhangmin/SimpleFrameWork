local BaseMessageMixin = require "BaseMessageMixin"
local SchedulerMixin = require "SchedulerMixin"
local BaseFrameWorker = require "BaseFrameWorker"
local EngineFrameWorker = class("EngineFrameWorker", BaseFrameWorker)
EngineFrameWorker:include(BaseMessageMixin)
EngineFrameWorker:include(SchedulerMixin)

--ENGINE : ENGINGE API CB FUNC
function EngineFrameWorker:ctor()
	EngineFrameWorker.super.ctor(self)
	self.armatureTbl = {} -- track to delete
end

function EngineFrameWorker:getArmatureTbl()
	return self.armatureTbl
end

function EngineFrameWorker:setArmatureTbl(armatureTbl)
	self.armatureTbl = armatureTbl
end

function EngineFrameWorker:startTask()
	self:startScheduler(1)

	--send msg
	local taskNum = self:getTaskNum()
	if isNil(taskNum) then printStack() return end
	local data = {}
	local id = self:getID()
	data.id = id
	data.taskNum = taskNum
	data.taskIndex = 0
	self:send(ENGINE_MSG.LOAD_BEG, data)
end

function EngineFrameWorker:onUpdate()
	local frameTask = self:getFrameTask()
	if isNil(frameTask) then printStack() return end

	local taskIndex = self:getTaskIndex()
	if isNil(taskIndex) then printStack() return end

	local taskNum = self:getTaskNum()
	if isNil(taskNum) then printStack() return end

	if taskNum >= taskIndex then
		local task = frameTask[taskIndex]
		if isNil(task) then printStack() return end
		dump(task)

		local params = task.params
		if isNil(params) then printStack() return end

		local callback = task.callback
		if isNil(callback) then printStack() return end

		callback(unpack(params))
		
		--send msg
		local data = {}
		local id = self:getID()
		data.id = id
		data.taskNum = taskNum
		data.taskIndex = taskIndex
		self:setTaskIndex(taskIndex + 1)

		self:send(ENGINE_MSG.LOAD_PROGRESS, data)
		print("taskIndex = " .. taskIndex)
	else
		--send msg
		local data = {}
		local id = self:getID()
		data.id = id
		self:send(ENGINE_MSG.LOAD_END, data)

		self:reset()
	end
end


function EngineFrameWorker:reset()
	EngineFrameWorker.super.reset(self)
	self:cancelScheduler()

	local armatureTbl = self:getArmatureTbl()
	for k, path in pairs(armatureTbl) do
		gArmatureManager:removeArmatureFileInfo(path)
	end
end

--HIGH LEVEL API
function EngineFrameWorker:loadFrames(plistPath)
	local callback = function(plistPath)
		gFrameCache:addSpriteFrames(plistPath)
	end
	
	local task = {}
	task.callback = callback
	task.params = {plistPath}
	self:addFrameTask(task)
end

function EngineFrameWorker:loadArmature(armaturePath)
	local callback = function(armaturePath)
		gArmatureManager:addArmatureFileInfo(armaturePath)
	end
	local task = {}
	task.callback = callback
	task.params = {armaturePath}
	self:addFrameTask(task)

	local armatureTbl = self:getArmatureTbl()
	if isNil(armatureTbl) then printStack() return end

	local num = table.nums(armatureTbl)
	if isNil(num) then printStack() return end
	
	local index = num + 1
	armatureTbl[index] = armaturePath
end


return EngineFrameWorker