ENGINE_MSG = 
{
	--UPLOAD USER BEHAVIOR
	UPLOAD_USER_BEHAVIOUR = "upload_user_behaviour",
	LOAD_BEG 			  = "msg_load_beg",
	LOAD_PROGRESS		  = "msg_load_progress",
	LOAD_END			  = "msg_load_end",


}