local BaseModel = require "BaseModel"
local EngineModel = class("EngineModel", BaseModel)

function EngineModel:ctor(data)
	EngineModel.super.ctor(self, data)
	self.systemMsgs = {} --把所有引擎来的点击消息 抽象成一个框架消息BASE_MSG.NODE_TOUCH
end

function EngineModel:onCreate(param)
	EngineModel.super.onCreate(self, param)
end

function EngineModel:getSystemMsgs()
	return self.systemMsgs
end

function EngineModel:setSystemMsgs(systemMsgs)
	self.systemMsgs = systemMsgs
end

function EngineModel:destroy()
	EngineModel.super.destroy(self)
	-- self:setSystemMsgs(nil)
end

return EngineModel

