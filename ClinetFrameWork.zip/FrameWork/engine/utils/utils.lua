local EngineControlManager = require "EngineControlManager"

function getNodeTreeSize(node)
	if isNil(node) then return nil end

	local defaultAmount = 10000000
	local retMinX = defaultAmount
	local retMinY = defaultAmount
	local retMaxX = 0
	local retMaxY = 0

	local calculateFunc = function(node, depth)
		
		print("name = " .. node:getName())

		local size = node:getContentSize()
		local width = size.width
		local height = size.height

		print("width = " .. width)
		print("height = " .. height)

		local posX = node:getPositionX()
		local posY = node:getPositionY()

		print("posX = " .. posX)
		print("posY = " .. posY)

		local anchorPoint = node:getAnchorPoint()
		local anchorX = anchorPoint.x
		local anchorY = anchorPoint.y

		print("anchorX = " .. anchorX)
		print("anchorY = " .. anchorY)

		local minX = posX - width * anchorX
		local maxX = posX + width * (1 - anchorX)

		local minY = posY - height * anchorY
		local maxY = posY + height * (1 - anchorY)	

		print("minX = " .. minX)
		print("maxX = " .. maxX)

		print("minY = " .. minY)
		print("maxY = " .. maxY)


		local minXMinY = cc.p(minX, minY)
		local maxXMaxY = cc.p(maxX, maxY)

		print("minXMinY =")
		dump(minXMinY)
		print("maxXMaxY =")
		dump(maxXMaxY)

		local minXMinYWorld = node:convertToWorldSpace(minXMinY)
		local maxXMaxYWorld = node:convertToWorldSpace(maxXMaxY)

		print("minXMinYWorld =")
		dump(minXMinYWorld)
		print("maxXMaxYWorld =")
		dump(maxXMaxYWorld)


		local minXWorld = minXMinYWorld.x
		local minYWorld = minXMinYWorld.y
		local maxXWorld = maxXMaxYWorld.x
		local maxYWorld = maxXMaxYWorld.y

		print("minXWorld =" .. minXWorld)
		print("minYWorld =" .. minYWorld)
		print("maxXWorld =" .. maxXWorld)
		print("maxYWorld =" .. maxYWorld)

		if retMinX > minXWorld then
			retMinX = minXWorld
		end

		if retMinY > minYWorld then
			retMinY = minYWorld
		end

		if retMaxX < maxXWorld then
			retMaxX = maxXWorld
		end

		if retMaxY < maxYWorld then
			retMaxY = maxYWorld
		end

		print("retMinX  = " .. retMinX)
		print("retMinY  = " .. retMinY)
		print("retMaxX  = " .. retMaxX)
		print("retMaxY  = " .. retMaxY)

	end

	nodeTravelAbstract(node, calculateFunc, "getChildren")

	if retMinY == defaultAmount or retMaxX == defaultAmount then
		printStack("getNodeTreeSize error")
	end

	local retSize = cc.size(retMaxX - retMinX, retMaxY - retMinY)

	dump(retSize)
	return retSize
end

function getNodeHelper(node, value)
	if isNil(node) then return nil end
	if isNil(value) then return nil end

	local funcName = nil
	if type(value) == "string" then
		funcName = "getName"
	elseif type(value) == "number" then
		funcName = "getTag"
	else
		printStack("unknow type value = " .. type(value))
	end

	return findNodeByValueAbstract(node, funcName, value, "getChildren")
end

function getTotalNode(node)
	return getTotalNodeAbstract(node, "getChildren")
end

function PrintNodeTree(node, level)
    print("TOTOAL NODE : " .. getTotalNode(node))
	local printFunc = function(node, depth)
		local str = ""
		for i = 1, depth do
			str = str .. "\t"
		end
		local name = node:getName()
		local nodetype = node:getDescription()
		print(str .. name .. " : " .. nodetype)
	end

	nodeTravelAbstract(node, printFunc, "getChildren")
end


function statSnapShot(key)
	if isNil(key) then printStack() return end

	local manager = EngineControlManager.getInstance()
	if isNil(manager) then printStack() return end

	manager:snapShot(key)
end 

function printTextureInfo(key)
	local info = gTextureCache:getCachedTextureInfo()
	print("[" .. tostring(key) .. "]" .. info)
end

function getNodeFullPathName(node, name)
	local retName = name or ""
	local nodeName = node:getName()
	retName = nodeName .. "/" .. retName
	local parent = node:getParent()
	if parent then	
		retName = getNodeFullPathName(parent, retName)
	end
	return retName
end

function toggleNodesVisible(node1,node2,state)
	if isNil(node1) then printStack() return end
	if isNil(node2) then printStack() return end
	if isNil(state) then printStack() return end

	if state then
		node1:setVisible(true)
		node2:setVisible(false)
	else
		node1:setVisible(false)
		node2:setVisible(true)
	end
end

function toggleNodesVisibleByName(rootNode,name1,name2,state)
	local node1 = getNodeHelper(rootNode,name1)
	if isNil(node1) then printStack() return end

	local node2 = getNodeHelper(rootNode,name2)
	if isNil(node2) then printStack() return end

	if isNil(state) then printStack() return end
	
	toggleNodesVisible(node1,node2,state)
end

function setNodeVisible(node,visible)
	if isNil(node) then printStack() return end
	if isNil(visible) then printStack() return end

	if visible then
		node:setVisible(true)
	else
		node:setVisible(false)
	end
end

function setNodeVisibleByName(rootNode,name,visible)
	local node = getNodeHelper(rootNode,name)
	if isNil(name) then printStack() return end

	if isNil(visible) then printStack() return end

	setNodeVisible(node,visible)
end

function setButtonEnable(button,enable)
	if isNil(button) then printStack() return end
	if isNil(enable) then printStack() return end

	if enable then
        button:setBright(true)
        button:setEnabled(true)
	else
        button:setBright(false)
        button:setEnabled(false)
	end
end

--DRAW FUNCTION

function DRAWLINE(parentNode, x0, y0, x1, y1, tag)
	if isNil(parentNode) then printStack() return end
	if notNumber(x0) then printStack() return end
	if notNumber(y0) then printStack() return end
	if notNumber(x1) then printStack() return end
	if notNumber(y1) then printStack() return end
	local drawNode = cc.DrawNode:create()
	drawNode:drawLine(cc.p(x0, y0), cc.p(x1, y1), cc.c4f(0,1,0,1))
	parentNode:addChild(drawNode)
	if tag then
		drawNode:setTag(tag)
	end
end

function DRAWCROSS(parentNode, x0, y0, x1, y1, x2, y2, x3, y3, tag1, tag2)
	if isNil(parentNode) then printStack() return end
	if notNumber(x0) then printStack() return end
	if notNumber(y0) then printStack() return end
	if notNumber(x1) then printStack() return end
	if notNumber(y1) then printStack() return end
	DRAWLINE(parentNode, x0, y0, x1, y1, tag1)
	DRAWLINE(parentNode, x2, y2, x3, y3, tag2)
end

function DRAWTAG(parentNode, centerX, centerY, tag1, tag2)
	if isNil(parentNode) then printStack() return end
	if notNumber(centerX) then printStack() return end
	if notNumber(centerY) then printStack() return end
	local delta = 5
	x0 = centerX - delta
	y0 = centerY - delta
	x1 = centerX + delta
	y1 = centerY + delta
	x2 = centerX + delta
	y2 = centerY - delta
	x3 = centerX - delta
	y3 = centerY + delta
	DRAWCROSS(parentNode, x0, y0, x1, y1, x2, y2, x3, y3, tag1, tag2)
end

function DRAWCIRCLE(parentNode, centerX, centerY, radius, color, tag)
	if isNil(parentNode) then printStack() return end
	if notNumber(centerX) then printStack() return end
	if notNumber(centerY) then printStack() return end
	if notNumber(radius) then printStack() return end
	local drawNode = cc.DrawNode:create()
	drawNode:drawCircle(cc.p(centerX, centerY), radius, math.pi/2, 50, false, 1.0, 1.0, color)
	parentNode:addChild(drawNode)
	if tag then
		drawNode:setTag(tag)
	end
end

function DRAWCIRCLETAG(parentNode, centerX, centerY, tag)
	if isNil(parentNode) then printStack() return end
	if notNumber(centerX) then printStack() return end
	if notNumber(centerY) then printStack() return end
	local radius = 10
	local color = cc.c4f(1.0, 0.0, 0.0, 0.5)
	DRAWCIRCLE(parentNode, centerX, centerY, radius, color, tag)
end


--c++ lua binding
function getObjectType(node)
	return tolua.type(node)
end

	 -- tolua = {
	 --     "cast"             = function: 0x0fe026e0
	 --     "getcfunction"     = function: 0x0fd17d10
	 --     "getpeer"          = function: 0x0fd17cc8
	 --     "inherit"          = function: 0x0fd17b38
	 --     "iskindof"         = function: 0x0fd17be0
	 --     "isnull"           = function: 0x0fd17ba0
	 --     "releaseownership" = function: 0x0fd11cd0
	 --     "setpeer"          = function: 0x0fd17c88
	 --     "takeownership"    = function: 0x0fd11c88
	 --     "type"             = function: 0x0fd11bc8
	 -- }


--USAGE EX:
-- local duration = 1
-- local flipImageFrame = "tiehua/tb_2000000.png"
-- flipNodeAction(node, duration, flipImageFrame)
function flipNodeAction(node, duration, flipImageFrame)
    if isNil(node) then printStack() return end
    if isNil(duration) then printStack() return end
    if isNil(flipImageFrame) then printStack() return end

    local totalZAngle = 180
    local firstPartPercent = 50 / totalZAngle
    local secondPartPercent = 1 - firstPartPercent

    local deltaAngleZOne = totalZAngle * firstPartPercent
    local timeOne = duration * firstPartPercent
    local orbitOne = cc.OrbitCamera:create(timeOne, 1, 0, 0, deltaAngleZOne, 0, 0)

    local switchFrame = cc.CallFunc:create(function ()
            node:setSpriteFrame(flipImageFrame)
    end)

    local angleZ = deltaAngleZOne
    local deltaAngleZTwo = totalZAngle * secondPartPercent
    local timeTwo = duration * secondPartPercent
    local orbitTwo = cc.OrbitCamera:create(timeTwo, 1, 0, angleZ, deltaAngleZTwo, 0, 0)

    local action = cc.Sequence:create(orbitOne, switchFrame, orbitTwo)
    node:runAction(action)
end


--防止可以点击裁剪区域外
function changeNodeToWidget(node)
    local widget = ccui.Widget:create()
    for _,child in pairs(node:getChildren()) do
        child:retain()
        child:removeFromParent()
        widget:addChild(child)
        child:release()
    end
    node:removeSelf()

    return widget
end

-- 添加动画
function addCommonAnime( node, name )
    local anime = cc.CSLoader:createNode("res/gamecocosstudio/csb/"..name..".csb")
    local size = node:getContentSize()
    anime:setPosition(cc.p(size.width/2,size.height/2))
    node:addChild(anime,9,99)
    local action = cc.CSLoader:createTimeline("res/gamecocosstudio/csb/"..name..".csb")
    anime:runAction(action)

    return action,anime
end