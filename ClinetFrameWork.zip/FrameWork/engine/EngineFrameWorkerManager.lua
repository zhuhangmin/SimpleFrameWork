local EngineFrameWorker = require "EngineFrameWorker"
local EngineFrameWorkerManager = class("EngineFrameWorkerManager")

function EngineFrameWorkerManager.getInstance()
    if not EngineFrameWorkerManager.instance then
        EngineFrameWorkerManager.instance = EngineFrameWorkerManager.new()
    end
    return EngineFrameWorkerManager.instance
end

function EngineFrameWorkerManager:ctor()
	self.workers = {}
end

function EngineFrameWorkerManager:getWorkers()
	return self.workers
end

function EngineFrameWorkerManager:setWorkers(workers)
	self.workers = workers
end

function EngineFrameWorkerManager:createWorker()
	local worker = EngineFrameWorker.new()
	return worker
end

function EngineFrameWorkerManager:setWorker(workerID, worker)
	local workers = self:getWorkers()
	workers[workerID] = worker
end

function EngineFrameWorkerManager:resetWorker(workerID)
	local worker = self:getWorker(workerID)
	worker:reset()
end

function EngineFrameWorkerManager:getWorker(workerID)
	local workers = self:getWorkers()
	return workers[workerID]
end

function EngineFrameWorkerManager:addFrameTask(workerID, task)
	local worker = self:getWorker(workerID)
	worker:addFrameTask(task)
end

function EngineFrameWorkerManager:startTask(workerID)
	local worker = self:getWorker(workerID)
	worker:startTask()
end

function EngineFrameWorkerManager:loadBatchFrame(workerID, plistTbl)
	local worker = self:getWorker(workerID)
	for k, plistPath in pairs(plistTbl) do
		worker:loadFrames(plistPath)
	end
end

function EngineFrameWorkerManager:loadBatchArmature(workerID, armatureTbl)
	local worker = self:getWorker(workerID)
	for k, armaturePath in pairs(armatureTbl) do
		worker:loadArmature(armaturePath)
	end
end

return EngineFrameWorkerManager