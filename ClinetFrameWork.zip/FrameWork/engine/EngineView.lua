local BaseView = require "BaseView"
local EngineView = class("EngineView", BaseView)

function EngineView:ctor(node)
	EngineView.super.ctor(self, node)
end

function EngineView:attach(view)
	-- print(self.__cname .. " attach VIEW : " .. view.__cname)
	if isNil(view) then return printStack() end
	EngineView.super.attach(self, view)
	local childNode = view:getNode()
	local parent = childNode:getParent()
	if isNil(parent) then
		self:getNode():addChild(childNode)
	else
		print("node already got parent")
	end
end

function EngineView:detach(view)
	-- print(self.__cname .. " DETACH VIEW : " .. view.__cname)
	if isNil(view) then return printStack() end
	EngineView.super.detach(self, view)
	local node = self:getNode()
	local childNode = view:getNode()
	node:removeChild(childNode)
end

function EngineView:onCreate(param)
end

function EngineView:onEnter(param)
	
end

function EngineView:onExit(param)
	
end

function EngineView:onDestroy(param)
	
end

function EngineView:onUpdate(param)
	
end

function EngineView:destroy()
	EngineView.super.destroy(self)
end

return EngineView





