--NOTE : USE CANCEL TASK
local EngineFrameWorkerManager = require "EngineFrameWorkerManager"
local engineFrameWorkerManager = EngineFrameWorkerManager.getInstance()
FrameTaskMixin = {
	initWorker = function(self)
		local workerID = self:getWorkerID()
		if isNil(workerID) then 
			local worker = engineFrameWorkerManager:createWorker()
			if isNil(worker) then printStack() return end
			dump(worker)
			local workerID = worker:getID()
			if isNil(workerID) then printStack() return end

			engineFrameWorkerManager:setWorker(workerID, worker)
			self:setWorkerID(workerID)
		end
	end,

	getWorkerID = function(self)
		return self.workerID
	end,

	setWorkerID = function(self,workerID)
		self.workerID = workerID
	end,

	startTask = function(self)
		local workerID = self:getWorkerID()
		if isNil(workerID) then printStack() return end
	    engineFrameWorkerManager:startTask(workerID)
	end,

	cancelFrameTask = function(self)
    	local workerID = self:getWorkerID()
    	if workerID then
    		engineFrameWorkerManager:resetWorker(workerID)
    		self:setWorkerID(nil)
    	end
	end,

    -- task : {callback = callback, params = { ... }}
	addFrameTask = function(self, task)
		self:initWorker()
		local workerID = self:getWorkerID()
		if isNil(workerID) then printStack() return end

		engineFrameWorkerManager:addFrameTask(workerID, task)
	end,
	
	loadBatchFrame = function(self, plistTbl)
		self:initWorker()
		local workerID = self:getWorkerID()
		if isNil(workerID) then printStack() return end
		engineFrameWorkerManager:loadBatchFrame(workerID, plistTbl)
	end,

	loadBatchArmature = function(self, armatureTbl)
		self:initWorker()
		local workerID = self:getWorkerID()
		if isNil(workerID) then printStack() return end
		engineFrameWorkerManager:loadBatchArmature(workerID, armatureTbl)
	end,
	
	
	
}

return FrameTaskMixin