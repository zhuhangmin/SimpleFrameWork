--NOTE : UNREGISTER ENGINE

KeyBoardMixin = {
	
	getListener = function(self)
		return self.listener
	end,

	setListener = function(self,listener)
		self.listener = listener
	end,

	registerKeyBoard = function(self, node, onKeyReleased)
		if isNil(node) then printStack() return end
		self:unregisterKeyBoard()
		local onKeyReleased = onKeyReleased or self.onKeyReleased
		local listener = cc.EventListenerKeyboard:create()
		listener:registerScriptHandler(handler(self, onKeyReleased), cc.Handler.EVENT_KEYBOARD_RELEASED)
		gEventDispatcher:addEventListenerWithSceneGraphPriority(listener, node)
		self:setListener(listener)
	end,
	
    unregisterKeyBoard = function(self)
		local listener = self:getListener()
		if listener then
			gEventDispatcher:removeEventListener(listener)
			self:setListener(nil)
		end
	end,
	
}

return KeyBoardMixin