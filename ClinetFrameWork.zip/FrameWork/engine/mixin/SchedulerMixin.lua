--NOTE : USE CANCEL SCHEDULER TO UNREGISTER ENGINE

SchedulerMixin = {
	
	getSchedulerID = function(self)
		return self.schedulerID
	end,

	setSchedulerID = function(self,schedulerID)
		self.schedulerID = schedulerID
	end,

	startScheduler = function(self, scheduleInteval, updateFunc) -- unit (秒)
		self:cancelScheduler()
	 	local scheduleInteval = scheduleInteval or 0
	 	local updateFunc = updateFunc or self.onUpdate
	 	local schedulerID = gScheduler:scheduleScriptFunc(handler(self, updateFunc), scheduleInteval, false)
		self:setSchedulerID(schedulerID)
	end,
	
    cancelScheduler = function(self)
		local schedulerID = self:getSchedulerID()
		if schedulerID then
			gScheduler:unscheduleScriptEntry(schedulerID)
			self:setSchedulerID(nil)
		end
	end,
	
}

return SchedulerMixin