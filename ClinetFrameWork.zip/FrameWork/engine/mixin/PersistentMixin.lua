--NOTE : USE CANCEL SCHEDULER TO UNREGISTER ENGINE

PersistentMixin = {
	
	getDataPersistent = function(self)
		if notString(key) then printStack() return end
		local userDefault = cc.UserDefault:getInstance()
		local value =  userDefault:getStringForKey(key)
		return value
	end,

	setDataPersistent = function(self, key, value)
		if notString(key) then printStack() return end
		if notString(value) then printStack() return end
		local userDefault = cc.UserDefault:getInstance()
		userDefault:setStringForKey(key,value)
	end,
}

return PersistentMixin