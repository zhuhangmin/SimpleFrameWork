local schedulerMixin = require "SchedulerMixin"
local BaseShaderManager = require "BaseShaderManager"
EngineShaderManager = class("EngineShaderManager", BaseShaderManager)
EngineShaderManager:include(schedulerMixin)
EngineShaderManager.instance = nil

local DEFAULT_GLPROGRAM = "ShaderPositionTextureColor_noMVP"
function EngineShaderManager.getInstance()
    if not EngineShaderManager.instance then
        EngineShaderManager.instance = EngineShaderManager.new()
    end
    return EngineShaderManager.instance
end

function EngineShaderManager:ctor()
	EngineShaderManager.super.ctor(self)
end

function EngineShaderManager:revertShader(node)
	if isNil(node) then printStack() return end

	local glProgram = cc.GLProgramCache:getInstance():getGLProgram(DEFAULT_GLPROGRAM)
	if isNil(glProgram) then printStack() return end

	local state =  cc.GLProgramState:getOrCreateWithGLProgram(glProgram)
	if isNil(state) then printStack() return end

	if node.setGLProgramState then
   		node:setGLProgramState(state)
	end
end

function EngineShaderManager:complieShader(shaderName)
	if isNil(shaderName) then printStack() return end
	local shaderPath = self:getShaderResource(shaderName)
	if isNil(shaderPath) then printStack() return end
	local glProgram = nil
	if shaderName ~= "DEFAULT" then
		local vsh = shaderPath[1]
		local fsh = shaderPath[2]
		glProgram = cc.GLProgram:createWithFilenames(vsh, fsh)
		if isNil(glProgram) then printStack() return nil end

	else
		glProgram = cc.GLProgramCache:getInstance():getGLProgram(DEFAULT_GLPROGRAM)
		if isNil(glProgram) then printStack() return nil end

	end
	return glProgram
end

function EngineShaderManager:shaderNode(node, shaderName)
	EngineShaderManager.super.shaderNode(self, node, shaderName)
	
	local shader = self:getShader(shaderName)
	if isNil(shader) then
		shader = self:complieShader(shaderName)
		if isNil(shader) then printStack() return end
	end
	
	self:addCache(shaderName, shader)

	if string.find(getObjectType(node), "ccui") then
		self:shaderWidget(node,shader)

	elseif string.find(getObjectType(node), "ccs.Armature") then
		self:shaderArmature(node,shader)

	else
		self:shaderSprite(node,shader)
	end
end

function EngineShaderManager:shaderSprite(sprite, shader)
	if isNil(shader) then printStack() return end
	if isNil(sprite) then printStack() return end
	if isNil(sprite.setGLProgram) then printStack() return end
	sprite:setGLProgram(shader)
end

function EngineShaderManager:shaderArmature(armature, shader)
	local boneDic = armature:getBoneDic()
	for k, bone in pairs(boneDic) do
		local sprite = bone:getDisplayRenderNode()
		if sprite then
			self:shaderSprite(sprite, shader)
		end
	end
end

function EngineShaderManager:shaderWidget(widget, shader)
	local render = widget:getVirtualRenderer()
	if widget.isScale9Enabled then
		if widget:isScale9Enabled() then
			widget:setScale9Enabled(false)
		end
	end
	
	if render.getSprite then
		local sprite = render:getSprite()
		if sprite then
			self:shaderSprite(sprite, shader)
		end
	end
end

function EngineShaderManager:setShaderTimer(node,shaderName)
	self:setCurNode(node)
	self:setCurShaderName(shaderName)
	self:startScheduler(nil,self.onUpdate)
end

function EngineShaderManager:onUpdate(dt)
	local node = self:getCurNode()
	if isNil(node) then printStack() return end

	local shaderName = self:getCurShaderName()
	if isNil(shaderName) then printStack() return end
	
	self:setShaderRecursive(node, shaderName)
	if shaderName == "DEFAULT" then
		self:cancelScheduler()
	end
end

return EngineShaderManager