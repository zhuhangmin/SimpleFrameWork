local BaseObject = require "BaseObject"
local BaseView = class("BaseView", BaseObject)

function BaseView:ctor(node)
	BaseView.super.ctor(self)
	self.node = node
end

function BaseView:getNode()
	return self.node
end

function BaseView:setNode(node)
	if isNil(node) then printStack() return end 	
	self.node = node
end

function BaseView:attach(view)
	BaseView.super.attach(self, view)
end

function BaseView:detach(view)
	BaseView.super.detach(self, view)
end

function BaseView:onCreate(param)
	
end

function BaseView:onEnter(param)
	
end

function BaseView:onExit(param)
	
end

function BaseView:onDestroy(param)
	
end

function BaseView:onUpdate(param)
	
end

function BaseView:replaceRootRenderNode(newRenderNode)
	self:setNode(newRenderNode)
end

function BaseView:destroy()
	BaseView.super.destroy(self)
	-- self:setNode(nil) --TODO
end


return BaseView





