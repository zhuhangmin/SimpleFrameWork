local BaseMessageMixin = require "BaseMessageMixin"
local BaseObject = require "BaseObject"

local BaseConfigManager = class("BaseConfigManager", BaseObject)
BaseConfigManager:include(BaseMessageMixin)
BaseConfigManager.instance = nil

function BaseConfigManager.getInstance()
    if not BaseConfigManager.instance then
        BaseConfigManager.instance = BaseConfigManager.new()
    end
    return BaseConfigManager.instance
end

function BaseConfigManager:ctor()
	BaseConfigManager.super.ctor(self)
	self.configTbl = nil
	self.referenceTbl = nil
	self:register(BASE_MSG.NOTIFY_CONFIG)
end

function BaseConfigManager:getReferenceTbl()
    return self.referenceTbl
end

function BaseConfigManager:setReferenceTbl(referenceTbl)
    self.referenceTbl = referenceTbl
end

function BaseConfigManager:getConfigTbl()
	return self.configTbl
end

function BaseConfigManager:setConfigTbl(configTbl)
	self.configTbl = configTbl
end

function BaseConfigManager:getTable(tableName)
	if notString(tableName) then printStack(tableName) return end
	local table = self:getConfigTbl()[tableName]
	return table
end

function BaseConfigManager:getConfigRecord(tableName, key)
	if notString(tableName) then printStack(tableName) return end
	if not isTypeNumberAndString(key) then printStack(key) return end
	
	local record = nil
	local configTbl = self:getConfigTbl()
	if configTbl then
		tbl = configTbl[tableName]
		if isNil(tbl) then printStack(tbl) return end
		record = tbl[key]
	end

	return record
end

function BaseConfigManager:getConfigField(tableName, key, field)
	if notString(tableName) then printStack(tableName) return end
	if not isTypeNumberAndString(key) then printStack(key) return end
	if not isTypeNumberAndString(field) then printStack(field) return end

	local value = nil

	local record = self:getConfigRecord(tableName, key)
	if record then
		value = record[field]
	end

	return value
end

function BaseConfigManager:getRecordByIndexValue(tblName, index, indexValue)
	local retRecord = nil
	if notString(tblName) then return end
	if isNil(index) then return end
	if isNil(indexValue) then return end

	local tbl = self:getTable(tblName)
	for key, record in pairs(tbl) do
		if record[index] == indexValue then
			retRecord = record
			return retRecord
		end
	end
	return retRecord
end

function BaseConfigManager:getConfigFieldByIndex(tblName, field, index, indexValue)
	if notString(tblName) then printStack() return end
	if isNil(index) then printStack() return end
	if isNil(indexValue) then printStack() return end

	local record = self:getRecordByIndexValue(tblName, index, indexValue)
	local value = nil
	if record then
		value = record[field]
		if isNil(value) then return end
	end
	return value
end

--ONLY RETURN FIRST MATCH
-- condition = {
-- 	srcTbl,
-- 	srcKey,
-- 	srcField,
-- 	dstTbl,
-- 	dstKey,
-- 	dstField,	
-- }
function BaseConfigManager:findConfigRecord(condition, depth)
	if isNil(condition) then printStack() return end
	if isNil(depth) then depth = 1 end

	local srcTbl = condition.srcTbl
	if notString(srcTbl) then printStack() return end
	local srcKey = condition.srcKey
	if isNil(srcKey) then printStack() return end
	local srcField = condition.srcField
	local dstTbl = condition.dstTbl
	local dstKey = condition.dstKey
	local dstField = condition.dstField

	local str = ""
	for i = 1, depth do
		str = str .. "\t"
	end
	print("--------------")
	print(str .. "srcTbl = " .. tostring(srcTbl))
	print(str .. "srcKey = " .. tostring(srcKey))
	print(str .. "srcField = " .. tostring(srcField))
	print(str .. "dstTbl = " .. tostring(dstTbl))
	print(str .. "dstKey = " .. tostring(dstKey))
	print(str .. "dstField = " .. tostring(dstField))

	local dstRecord = nil

	if isNil(dstTbl) then
		return self:getConfigRecord(srcTbl,srcKey)
	end

	if srcTbl and dstTbl then
		if srcTbl == dstTbl then
			print("HIT")
			return self:getConfigRecord(dstTbl,srcKey)
		end
	end

	local referTbls = self:getReferenceTbl()
	if isNil(referTbls) then printStack() return end

	local referTbl = referTbls[srcTbl]
	if referTbl then
		depth = depth + 1
		for indexField, referObj in pairs(referTbl) do
			if srcField then 
				indexField = srcField
			end

			local refSrcKey = self:getConfigField(srcTbl, srcKey, indexField)
			local refSrcTbl = referObj["dstTbl"]
			if refSrcTbl and refSrcKey and dstTbl then
				print(str .. "ref refSrcTbl = " .. refSrcTbl)
				print(str .. "ref refSrcKey = " .. refSrcKey)
				print(str .. "ref dstTbl = " .. dstTbl)
				local result = self:findDstRecord(refSrcTbl, refSrcKey, dstTbl, depth)
				if result then
					dstRecord = result
					break
				end
			end
		end
	end

	return dstRecord
	
end

-- EX:
-- dump(configmanager:findDstRecord("shopItem", 1, "shopItem"))
-- dump(configmanager:findDstRecord("item", 40001))
-- dump(configmanager:findDstRecord("shopItem", 1, "item"))
-- dump(configmanager:findDstRecord("shopItem", 1, "sellType"))
-- dump(configmanager:findDstRecordWithField("shop", 1, "shop_item_2","item"))
function BaseConfigManager:findDstRecord(srcTbl, srcKey, dstTbl)
	if notString(srcTbl) then printStack() return end
	if isNil(srcKey) then printStack(srcTbl) return end
	if notString(dstTbl) then printStack() return end

	local condition = {
		srcTbl = srcTbl,
		srcKey = srcKey,
		dstTbl = dstTbl,
	}

	return self:findConfigRecord(condition)
end

function BaseConfigManager:findDstRecordWithField(srcTbl, srcKey, srcField, dstTbl)
	if notString(srcTbl) then printStack() return end
	if isNil(srcKey) then printStack(srcTbl) return end
	if notString(dstTbl) then printStack() return end

	local condition = {
		srcTbl = srcTbl,
		srcKey = srcKey,
		srcField = srcField,
		dstTbl = dstTbl,
	}

	return self:findConfigRecord(condition)
end

function BaseConfigManager:recv(event)
    if isNil(event) then printStack() return end
    if isNil(event.name) then printStack() return end
    if isNil(event.data) then printStack() return end

    local name = event.name
    local data = event.data

    if name == BASE_MSG.NOTIFY_CONFIG then
    	-- if isNil(data) then printStack() return end
    	-- if isNil(data.configName) then printStack() return end
    	-- if isNil(data.config) then printStack(data) return end

     --    local configName = data.configName
     --    local config = data.config

     --   	self:getConfigTbl()[configName] = config

     --   	local name = BASE_MSG.UPDATE_CONFIG
     --   	local data = {}
     --   	data.configName = configName
     --   	self:dispatch(name, data)
    end
end


return BaseConfigManager


--test
    -- local ConfigManager = require "ConfigManager"
    -- local configmanager = ConfigManager.getInstance()
    
    -- print("1 [TEST SINGLE TBL RECORD] = " )
    -- dump(configmanager:findDstRecord("shopItem", 1, "shopItem"))
    -- dump(configmanager:findDstRecord("shop", 1, "shop"))
    -- dump(configmanager:findDstRecord("item", 40001, "item"))
    -- print("2 [TEST TWO TBL RECORD] = " )
    -- dump(configmanager:findDstRecord("shopItem", 1, "item"))
    -- dump(configmanager:findDstRecord("shopItem", 1, "sellType"))
    -- print("3 [TEST THREE TBL RECORD] = " )
    -- dump(configmanager:findDstRecordWith("shop", 1, "shop_item_2","item"))
