local BaseObject = require "BaseObject"
local BaseGuideMgr = class("BaseGuideMgr", BaseObject)
BaseGuideMgr.instance = nil

DEFAULT_INDEX = 1

function BaseGuideMgr.getInstance()
    if not BaseGuideMgr.instance then
        BaseGuideMgr.instance = BaseGuideMgr.new()
    end
    return BaseGuideMgr.instance
end

function BaseGuideMgr:ctor()
    BaseGuideMgr.super.ctor(self)
    self.index = DEFAULT_INDEX --当前引导第几步
    self.queue = {} --当前引导操作组
end

function BaseGuideMgr:getQueue()
    return self.queue
end

function BaseGuideMgr:setQueue(queue)
    self.queue = queue
end

function BaseGuideMgr:addStep(stepInfo)
    local queue = self:getQueue()
    table.insert(queue,stepInfo)
end

function BaseGuideMgr:getStepCount()
    return table.nums(self.queue)
end

function BaseGuideMgr:getIndex()
    return self.index
end

function BaseGuideMgr:setIndex(index)
    self.index = index
end

function BaseGuideMgr:addIndex(count)
    local index = self:getIndex()
    index = index + count
    self:setIndex(index)
end

function BaseGuideMgr:isGuiding()
    local stepCount = self:getStepCount()
    if notNumber(stepCount) then printStack() return end

    local index = self:getIndex()
    if notNumber(index) then printStack() return end

    return index <= stepCount
end

function BaseGuideMgr:startGuide()
    --(override)
end

function BaseGuideMgr:finishGuide()
    --(override)
end

function BaseGuideMgr:resetData()
    self:setIndex(DEFAULT_INDEX)
    self:setQueue({})
end

function BaseGuideMgr:getInfo()
    local queue = self:getQueue()
    if isNil(queue) then printStack() return end

    local index = self:getIndex()
    if notNumber(index) then printStack() return end

    return queue[index]
end

function BaseGuideMgr:processGuide()
    self:addIndex(1)

    if self:isGuiding() then
        self:startGuide()
    else
        self:finishGuide()
    end
end

return BaseGuideMgr