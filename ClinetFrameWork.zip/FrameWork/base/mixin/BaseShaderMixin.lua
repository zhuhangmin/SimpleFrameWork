local ShaderManager = require "ShaderManager"
local shaderManager = ShaderManager.getInstance()

BaseShaderMixin = {
--BASIC LEVEL
	setShader = function(self, node, shaderName)
		shaderManager:setShaderRecursive(node, shaderName)	
	end,

	setShaderTimer = function(self, node, shaderName)
		shaderManager:setShaderTimer(node, shaderName)	
	end,
}

return BaseShaderMixin