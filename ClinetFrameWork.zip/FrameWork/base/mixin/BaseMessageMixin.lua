
local BaseMessageManager = require "BaseMessageManager"
local baseMessageManager = BaseMessageManager.getInstance()

--NOTE : NO STATE TO MAINTAIN, 
--NOTE : NO self.property, pure mathmatical likely obj


BaseMessageMixin = {
--BASIC LEVEL
	send = function(self, name, data)
		local event = {}
		event.data = data
		baseMessageManager:dispatch(name, event)
	end,

	recv = function(self, event)
		-- error("should be override by mixin class")
	end,

	sendTarget = function(self, name, data, target)
		if isNil(name) then return printStack() end
		if isNil(data) then data = {} end
	
		local event = {}
		event.name = name
		event.data = data
		baseMessageManager:sendTarget(name, event, target)
	end,

	dispatch =  function(self, name,event)
		baseMessageManager:dispatch(name,event)
	end,

	register =  function(self, name)
		baseMessageManager:register(self, name, handler(self, self.recv))
	end,

	unRegister =  function(self, name)
		baseMessageManager:unRegister(self, name)
	end,

	unRegisterAll =  function(self)
		baseMessageManager:unRegisterAll(self)
	end,

-- HIGH LEVEL

	submitForm = function(self, func, params)
		local data ={}
		data.func = func
		data.params = params
		self:send(BASE_MSG.NET_FORM, data)
	end,

	submitFormWait = function(self,func, params)
		local data ={}
		data.func = func
		data.params = params
		self:send(BASE_MSG.NET_FORM_WAIT, data)
	end,

	addPanelOnControl = function(self, parentControl, name, param, alias)
		if isNil(name) then printStack() return end
		if isNil(param) then param = {} end
		local data = buildMsgData(name, param.modelParam, param.viewParam, param.controlParam, alias)
		data.parentControl = parentControl
		self:send(BASE_MSG.OPEN_MVC, data)
	end,

	addPop  = function(self, name, param, alias)
		if isNil(name) then printStack() return end
		if isNil(param) then param = {} end
		local data = buildMsgData(name, param.modelParam, param.viewParam, param.controlParam, alias)
		self:send(BASE_MSG.OPEN_FRONT_MVC, data)
	end,

	addTip  = function(self, str, priority)
		if notString(str) then printStack() return end
		local data = {}
		data.param = {}
		data.param.modelParam = {}
		data.param.modelParam.str = str
		data.param.modelParam.priority = priority
		self:send(BASE_MSG.OPEN_TIP_MVC , data)
	end,

	addMsgBox = function(self, contentStr, confirmCB, cancelCB, priority)
		if notString(contentStr) then printStack() return end
		local data = {}
		data.param = {}
		data.param.modelParam = {}
		data.param.modelParam.priority = priority
		data.param.modelParam.contentStr = contentStr
		data.param.modelParam.confirmCB = confirmCB
		data.param.modelParam.cancelCB = cancelCB

		self:send(BASE_MSG.OPEN_MSGBOX_MVC, data)
	end,
}

return BaseMessageMixin