local ConfigManager = require "ConfigManager"
local configManager = ConfigManager.getInstance()

BaseConfigMixin = {
	getTable = function(self, tableName)
		return configManager:getTable(tableName)
	end,

	getConfigRecord = function(self, tableName, key)
		return configManager:getConfigRecord(tableName, key)
	end,

	getConfigField = function(self, tableName, key, field)
		return configManager:getConfigField(tableName, key, field)
	end,

	TABLE = function(self, tableName)
		return configManager:getTable(tableName)
	end,

	RECORD = function(self, tableName, key)
		return configManager:getConfigRecord(tableName, key)
	end,

	FIELD = function(self, tableName, key, field)
		return configManager:getConfigField(tableName, key, field)
	end,

	RECORD_INDEX  = function(self, tblName, index, indexValue)
			return configManager:getRecordByIndexValue(tblName, index, indexValue)
	end,

	FIELD_INDEX = function(self, tblName, field, index, indexValue)
			return configManager:getConfigFieldByIndex(tblName, field, index, indexValue)
	end,

}

return BaseConfigMixin