local BaseObject = require "BaseObject"
local BaseMessageManager = class("BaseMessageManager", BaseObject)
BaseMessageManager.instance = nil

function BaseMessageManager.getInstance()
    if not BaseMessageManager.instance then
        BaseMessageManager.instance = BaseMessageManager.new()
    end
    return BaseMessageManager.instance
end

function BaseMessageManager:ctor()
	BaseMessageManager.super.ctor(self)
	self.targets = {} -- targets, name , callback
end

function BaseMessageManager:getTargets()
	return self.targets
end

function BaseMessageManager:register(target, name, callback)
	if isNil(target) then printStack() return end
	if isNil(name) then printStack() return end
	if isNil(callback) then printStack() return end
	if isNil(self.targets[target]) then
		self.targets[target] = {}
	end
	self.targets[target][name] = callback
end

function BaseMessageManager:unRegister(target, name)
	if isNil(target) then printStack() return end
	if isNil(name) then printStack() return end
	if isNil(self.targets) then printStack() return end
	if isNil(self.targets[target]) then printStack() return end
	if isNil(self.targets[target][name]) then printStack() return end

	print("BaseMessageManager:unRegister : " .. tostring(name))

	self.targets[target][name] = nil
end

function BaseMessageManager:dispatch(name,event)
	if notString(name) then printStack() return end
	if notTable(event) then event = {} end
	if isNil(event.data) then event.data = {} end
	event.name = name

	filterMsgsPrint(event.name, "[DISPATCH BEG]")

	local msgNotRegistered = true

	local targets = self:getTargets()
	local keys = table.keys(targets)

	for index, key in pairs(keys) do
		local target = targets[key]
		if target then
		for msgName, callback in pairs(target) do
			if msgName == name then
				callback(event)
				msgNotRegistered = false
			end
		end
	end
	end

	if msgNotRegistered then print("not hit name = " .. tostring(name)) end

	-- filterMsgsPrint(event.name, "[DISPATCH END]")
end

function BaseMessageManager:sendTarget(name, event, target)
	if isNil(name) then printStack() return end
	if isNil(event) then printStack() return end
	if isNil(event.name) then printStack() return end
	if isNil(event.data) then printStack() return end
	if isNil(target) then printStack() return end

	-- filterMsgsPrint(event.name, "[DISPATCH TARGET BEG]")

	local msgNotRegistered = true

	local targets = self:getTargets()
	local value = targets[target]
	if isNil(value) then printStack() return end

	for msgName , callback in pairs(value) do
		if msgName == name then
			callback(event)
			-- filterMsgsPrint(event.name, "[DISPATCH TARGET END]")
			return
		end
	end

	-- filterMsgsPrint(event.name, "[*** DISPATCH MSG TARGET END ***]")

	if msgNotRegistered then
		printStack("[WARN] not hit name = " .. name)
	end
end

function BaseMessageManager:unRegisterAll(target)
	if isNil(target) then printStack() return end
	self.targets[target] = nil	
end

function BaseMessageManager:description(key)
	print("[" .. tostring(key) .. "]")
	local targets = self:getTargets()
	for target, value in pairs(targets) do
		print("target : " .. tostring(target) .. " , className = " .. target.__cname)
		for msgName, callback in pairs(value) do
			print("\t msgName : " .. tostring(msgName))
		end
	end
	print("*************************")
end

return BaseMessageManager
