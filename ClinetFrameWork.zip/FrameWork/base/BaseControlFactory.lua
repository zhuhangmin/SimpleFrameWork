require "function"
local BaseControlFactory = class("BaseControlFactory")
BaseControlFactory.instance = nil

function BaseControlFactory.getInstance()
    if not BaseControlFactory.instance then
        BaseControlFactory.instance = BaseControlFactory.new()
    end
    return BaseControlFactory.instance
end

function BaseControlFactory.create(msg)
	local data = msg.data
	local node = msg.node
	local modelName = msg.modelName
	local viewName = msg.viewName
	local controlName = msg.controlName
	
	local model = require(modelName):create(data)
	model:onCreate(param)
	local view = require(viewName):create(node)
	view:onCreate(param)
	local control = require(controlName):create(model, view)
	control:onCreate(param)

	local modelParam = {}
	model:onEnter(modelParam)
	local viewParam = {}
	view:onEnter(viewParam)
	local controlParam = {}
	control:onEnter(viewParam)
	return control
end

function BaseControlFactory.create(model)
	local data = model:getData()
	local node = cc.Node:create()
	local modelName = model:getName()
	local viewName = msg.viewName
	local controlName = msg.controlName
	
	local model = require(modelName):create(data)
	model:onCreate(param)
	local view = require(viewName):create(node)
	view:onCreate(param)
	local control = require(controlName):create(model, view)
	control:onCreate(param)

	local modelParam = {}
	model:onEnter(modelParam)
	local viewParam = {}
	view:onEnter(viewParam)
	local controlParam = {}
	control:onEnter(viewParam)
	return control
end

return BaseControlFactory