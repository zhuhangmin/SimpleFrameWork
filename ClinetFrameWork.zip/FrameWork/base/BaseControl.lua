local BaseObject = require "BaseObject"
local BaseMessageMixin = require "BaseMessageMixin"
local BaseShaderMixin = require "BaseShaderMixin"
local BaseConfigMixin = require "BaseConfigMixin"

local BaseControl = class("BaseControl", BaseObject)
BaseControl:include(BaseMessageMixin)
BaseControl:include(BaseShaderMixin)
BaseControl:include(BaseConfigMixin)

function BaseControl:ctor(model, view)
	if isNil(model) then printStack() return end 	
	if isNil(view) then printStack() return end
	BaseControl.super.ctor(self)
	self.model = model
	self.view = view
end

function BaseControl:getModel()
	return self.model
end

function BaseControl:setModel(model)
	self.model = model
end

function BaseControl:getView()
	return self.view
end

function BaseControl:setView(view)
	self.view = view
end

function BaseControl:getNode()
	local view = self:getView()
	if isNil(view) then printStack() return nil end
	
	local node = view:getNode()
	if isNil(node) then printStack() return nil end

 	return node
end

function BaseControl:setNode(node)
	if isNil(node) then printStack() return end 	

	local view = self:getView()
	if isNil(view) then printStack() return nil end
	
	view:setNode(node)
end

function BaseControl:getChildControlByName(name)
	if isNil(name) then printStack() return end
	local ret = nil
	local children = self:getChildren()
	for fd, v in pairs(children) do
		local control = v
		local childName = control:getModel():getName()
		if childName == name then
			ret = control
			return ret
		end
	end

	return ret
end

function BaseControl:getChildControlByAlias(name, alias)
	if notString(name) then printStack() return end
	if notString(alias) then printStack() return end

	local ret = nil
	local children = self:getChildren()
	for fd, v in pairs(children) do
		local control = v
		local childName = control:getModel():getName()
		if childName == name then
			local childAlias = control:getModel():getAlias()
			-- print("childAlias = " .. childAlias)
			-- print("alis = " .. alias)
			if childAlias == alias then
				-- print("HITTTTTTTTTTTTTTTT Alias")
				ret = control
				return ret
			end
		end
	end
	return ret
end


function BaseControl:attach(control)
	BaseControl.super.attach(self, control)
	if isNil(control) then printStack() return end
	local fd = control:getModel():getFD()
	local view = control:getView()

	self:setChild(fd, control)
	self:getView():attach(view)
	control:setParent(self)

	local data = {}
	data.fd = fd
	self:send(BASE_MSG.ATTACH, data)
end

function BaseControl:detach(control)
	BaseControl.super.detach(self, control)
	if isNil(control) then printStack() return end 	
	local fd = control:getModel():getFD()
	local view = control:getView()
	
	self:setChild(fd, nil)
	control:setParent(nil)

	local data = {}
	data.fd = fd
	self:send(BASE_MSG.DETACH, data)

	--NOTE , move child node first , move parent node later
	self:getView():detach(view)
end

function BaseControl:registerLuaMsgs()
	local luaMsgs = self:getModel():getLuaMsgs()
	if isNil(luaMsgs) then return end
	for k,msg in pairs(luaMsgs) do
		traceInfo(self.__cname .. " : " .. msg)
		self:register(msg)
	end
end


function BaseControl:recv(event)
	if isNil(event) then printStack() return end
	if isNil(event.name) then printStack() return end
	if isNil(event.data) then printStack() return end
end

function BaseControl:refreshUI()

end

function BaseControl:onCreate(param)
	self:registerLuaMsgs()
	self:register(BASE_MSG.NODE_TOUCH) -- Engine层抽象
end

function BaseControl:onEnter(param)
	
end

function BaseControl:onExit(param)
	
end

function BaseControl:onDestroy(param)
	
end

function BaseControl:onUpdate(param)
	
end

function BaseControl:destroy()
	BaseControl.super.destroy(self)
	self:unRegisterAll()
	self:setModel(nil)
	self:setView(nil)
end

function BaseControl:description()
	BaseControl.super.description(self)
	local name = self:getModel():getName()
	local fd = self:getModel():getFD()
	print(name .. " , " .. fd)
	local children = self:getChildren()
	for k,child in pairs(children) do
		child:description()
	end
end

function BaseControl:addPanel(name, param, alias)
	if isNil(name) then printStack() return end
	if isNil(param) then param = {} end
	local parentControl = self
	self:addPanelOnControl(parentControl, name, param, alias)
end

return BaseControl


