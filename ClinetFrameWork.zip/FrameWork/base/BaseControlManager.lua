-- require "function"
local Stack = require "Stack"
local BaseObject = require "BaseObject"
local BaseMessageMixin = require "BaseMessageMixin"
local BaseConfigMixin = require "BaseConfigMixin"
local BaseControlManager = class("BaseControlManager", BaseObject)
BaseControlManager:include(BaseMessageMixin)
BaseControlManager:include(BaseConfigMixin)
BaseControlManager.instance = nil

function BaseControlManager.getInstance()
    if not BaseControlManager.instance then
        BaseControlManager.instance = BaseControlManager.new()
    end
    return BaseControlManager.instance
end

function BaseControlManager:ctor()
	BaseControlManager.super.ctor(self)
	self.controlMap = {} -- fd : control
	self.messageManager = {}
    self.modelStack = {} -- stack track model
    self.homeName = "" -- home control name
 	self.rootControl = nil
 	self.rearControl = nil
 	self.frontControl = nil
 	self.tipMVCName = ""
 	self.msgBoxMVCName = ""
 	self.waitingMVCName = ""
 	self.waitingControl = nil
 	self.GMControl = nil
end

--First
function BaseControlManager:getMsgBoxMVCName()
	return self.msgBoxMVCName
end

function BaseControlManager:setMsgBoxMVCName(msgBoxMVCName)
    if notString(msgBoxMVCName) then printStack() return end 
	self.msgBoxMVCName = msgBoxMVCName
end

function BaseControlManager:getWaitingControl()
	return self.waitingControl
end

function BaseControlManager:setWaitingControl(waitingControl)
	self.waitingControl = waitingControl
end

function BaseControlManager:getWaitingMVCName()
	return self.waitingMVCName
end

function BaseControlManager:setWaitingMVCName(waitingMVCName)
    if notString(waitingMVCName) then printStack() return end 
	self.waitingMVCName = waitingMVCName
end

function BaseControlManager:getTipMVCName()
	return self.tipMVCName
end

function BaseControlManager:setTipMVCName(tipMVCName)
    if notString(tipMVCName) then printStack() return end 
	self.tipMVCName = tipMVCName
end

function BaseControlManager:getModelStack()
	return self.modelStack
end

function BaseControlManager:setModelStack(modelStack)
    if notTable(modelStack) then printStack() return end 
	self.modelStack = modelStack
end


function BaseControlManager:getHomeName()
	return self.homeName
end

function BaseControlManager:setHomeName(homeName)
    if notString(homeName) then return printStack() end 
	self.homeName = homeName
end

function BaseControlManager:getControlMap()
	return self.controlMap
end

function BaseControlManager:setControlMap(controlMap)
	if notTable(controlMap) then printStack() return end 
	self.controlMap = controlMap
end

function BaseControlManager:getControl(fd)
	return self.controlMap[fd]
end

function BaseControlManager:setControl(fd, control)
	-- print("setControl fd = " .. fd)
	-- print("setControl control = " .. tostring(control))
	if isNil(fd) then printStack() return end 
	self.controlMap[fd] = control
end

function BaseControlManager:getRootControl()
	return self.rootControl
end

function BaseControlManager:setRootControl(control)
    if notTable(control) then printStack() return end 
	self.rootControl = control
end

function BaseControlManager:getRearControl()
	return self.rearControl
end

function BaseControlManager:setRearControl(control)
	if notTable(control) then printStack() return end 
	self.rearControl = control
end

function BaseControlManager:getFrontControl()
	return self.frontControl
end

function BaseControlManager:setFrontControl(control)
	if notTable(control) then printStack() return end 
	self.frontControl = control
end

function BaseControlManager:getGMControl()
	return self.frontControl
end

function BaseControlManager:setGMControl(control)
	if notTable(control) then printStack() return end 
	self.GMControl = control
end

-- SecondLevel Base On FirstLevel
function BaseControlManager:getRootView()
	local ret = nil
	local rootControl = self:getRootControl()
	if rootControl then
		ret = rootControl:getView()
	end
	return ret
end

function BaseControlManager:setRootView(view)
    if notTable(view) then printStack() return end 
	self:getRootControl():setView(view)
end

function BaseControlManager:getRearView()
	local ret = nil
	local rearControl = self:getRearControl()
	if rearControl then
		ret = rearControl:getView()
	end
	return ret
end

function BaseControlManager:setRearView(view)
    if notTable(view) then printStack() return end 
	self:getRearControl():setView(view)
end

function BaseControlManager:getFrontView()
	local ret = nil
	local frontControl = self:getFrontControl()
	if frontControl then
		ret = frontControl:getView()
	end
	return ret
end

function BaseControlManager:setFrontView(view)
    if notTable(view) then printStack() return end 
    local frontControl = self:getFrontControl()
    if frontControl then
    	frontControl:setView(view)
    end
end

function BaseControlManager:getModel(fd)
	if isNil(fd) then printStack() return end
	local ret = nil
	local control = self:getControl(fd)
	if control then
		ret = control:getModel()
	end
	return ret
end

function BaseControlManager:setModel(fd, model)
	if isNil(fd) then printStack() return end 
	if isNil(model) then printStack() return end 
	local control = self:getControl(fd)
	if control then
		control:setModel(model)
	end
end

function BaseControlManager:getView(fd)
	if isNil(fd) then printStack() return end
	local ret = nil
	local control = self:getControl(fd)
	if control then
		ret = control:getView()
	end
	return ret
end

function BaseControlManager:setView(fd, view)
	if isNil(fd) then printStack() return end 
	if isNil(view) then printStack() return end
	local control = self:getControl(fd)
	if control then
		control:setView(view)
	end
end

function BaseControlManager:rearAttach(control)
	if isNil(control) then printStack() return end 	
	local rearControl = self:getRearControl()
	if rearControl then
		rearControl:attach(control)
	end
end

function BaseControlManager:rearDetach(control)
	if isNil(control) then printStack() return end 	
	local rearControl = self:getRearControl()
	if rearControl then
		rearControl:detach(control)
	end
end

function BaseControlManager:frontAttach(control)
	if isNil(control) then printStack() return end 	
	local frontControl = self:getFrontControl()
	if frontControl then
		frontControl:attach(control)
	end
end

function BaseControlManager:frontDetach(control)
	if isNil(control) then printStack() return end 	
	local frontControl = self:getFrontControl()
	if frontControl then
		frontControl:detach(control)
	end
end

function BaseControlManager:replaceControl(control)
	

	if isNil(control) then printStack() return end

	local frontControl = self:getFrontControl()
	if frontControl then
		frontControl:detachAllChildren()
	end	

	local rearControl = self:getRearControl()
	if rearControl then
		rearControl:detachAllChildren()

		-- self:snapShot("BEFORE ATTACH CONTROL")

		rearControl:attach(control)

		-- self:snapShot("AFTER ATTACH CONTROL")		
	end

	self:freeMemory()
end

function BaseControlManager:pushModel(model)
	if isNil(model) then printStack() return end
	local modelStack = self:getModelStack()
	if modelStack then
		modelStack:push(model)
	end
end

function BaseControlManager:popModel()
	local modelStack = self:getModelStack()
	if modelStack then
		modelStack:pop()
	end
end

function BaseControlManager:topModel()
	local ret = nil
	local modelStack = self:getModelStack()
	if modelStack then
		ret = modelStack:top()
	end
	return ret
end

--FouthLevel, couple other modules, 
function BaseControlManager:addControl(control)
	if isNil(control) then printStack() return end 
	local model = control:getModel()
	if model then
		local fd = model:getFD()
		self:send(BASE_MSG.ENTER_BEFORE, fd)
		self:setControl(fd, control)
		self:send(BASE_MSG.ENTER_AFTER, fd)
	end
end

function BaseControlManager:removeControl(fd)
	-- print("removeControl FD = " .. tostring(fd))
	if isNil(fd) then printStack() return end 
	local control = self:getControl(fd)
	if isNil(control) then printStack() return end 

	self:send(BASE_MSG.DESTROY_BEFORE, fd)
	self:destroy(control, BASE_MSG.DESTROY_BEFORE)
	self:setControl(fd, nil)
	self:send(BASE_MSG.DESTROY_AFTER, fd)
end

function BaseControlManager:destroyObj(lifeCycleObj, param)
	if isNil(lifeCycleObj) then printStack() return end 
	lifeCycleObj:onDestroy(param)
	lifeCycleObj:destroy()
end

function BaseControlManager:destroy(control, param)
	if isNil(control) then printStack() return end 

	local model = control:getModel()
	if isNil(model) then printStack() return end

	local view = control:getView()
	if isNil(view) then printStack() return end

	self:destroyObj(control, param)
	self:destroyObj(model, param)
	self:destroyObj(view, param)
end

function BaseControlManager:createModel(modelName, data)
	if isNil(modelName) then printStack() return nil end 
	if isNil(data) then printStack() return nil end 

	local modelClass = nil
	if LUA_RELOAD_DEBUG then
		modelClass = reloadRequireFile(modelName)
	else
		modelClass = require(modelName)
	end

	if isNil(modelClass) then printStack() return nil end 
	local model = modelClass.new(data)
	return model
end

function BaseControlManager:createView(viewName, node)
	if isNil(viewName) then printStack() return nil end 
	if isNil(node) then printStack() return nil end 

	local viewClass = nil
	if LUA_RELOAD_DEBUG then
		viewClass = reloadRequireFile(viewName)
	else
		viewClass = require(viewName)
	end

	if isNil(viewClass) then printStack() return nil end 
	local view = viewClass.new(node)
	return view
end

function BaseControlManager:createControl(controlName, model, view)
	if isNil(controlName) then printStack() return nil end 
	if isNil(model) then printStack() return nil end 
	if isNil(view) then printStack() return nil end 

	local controlClass = nil
	if LUA_RELOAD_DEBUG then
		controlClass = reloadRequireFile(controlName)
	else
		controlClass = require(controlName)
	end

	if isNil(controlClass) then printStack() return nil end
	local control = controlClass.new(model, view)
	return control
end

function BaseControlManager:createWithMVCInfo(mvc, param)
	if isNil(mvc) then printStack() return nil end 

	local modelParam = {}
	local viewParam = {}
	local controlParam = {}
	if param then
		if param.modelParam then
			modelParam = param.modelParam
		end

		if param.viewParam then
			viewParam = param.viewParam
		end

		if param.controlParam then
			controlParam = param.controlParam
		end
	end

	local data = mvc.data
	local node = mvc.node
	local modelName = mvc.modelName
	local viewName = mvc.viewName
	local controlName = mvc.controlName

	local model = self:createModel(modelName, data)
	if isNil(model) then printStack() return nil end 
	model:onCreate(modelParam)

	local view = self:createView(viewName, node)
	if isNil(view) then printStack() return nil end 
	view:onCreate(viewParam)

	local control = self:createControl(controlName, model, view)
	if isNil(control) then printStack() return nil end 
	control:onCreate(controlParam)

	model:onEnter(modelParam)
	view:onEnter(viewParam)
	control:onEnter(controlParam)

	self:addControl(control)

	return control
end

--MSG API
function BaseControlManager:recv(event)
	if isNil(event) then printStack() return end
	if isNil(event.name) then printStack() return end
	if isNil(event.data) then printStack() return end
	
	-- filterMsgsPrint(event.name, "[MANAGER RECV MSG]")

	local name = event.name
	local data = event.data

	if name == BASE_MSG.ATTACH then
		local fd = data.fd
		return
	end

	if name == BASE_MSG.DETACH then
		local fd = data.fd
		self:removeControl(fd)
		return
	end

	if name == BASE_MSG.REPLACE then
		local mvcName = data.name
		local param = data.param
		local control =	self:createControlWithName(mvcName, param)
		self:replace(control)
		return
	end

	if name == BASE_MSG.POP then
		self:pop()
		return
	end

	if name == BASE_MSG.PUSH then
		local mvcName = data.name
		local param = data.param
		local control =	self:createControlWithName(mvcName, param)
		self:push(control)
		
		return
	end

	if name == BASE_MSG.GOHOME then
		local param = data.param
		self:goHome(param)
		
		return
	end

	if name == BASE_MSG.OPEN_MVC then
		local parentControl = data.parentControl
		local mvcName = data.name
		local param = data.param
		local alias = data.alias
		self:openMVC(parentControl, mvcName, param, alias)
		return
	end

	if name == BASE_MSG.OPEN_REAR_MVC then
		local parentControl = self:getRearControl()
		local mvcName = data.name
		local param = data.param
		local alias = data.alias
    	self:openMVC(parentControl, mvcName, param, alias)
		return
	end

	if name == BASE_MSG.OPEN_FRONT_MVC then
		local parentControl = self:getFrontControl()
		local mvcName = data.name
		local param = data.param
		local alias = data.alias
		local pop = true

		local priority = param.modelParam.priority--pop priority
		if priority == POP_PRIORITY.NONPREEMPTIVE then
			local previousMVC = parentControl:getChildControlByName(mvcName)
			if previousMVC then
				return
			end
		elseif priority == POP_PRIORITY.PREEMPTIVE then
			local previousMVC = parentControl:getChildControlByName(mvcName)
			if previousMVC then
				previousMVC:detachFromParent()
			end
		end
		self:openMVC(parentControl, mvcName, param, alias, pop)
		return
	end

	if name == BASE_MSG.OPEN_TIP_MVC then
		local parentControl = self:getFrontControl()
		local mvcName = self:getTipMVCName()
		local param = data.param
		local alias = data.alias
    	self:openMVC(parentControl, mvcName, param, alias)
		return
	end

	if name == BASE_MSG.OPEN_MSGBOX_MVC then
		local name =  self:getMsgBoxMVCName()
		local param = data.param
		local alias = data.alias
		local data = buildMsgData(name, param.modelParam, param.viewParam, param.controlParam, alias)
    	self:send(BASE_MSG.OPEN_FRONT_MVC, data)
	end

	if name == BASE_MSG.OPEN_ITEM_MVC then
		local parentControl = data.parentControl
		local mvcName = data.name
		local param = data.param
		local alias = data.alias
		self:openItemMVC(parentControl, mvcName, param, alias)
		return
	end

	if name == BASE_MSG.CANCEL_WAITING_MVC then
		local waitingControl = self:getWaitingControl()
    	if isNil(waitingControl) then return end
    	waitingControl:detachFromParent()
    	self:setWaitingControl(nil)
	end

	if name == BASE_MSG.NET then
		--TODO
	end

	if name == BASE_MSG.NET_WAIT then
		--TODO
		local name = self:getWaitingMVCName()
		local parentControl = self:getFrontControl()
		local mvcName = name
		local pop = true
    	self:openMVC(parentControl, mvcName, param, nil, pop)
	end

	if name == BASE_MSG.NET_FORM then
		local func = data.func
		if isNil(data.params) then data.params = "" end
		local params = data.params
		NetFunc:submitForm(func, params) --TODO BASE NET MANAGER
	end

	if name == BASE_MSG.NET_FORM_WAIT then
		local func = data.func
		if isNil(data.params) then data.params = "" end
		local params = data.params
		NetFunc:submitForm(func, params) --TODO BASE NET MANAGER

		local name = self:getWaitingMVCName()
		local parentControl = self:getFrontControl()
		local mvcName = name
		local pop = true
    	local control = self:openMVC(parentControl, mvcName, param, nil, pop)
    	local waitingControl = self:getWaitingControl()
    	if waitingControl then return end
    	self:setWaitingControl(control)
	end

	if name == BASE_MSG.RESET_APP then
		print("BASE_MSG.RESET_APP")
		local rootControl = self:getRootControl()
		if isNil(rootControl) then printStack() return end
		rootControl:detachAllChildren()
	end
end

function BaseControlManager:replaceModel(model)
	if isNil(model) then printStack() return end 	
	self:popModel()
	self:pushModel(model)
end

function BaseControlManager:push(control)
	if isNil(control) then printStack() return end 	
	
	-- statSnapShot("BEFORE ")

	-- self:snapShot("BEFORE PUSH")

	local model = control:getModel()

	-- self:snapShot("BEFORE PUSH MODEL")

	self:pushModel(model)

	-- self:snapShot("AFTER PUSH MODEL")


	self:replaceControl(control)
	

	-- self:snapShot("AFTER PUSH")

	-- statSnapShot("AFTER")
end

function BaseControlManager:pop()
	-- self:snapShot("BEFORE POP")

	self:popModel()
	local model = self:topModel()
	if isNil(model) then printStack() return end

	local control = self:createWithModel(model)
	self:replaceControl(control)

	-- self:snapShot("AFTER POP")
end

function BaseControlManager:replace(control)
	-- self:snapShot("BEFORE REPLACE")	

	if isNil(control) then printStack() return end 	
	local model = control:getModel()
	self:replaceModel(model)
	self:replaceControl(control)

	-- self:snapShot("AGTER REPLACE")	
end

function BaseControlManager:goHome(param)
	-- self:snapShot("BEFORE GOHOME")	

	self:getModelStack():popToRoot()
	local homeModel = self:getModelStack():top()
	local homeControl = self:createWithModel(homeModel, param)
	self:replaceControl(homeControl)

	-- self:snapShot("BEFORE GOHOME")	
end



function BaseControlManager:start()
	print("[MVC] 初始化mvc框架")

	print("[MVC] 设置数据层MODEL管理器")
	local modelStack = Stack.create()
	if isNil(modelStack) then printStack() return end       
	self:setModelStack(modelStack)
	
	print("[MVC] 注册消息")
        -- LIFE CYCLE
        self:register(BASE_MSG.ENTER_BEFORE)
        self:register(BASE_MSG.ENTER_AFTER)
        self:register(BASE_MSG.DESTROY_BEFORE)
        self:register(BASE_MSG.DESTROY_AFTER)

        --CONTROL ATTACH, DETACH 
        self:register(BASE_MSG.ATTACH)
        self:register(BASE_MSG.DETACH)

        --STACK
        self:register(BASE_MSG.REPLACE)
        self:register(BASE_MSG.PUSH)
        self:register(BASE_MSG.POP)
        self:register(BASE_MSG.GOHOME)

        --OPEN MVC
        self:register(BASE_MSG.OPEN_TIP_MVC)
		self:register(BASE_MSG.OPEN_FRONT_MVC)
        self:register(BASE_MSG.OPEN_REAR_MVC)        
        self:register(BASE_MSG.OPEN_MVC)
        self:register(BASE_MSG.OPEN_MSGBOX_MVC)
        self:register(BASE_MSG.OPEN_ITEM_MVC)
        

        --NET
        self:register(BASE_MSG.NET)
        self:register(BASE_MSG.NET_WAIT)
        self:register(BASE_MSG.NET_FORM)
        self:register(BASE_MSG.NET_FORM_WAIT)
        self:register(BASE_MSG.NET_RESP_ERROR)

        --WAITING
        self:register(BASE_MSG.CANCEL_WAITING_MVC)

        --RESET
        self:register(BASE_MSG.RESET_APP)

end

function BaseControlManager:description()
	local rootControl = self:getRootControl()
	if rootControl then
		local name = rootControl:getModel():getName()
		local fd = rootControl:getModel():getFD()
		print(name .. " , " .. fd)
		local children = rootControl:getChildren()
		for k,child in pairs(children) do
			child:description()
		end
	end
end

function BaseControlManager:printControlTbl()
	local tbl = self:getControlMap()
	for fd, control in pairs(tbl) do
		print("fd = " .. tostring(fd));
	end
end

function BaseControlManager:snapShot(key)
	if isNil(key) then printStack() return end
	print("[" .. tostring(key) .. "]")
	local stack = self:getModelStack()
	-- if stack then printStack() return end
	stack:description()
	self:description()
	print("-------------------------")
end

return BaseControlManager
