local ProFi = require "ProFi"
local count = 1

function startProFi()
	ProFi:start()
	ProFi:setGetTimeMethod(os.time)
end

function stopProFi()
	ProFi:stop()
	local name = "MyProfilingReport"..count..".txt"
	ProFi:writeReport(name)
	count = count + 1
end

function stopProFiWithName(name_text)
	ProFi:stop()
	local name = "Report/Report="..name_text.."="..count..".txt"
	ProFi:writeReport(name)
	count = count + 1
end

function stopProFiWithNameAndTime(name_text,time)
	ProFi:stop()
	if ProFi.stopTime - ProFi.startTime > time then
		print("ProFi.stopTime - ProFi.startTime==="..(ProFi.stopTime - ProFi.startTime))
		local name = "Report/Report="..name_text.."="..count..".txt"
		ProFi:writeReport(name)
		count = count + 1
	end
end

function snapShotProFiMemory(interval, operator) -- interval seconds
	local date = tostring(os.date())
	local tag = date .. " : " .. tostring(operator)
	ProFi:checkMemory(interval, tag)
end

