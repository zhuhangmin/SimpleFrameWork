require "function"
local Stack = class("Stack")

function Stack:ctor()
   self.stack = {}
end

function Stack:push(val)
   local index = self:getLen() + 1
   self.stack[index] = val
end

function Stack:pop()
   local index = self:getLen()
   local rv = self.stack[index]
   self.stack[index] = nil
   return rv
end

function Stack:top()
   local index = self:getLen()
   local rv = self.stack[index]
   return rv
end

function Stack:popToRoot()
	local length = self:getLen()
	while length >= 2 do
		local index = length
    	local rv = self.stack[index]
    	self.stack[index] = nil
    	length = self:getLen()
	end
end

function Stack:clean()
   self.stack = {}
end

function Stack:getLen()
   return #self.stack
end

function Stack:isEmpty()
	return #self.stack == 0
end

function Stack:description()
    print("stack len = " .. self:getLen())
    for k, v in pairs(self.stack) do
        print(k)
        if type(v) == "table" then
            for key, value in pairs(v) do
                if key == "fd" then
                  print("\t", key, value)
                end
            end
        end
    end
end

 
return Stack