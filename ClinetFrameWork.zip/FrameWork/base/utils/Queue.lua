require "function"
local Queue = class("Queue")

function Queue:ctor()
   self.queue = {}
   self.first  = 0
   self.last = -1
end

function Queue:getData()
    return self.queue
end

function Queue:pushLeft(val)
   self.first = self.first - 1
   self.queue[self.first] = val
end

function Queue:pushRight(val)
   self.last = self.last + 1
   self.queue[self.last] = val
end

function Queue:popLeft()
   local first = self.first
   if first > self.last then error("self.queue is empty") end
   local value = self.queue[self.first]
   self.queue[self.first] = nil        
   self.first = first + 1
   return value
end

function Queue:popRight()
    local last = self.last
    if self.first > last then error("self.queue is empty") end
    local value = self.queue[self.last]
    self.queue[self.last] = nil         
    self.last = last - 1
    return value
end

function Queue:clean()
   self.queue = {}
end

function Queue:getLen()
   return table.nums(self.queue)
end

function Queue:isEmpty()
	return self:getLen() == 0
end

function Queue:description()
    print("Queue len = " .. self:getLen())
    for k, v in pairs(self.queue) do
        print("index = " ..  k .. " , value = " .. v)
    end
end

 
return Queue