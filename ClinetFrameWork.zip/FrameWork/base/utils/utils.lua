-- require "define"
-- require "function"

function doTrace(logtype,  ...)
    local info = debug.getinfo(3)
    local name = ""
    if info.name then
        name = info.name
    end
    local str = string.sub(info.source, 7) .. ',' .. name .. ':' .. info.currentline .. logtype .. ":"
    print(str, ...)       
end

function traceInfo( ... )
    if LOG_LEVEL >= LOG_LEVEL_ENUM.INFO then
        doTrace("--info", ...)
    end
end

function traceWarn( ... )
    if LOG_LEVEL >= LOG_LEVEL_ENUM.WARN then
        doTrace("--warn", ...)
    end
end

function traceException( ... )
    if LOG_LEVEL >= LOG_LEVEL_ENUM.EXCEPTION then
        doTrace("--exception", ...)
    end
end

function traceError( ... )
    if LOG_LEVEL >= LOG_LEVEL_ENUM.ERROR then
        doTrace("--error", ...)
    end
end


function buildClassPath(name, subFix)
	if notString(name) then return printStack() end
	if notString(subFix) then return printStack() end
		
	local classPath = PROJECT_PATH .. name .. subFix
	return classPath
end

-- mvcInfo = {
-- 	"data" = {
-- 				"name" 
-- 				"alias"
--				"action"
-- 			}
-- 	"node" 
-- 	"modelName" 
-- 	"viewName" 
-- 	"controlName" 
-- }

function buildMVCInfo(data, node)
	if isNil(data) then return printStack() end
	if isNil(data.name) then return printStack() end
	if isNil(data.alias) then data.alias = "" end
	if isNil(data.action) then data.action = "" end
	if isNil(node) then return printStack() end
	local name = data.name

	local mvcInfo = {}
	mvcInfo.data = data
	mvcInfo.node = node
	mvcInfo.modelName = buildClassPath(name, CLASS_SUBFIX.MODEL)
	mvcInfo.viewName = buildClassPath(name, CLASS_SUBFIX.VIEW)
	mvcInfo.controlName = buildClassPath(name, CLASS_SUBFIX.CONTROL)

	return mvcInfo
end

function report(source, msg)
	if notString(source) then return printStack() end
	if notString(msg) then return printStack() end
	local str = ""
	str = str .. source
	str = str .. CONSTANT_STRING.WARNNING
	str = str .. CONSTANT_STRING.REPORT_UNKNOW
	str = str .. msg
	print(str)
end

function printAddress(control)
	if isNil(control) then return printStack() end
	print("")
	print("control : " .. tostring(control))
	print("   |    ")
	print("   |    ")
	print("   |--- view : " .. tostring(control:getView()))
	print("   |      |    ")
	print("   |      |--- node : " .. tostring(control:getView():getNode()))
	print("   |           ")
	print("   |           ")
	print("   |--- model : " .. tostring(control:getModel()))
	print("          |           ")
	print("          |--- data : " .. tostring(control:getModel():getData()))
	print("          |           ")
	print("          |--- fd   : " .. tostring(control:getModel():getFD()))
	print("")
end

function filterPrint(value, prefix, filterValues)
	if isNil(value) then printStack() return end
	if isNil(filterValues) then printStack() return end
	if notString(prefix) then printStack() return end

	for k , v in pairs(filterValues) do
		if v == value then
			return
		end
	end
	print(prefix .. " : ".. tostring(value))
end

function filterMsgsPrint(value, prefix)
	local filterMsgs ={
		BASE_MSG.ENTER_BEFORE,
		BASE_MSG.ENTER_AFTER,
		BASE_MSG.DESTROY_BEFORE,
		BASE_MSG.DESTROY_AFTER,

		BASE_MSG.PLAY_SOUND,
		BASE_MSG.PLAY_DEFAULT_BUTTON_SOUND,

		BASE_MSG.DETACH,

		-- BASE_MSG.OPEN_MVC,

		-- BASE_MSG.NODE_TOUCH
	}

	filterPrint(value, prefix, filterMsgs)	
end

function buildMsgData(mvcName, modelParam, viewParam, controlParam, alias)
	if isNil(mvcName) then printStack() return end
	if isNil(alias) then alias = "" end
	local data = {}
	data.name = mvcName
	data.alias = alias
	data.param = {}
	if isNil(controlParam) then
	  data.param.controlParam = {}
	else
	  data.param.controlParam = controlParam
	end

	if isNil(viewParam) then
	  data.param.viewParam = {}
	else
	  data.param.viewParam = viewParam
	end

	if isNil(modelParam) then
	  data.param.modelParam = {}
	else
	  data.param.modelParam = modelParam
	end

	return data
end

function queueAverage(queue, limitNum, value)
	queue:pushLeft(value)
	local len = queue:getLen()
	if len >= limitNum + 1 then
		queue:popRight()
	end

	local data = queue:getData()
	local average = table.average(data)
	return average
end