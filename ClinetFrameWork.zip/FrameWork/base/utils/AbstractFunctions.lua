-- TRAVEL NODE
function nodeTravelAbstract(node, executeFunc, getChildrenFuncName, depth)
	if isNil(node) then printStack() return end
	if isNil(executeFunc) then printStack() return end
	if isNil(getChildrenFuncName) then getChildrenFuncName = "getChildren" end
	if isNil(depth) then depth = 1 end

	local breakRecursiveFlag = executeFunc(node, depth)
	if breakRecursiveFlag then return end

	local children = node[getChildrenFuncName](node)
	local childNum = table.nums(children)
	if childNum == 0 then return end
	
	depth = depth + 1
	for index = 1, childNum do
		local childNode = children[index]
		nodeTravelAbstract(childNode, executeFunc, getChildrenFuncName, depth)
	end
end

--FIND CHILD NODE
function findNodeByValueAbstract(node, funcName, value, getChildrenFuncName)
	if isNil(node) then printStack() return end
	if notString(funcName) then printStack() return end
	if isNil(value) then printStack() return end
	if notString(getChildrenFuncName) then printStack() return end
	
	local retNode = nil
	local findFunc = function(node, depth)
		local breakRecursiveFlag = false
		local nodeValue = node[funcName](node)
		if nodeValue == value then
			retNode = node
			breakRecursiveFlag = true
		end
		return breakRecursiveFlag
	end

	nodeTravelAbstract(node, findFunc, getChildrenFuncName)
	return retNode
end

--SUM NODE
function sumNodeAbstract(node, funcName, getChildrenFuncName)
	if isNil(node) then printStack() return end
	if notString(funcName) then printStack() return end
	if notString(getChildrenFuncName) then printStack() return end
	
	local sum = 0
	local sumFunc = function(node, depth)
		local nodeValue = node[funcName](node)
		sum = sum + nodeValue
	end

	nodeTravelAbstract(node, sumFunc, getChildrenFuncName)
	return sum
end

--TOTAL NODE
function getTotalNodeAbstract(node, getChildrenFuncName)
	if isNil(node) then printStack() return end
	if notString(getChildrenFuncName) then printStack() return end
	
	local sum = 0
	local sumFunc = function(node, depth)
		sum = sum + 1
	end

	nodeTravelAbstract(node, sumFunc, getChildrenFuncName)
	return sum
end