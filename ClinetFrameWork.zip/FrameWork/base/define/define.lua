PROJECT_PATH = "FrameWork."

LUA_RELOAD_DEBUG = true
LUA_TEXTURE_MEMORY = false

LOG_LEVEL_ENUM = {
	ERROR 		= 0, 
	EXCEPTION 	= 1, 
	WARN 		= 2, 
	INFO 		= 3, 
}

LOG_LEVEL = LOG_LEVEL_ENUM.INFO

CLASS_SUBFIX ={
	MODEL = "Model",
	VIEW = "View",
	CONTROL = "Control",
}

CONSTANT_STRING = {
	ERROR				= " [ERROR] ",
	WARNNING 			= " [WARNNING] ",
	REPORT_UNKNOW		= " report unkonw ",
}

POP_PRIORITY = {
  DAFAULT = 0,
  PREEMPTIVE = 1,
  NONPREEMPTIVE = 2,
}

BASE_MSG = 
{
	--LIFE CYCLE
	ENTER_BEFORE	 		= "ENTER_BEFORE", 
	ENTER_AFTER 			= "ENTER_AFTER",
	DESTROY_BEFORE 			= "DESTROY_BEFORE",
	DESTROY_AFTER 			= "DESTROY_AFTER",

	--CONTROL
	DETACH							= "msg_detach",
	ATTACH							= "msg_attach",

	--SOUND
	PLAY_SOUND               		= "msg_play_sound",
	PLAY_DEFAULT_BUTTON_SOUND       = "msg_play_default_button_sound",
	PAUSE_SOUND_MUSIC		        = "msg_pause_sound_music",
	RESUME_SOUND_MUSIC       		= "msg_resume_sound_music",

	--TOUCH
	NODE_TOUCH						= "msg_node_touch",

	GET_BUTTON_INFO					= "get_button_info",

	--MODEL STACK
	PUSH					= "msg_control_push",
	POP						= "msg_control_pop",
	REPLACE				    = "msg_control_replace",
	GOHOME				    = "msg_control_gohome",

	--MVC
	OPEN_MSGBOX_MVC                 = "msg_open_msgbox_mvc",
	OPEN_TIP_MVC                    = "msg_open_front_tip_mvc",
	OPEN_FRONT_MVC					= "msg_open_front_mvc",
	OPEN_REAR_MVC					= "msg_open_rear_mvc",
	OPEN_MVC						= "msg_open_mvc",
	OPEN_ITEM_MVC					= "msg_open_item_mvc",


	--MEMORY
	REMOVE_UNUSED 			= "msg_remove_unused_res",

	--NET
	NET                          = "msg_net",
	NET_WAIT                     = "msg_net_wait",
	NET_FORM                          = "msg_net_form",
	NET_FORM_WAIT                     = "msg_net_form_wait",
	NET_RESP_ERROR              = "msg_net_resp_error",

	--CANCEL WAITING
	CANCEL_WAITING_MVC           = "cancel_waiting_mvc",

	--NOTIFY CONFIG
	NOTIFY_CONFIG				 = "notifyConfig",
	UPDATE_CONFIG				 = "updateConfig",

	--USER BEHAVIOR
	USER_BEHAVIOR				 = "behavior",

	--RESET GAMEDATA
	RESET_APP			= "msg_reset_app",

}

