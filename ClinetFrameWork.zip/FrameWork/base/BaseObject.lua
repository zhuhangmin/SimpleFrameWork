local LifeCycleInterface = require "LifeCycleInterface"
local BaseObject = class("BaseObject", LifeCycleInterface)

function BaseObject:ctor(model, view)
	BaseObject.super.ctor(self)
	self.children = {} -- 二元信息描述所有数据结构
	self.parent = nil  -- 二元信息描述所有数据结构
end

function BaseObject:getParent()
	return self.parent
end

function BaseObject:setParent(parent)
	self.parent = parent
end

function BaseObject:getChildren()
	return self.children
end

function BaseObject:setChildren(children)
	self.children = children
end

function BaseObject:getChild(childName)
	if isNil(childName) then printStack() return end

	local childControl = self:getChildren()[childName]
	if isNil(childControl) then printStack() return end

	return childControl
end

function BaseObject:setChild(childName, child)
	if isNil(childName) then printStack() return end

	local children = self:getChildren()
	if isNil(children) then printStack() return end

	children[childName] = child
end

-- 同类单向信息强连接，适合生成递归数据结构
function BaseObject:attach(baseObject)
	-- error("should be overrided by subClass")
end

function BaseObject:detach(baseObject)
	-- error("should be overrided by subClass")
end

function BaseObject:detachFromParent()
	local parent = self:getParent()
	if isNil(parent) then return end
	parent:detach(self)
end

function BaseObject:detachAllChildren()
	local children = self:getChildren()
	for k, child in pairs(children) do
		self:detach(child)
	end
end

function BaseObject:destroy()
	BaseObject.super.destroy(self)
	self:detachAllChildren()
	-- self:setChildren(nil)
	-- self:setParent(nil)
end

function BaseObject:description()
	print("class name = " .. self.__cname)
end

return BaseObject


