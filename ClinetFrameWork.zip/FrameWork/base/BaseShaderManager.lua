local BaseObject = require "BaseObject"
local BaseShaderManager = class("BaseShaderManager", BaseObject)
BaseShaderManager.instance = nil

function BaseShaderManager.getInstance()
    if not BaseShaderManager.instance then
        BaseShaderManager.instance = BaseShaderManager.new()
    end
    return BaseShaderManager.instance
end

function BaseShaderManager:ctor()
	BaseShaderManager.super.ctor(self)
	print("BaseShaderManager ctor")
	self.shaderTbl = {} -- key : value(vsh, fsh)
	self.compliedCache = {}
	self.curShaderName = "DEFAULT"
	self.curNode = nil
end

function BaseShaderManager:getCurNode()
    return self.curNode
end

function BaseShaderManager:setCurNode(curNode)
    self.curNode = curNode
end

function BaseShaderManager:getCurShaderName()
    return self.curShaderName
end

function BaseShaderManager:setCurShaderName(curShaderName)
    self.curShaderName = curShaderName
end

function BaseShaderManager:getCompliedCache()
    return self.compliedCache
end

function BaseShaderManager:setCompliedCache(compliedCache)
    self.compliedCache = compliedCache
end

function BaseShaderManager:addCache(shaderName, compliedShader)
	if isNil(shaderName) then printStack() return end
	if isNil(compliedShader) then printStack() return end
	local cache = self:getCompliedCache()
	if isNil(cache) then printStack() return end
	cache[shaderName] = compliedShader
end

function BaseShaderManager:getShader(shaderName)
	if isNil(shaderName) then printStack() return end
	local cache = self:getCompliedCache()
	if isNil(cache) then printStack() return end
    return cache[shaderName]
end

function BaseShaderManager:setCompliedCache(compliedCache)
    self.compliedCache = compliedCache
end

function BaseShaderManager:getShaderTbl()
    return self.shaderTbl
end

function BaseShaderManager:setShaderTbl(shaderTbl)
    self.shaderTbl = shaderTbl
end

function BaseShaderManager:getShaderResource(shaderName)
	if isNil(shaderName) then printStack() return end
	local tbl = self:getShaderTbl()
	return tbl[shaderName]
end

function BaseShaderManager:shaderNode(node, shader)
	-- error("overrided by subclass")
end

function BaseShaderManager:setShaderRecursive(rootNode, shaderName)
	if isNil(rootNode) then printStack() return end
	if isNil(shaderName) then printStack() return end

	self:setCurShaderName(shaderName)

	local shaderFunc = function(node)
		if node then
			self:shaderNode(node,shaderName)
		end
	end
	nodeTravelAbstract(rootNode, shaderFunc, "getChildren")
end


function BaseShaderManager:revertShaderRecursive(rootNode)
	self:setCurShaderName("DEFAULT")
	local shaderFunc = function(node)
		if node then
			self:revertShader(node)
		end
	end
	nodeTravelAbstract(rootNode, shaderFunc, "getChildren")
end


return BaseShaderManager
