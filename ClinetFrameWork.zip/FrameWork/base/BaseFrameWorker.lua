local BaseObject = require "BaseObject"
local BaseFrameWorker = class("BaseFrameWorker", BaseObject)

BaseFrameWorker.static_id = 1 -- global file desciptor
function BaseFrameWorker:ctor()
	BaseFrameWorker.super.ctor(self)
	self.id = BaseFrameWorker.static_id
	self.frameTask = {} -- index: {path,cb} -- 注意原子性
	self.taskIndex = 1 
	BaseFrameWorker.static_id = BaseFrameWorker.static_id + 1
end

function BaseFrameWorker:getID()
	return self.id
end

function BaseFrameWorker:setID(id)
	self.id = id
end

function BaseFrameWorker:getFrameTask()
	return self.frameTask
end

function BaseFrameWorker:setFrameTask(frameTask)
	self.frameTask = frameTask
end

function BaseFrameWorker:getTaskIndex()
	return self.taskIndex
end

function BaseFrameWorker:setTaskIndex(taskIndex)
	self.taskIndex = taskIndex
end

function BaseFrameWorker:getTaskNum()
	local frameTask = self:getFrameTask()
	if isNil(frameTask) then printStack() return end

	local num = table.nums(frameTask)
	if isNil(num) then printStack() return end
	return num
end

-- task : {callback = callback, params = { ... }}
function BaseFrameWorker:addFrameTask(task)
	local frameTask = self:getFrameTask()
	if isNil(frameTask) then printStack() return end

	local taskNum = self:getTaskNum()
	if isNil(taskNum) then printStack() return end

	local index = taskNum + 1
	frameTask[index] = task
end

function BaseFrameWorker:reset()
	self:setFrameTask({})
	self:setTaskIndex(1)
	self:setID(0)
end

return BaseFrameWorker