local BaseObject = require "BaseObject"
local BaseModel = class("BaseModel", BaseObject)

BaseModel.static_fd = 1 -- global file desciptor
function BaseModel:ctor(data)
	BaseModel.super.ctor(self)
	self.data = data
	self.fd = BaseModel.static_fd
	self.luaMsgs = {}
	BaseModel.static_fd = BaseModel.static_fd + 1
	-- print("BaseModel ctor FD = " .. self.fd)
end

function BaseModel:getFD()
	return self.fd
end

function BaseModel:setFD(fd)
	self.fd = fd
end

function BaseModel:getData()
	return self.data
end

function BaseModel:setData(data)
	-- if isNil(data) then printStack() return end 	
	self.data = data
end

function BaseModel:getName()
	return self:getData().name
end

function BaseModel:setName(name)
	self:getData().name = name
end

function BaseModel:getAlias()
	return self:getData().alias
end

function BaseModel:setAlias(alias)
	self:getData().alias = alias
end

function BaseModel:getAction()
	return self:getData().action
end

function BaseModel:setAction(action)
	self:getData().action = action
end

function BaseModel:attach(model)
	BaseModel.super.attach(self, model)
end

function BaseModel:detach(model)
	BaseModel.super.detach(self, model)
end

function BaseModel:getLuaMsgs()
	return self.luaMsgs
end

function BaseModel:setLuaMsgs(luaMsgs)
	self.luaMsgs = luaMsgs
end

function BaseModel:onCreate(param)
	
end

function BaseModel:onEnter(param)
	
end

function BaseModel:onExit(param)
	
end

function BaseModel:onDestroy(param)
	
end

function BaseModel:onUpdate(param)
	
end

function BaseModel:destroy()
	BaseModel.super.destroy(self)
	-- self:setData(nil)
	-- self:setFD(nil)
	-- self:setLuaMsgs(nil)
end

return BaseModel

