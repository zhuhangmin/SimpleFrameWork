local LifeCycleInterface = require "LifeCycleInterface"
local ViewInterface = class("ViewInterface", LifeCycleInterface)

function ViewInterface:ctor()
	ViewInterface.super.ctor(self)
end

function ViewInterface:getNode()
	error("should be override by subClass", 2)
end

function ViewInterface:setNode(node)
	error("should be override by subClass", 2)
end

function ViewInterface:attach(view)
	error("should be override by subClass", 2)
end

function ViewInterface:detach(view)
	error("should be override by subClass", 2)
end

return ViewInterface