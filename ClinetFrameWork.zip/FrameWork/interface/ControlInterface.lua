local LifeCycleInterface = require "LifeCycleInterface"
local ControlInterface = class("ControlInterface", LifeCycleInterface)

function ControlInterface:ctor()
	ControlInterface.super.ctor(self)
end

function ControlInterface:getModel()
	error("should be override by subClass", 2)
end

function ControlInterface:setModel(model)
	error("should be override by subClass", 2)
end

function ControlInterface:getView()
	error("should be override by subClass", 2)
end

function ControlInterface:setView(view)
	error("should be override by subClass", 2)
end

function ControlInterface:attach(control)
	error("should be override by subClass", 2)
end

function ControlInterface:detach(control)
	error("should be override by subClass", 2)
end

return ControlInterface