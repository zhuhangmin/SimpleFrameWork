require "function"
local MsgInterface = class("MsgInterface")

function MsgInterface:ctor()
end

function MsgInterface:register(msg)
	error("should be override by subClass", 2)
end

function MsgInterface:unRegister(msg)
	error("should be override by subClass", 2)
end

function MsgInterface:recv(event)
	error("should be override by subClass", 2)
end

function MsgInterface:send(name, data)
	error("should be override by subClass", 2)
end

return MsgInterface