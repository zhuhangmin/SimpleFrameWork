local LifeCycleInterface = require "LifeCycleInterface"
local ModelInterface = class("ModelInterface", LifeCycleInterface)

function ModelInterface:ctor()
	ModelInterface.super.ctor(self)
end

function ModelInterface:getFD()
	error("should be override by subClass", 2)
end

function ModelInterface:getData()
	error("should be override by subClass", 2)
end

function ModelInterface:setData(data)
	error("should be override by subClass", 2)
end

return ModelInterface