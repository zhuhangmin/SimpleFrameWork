require "function"
local MessageManagerInterface = class("MessageManagerInterface")

function MessageManagerInterface:ctor()
end

--@target: 监听者
--@name：注册消息
--@callBack:回调方法
function MessageManagerInterface:registerMsg(target, name, callBack)
	error("should be override by subClass", 2)
end

function MessageManagerInterface:unRegisterMsg(target, name)
	error("should be override by subClass", 2)
end

function MessageManagerInterface:dispatch(name,data)
	error("should be override by subClass", 2)
end

return MessageManagerInterface

