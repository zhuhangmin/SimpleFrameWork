local LifeCycleInterface = class("LifeCycleInterface")

function LifeCycleInterface:onCreate(param)
	-- error("should be override by subClass", 2)
end

function LifeCycleInterface:onEnter(param)
	-- error("should be override by subClass", 2)
end

function LifeCycleInterface:onExit(param)
	-- error("should be override by subClass", 2)
end

function LifeCycleInterface:onDestroy(param)
	-- error("should be override by subClass", 2)
end

function LifeCycleInterface:onUpdate(param)
	-- error("should be override by subClass", 2)
end

function LifeCycleInterface:destroy()
	-- error("should be override by subClass", 2)
end

return LifeCycleInterface