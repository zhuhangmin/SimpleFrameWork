local ConfigManager = require "ConfigManager"
local ResourceManager = require "ResourceManager"
local EngineFrameWorker = require "EngineFrameWorker"
local CONFIGURATION = require "configTable"
local EngineControlManager = require "EngineControlManager"
local Application = class("Application")

function Application:ctor()    
    traceInfo("start Application")
end

function Application:init()
    traceInfo("init config manager")
    local configManager = ConfigManager.getInstance()
    configManager:init(CONFIGURATION)

    -- traceInfo("init resource manager")
    -- local resourceLoadManger = ResourceManager.getInstance()
    -- local loader = EngineFrameWorker.new()
    -- resourceLoadManger:setWorker(loader)
    -- local preloadPlist = configManager:getTable(PRELOAD_PLIST)
    -- local preloadArmature = configManager:getTable(PRELOAD_ARMATURE)
    -- resourceLoadManger:loadBatchFrame(preloadPlist)
    -- resourceLoadManger:loadBatchArmature(preloadArmature)
    -- preload to acceratele loading 
    -- resourceLoadManger:startLoad() --TODO MOVE TO LOADING

    local manager = EngineControlManager.getInstance()
    manager:start()

    local brandControl = manager:createControlWithName("game.Brand")
    manager:push(brandControl)

end

function Application:hotUpdateEnded()
    
end

return Application
