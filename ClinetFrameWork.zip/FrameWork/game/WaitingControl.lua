local EngineControl = require  "EngineControl"
local WaitingControl = class("WaitingControl", EngineControl)
local EngineGlobalStatus = require "EngineGlobalStatus"
--LUA MSGS
local LUA_MSGS = {
}

--SYSTEM MSGS
local SYSTEM_MSGS = {
}

local NET_ERROR_STR = WaitingControl:getConfigField("tips", "CONNECTION_FAIL", "content")

function WaitingControl:ctor(model, view)
	WaitingControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function WaitingControl:onCreate(param)
	WaitingControl.super.onCreate(self, param)
	if isNil(param) then printStack() end

	local node = self:getView():getNode()
	node:setVisible(false)

	local model = self:getModel()
	local engineGlobalStatus = EngineGlobalStatus:getInstance()

	local delay = model:getDelay()
	local delayAction = cc.DelayTime:create(delay)
	local callBackAction = cc.CallFunc:create(function()
			engineGlobalStatus:setBackEventEnable(true)
			node:setVisible(true)
	end)
	local action = cc.Sequence:create(delayAction, callBackAction)
	node:runAction(action)

	local timeout = model:getTimeout()
	local timeoutDelay = cc.DelayTime:create(timeout)
	local timeoutCB = cc.CallFunc:create(function()
			self:addTip(NET_ERROR_STR)
			engineGlobalStatus:setBackEventEnable(false)
			self:send(BASE_MSG.CANCEL_WAITING_MVC)
	end)
	local timeoutAction = cc.Sequence:create(timeoutDelay, timeoutCB)
	node:runAction(timeoutAction)

	local waitImg = self:getChildNode(WAITING_IMG_TAG)
	local posX = gScreenSize.width / 2
	local posY = gScreenSize.height / 2
	waitImg:setPosition(posX, posY)

	local rotateAction = cc.RotateBy:create(3, -720)
	local repeatAction = cc.RepeatForever:create(rotateAction)
	waitImg:runAction(repeatAction)
end

function WaitingControl:onDestroy(param)
	WaitingControl.super.onDestroy(self, param)
	local engineGlobalStatus = EngineGlobalStatus:getInstance()
	engineGlobalStatus:setBackEventEnable(false)
end
return WaitingControl


