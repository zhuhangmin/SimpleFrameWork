local EngineModel = require "EngineModel"
local TimeGiftModel = class("TimeGiftModel", EngineModel)

function TimeGiftModel:ctor(data)
	TimeGiftModel.super.ctor(self, data)
end

function TimeGiftModel:onCreate(param)
	TimeGiftModel.super.onCreate(self, param)
end

return TimeGiftModel

