local EngineModel = require "EngineModel"
local RootModel = class("RootModel", EngineModel)

function RootModel:ctor(data)
	RootModel.super.ctor(self, data)
	self.time = 1
	self.count = 1
	self.interval = 60

	self.popActivityIDs = {}
end

function RootModel:getTime()
	return self.time
end

function RootModel:setTime(time)
	self.time = time
end

function RootModel:getCount()
	return self.count
end

function RootModel:setCount(count)
	self.count = count
end

function RootModel:getInterval()
	return self.interval
end

function RootModel:setInterval(interval)
	self.interval = interval
end

function RootModel:setPopActivityIDs(popActivityIDs)
	self.popActivityIDs = popActivityIDs
end

function RootModel:getPopActivityIDs()
	return self.popActivityIDs
end

return RootModel

