local EngineView = require "EngineView"
local RichesView = class("RichesView", EngineView)

RICHES_CSB = 1000
RICHES_DIAMOND_ARMATURE = 2000



function RichesView:ctor(node)
	RichesView.super.ctor(self, node)
end

function RichesView:onCreate(param)
	RichesView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode("res/DiamondStar.csb")
	if isNil(csbNode) then printStack() return end
	csbNode:setTag(RICHES_CSB)
	self:getNode():addChild(csbNode)

	local diamondArmature = ccs.Armature:create("mjzjm")
	diamondArmature:setTag(RICHES_DIAMOND_ARMATURE)
	self:getNode():addChild(diamondArmature)
	
	
end

return RichesView





