local GameData = class("GameData")

function GameData:ctor()
	self:resetBaseData()
	self:resetSettingData()
	self:resetCustomModeData()
	self:resetGameData()
end

function GameData:resetBaseData()
	self.serverID = 0 								--玩家服务端ID
	self.enterServerTime = 0 						--登录服务器时间
	self.mode = 0 									--当前游戏模式
	self.matchData = {}
	self.syncTimeDelta = 0 							--与服务器时间差
	self.netDelta = 0 								--网络延迟
	self.battleScene = nil
	self.syncCD = 0
	self.enterTime = 0				--进入房间时间
	self.roomType = 1
	self.voiceFilter = {}
end

function GameData:resetSettingData()
	self.settingInfo = {
		musicEnable = true,							--背景音乐配置
		effectEnable = true,						--音效配置
		skinEnable = true,							--皮肤配置
		talkEnable = false,							--语音配置
		qualityValue = 2,							--游戏画面质量配置
		battleBgValue = 1,							--战斗背景配置
		handValue = 2,								--战斗左右手
	}
end

function GameData:resetCustomModeData()
	--自定义模式配置数据
	self.customModeInfo = {
		-- battleSize = CustomConfig.DEFAULT_BATTLE_SIZE,
		-- foodCount = CustomConfig.DEFAULT_FOOD_COUNT,
		-- grassCount = CustomConfig.DEFAULT_GRASS_COUNT,
		-- AICount = CustomConfig.DEFAULT_AI_COUNT,
		-- AIScore = CustomConfig.DEFAULT_AI_SCORE,

		-- AIType = CustomConfig.DEFAULT_AI_TYPE,
		-- isBornFood = CustomConfig.DEFAULT_FOOD_REFRESH,
		-- isBornGrass = CustomConfig.DEFAULT_GRASS_REFRESH,
	}
end

function GameData:resetGameData()
	if not self.battleInfo then
		self.battleInfo = {}
	else
		if self.battleInfo.roleDataManager then
			self.battleInfo.roleDataManager:clear()
			self.battleInfo.roleDataManager = nil
		end
	end
	self.voiceFilter = {}
	self.battleInfo = {
		userID = 0,
		roomID = -1,
		controlID = -1,
		leftTime = 0,
		isUserDie = false,
		roleDataManager = nil,

		joyDir = -1,

		--用于单机部分
		currGate = 0,					--关卡索引

		maxScore = 0,					--最大分数
	}
end


cc.exports.GameData = GameData:create()


--[[
cc.exports.GameData = 
{

	unlockGateIndex = 0,						--单机模式下，已经打过的关卡最大索引
	currentGateIndex = 0,						--单机模式下，当前进入的关卡索引

	--战斗相关
	-- userBattleID = 0,							--战斗中的玩家ID
	-- userBattleRoomID = -1,						--战斗房间ID
	-- userBattleControlID = -1,					--战斗控制id
	-- enterBattleRoomTime = 0,					--进入战斗房间时间

	-- --虚拟摇杆指向
	-- TouchDirect = -1,							--玩家移动的方向角度

	-- --数据管理器
	-- RoleDataManager = nil,						--玩家数据管理器

	--关卡模式中，战斗界面的提示层是否关闭
	gateModeIsHintLayerClose = false,



	MaxScore = 0,							--最大体重
}
]]
