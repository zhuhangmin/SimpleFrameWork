
local RoleDataManager = class("RoleDataManager")

function RoleDataManager:ctor()
	self.roleDataList = {}
	self.schedulerID = nil

	self.checkTime = socket.gettime()
	self.isCheck = true

	self.primaryTime = socket.gettime()

	self.syncCD = 0
	self.isSyncTime = true

	self:addRoleData(GameData.battleInfo.userID)

	-- if GameData.mode == Constant.GameMode.ALIVE then
		-- self:startFrameScheduler()
	-- end
end

function RoleDataManager:startFrameScheduler()
	-- if not self.schedulerID then
	-- 	self.schedulerID = gScheduler:scheduleScriptFunc(handler(self, self.updateFrame), 0, false)
	-- end
end

function RoleDataManager:cancelFrameScheduler()
	if self.schedulerID then
		gScheduler:unscheduleScriptEntry(self.schedulerID)
		self.schedulerID = nil
	end
end

function RoleDataManager:updateFrame(dt)	
	self:updateChildren(dt)
	self:checkCollsion()
	-- self:syncServerTime(dt)

	local time = socket.gettime()
	self:checkRolePos(time)
	self:setPrimaryBall(time)
end

function RoleDataManager:updateChildren(dt)
	for k, v in pairs(self.roleDataList) do
		v:update(dt)
	end
end

function RoleDataManager:checkCollsion()
	for k, v in pairs(self.roleDataList) do
		v:collsion()
	end
end

--每100毫秒同步一次位置
function RoleDataManager:checkRolePos(time)
	if not GameData.battleInfo.isUserDie then
			--[[
			self.checkTime = socket.gettime()
			self.isCheck = true
			]]

		if time - self.checkTime >= 1 and not self.isCheck then
			self.isCheck = true
		end

		if time - self.checkTime >= 0.1 and self.isCheck then
			self.checkTime = time
			assert(self.roleDataList,"self.roleDataList")
			local list = {}
			local data = self.roleDataList[GameData.battleInfo.userID]
			assert(data,"user data")
			if data and data.elementList  then
				for k, v in pairs(data.elementList) do
					if v and v.userID == GameData.battleInfo.userID then
						local tab = {eid = v.eid, x = v.x, y = v.y}
						table.insert(list, tab)
					end
				end
			end

			if #list > 0 then
				self.isCheck = false
				NetFunc.netBattle:checkPos(list)
			end
		end
	end
end

--每100毫秒计算一次主球
function RoleDataManager:setPrimaryBall(time)
	if not GameData.battleInfo.isUserDie then
		if time - self.primaryTime >= 0.1 then
			self.primaryTime = time
			self.roleDataList[GameData.battleInfo.userID]:setPrimary()
		end
	end
end

--每2秒与服务器同步一次时间
function RoleDataManager:syncServerTime(dt)
	self.syncCD = self.syncCD + dt

	if self.syncCD >= 2 then
		if not self.isSyncTime then
			GameData.netDelta = 2001
		end

		self.syncCD = self.syncCD - 2
		self.isSyncTime = false
		NetFunc.netBattle:timeSync()
	end
end


--------------------------------------外部可调用方法-------------------------------------
--增加一个角色
function RoleDataManager:addRoleData(userid)
	-- print("add role data ===="..userid)
	local rd = require("data.RoleData"):create(userid)
	self.roleDataList[userid] = rd
end

--删除一个角色
function RoleDataManager:delRoleData(userid)
	self.roleDataList[userid] = nil
end

--清空方法(在退出战斗的时候调用)
function RoleDataManager:clear()
	self:cancelFrameScheduler()
	self.roleDataList = nil
end

--实体变化通知
function RoleDataManager:stateNotify(resp)
	local role = self.roleDataList[resp.userid]
	if role then
		role:stateNotify(resp.enter, resp.leave, resp.move, resp.dead, tonumber(resp.time))
	end
	-- print(resp.userid..":"..GameData.battleInfo.userID)
	-- if resp.userid == GameData.battleInfo.userID then
	-- 	if resp.move and role.peerList then
	-- 		for k , v in pairs(role.peerList) do
	-- 			-- print("elementList ==========="..k..";"..GameData.battleInfo.userID)
	-- 			if k ~= GameData.battleInfo.userID then
	-- 				local peer = self.roleDataList[GameData.battleInfo.userID]
	-- 				print("elementList ==========="..type(peer))
	-- 				if type(peer) == "table" then
	-- 					for k1 , v1 in pairs(peer.elementList) do
	-- 						-- print("elementList ==========="..k1)
	-- 						-- dump(resp.move)
	-- 						for k2 , v2 in pairs(resp.move) do
	-- 							if v2.eid == k1 then
	-- 								print("userid ==========="..k1)
	-- 								dump(v2)
	-- 							end
	-- 						end
	-- 					end
	-- 				end
	-- 			end
	-- 		end
	-- 	end
	-- end
end

--实体属性变化通知
function RoleDataManager:propertyNotify(resp)
	local role = self.roleDataList[resp.userid]
	if role then
		role:propertyNotify(resp.weight_set)
	end
end

--系统养分变化通知
function RoleDataManager:foodNotify(resp)
	local role = self.roleDataList[resp.userid]
	if role then
		role:foodNotify(resp.enter, resp.leave)
	end
end

--盟友位置变化通知
function RoleDataManager:peerNotify( resp )
	local role = self.roleDataList[resp.userid]
	if role then
		role:peerNotify(resp.users)
	end
end

--方向改变通知
function RoleDataManager:changeDir(resp)
	local roleData = self.roleDataList[resp.touserid]
	if roleData then
		roleData:changeDir(resp)
	end
end

--玩家视野中心点变化通知以及主球通知
function RoleDataManager:centerNotify(resp)
	local roleData = self.roleDataList[resp.userid]
	if roleData then
		roleData:centerNotify(resp)
	end
end

--核对玩家位置返回
function RoleDataManager:checkPosNotify(resp)
	local roleData = self.roleDataList[resp.userid]
	if roleData then
		roleData:checkPosNotify(resp.balls, resp.time)
	end
end

------------------------------------------单机版本接口-------------------------------------
function RoleDataManager:safeNotify(resp)
	local roleData = self.roleDataList[resp.userid]
	dump( self.roleDataList )
	if roleData then
		roleData:safeNotify(resp.safe)
	end
end

--实体属性变化通知
function RoleDataManager:singlePropertyNotify(resp)
	local roleData = self.roleDataList[resp.userid]
	if roleData then
		roleData:singlePropertyNotify(resp.weight_set, resp.directset)
	end
end

--主球通知
function RoleDataManager:primaryNotify(resp)
	for i = 1, #resp do
		self.roleDataList[resp[i].userid]:primaryNotify(resp[i])
	end
end


return RoleDataManager
