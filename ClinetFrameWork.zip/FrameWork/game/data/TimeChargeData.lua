TimeChargeData = 
{
     index = 3, -- 活动ID
     timeout = 0, -- 剩余时间
}
