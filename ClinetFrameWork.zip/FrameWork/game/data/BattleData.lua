local BattleData = class("BattleData")

function BattleData:ctor()
	self:resetBattleData()
	self:resetSettingData()
end

function BattleData:resetBattleData( )
	self.battleInfo = {}
	self.matchData = nil
	self.joyDir = -1
	self.netDelta = 0
	self.syncTimeDelta = 0 

	self.syncCD = 0
	self.isSyncTime = true			
end

function BattleData:resetSettingData()
	self.settingInfo = {
		musicEnable = true,							--背景音乐配置
		effectEnable = true,						--音效配置
		skinEnable = true,							--皮肤配置
		talkEnable = false,							--语音配置
		qualityValue = 2,							--游戏画面质量配置
		battleBgValue = 2,							--战斗背景配置
		handValue = 2,								--战斗左右手
	}
end				

cc.exports.BattleData = BattleData:create()