local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()
local EConfig = cfg:getTable("entityConfig") 
local RoleData = class("RoleData")

function RoleData:ctor(userid)
	self.userID = userid

	self.elementList = {} 				--实体列表
	self.foodList = {}					--养分
	self.userList = {} 					--实体分类索引列表(草球，喷射养分，玩家球体)
	self.peerList = {}

end

function RoleData:update(dt)
	for k, v in pairs(self.elementList) do
		v:update(dt)
	end

	--如果是玩家自己，则记录下战斗中的最大分数
	if self.userID == GameData.battleInfo.userID then
		local score = Utils:getTotalBallScore()
		if score > GameData.battleInfo.maxScore then
			GameData.battleInfo.maxScore = score
		end
	end
end

function RoleData:addElementToUser(userid, eid, turnDir)
	if not self.userList[userid] then
		self.userList[userid] = {
			userID = userid,
			dir = turnDir,
			merge_time = socket.gettime(),
			balls = {},
		}
	else
		table.removebyvalue(self.userList[userid].balls, eid)
	end

	table.insert(self.userList[userid].balls, eid)
	-- table.sort(self.userList[userid].balls, function(a, b) return a < b end)
end

function RoleData:removeElementFromUser(userid, eid)
	-- print("removeElementFromUser=-==="..eid)
	table.removebyvalue(self.userList[userid].balls, eid)
end


----------------------------------服务器通知接口--------------------------------------
function RoleData:stateNotify(enter, leave, move, dead, time)
	if enter then
		for k, v in pairs(enter) do
			local ed = require("data.ElementData"):create(self, v)
			self.elementList[v.eid] = ed

			self:addElementToUser(ed.userID, ed.eid, ed.turnDir)
		end
	end

	if leave then
		for k, v in pairs(leave) do
			local ball = self.elementList[v]
			if ball then
				self:removeElementFromUser(ball.userID, ball.eid)
				self.elementList[v] = nil
			end
		end
	end

	if move then
		for k, v in pairs(move) do
			if self.elementList[v.eid] then
				self.elementList[v.eid]:setPos(v.x, v.y, time)
			end
		end
	end

	if dead then
		for k, v in pairs(dead) do
			local eid, eat_eid = Utils:sepInt32ToInt16(v)
			local ball = self.elementList[eid]
			if ball then
				self:removeElementFromUser(ball.userID, ball.eid)
				self.elementList[eid] = nil
			end
		end
	end
end

function RoleData:propertyNotify(score)
	if score then
		for k, v in pairs(score) do
			-- print("eid==="..v.eid..";"..tostring(self.elementList[v.eid])..";"..v.weight)
			if self.elementList[v.eid] then
				self.elementList[v.eid]:setScore(v.weight)
			end
		end
	end
end

function RoleData:foodNotify(enter, leave)
	for k, v in pairs(leave) do
		if v.entities then
			for m, n in pairs(v.entities) do
				self.foodList[n] = nil
			end
		end
	end

	for k, v in pairs(enter) do
		self.foodList[v.eid] = {eid = v.eid, x = v.x, y = v.y}
	end
end

function RoleData:peerNotify( users )

	for k, v in pairs(users) do
		self.peerList[v.userid] = {weight = v.weight, x = v.x, y = v.y}
	end
end

function RoleData:changeDir(resp)
	local user = self.userList[resp.userid]

	if user then
		user.dir = resp.rotation / 10000

		for i = 1, #user.balls do
			local ed = self.elementList[user.balls[i]]

			if ed then
				ed:changeDir(resp.rotation)
			end
		end
	end
end

function RoleData:centerNotify(resp)
	for k, v in pairs(resp.center) do
		local user = self.userList[v.userid]
		if user then
			user.merge_time = (tonumber(v.merge_time) + GameData.syncTimeDelta) / 1000

			--设置其他玩家的主球
			if GameData.battleInfo.userID ~= v.userid then
				for i = 1, #user.balls do
					local ed = self.elementList[user.balls[i]]

					if ed then
						ed:setPrimary(v.eid, v.x, v.y)
					end
				end
			end
		end
	end

	for k, v in pairs(resp.together) do
		local user = self.userList[v.userid]

		for i = 1, #user.balls do
			local ed = self.elementList[user.balls[i]]

			if ed then
				ed:setCenter(v.x, v.y)
			end
		end
	end
end

function RoleData:checkPosNotify(balls, time)
	for k, v in pairs(balls) do
		local ed = self.elementList[v.eid]
		if ed then
			ed:checkPos(v.x, v.y, time)
		end
	end
end


----------------------------------每帧刷新调用--------------------------------------
--碰撞处理
function RoleData:collsionHandle(ballDis, disSum, ball1, ball2, r1, r2)
	local dir1 = Utils:getMoveDirection(cc.p(ball2.x, ball2.y), cc.p(ball1.x, ball1.y))
	local dir2 = Utils:getMoveDirection(cc.p(ball1.x, ball1.y), cc.p(ball2.x, ball2.y))

	if dir1 and dir2 then
		dir1 = math.floor(dir1)
		dir2 = math.floor(dir2)
		local overlap = disSum - ballDis

		local rad1 = math.rad(dir1)
		local radio2 = r2 / disSum
		ball1.x = ball1.x + overlap * radio2 * math.cos(rad1)
		ball1.y = ball1.y + overlap * radio2 * math.sin(rad1)
		ball1:boundaryJudge()

		local rad2 = math.rad(dir2)
		local radio1 = r1 / disSum
		ball2.x = ball2.x + overlap * radio1 * math.cos(rad2)
		ball2.y = ball2.y + overlap * radio1 * math.sin(rad2)
		ball2:boundaryJudge()
	end
end

--碰撞检测
function RoleData:collsion()
	local time = socket.gettime()
	for k, v in pairs(self.userList) do
		if tonumber(v.userID) and tonumber(v.userID) > 0 or tonumber(v.userID) < -1000000 and time < v.merge_time then
			for i = 1, #v.balls do
				local ed_i = self.elementList[v.balls[i]]

				if ed_i then
					for j = i + 1, #v.balls do
						local ed_j = self.elementList[v.balls[j]]

						if ed_j then
							local r1 = Utils:getBallDia(ed_i.score) / 2
							local r2 = Utils:getBallDia(ed_j.score) / 2
							local disSum = r1 + r2
							local dis = cc.pGetDistance(cc.p(ed_i.x, ed_i.y), cc.p(ed_j.x, ed_j.y))

							if dis < disSum then
								self:collsionHandle(dis, disSum, ed_i, ed_j, r1, r2)
							end
						end
					end
				end
			end
		end
	end
end

--设置玩家自己的主球
function RoleData:setPrimary()
	-- print("setPrimary==========")
	local user = self.userList[GameData.battleInfo.userID]
	if user and user.dir >= 0 then
		local rad = math.rad(user.dir)
		local dx = math.cos(rad)
		local dy = math.sin(rad)

		local eid = nil
		local maxD = nil

		--获取移动方向上，最前面的球为主球
		for i = 1, #user.balls do
			local ed = self.elementList[user.balls[i]]

			if ed then
				local dis = ed.x * dx + ed.y * dy

				if not maxD or dis > maxD then
					maxD = dis
					eid = user.balls[i]
				end
			end
		end

		--设置每个球中的主球eid和坐标
		if eid and self.elementList[eid] then
			local x = self.elementList[eid].x
			local y = self.elementList[eid].y

			for i = 1, #user.balls do
				local ed = self.elementList[user.balls[i]]

				if ed then
					ed:setPrimary(eid, x, y)
				end
			end
		end
	end
end


-----------------------------------单机版本接口-------------------------------------
function RoleData:safeNotify(safe)
	for k, v in pairs(safe) do
		local ed = self.elementList[v]

		if ed then
			ed:setIsSafe(0)
		end
	end
end

--实体属性变化通知
function RoleData:singlePropertyNotify(score, rotation)
	for k, v in pairs(score) do
		if self.elementList[v.eid] then
			self.elementList[v.eid]:setScore(v.weight)
		end
	end

	for k, v in pairs(rotation) do
		if self.elementList[v.eid] then
			self.elementList[v.eid]:setRotation(v.rotation)
		end
	end
end

--主球通知
function RoleData:primaryNotify(resp)
	local user = self.userList[resp.userid]

	for i = 1, #user.balls do
		local ed = self.elementList[user.balls[i]]

		if ed then
			ed:setPrimary(resp.eid, resp.x, resp.y)
		end
	end
end


return RoleData
