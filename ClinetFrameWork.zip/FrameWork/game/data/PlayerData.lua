PlayerDataBasic = {
         cur_diamond       = 0,
         cur_skin          = 30108,
         cur_star          = 0,
         cur_lollipop      = 0,
         first_charge      = 0,
         gacha_coupon1     = 0,
         gacha_coupon2     = 0,
         gacha_coupon3     = 0,
         gacha_num1        = 0,
         gacha_num2        = 0,
         gacha_num3        = 0,
         gender            = 0,
         id                = "8934238948239047",
         nickname          = "***",
         play_count        = 0,
         rmb               = 0,
         round_count       = 0,
         score             = 0,
         total_kill        = 0,
         total_mvp         = 0,
         total_online_time = 0,
         version           = 0,
         vip               = 0,
         vip_time          = 0,
         weight            = 0,
         year           = 2000,
         month             = 1,
         day               = 1,
         area              = 1,
         charge_activity1 = 0,
         charge_activity2 = 0,
         charge_activity3 = 0,
         charge_activity4 = 0,
         charge_activity5 = 0,
         charge_activity6 = 0,
         charge_activity7 = 0,
         charge_activity8 = 0,
         charge_activity9 = 0,
         charge_activity10 = 0,
}

PlayerDataSystem = {
         bind_name         = "1234222",
         channel           = 1,
         device_type       = 1, -- 1 ANDROID, 2 IOS
         id                = "555556445704808609",
         invalid           = true,
         last_device       = "50A4C8D11116",
         last_ip           = "192.168.6.123",
         last_login_time   = 1521620608,
         last_logout       = 1521620276,
         login_count       = 17, -- 登陆数, 判断新用户
         login_day         = 1,
         ostype            = 1,
         register_time     = 1521603107,
         state             = 0,
         total_online_time = 5673,
         user_name         = "",
}


PlayerDataCustom = {
         redeem_count      = 0, --玩家用过的兑换券数
         guide_step        = 0, --新手引导过过程步
         AD_available_num  = 0,  --玩家积累可以看广告次数
         AD_num            = 0, --玩家积累已经观看广告次数
         lottery_num       = 0, --玩家拥有抽奖次数(广告)
                 

}

PlayerData_AD_show_look_btn = false  --显示看广告按钮
PlayerData_AD_show_loot_btn = false  --显示抽奖按钮
PlayerData_AD_show_enter_btn = false --显示进入广告按钮