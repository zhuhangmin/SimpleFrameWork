ChargeData = 
{
     ex9  =   0, -- 0 未充值过， 1 充值过
     ex3  =   0,
     ex4  =   0,
     ex1  =   0,
     ex6  =   0,
     ex5  =   0,
     ex2  =   0,
     ex8  =   0,
     ex10 =   0,
     ex11 =   0,
     ex7  =   0,
     ex12 =   0,
}

ChargeData_curOrderID = 0 -- 当前订单号