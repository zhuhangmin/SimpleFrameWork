MailData = {
	 [1] = {
         -- content     = "亲爱的玩家：欢迎来到萌菌的世界，我是你的小助手",
         id          = "6537594438242402305",
         isread      = 0,
         outtime     = 604800,
         recver      = "564457084079378434",
         reward      = 1,
         rewardstate = 0,
         sender      = 0,
         sendtime    = 1522152659,
         title       = "欢迎您的加入",
         type        = "NEW",
     },
     [2] = {
         -- content     = "亲爱的玩家：欢迎来到萌菌的世界，我是你的小助手",
         id          = "6537594438242402306",
         isread      = 0,
         outtime     = 604800,
         recver      = "564457084079378434",
         reward      = 1,
         rewardstate = 0,
         sender      = 0,
         sendtime    = 1522152659,
         title       = "欢迎您的加入",
         type        = "RECHARGE",
     }
}


MailData_unReadMailExist = 0 -- 是否有未读邮件 1 有， 0 无