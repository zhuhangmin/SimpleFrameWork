GachaData = {
   --  "STAR" = {
   --      "cost" = 1000
   --      "des"  = "有几率获得皮肤"
   --      "coupon" = 56001
   --       double = 1  -- 1 为可双倍获得
   --       icon = "12312" 
   --  }
   -- "DIAMOND" = {
   --      "cost" = 60
   --      "des"  = "再扭4次必得皮肤"
   --      "coupon" = 56002
   --       double = 1  -- 1 为可双倍获得
   --       icon = "12312" 
   --  }
   --  "FIVE_DIAMOND" = {
   --      "cost" = 270
   --      "des"  = "本次必得皮肤"
   --      "coupon" = 56003
   --       double = 1  -- 1 为可双倍获得
   --       icon = "12312" 
   --  }
   
}
