local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()

local NConfig = cfg:getConfigRecord("netBattle",1)
local EConfig = cfg:getTable("entityConfig") 
local ElementData = class("ElementData")

function ElementData:ctor(parent, info)
	self.parent = parent
	self.frameDt = 0
	self.lastFrameTime = math.floor(socket.gettime() * 1000)

-------------------------------info数据(协议)-------------------------------------
	self.eid = info.eid
	self.userID = info.userid
	self.time = tonumber(info.time)
	self.x = info.x
	self.y = info.y
	self.speedx = info.speedx
	self.speedy = info.speedy
	self.turnDir = info.turndir / 10000
	self.safeTime = (tonumber(info.safetime) + GameData.syncTimeDelta) / 1000
	self.entity_id = info.entity_id
	self:setScore(info.weight)

-------------------------------自定义数据-----------------------------------------
	--保护时间状态 | 是否聚拢标志
	self.isSafe = 1
	self.isTogether = false

	--中心点坐标
	self.centerX = info.x
	self.centerY = info.y

	--移动方向 | 箭头旋转角度
	self.rotation = 0
	self.destDir = 0
	self.angleVec = 0
	self.actDir = 0

	--主球的edi和坐标
	self.primaryEid = 0
	self.primaryX = 0
	self.primaryY = 0
	self:setPrimary(info.eid, info.x, info.y)

	--追帧增量补偿
	self.vIncreX = 0
	self.vIncreY = 0
	self.increFrameCount = 0
	self.vRate = 0

	self.DConfig = cfg:getConfigRecord("room",GameData.roomType) 
end

--计算位移
function ElementData:calcMove(dt)
	local sx, sy, vx, vy = 0, 0, 0, 0
	-- print("self.turnDir==="..self.turnDir)
	-- print("self.isTogether"..tostring(self.isTogether))
	if self.turnDir >= 0 or self.isTogether then
		local velocity = 0
		local e_type = EConfig[self.entity_id].type
		if e_type ~= "GRASS" and e_type ~= "JETFOOD" then
			-- local radius = Utils:getBallDia(self.score) * 0.5
			velocity = Utils:getVelocityByScore(self.score)
		end

		sx, sy, vx, vy = Utils:getDeltaMove(self.speedx, self.speedy, velocity, self.actDir, dt)
		-- if tonumber(self.userID) > 0 and tonumber(self.userID) ~= tonumber(GameData.battleInfo.userID) then
		-- 	print("eid ==========="..sx..";"..sy..";"..vx..";"..vy..";"..velocity..";"..self.actDir)
		-- end
				-- print("sx=="..sx..";"..sy..";"..vx..";"..vy..";"..velocity..";"..self.score)
	end

	return sx, sy, vx, vy
end


------------------------------------ 外部设置接口--------------------------------------
--设置主球
function ElementData:setPrimary(eid, x, y)
	self.primaryEid = eid
	self.primaryX = x
	self.primaryY = y
end

--设置实体位置(主要用于当前视野范围内非当前玩家的位置，当前玩家的位置用checkPos为准)
function ElementData:setPos(x, y, time)
	-- if GameData.mode == Constant.GameMode.ALIVE then
		if self.userID ~= GameData.battleInfo.userID and self.userID ~= "0" then
			local _x = x
			local _y = y

			--根据时间差，计算新坐标和速度
			local sTime = time + GameData.syncTimeDelta
			local dt = (self.lastFrameTime - sTime) / 1000

			if dt > 0 then
				local sx, sy, vx, vy = self:calcMove(dt)

				_x = _x + sx
				_y = _y + sy

				self.speedx = vx
				self.speedy = vy
			end

			--计算补帧数量
			local stepT = (1 / 60) * NConfig.OTHER_INCRE_FRAME_COUNT
			self.vIncreX = (_x - self.x) / stepT
			self.vIncreY = (_y - self.y) / stepT
			self.increFrameCount = NConfig.OTHER_INCRE_FRAME_COUNT
		end
	-- else
	-- 	self.x = x
	-- 	self.y = y
	-- end
end

--设置分数
function ElementData:setScore(score)
	self.score = score
end

--实体方向改变
function ElementData:changeDir(dir)
	-- if tonumber(self.userID) > 0 and tonumber(self.userID) ~= tonumber(GameData.battleInfo.userID) then
	-- 	print("eid ==========="..(tostring(dir)))
	-- end
	self.turnDir = dir / 10000

	if self.turnDir >= 0 then
		self.isTogether = false
	end
end

--设置中心点位置
function ElementData:setCenter(x, y)
	self.centerX = x
	self.centerY = y

	self.isTogether = true
end

--同步位置(只有自己才会走位置校验，其他玩家都走setPos去设置位置)
function ElementData:checkPos(x, y, time)
	local _x = x
	local _y = y
	local sTime = time + GameData.syncTimeDelta
	local dt = (self.lastFrameTime - sTime) / 1000

	if dt > 0 then
		local sx, sy, vx, vy = self:calcMove(dt)

		_x = _x + sx
		_y = _y + sy

		self.speedx = vx
		self.speedy = vy
	end

	--计算补帧数量
	local stepT = (1 / 60) * NConfig.SELF_INCRE_FRAME_COUNT
	self.vIncreX = (_x - self.x) / stepT
	self.vIncreY = (_y - self.y) / stepT
	self.increFrameCount = NConfig.SELF_INCRE_FRAME_COUNT
end


------------------------------------帧刷新--------------------------------------
function ElementData:update(dt)
	self.lastFrameTime = math.floor(socket.gettime() * 1000)

	--计算是否保护状态
	self:updateIsSafe(self.lastFrameTime)

	--如果是本体球，则实时更新自己的分数
	if self.userID == GameData.battleInfo.userID then
		self:updateScore(dt)
		-- print("self.x===="..self.x..';'..self.y)
	end

	--只要不是草丛，就更新方向和位置
	if self.userID ~= "0" then
		self:updateRotation()
		self:updateDir()
		self:updatePos(dt)
	end
end

--判断是否处于安全状态
function ElementData:updateIsSafe(time)
	if (time / 1000) < self.safeTime then
		self.isSafe = 1
	else
		self.isSafe = 0
	end
end

function ElementData:updateScore(dt)
	self.frameDt = self.frameDt + dt

	if self.frameDt >= 1 then
		self.frameDt = self.frameDt - 1

		if self.score > self.DConfig.min_score then
			local score = Utils:getBallReduceScore(self.score)

			if score < self.DConfig.min_score then
				score = self.DConfig.min_score
			end

			self.score = score
		end
	end
end

function ElementData:updateRotation()
	local angle = self.rotation - self.destDir

	if math.abs(angle) > 180 then
		if angle > 0 then
			angle = self.rotation - (self.destDir + 360)
		else
			angle = self.rotation + 360 - self.destDir
		end
	end

	--判断是否达到目标角度(这边用乘法判断原因是：判断是否有可能超过)
	if angle * self.angleVec < 0 then
		self.rotation = self.rotation + self.angleVec
	else
		self.rotation = self.destDir
	end
end

--更新方向
function ElementData:updateDir()
	-- if tonumber(self.userID) > 0 and tonumber(self.userID) ~= tonumber(GameData.battleInfo.userID) then
	-- 	print("eid ==========="..(tostring(self.isTogether)) ..";"..self.turnDir..";"..self.eid..";" ..self.primaryEid)
	-- end
	if self.isTogether then
		if #self.parent.userList[self.userID].balls <= 1 then
			self.turnDir = -1
			self.isTogether = false
		else
			if math.floor(self.x) ~= self.centerX or math.floor(self.y) ~= self.centerY then
				local direct = Utils:getMoveDirection(cc.p(self.x, self.y), cc.p(self.centerX, self.centerY))

				if direct then
					direct = math.floor(direct)
					self.actDir = direct
				end
			end
		end
	else
		if self.turnDir >= 0 then
			if self.eid ~= self.primaryEid then
				local dir = Utils:getMoveDirection(cc.p(self.x, self.y), cc.p(self.primaryX, self.primaryY))

				if dir then
					dir = math.floor(dir)
					local angle = math.abs(dir - self.turnDir)

					if angle >= 180 then
						self.actDir = ((self.turnDir + dir + 360) / 2) % 360
					else
						self.actDir = (self.turnDir + dir) / 2
					end
				else
					self.actDir = self.turnDir
				end
			else
				self.actDir = self.turnDir
			end
		end
	end

	if self.destDir ~= self.actDir then
		self.destDir = self.actDir
		self:calcRotationAngle()
	end
end

--计算箭头旋转速度
function ElementData:calcRotationAngle()
	local angle = self.destDir - self.rotation
	local frameCount = NConfig.TURN_FRAME_COUNT

	if math.abs(angle) > 180 then
		if angle > 0 then
			self.angleVec = (self.destDir - (self.rotation + 360)) / frameCount
		else
			self.angleVec = (self.destDir + 360 - self.rotation) / frameCount
		end
	else
		self.angleVec = angle / frameCount
	end
end

function ElementData:updatePos(dt)
	local sx, sy, vx, vy = self:calcMove(dt)
	self.x = self.x + sx
	self.y = self.y + sy
	-- print("sx=="..self.x..";"..self.y)
	
	self.speedx = vx
	self.speedy = vy

	--补帧
	self:calcIncreMove(sx,sy)

	--边界判断
	self:boundaryJudge()
	-- if tonumber(self.userID) > 0 and tonumber(self.userID) ~= tonumber(GameData.battleInfo.userID) then
	-- 	print("eid ==========="..self.eid ..";"..self.x..";"..self.y)
	-- end

end

--计算增量位移（追帧）
function ElementData:calcIncreMove(sx,sy)
	local dt = 1 / 60

	if self.increFrameCount > 0 then
		if self.vRate == nil then --容错
			self.vRate = 0
		end
		if self.vRate < 2 then 
			self.vRate = self.vRate + 2/NConfig.SELF_INCRE_FRAME_COUNT
		end

		local dx = (self.vIncreX) * dt * self.vRate
		local dy = (self.vIncreY) * dt * self.vRate

		if math.abs(dx) < 100 then--防止峰值抖动
			self.x = self.x + dx
		else
			-- print("error net data ,move has risk")
		end

		if math.abs(dy) < 100 then--防止峰值抖动
			self.y = self.y + dy
		else
			-- print("error net data ,move has risk")
		end
		self.increFrameCount = self.increFrameCount - 1

		-- if tonumber(self.userID) > 0 and tonumber(self.userID) ~= tonumber(GameData.battleInfo.userID) then
		-- 	print("eid ==========="..self.eid ..";"..dx..";"..dy..";"..self.vRate)
		-- end
	else
		self.vRate = 0
	end
end

--边界判断
function ElementData:boundaryJudge()
	if self.x < 0 then
		self.x = 0
	elseif self.x > self.DConfig.battlefield_wide then
		self.x = self.DConfig.battlefield_wide
	end

	if self.y < 0 then
		self.y = 0
	elseif self.y > self.DConfig.battlefield_high then
		self.y = self.DConfig.battlefield_high
	end
end


----------------------------------单机版本接口------------------------------------
--设置安全状态(用于单机版本)
function ElementData:setIsSafe(is_safe)
	self.isSafe = is_safe
end

--设置角度(AI里面会用到)
function ElementData:setRotation(rotation)
	self.rotation = rotation
end


return ElementData
