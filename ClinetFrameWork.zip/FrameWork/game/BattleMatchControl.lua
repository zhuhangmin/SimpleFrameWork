local EngineControl = require  "EngineControl"
local MatchingControl = class("MatchingControl", EngineControl)
--LUA MSGS
local LUA_MSGS = {
    -- BattleMsg.MATCH_DATA  --主界面接收
}

--SYSTEM MSGS
local BTN_CANCEL = "Button_return"
local SYSTEM_MSGS = {
	BTN_CANCEL,
}

function MatchingControl:ctor(model, view)
	MatchingControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
end

function MatchingControl:onCreate(param)
	MatchingControl.super.onCreate(self, param)
	NetFunc.match:enterMatch()
	self.showBtn = false
	self.matchData = nil
    self:initUi()
    -- self:startORIGScheduler()
    self:startScheduler()
end

----------------------------------定时器--------------------------------------

function MatchingControl:onUpdate(dt)
	local model = self:getModel()
	local count = model:getCount()
	count = count + 1
	model:setCount(count)
	local interval = model:getInterval()

	if count % interval == 0 then
		model:setCount(0)
	
		local time = model:getTime()
		time = time + 1
		model:setTime(time)
		local MATCH_CANCLE_TIME = self:getConfigField("global",1,"MATCH_CANCLE_TIME")/1000

		if time > MATCH_CANCLE_TIME and not self.showBtn then
			self.showBtn = true
			self:getChildNode(BTN_CANCEL):setVisible( true )
		end
	end
end


-- function MatchingControl:startORIGScheduler()
-- 	local MATCH_CANCLE_TIME = self:getConfigField("global",1,"MATCH_CANCLE_TIME")/1000
-- 	self.time = 1

-- 	local function update(  )
-- 		self.time = self.time + 1
-- 		if self.time > MATCH_CANCLE_TIME and not self.showBtn then
-- 			self.showBtn = true
-- 			self:getChildNode(BTN_CANCEL):setVisible( true )
-- 		end

-- 		-- if self.time > 1 then
-- 		-- 	self:matchGame()
-- 		-- end
-- 	end
	
-- 	if not self.frameID then
-- 		self.frameID = gScheduler:scheduleScriptFunc(handler(self, update), 1, false)
-- 	end
-- end

-- function MatchingControl:cancelSchedule()
-- 	if self.frameID then
-- 		gScheduler:unscheduleScriptEntry(self.frameID)
-- 		self.frameID = nil
-- 	end
-- end

function MatchingControl:matchGame(  )
	-- print("match end PUSH battle")
	if GameData.matchData then
		-- self:cancelScheduler()
		-- NetFunc.match:exitMatch()
		self:send(BASE_MSG.PUSH, {name = "game.Battle"})
	end
end

function MatchingControl:initUi()
 	self:getChildNode(BTN_CANCEL):setVisible( self.showBtn )
end

function MatchingControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_CANCEL then
		-- self:cancelScheduler()
		NetFunc.match:exitMatch()
		self:detachFromParent()
	end
end

function MatchingControl:recv(event)
	if isNil(event) then printStack() end
	if isNil(event.name) then printStack() end
	if isNil(event.data) then printStack() end
	-- print("MatchingControl:recv name = " .. tostring(event.name))
	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

	-- if name == BattleMsg.MATCH_DATA then
	-- 	self:matchGame()
	-- 	return
	-- end	
end

return MatchingControl;