local EngineControl = require  "EngineControl"
local BattleOverControl = class("BattleOverControl", EngineControl)
--LUA MSGS
local LUA_MSGS = {
    BattleMsg.UP_RANK,
	BattleMsg.DOWN_RANK,
	BattleMsg.UP_STAR,
	BattleMsg.DOWN_STAR,
	BattleMsg.NONE_STAR,
}

--SYSTEM MSGS
local BTN_CANCEL = "Button_return"
local BTN_MORE = "Button_onemore"
local BTN_BACK = "Button_return_down"
local BTN_SHARE = "Button_share"
local SYSTEM_MSGS = {
	BTN_CANCEL,
	BTN_MORE,
	BTN_BACK,
	BTN_SHARE,
}

function BattleOverControl:ctor(model, view)
	BattleOverControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
end

function BattleOverControl:onCreate(param)
	BattleOverControl.super.onCreate(self, param)
	
	
end

function BattleOverControl:onEnter( param )
	dump(param)
	dump(self.model.netData)

	self.tabIndex = - 1
	self.tabList = {}

	self.params = self.model.netData

	self.currIndex = 0
	self.maxCount = 0
	self.schedulerID = nil

	self.btnEnable = true
	
	self:initUi()
	print("GameData.mode===="..GameData.mode)
	
	self:startAction()
	self:startLoad()

end

function BattleOverControl:startAction()
	local action1 = cc.DelayTime:create(0)
	local action2 = cc.CallFunc:create(function()
		self:clickTab(1)
	 	if tostring(GameData.mode) == "2" then
 			local panel_name = "game.BattleTeamOver"
			local params = {}
			params.modelParam = {self.params}
		    self:addPanel(panel_name,params)
		end
	end)
	local action3 = cc.Sequence:create(action1, action2)
	self:getNode():runAction(action3)
end

function BattleOverControl:startLoad()
	if self.maxCount > 0 then
		self:startScheduler()
	end
end

function BattleOverControl:startScheduler()
	if not self.schedulerID then
		self.schedulerID = gScheduler:scheduleScriptFunc(handler(self, self.updateLoad), 0, false)
	end
end

function BattleOverControl:cancelScheduler()
	if self.schedulerID then
		gScheduler:unscheduleScriptEntry(self.schedulerID)
		self.schedulerID = nil
	end
end

function BattleOverControl:updateLoad(dt)
	self.currIndex = self.currIndex + 1

	if self.currIndex <= self.maxCount then
		local item = require("battle.Node.OverAliveRankNode"):create(self.currIndex, false, self.params.alluser[self.currIndex])
		self.rankListView:pushBackCustomItem(item)
	else
		self.rankListView:jumpToTop()
		self:cancelScheduler()
	end
end

function BattleOverControl:initUi()
	self:addPanel("game.Riches")
	print("initUi")
 	local rootNode = self:getNode():getChildByName("csbNode")
 	self:getChildNode("Text_title"):setString("结算")

	-- local x = gScreenSize.width - self.richesLayer:getContentSize().width / 2 - 40
	-- local y = backBtn:getPositionY() - 3
	-- self.richesLayer:setPosition(x, y)

	self:initOver(rootNode)
	self:initMine(rootNode)
	self:initBtn(rootNode)
end

function BattleOverControl:initBtn(node)
	local againBtn = node:getChildByName("Button_onemore")

	local backMainBtn = node:getChildByName("Button_return_down")

	local shareBtn = node:getChildByName("Button_share")

	if not SDKFunc.share:isSupport() then
		shareBtn:setVisible(false)
		-- againBtn:setPositionX(againBtn:getPositionX() + 350)
	 	againBtn:setVisible(false) -- change 
		backMainBtn:setPositionX(backMainBtn:getPositionX() + 350)
	end

	--用户转化入口
	-- Utils:checkUserConvert(cc.p(gScreenSize.width / 2, againBtn:getPositionY()))
end

function BattleOverControl:initOver(node)
	self.tabList[1] = {}

	self.tabList[1].btn = node:getChildByName("Button_total")
	self.tabList[1].btn:loadTextureNormal("tongyong/btn_xiaoyeqian1.png", ccui.TextureResType.plistType)
	self.tabList[1].btn:loadTexturePressed("tongyong/btn_xiaoyeqian2.png", ccui.TextureResType.plistType)
	self.tabList[1].btn:addTouchEventListener(handler(self, self.clickOver))

	self.tabList[1].focusLabel = self.tabList[1].btn:getChildByName("Text_total_2")
	self.tabList[1].focusLabel:setVisible(false)

	self.tabList[1].normalLabel = self.tabList[1].btn:getChildByName("Text_total_1")
	self.tabList[1].normalLabel:setVisible(true)

	self.tabList[1].panel = node:getChildByName("Panel_total")
	self.tabList[1].panel:setVisible(false)

	--自己的结点
	local myImage = self.tabList[1].panel:getChildByName("Image_mine_bg")
	local myItem = require("battle.Node.OverAliveRankNode"):create(self.params.rank, true, self.params.alluser[self.params.rank])
	myItem:setPosition(5, 0)
	myImage:addChild(myItem)

	--列表
	self.rankListView = self.tabList[1].panel:getChildByName("ListView_total")
	self.maxCount = #self.params.alluser
end

function BattleOverControl:initMine(node)
	self.tabList[2] = {}

	self.tabList[2].btn = node:getChildByName("Button_mine")
	self.tabList[2].btn:loadTextureNormal("tongyong/btn_xiaoyeqian1.png", ccui.TextureResType.plistType)
	self.tabList[2].btn:loadTexturePressed("tongyong/btn_xiaoyeqian2.png", ccui.TextureResType.plistType)
	self.tabList[2].btn:addTouchEventListener(handler(self, self.clickMine))

	self.tabList[2].focusLabel = self.tabList[2].btn:getChildByName("Text_mine_2")
	self.tabList[2].focusLabel:setVisible(false)

	self.tabList[2].normalLabel = self.tabList[2].btn:getChildByName("Text_mine_1")
	self.tabList[2].normalLabel:setVisible(true)

	self.tabList[2].panel = node:getChildByName("Panel_mine")
	self.tabList[2].panel:setVisible(false)

	--panel内部控件
	local meEatListView = self.tabList[2].panel:getChildByName("ListView_mine_1")
	local count = self.params.alluser[self.params.rank].kill

	for i = 1, #self.params.meeat do
		local item = require("battle.Node.OverAliveEatNode"):create(self.params.meeat[i])
		meEatListView:pushBackCustomItem(item)

	end



	meEatListView:jumpToTop()

	local eatMeListView = self.tabList[2].panel:getChildByName("ListView_mine_2")
	for i = 1, #self.params.eatme do
		local item = require("battle.Node.OverAliveEatNode"):create(self.params.eatme[i])
		eatMeListView:pushBackCustomItem(item)
	end
	eatMeListView:jumpToTop()
	
	local maxWeightImage = self.tabList[2].panel:getChildByName("Image_weight")
	local maxWeightLabel = self.tabList[2].panel:getChildByName("Text_weight_amount")
	local weight = Utils:getWeightFromScore(self.params.maxweight)
	local str, index = Utils:getWeightString(weight)
	local WeightConfig = self:getConfigRecord("weightConfig",index) 
	maxWeightImage:loadTexture(WeightConfig.imgName, ccui.TextureResType.plistType)
	maxWeightLabel:setString(str)

	local killLabel = self.tabList[2].panel:getChildByName("Text_kill_amount")
	killLabel:setString(count)

	local aliveTimeLabel = self.tabList[2].panel:getChildByName("Text_time_amount")
	local time = math.floor(os.time() - GameData.enterTime)
	time = math.min(360,time)
	aliveTimeLabel:setString(string.format("%02d:%02d", math.floor(time / 60), time % 60))
end

function BattleOverControl:clickOver(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended then
		SoundManager:playEffect("button.mp3")
		self:clickTab(1)
	end
end

function BattleOverControl:clickMine(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended then
		SoundManager:playEffect("button.mp3")
		self:clickTab(2)
	end
end

function BattleOverControl:clickTab(index)
	if self.tabIndex ~= -1 then
		self.tabList[self.tabIndex].btn:setTouchEnabled(true)
		self.tabList[self.tabIndex].btn:loadTextureNormal("tongyong/btn_xiaoyeqian1.png", ccui.TextureResType.plistType)
		self.tabList[self.tabIndex].btn:loadTexturePressed("tongyong/btn_xiaoyeqian2.png", ccui.TextureResType.plistType)

		self.tabList[self.tabIndex].focusLabel:setVisible(false)
		self.tabList[self.tabIndex].normalLabel:setVisible(true)

		self.tabList[self.tabIndex].panel:setVisible(false)
	end

	self.tabIndex = index

	self.tabList[self.tabIndex].btn:setTouchEnabled(false)
	self.tabList[self.tabIndex].btn:loadTextureNormal("tongyong/btn_yeqian1.png", ccui.TextureResType.plistType)
	self.tabList[self.tabIndex].btn:loadTexturePressed("tongyong/btn_yeqian2.png", ccui.TextureResType.plistType)

	self.tabList[self.tabIndex].focusLabel:setVisible(true)
	self.tabList[self.tabIndex].normalLabel:setVisible(false)

	self.tabList[self.tabIndex].panel:setVisible(true)

	-- if index == 2 then
	-- 	SDKFunc.log:logEventData(Constant.LogEventName[14])
	-- end
end

function BattleOverControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_CANCEL then
		self:backEventExt()
	end

	if senderName == BTN_MORE then
		self:againEvent()
	end

	if senderName == BTN_BACK then
		self:backEventExt()
	end


	if senderName == BTN_SHARE then
		self:shareEvent()
	end
	
end

function BattleOverControl:againEvent()
	self:addPop("game.BattleMatch")
	-- self.btnEnable = false

	-- --数据埋点(再来一局)
	-- SDKFunc.log:logEventData(Constant.LogEventName[11])

	-- SoundManager:playEffect("button.mp3")

end

function BattleOverControl:shareEvent(sender, touchEventType)
	SDKFunc.log:logEventData(Constant.LogEventName[13])
	SDKFunc.share:shareToWeiXin()
end

function BattleOverControl:backEventExt()
	send_info("room.leave_room2", {})--请求结算宝箱

	self:cancelScheduler()

	-- --数据埋点(返回主页按钮，返回按钮，物理back按键，全部监听)
	-- SDKFunc.log:logEventData(Constant.LogEventName[12])
	self:send(BASE_MSG.GOHOME)
end


function BattleOverControl:recv(event)
	if isNil(event) then printStack() end
	if isNil(event.name) then printStack() end
	if isNil(event.data) then printStack() end
	print("BattleOverControl:recv name = " .. tostring(event.name))
	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

	if name == BattleMsg.UP_RANK then
		self:addAnime(name,data)
	end	

	if name == BattleMsg.DOWN_RANK then
		self:addAnime(name,data)
	end	

	if name == BattleMsg.UP_STAR then
		self:addAnime(name,data)
	end	

	if name == BattleMsg.DOWN_STAR then
		self:addAnime(name,data)
	end	

	if name == BattleMsg.NONE_STAR then
		self:addAnime(name,{})
	end	
end

function BattleOverControl:addAnime( name, data )
	local panel_name = "game.BattleReward"
	local params = {}
	params.modelParam = {anime = name,data = data,num = self.params.rank}
	dump(params)
	self:addPop(panel_name,params) 
end


return BattleOverControl;