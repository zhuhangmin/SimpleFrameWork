local EngineView = require "EngineView"
local LoadingView = class("LoadingView", EngineView)

local csbFilePath = "res/Loading.csb"

function LoadingView:ctor(node)
	LoadingView.super.ctor(self, node)
end

function LoadingView:onCreate(param)
	LoadingView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	if isNil(csbNode) then printStack() return end

	local node = self:getNode()
	if isNil(node) then printStack() return end	
	
	node:addChild(csbNode)

end

return LoadingView





