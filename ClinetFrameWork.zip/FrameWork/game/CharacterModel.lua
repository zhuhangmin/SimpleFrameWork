local EngineModel = require "EngineModel"
local CharacterModel = class("CharacterModel", EngineModel)

function CharacterModel:ctor(data)
	CharacterModel.super.ctor(self, data)

	self.curPage = 1
	self.needPanel = {}
	self.btnLeftList = {}
	self.menuList = {}
	self.leftskinindex = 0
	self.leftskindata = {}
	self.curClickNode = nil
end

function CharacterModel:onCreate(param)
	CharacterModel.super.onCreate(self, param)
end

function CharacterModel:getCurPage()
	return self.curPage
end

function CharacterModel:setCurPage(curPage)
	self.curPage = curPage
end

function CharacterModel:getNeedPanel()
	return self.needPanel
end

function CharacterModel:setNeedPanel(needPanel)
	self.needPanel = needPanel
end

function CharacterModel:getBtnLeftList()
	return self.btnLeftList
end

function CharacterModel:setBtnLeftList(btnLeftList)
	self.btnLeftList = btnLeftList
end

function CharacterModel:getHaveList()
	return self.menuList[1]
end

function CharacterModel:setHaveList(haveList)
	self.menuList[1] = haveList
end

function CharacterModel:getEvolutionList()
	return self.menuList[2]
end

function CharacterModel:setEvolutionList(evolutionList)
	self.menuList[2] = evolutionList
end

function CharacterModel:getFragmentList()
	return self.menuList[3]
end

function CharacterModel:setFragmentList(fragmentList)
	self.menuList[3] = fragmentList
end

function CharacterModel:getMenuList()
	return self.menuList
end

function CharacterModel:getLeftskinindex()
	return self.leftskinindex
end

function CharacterModel:setLeftskinindex(leftskinindex)
	self.leftskinindex = leftskinindex
end

function CharacterModel:getLeftskindata()
	return self.leftskindata
end

function CharacterModel:setLeftskindata(leftskindata)
	self.leftskindata = leftskindata
end

function CharacterModel:getCurClickNode()
	return self.curClickNode
end

function CharacterModel:setCurClickNode(curClickNode)
	self.curClickNode = curClickNode
end



return CharacterModel

