local EngineModel = require "EngineModel"
local CulturingRoomModel = class("CulturingRoomModel", EngineModel)

function CulturingRoomModel:ctor(data)
	CulturingRoomModel.super.ctor(self, data)

	self.cultures = {}
	self.reward = {}
end

function CulturingRoomModel:onCreate(param)
	CulturingRoomModel.super.onCreate(self, param)
end

function CulturingRoomModel:setCultures(cultures)
	self.cultures = cultures
end

function CulturingRoomModel:getCultures()
	return self.cultures
end

function CulturingRoomModel:setReward(reward)
	self.reward = reward
end

function CulturingRoomModel:getReward()
	return self.reward
end

return CulturingRoomModel

