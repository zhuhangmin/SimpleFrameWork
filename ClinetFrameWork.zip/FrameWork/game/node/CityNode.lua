
local CityNode = class("CityNode", function()
	return ccui.Widget:create()
end)

function CityNode:ctor(index)
	self.index = index

	self:init()
end

function CityNode:init()
	local rootNode = cc.CSLoader:createNode("res/City.csb")
	self:addChild(rootNode)

	self:setAnchorPoint(0, 0)
	self:setContentSize(rootNode:getContentSize())
	self:setTouchEnabled(true)
	self:addTouchEventListener(handler(self, self.clickEvent))

	self.cityLabel = rootNode:getChildByName("Text_city")
	self.cityLabel:setString(DConfig.CITY_LIST[self.index].fName)

	self.selectedImage = rootNode:getChildByName("Image_right")
end

--设置是否选中
function CityNode:setSelect()
	self.cityLabel:setTextColor(cc.c3b(255, 90, 0))
	self.selectedImage:setVisible(true)
end

function CityNode:setNormal()
	self.cityLabel:setTextColor(cc.c3b(0, 58, 137))
	self.selectedImage:setVisible(false)
end

--点击选中
function CityNode:clickEvent(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended then
		MsgManager:sendMsg(GameMsg.MSG_CHANGE_SELECT_CITY, self.index)
	end
end


return CityNode