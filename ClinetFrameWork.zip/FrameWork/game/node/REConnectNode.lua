
local REConnectNode     = class("REConnectNode")
function REConnectNode:create(count)
    
    return REConnectNode.new(count)
end

function REConnectNode:ctor(count)
    --数据
    self._Count                 = count
    self._Parent                = nil
    self:init()
end

function REConnectNode:init()
     --资源
    self._NodeREConnect = cc.CSLoader:createNode("res/Node_REConnectPanel.csb")
    self._Parent = gDirector:getRunningScene()
    self._Parent:addChild(self._NodeREConnect)
    self._NodeREConnect:setPosition(gScreenSize.width / 2, gScreenSize.height /5)
	local action = cc.CSLoader:createTimeline("res/Node_REConnectPanel.csb")
	self._NodeREConnect:runAction(action)
    action:play("run_reconnect_ani",true)
end

function REConnectNode:hide()
    if self._Parent == gDirector:getRunningScene() then
        self._NodeREConnect:removeSelf()
        self._NodeREConnect = nil
    end 
end

function REConnectNode:isVisible()
    if self._Parent == gDirector:getRunningScene() and self._NodeREConnect then
        return true
    end 
    return false
end 

return REConnectNode 