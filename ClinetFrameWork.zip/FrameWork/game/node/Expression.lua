
local Expression = class("Expression", function()
	return cc.Sprite:createWithSpriteFrameName("zd/zd_bq_pao.png")
end)

function Expression:ctor(callback)
	self.cb = callback
	self.loopCount = 0

	self:init()
end

function Expression:init()
	self:setAnchorPoint(cc.p(0, 0))
	self:setScale(1.70)

	local size = self:getContentSize()

	self.armature = ccs.Armature:create("mjdzzface")
	self.armature:setScale(1 / 1.7)
	self.armature:setPosition(size.width / 2, size.height / 2)
	self.armature:getAnimation():setMovementEventCallFunc(handler(self, self.movementEventCallback))
	self:addChild(self.armature)
end

function Expression:movementEventCallback(armature, type, movementID)
	if type == ccs.MovementEventType.loopComplete then
		self.loopCount = self.loopCount + 1

		if self.loopCount >= 5 then
			self.loopCount = 0
			self.armature:pause()

			if self.cb then
				self.cb()
			end
		end
	end
end

--播放表情(index；表情id，sex：性别)
function Expression:playExpression(index, sex)
	local s = 1
	if sex ~= 1 then
		s = 2
	end

	self.armature:resume()
	self.armature:getAnimation():play(Constant.BattleExpConfig[index][s].armature, -1, 1)
end


return Expression
