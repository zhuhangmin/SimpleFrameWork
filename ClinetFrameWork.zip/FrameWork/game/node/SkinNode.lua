
local SkinNode = class("SkinNode", function()
	return cc.CSLoader:createNode("res/SkinItem.csb")
end)

function SkinNode:ctor(type, lineIndex, index, skinIndex)
	self.type = type
	self.lineIndex = lineIndex
	self.index = index
	self.skinIndex = skinIndex

	self.state = nil
	self.count = -1
	self.cost = -1

	self:init()
	self:updateUI()
end

function SkinNode:init()
	local headImage = self:getChildByName("Image_skin")
	local headSize = headImage:getContentSize()
	headImage:setTouchEnabled(true)
	headImage:addTouchEventListener(handler(self, self.clickHead))

	local fileName, animName = Utils:getHeadImageInfo(ToolConfig[self.skinIndex].did, 256)
	local iconname = fileName.."_"..animName..".png"
	headImage:loadTexture(iconname,ccui.TextureResType.plistType)
	headImage:ignoreContentAdaptWithSize(true)
	headImage:setScale(0.45)

	--正在使用
	self.useImage = self:getChildByName("Sprite_using")

	--功能按钮
	self.btn = self:getChildByName("Button")
	self.btn:addTouchEventListener(handler(self, self.clickBtn))

	--碎片
	self.piecePanel = self:getChildByName("Panel_piece")
	self.fragmentLabel = self.piecePanel:getChildByName("Text_piece_amount")

	--价格
	self.payPanel = self:getChildByName("Panel_price")
	self.payImage = self.payPanel:getChildByName("Sprite_item")
	self.payLabel = self.payPanel:getChildByName("Text_price")
end

function SkinNode:updateUI()
	local data = nil

	for i = 1, #UserData.skinInfo do
		if UserData.skinInfo[i].tid == ToolConfig[self.skinIndex].tid
				or UserData.skinInfo[i].tid == ToolConfig[self.skinIndex].did then
			data = UserData.skinInfo[i]
			break
		end
	end

	if self.type == 1 then
		self:updateUI_1(data)
	elseif self.type == 2 then
		self:updateUI_2(data)
	elseif self.type == 3 then
		self:updateUI_3(data)
	else
		self:updateUI_4(data)
	end
end

function SkinNode:updateUI_1(data)
	self.piecePanel:setVisible(false)
	self.payPanel:setVisible(false)

	if data.id == UserData.userInfo.curSkinID then
		self.useImage:setVisible(true)
		self.btn:setVisible(false)

		self.state = 1
	else
		self.useImage:setVisible(false)
		self.btn:setVisible(true)

		self.btn:loadTextureNormal("tongyong/btn_lan_xiao1.png", ccui.TextureResType.plistType)
		self.btn:loadTexturePressed("tongyong/btn_lan_xiao2.png", ccui.TextureResType.plistType)
		self.btn:setTitleText("更换")
		self.btn:setTitleColor(Constant.BtnTextColor[1])

		self.state = 2
	end
end

function SkinNode:updateUI_2(data)
	self.count = 0

	if data then
		if data.count >= ToolConfig[self.skinIndex].totalNum then
			self.count = ToolConfig[self.skinIndex].totalNum
			self.state = 2
		else
			self.count = data.count
			self.state = 1
		end
	else
		self.state = 1
	end

	self.useImage:setVisible(false)
	self.payPanel:setVisible(false)
	self.piecePanel:setVisible(true)
	self.btn:setVisible(true)

	self.fragmentLabel:setString(self.count .. " / " .. ToolConfig[self.skinIndex].totalNum)

	if self.state == 1 then
		self.btn:loadTextureNormal("tongyong/btn_lan_xiao1.png", ccui.TextureResType.plistType)
		self.btn:loadTexturePressed("tongyong/btn_lan_xiao2.png", ccui.TextureResType.plistType)
		self.btn:setTitleText("查看")
		self.btn:setTitleColor(Constant.BtnTextColor[1])
	else
		self.btn:loadTextureNormal("tongyong/btn_huang_xiao1.png", ccui.TextureResType.plistType)
		self.btn:loadTexturePressed("tongyong/btn_huang_xiao2.png", ccui.TextureResType.plistType)
		self.btn:setTitleText("合成")
		self.btn:setTitleColor(Constant.BtnTextColor[2])
	end
end

function SkinNode:updateUI_3(data)
	self.count = 0

	if data then
		if data.count >= ToolConfig[self.skinIndex].totalNum then
			self.count = ToolConfig[self.skinIndex].totalNum
			self.state = 2
		else
			self.count = data.count
			self.state = 1
		end
	else
		self.state = 1
	end

	self.cost = (ToolConfig[self.skinIndex].totalNum - self.count) * ToolConfig[self.skinIndex].step

	self.useImage:setVisible(false)
	self.piecePanel:setVisible(false)
	self.btn:setVisible(true)
	self.payPanel:setVisible(true)

	self.btn:loadTextureNormal("tongyong/btn_huang_xiao1.png", ccui.TextureResType.plistType)
	self.btn:loadTexturePressed("tongyong/btn_huang_xiao2.png", ccui.TextureResType.plistType)
	self.btn:setTitleText(" ")

	self.payImage:setSpriteFrame("home/icon_zuanshi.png")
	self.payLabel:setString(self.cost)
	self.payLabel:setTextColor(Constant.BtnTextColor[2])
end

function SkinNode:updateUI_4(data)
	self.count = 0

	if data then
		if data.count >= ToolConfig[self.skinIndex].totalNum then
			self.count = ToolConfig[self.skinIndex].totalNum
			self.state = 2
		else
			self.count = data.count
			self.state = 1
		end
	else
		self.state = 1
	end

	self.cost = (ToolConfig[self.skinIndex].totalNum - self.count) * ToolConfig[self.skinIndex].step

	self.useImage:setVisible(false)
	self.piecePanel:setVisible(false)
	self.btn:setVisible(true)
	self.payPanel:setVisible(true)

	self.btn:loadTextureNormal("tongyong/btn_lan_xiao1.png", ccui.TextureResType.plistType)
	self.btn:loadTexturePressed("tongyong/btn_lan_xiao2.png", ccui.TextureResType.plistType)
	self.btn:setTitleText(" ")

	self.payImage:setSpriteFrame("home/icon_star.png")
	self.payImage:setPositionY(self.payImage:getPositionY() + 2)
	self.payLabel:setString(self.cost)
	self.payLabel:setTextColor(Constant.BtnTextColor[1])
end

function SkinNode:addInfoLayer()
	local info = {
		type = self.type,
		skinIndex = self.skinIndex,
		state = self.state,
		count = self.count,
		cost = self.cost,
	}

	MsgManager:sendMsg(GameMsg.MSG_SKIN_ADD_INFO_LAYER, info)
end

function SkinNode:clickHead(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended then
		self:addInfoLayer()
		SoundManager:playEffect("button.mp3")
	end
end

function SkinNode:clickBtn(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended then
		if self.type == 1 then
			self:clickNode_1()
		elseif self.type == 2 then
			self:clickNode_2()
		elseif self.type == 3 then
			self:clickNode_3()
		else
			self:clickNode_4()
		end

		SoundManager:playEffect("button.mp3")
	end
end

function SkinNode:clickNode_1()
	if self.state == 2 then
		local id = nil

		for i = 1, #UserData.skinInfo do
			if UserData.skinInfo[i].tid == ToolConfig[self.skinIndex].tid
						or UserData.skinInfo[i].tid == ToolConfig[self.skinIndex].did then
				id = UserData.skinInfo[i].id
				break
			end
		end

		if id then
			MsgManager:sendMsg(GameMsg.MSG_NET_WAITTING)
			NetFunc.tool:skinChange(id)
		end
	end
end

function SkinNode:clickNode_2()
	if self.state == 1 then
		self:addInfoLayer()
	elseif self.state == 2 then
		local data = nil

		for i = 1, #UserData.skinInfo do
			if UserData.skinInfo[i].tid == ToolConfig[self.skinIndex].tid
						or UserData.skinInfo[i].tid == ToolConfig[self.skinIndex].did then
				data = UserData.skinInfo[i]
				break
			end
		end

		if data then
			MsgManager:sendMsg(GameMsg.MSG_NET_WAITTING)
			NetFunc.tool:skinMerge(data.id, data.tid, 3)
		end
	end
end

function SkinNode:clickNode_3()
	local info = {
		type = self.type,
		cost = self.cost,
		skinIndex = self.skinIndex,
	}

	MsgManager:sendMsg(GameMsg.MSG_SKIN_ADD_SURE_PAY_LAYER, info)
end

function SkinNode:clickNode_4()
	local info = {
		type = self.type,
		cost = self.cost,
		skinIndex = self.skinIndex,
	}

	MsgManager:sendMsg(GameMsg.MSG_SKIN_ADD_SURE_PAY_LAYER, info)
end


return SkinNode
