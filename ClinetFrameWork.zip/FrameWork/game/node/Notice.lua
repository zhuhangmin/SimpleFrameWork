--region *.lua
--Date
--此文件由[BabeLua]插件自动生成



--endregion
local Notice     = class("Notice")
function Notice:create(str,tag)
    
    return Notice.new(str,tag)
end

function Notice:ctor(str, tag)
    --数据
    self._NoticeCount               = 1
    self._ListNoticeData            = {}
    local data  = {str = str,tag = tag or 1}
    table.insert(self._ListNoticeData,data)

    self:runNotice()
end

function Notice:init()
     --资源
    self._NodeNotice = cc.CSLoader:createNode("res/Node_Notice.csb")
    self._RunSence  = gDirector:getRunningScene()
    if self._RunSence.class.__cname == "GameScene" then
        self._NodeNoticeTouchPanel = self._NodeNotice:getChildByName("Panel_2"):getChildByName("Panel_Touch")
        self._NodeNoticeText1 = self._NodeNoticeTouchPanel:getChildByName("Text_Notice1")
        self._NodeNotice:setPosition(gScreenSize.width /3*2-50, gScreenSize.height-5 )
        self._NodeNotice:getChildByName("Panel_1"):setVisible(false)
        self._NodeNotice:getChildByName("Panel_2"):setVisible(true)
    else
        self._NodeNoticeTouchPanel = self._NodeNotice:getChildByName("Panel_1"):getChildByName("Panel_Touch")
        self._NodeNoticeText1 = self._NodeNoticeTouchPanel:getChildByName("Text_Notice1")
        self._NodeNotice:setPosition(gScreenSize.width / 2, gScreenSize.height-89 )
        self._NodeNotice:getChildByName("Panel_2"):setVisible(false)
        self._NodeNotice:getChildByName("Panel_1"):setVisible(true)
    end 

    self._RunSence:addChild(self._NodeNotice,999)
end

function Notice:getFirstMsg(bool)
    table.sort(self._ListNoticeData, function(a, b)
		return a.tag < b.tag
	end)
    local str = self._ListNoticeData[1]
    if bool then
        table.remove(self._ListNoticeData, 1)
    end 
    return str
end
function Notice:runNotice()
    
    if self._NoticeRuning then return end 

    if not self._RunSence or self._RunSence ~=  gDirector:getRunningScene() then
        self:init()
    end 

    if GameData.settingInfo.battleBgValue == 1 then--黑色
        self._NodeNotice:getChildByName("Panel_2"):getChildByName("Image_bg"):loadTexture("tongyong/img_paomadeng_bai.png",ccui.TextureResType.plistType)
    elseif GameData.settingInfo.battleBgValue == 2 then--蓝色
        self._NodeNotice:getChildByName("Panel_2"):getChildByName("Image_bg"):loadTexture("tongyong/img_paomadeng_hei.png",ccui.TextureResType.plistType)
    end  

    local messageInfo = self:getFirstMsg(true)
    if not messageInfo then
        self:broadcastEnd()
        return
    end

    self._NodeNotice:setVisible(true)
    self._NoticeRuning   = true
    self._CenterY        = self._NodeNoticeText1:getPositionY()

    local label = self._NodeNoticeText1

    label:setString(messageInfo.str)

    local szFont    = label:getContentSize()
    local szPanel   = self._NodeNoticeTouchPanel:getContentSize()
    local moveSpeed = 100 -- 移动速度 像素/秒

    --label:stopAllActions()
    -- 从右向左滚动
    label:setPosition(szPanel.width + 10, self._CenterY)

    local duration      = (szPanel.width + szFont.width + 40) / moveSpeed
    local actionLeft    = cc.MoveTo:create(duration, { x = - szFont.width, y = self._CenterY })

    label:runAction(actionLeft)
    scheduleOnce(
        function()
            self:runNoticeFinish()
            self:runNotice()
        end,duration)
end

function Notice:broadcastEnd()
    self._NodeNotice:setVisible(false)
end

function Notice:runNoticeFinish()
    self._NoticeRuning   = false
end

function Notice:showNotice(str,tag)
    local data  = {str = str,tag = tag or 1}
    table.insert(self._ListNoticeData,data)
    self:runNotice()
end
return Notice 