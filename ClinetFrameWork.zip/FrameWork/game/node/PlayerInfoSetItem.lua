local ConfigManager = require "ConfigManager"
local configmanager = ConfigManager.getInstance()

local PlayerInfoSetItem = class("PlayerInfoSetItem", function()
	return ccui.Widget:create()
end)

local STATE = {
    Year = 1,
    Month = 2,
    Day = 3,
    Address = 4,
}
function PlayerInfoSetItem:ctor(index,ntype)
    self._Year = os.date("%Y")
    self._Month = 0
    self._Day = 0
    self._Address = 0
    self._Type = ntype
    self._Index  = index 

	self:init()
end

function PlayerInfoSetItem:init()
	self._PlayerInfoSetItemNode = cc.CSLoader:createNode("res/Node_PlayerInfoSetItem.csb")
    self._PlayerInfoSetItemNode = changeNodeToWidget(self._PlayerInfoSetItemNode)
	self:addChild(self._PlayerInfoSetItemNode)

    self._Text_PlayerInfoItem     = self._PlayerInfoSetItemNode:getChildByName("Panel_PlayerInfoItem"):getChildByName("Text_PlayerInfoItem")
    if self._Type == STATE.Year then
        self._Text_PlayerInfoItem:setString(self._Year-50 + self._Index)
    elseif self._Type == STATE.Month then
        self._Text_PlayerInfoItem:setString(self._Month + self._Index)
    elseif self._Type == STATE.Day then
        self._Text_PlayerInfoItem:setString(self._Day + self._Index)
    elseif self._Type == STATE.Address then
        local areaText = configmanager:getConfigField("city", self._Address + self._Index, "name")
        -- DConfig.CITY_LIST[self._Address + self._Index].sName
        self._Text_PlayerInfoItem:setString(areaText)
    end  
end

function PlayerInfoSetItem:setInfo()
    
end 

return PlayerInfoSetItem
