
local BattleRankItem = class("BattleRankItem", function()
	return cc.CSLoader:createNode("res/BattleRank.csb")
end)

function BattleRankItem:ctor(isSelf, index)
	self.isSelf = isSelf
	self.index = index

	self:setAnchorPoint(cc.p(0.5, 0.5))
	self:init()
end

function BattleRankItem:init()
	self.rankBgImage = self:getChildByName("Sprite_rank_bg")
	-- self.rankBgImage:ignoreContentAdaptWithSize(true)

	self.rankLabel = self:getChildByName("Text_rank")
	self.nickname = self:getChildByName("Text_name")

	if self.isSelf then
		self.rankBgImage:setVisible(true)
		self.rankBgImage:setPositionX(self.rankBgImage:getPositionX() - 2)
		self.rankBgImage:setSpriteFrame("zd/zd_ph_zj.png")

		self.rankLabel:setString("")

		self.nickname:setTextColor(cc.c3b(255, 186, 0))
		self.nickname:setString(UserData.userInfo.nickname)
	else
		local isVisible = false
		local imageName = nil
		local color = nil

		if self.index > 3 then
			isVisible = false
			color = cc.c3b(255, 255, 255)
		else
			isVisible = true

			if self.index == 1 then
				imageName = "zd/zd_ph1.png"
				color = cc.c3b(255, 88, 88)
			elseif self.index == 2 then
				imageName = "zd/zd_ph2.png"
				color = cc.c3b(78, 207, 255)
			elseif self.index == 3 then
				imageName = "zd/zd_ph3.png"
				color = cc.c3b(255, 170, 132)
			end
		end

		if isVisible then
			self.rankBgImage:setSpriteFrame(imageName)
		end
		self.rankBgImage:setVisible(isVisible)

		self.rankLabel:setString(self.index)
		self.rankLabel:setPosition(self.rankLabel:getPositionX() + 2, self.rankLabel:getPositionY() - 2)

		self.nickname:setTextColor(color)
		self.nickname:setString("")
	end
end

function BattleRankItem:setRank(rank)
	self.rankLabel:setString(rank)
end

function BattleRankItem:setNickname(nickname)
	self.nickname:setString(nickname)
end


return BattleRankItem
