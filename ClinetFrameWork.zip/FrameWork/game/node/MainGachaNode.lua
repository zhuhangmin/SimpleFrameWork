
local MainGachaNode = class("MainGachaNode", function()
	return ccui.Widget:create()
end)

function MainGachaNode:ctor()
	self.size = nil
	self.btnEnable = true

	self:init()
	self:setContentSize(self.size)
end

function MainGachaNode:init()
	self:setAnchorPoint(cc.p(0, 0.5))
	self:setTouchEnabled(true)
	self:addTouchEventListener(handler(self, self.clickEvent))

	local armature = ccs.Armature:create("MengJun_DaTing")
	self.size = armature:getBoundingBox()
	armature:setPosition(self.size.width / 2 + 200, self.size.height / 2 - 40)
	armature:getAnimation():play("Animation01", -1, 1)
	self:addChild(armature)

	local armHint = ccs.Armature:create("MengJun_DaTing_tanchuang")
	local size = armHint:getBoundingBox()
	armHint:setPosition(size.width + 200, size.height / 2 + 90)
	armHint:getAnimation():play("Animation01", -1, 1)
	self:addChild(armHint)
end

function MainGachaNode:clickEvent(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended then
		SoundManager:playEffect("button.mp3")
		self:openGachaScene()
	end
end

function MainGachaNode:openGachaScene()
	if self.btnEnable then
		if #UserData.gachaData > 0 then
			self.btnEnable = false

			local gachaScene = require("src.app.game.Scene.Gacha.GachaScene"):create(1)
			gDirector:pushScene(gachaScene)
			SDKFunc.log:logEventData(Constant.LogEventName[20])
			local action1 = cc.DelayTime:create(1.0)
			local action2 = cc.CallFunc:create(function()
				self.btnEnable = true
			end)
			local action3 = cc.Sequence:create(action1, action2)
			self:runAction(action3)
		else
			local params = {}
			local function netFunc( ... )
				NetFunc.gacha:gachaShow()
			end
			params.netFunc = netFunc
			params.parent = self:getParent()
			require("app.game.Scene.WaitingLayerCommon"):create(params)
		end
	end
end


return MainGachaNode
