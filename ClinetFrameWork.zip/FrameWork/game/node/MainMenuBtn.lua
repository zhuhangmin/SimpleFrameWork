
local MainMenuBtn = class("MainMenuBtn", function()
	return cc.CSLoader:createNode("res/MainMenubtn.csb")
end)

--normal: btn normal state image name
--press: btn pressed state image name
local BtnConfig = {
	[1] = {normal = "home_new/btn_huodong.png", press = "home_new/btn_huodong_f.png"},
	[2] = {normal = "home_new/btn_renwu.png", press = "home_new/btn_renwu_f.png"},
	[3] = {normal = "home_new/btn_paihang.png", press = "home_new/btn_paihang_f.png"},
	[4] = {normal = "home_new/btn_youjian.png", press = "home_new/btn_youjian_f.png"},
	[5] = {normal = "home_new/btn_shezhi.png", press = "home_new/btn_shezhi_f.png"},
	[6] = {normal = "home_new/btn_gxjs.png", press = "home_new/btn_gxjs_f.png"},
	[7] = {normal = "home_new/btn_bangzhu.png", press = "home_new/btn_bangzhu_f.png"},
}

function MainMenuBtn:ctor(index)
	self.btnEnable = true
	self.index = index

	self:init()
	self:updateRedPoint()
	self:enableNodeEvents()
end
function MainMenuBtn:onEnter()
	self:updateRedPoint()
end

function MainMenuBtn:init()
	local btn = self:getChildByName("Button")
	btn:loadTextureNormal(BtnConfig[self.index].normal, ccui.TextureResType.plistType)
	btn:loadTexturePressed(BtnConfig[self.index].press, ccui.TextureResType.plistType)
	btn:addTouchEventListener(handler(self, self.clickEvent))

	self.redPoint = self:getChildByName("Sprite_red_point")
	-- local x, y = self.redPoint:getPosition()
	-- self.redPoint:setPosition(x - 5, y - 5)
end

function MainMenuBtn:updateRedPoint()
	self.redPoint:setVisible(self:getRedPointVisible())
end

function MainMenuBtn:clickEvent(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended and self.btnEnable then
		self.btnEnable = false
		SoundManager:playEffect("button.mp3")
		self:clickExt()
		self.btnEnable = true
	end
end

function MainMenuBtn:clickExt()
	if self.index == 1 then
		local scene = require("src.app.game.Scene.Activity.ActivityScene"):create()
		gDirector:replaceScene(scene)
	elseif self.index == 2 then
		local scene = require("src.app.game.Scene.NewTask.NewTaskScene"):create()
		gDirector:pushScene(scene)
	elseif self.index == 3 then
		--排行榜
		local scene = require("src.app.game.Scene.Rank.RankScene"):create()
		gDirector:replaceScene(scene)
	elseif self.index == 4 then
		--邮件
		local scene = require("src.app.game.Scene.Mail.MailScene"):create()
		gDirector:replaceScene(scene)
	elseif self.index == 5 then
		--设置
		gDirector:getRunningScene():addSettingLayer()
        self:getParent():getParent():initMenuAction() --为了点击不是页面的按钮时，缩进按钮也能收回
	elseif self.index == 6 then
		--更新介绍
		local sceneactivity = require("src.app.game.Scene.Activity.ActivityNoticeScene"):create()
        self:getParent():getParent():initMenuAction() --为了点击不是页面的按钮时，缩进按钮也能收回
	elseif self.index == 7 then
		--帮助
		local scene = require("src.app.game.Scene.Help.HelpScene"):create()
		gDirector:replaceScene(scene)
	end
end

function MainMenuBtn:getRedPointVisible()
	if self.index == 1 then
		--活动
		return self:getActivityRedVisible()
	elseif self.index == 2 then
		--任务
		return self:getTaskRedVisible()
	elseif self.index == 3 then
		--排行榜
		return false
	elseif self.index == 4 then
		--邮件
		return self:getMailRedVisible()
	elseif self.index == 5 then
		--设置
		return false
	elseif self.index == 6 then
		--更新介绍
		return false
	elseif self.index == 7 then
		--帮助
		return false
	end
end

function MainMenuBtn:getActivityRedVisible()
	local isVisible = false

	for i, v in pairs(UserData.ActivityInfo.ActivityData) do
		for j, m in ipairs(v) do
			if not ((i == 4 or i ==5 or i== 6) and UserData.ActivityInfo.isNewbie == 0) and m.able == 1 then
				isVisible = true
				break
			end
		end
	end

	return isVisible
end

function MainMenuBtn:getTaskRedVisible()
	local isVisible = false

	if UserData.taskInfo.data then
		for k, v in pairs(UserData.taskInfo.data) do
			if v.state == 1 and math.floor(v.configID / 1000) ~= 2 then
				isVisible = true
				break
			end
		end
	end

	return isVisible
end

function MainMenuBtn:getMailRedVisible()
	local isVisible = false

	if UserData.mailInfo.isForceRedPoint == 1 then
		isVisible = true
	else
		if UserData.mailInfo.data then
			for k, v in pairs(UserData.mailInfo.data) do
				if v.isread == 0 then
					isVisible = true
					break
				end
			end
		end
	end

	return isVisible
end


return MainMenuBtn
