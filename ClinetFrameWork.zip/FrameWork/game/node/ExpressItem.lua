
local ExpressItem = class("ExpressItem", function()
	return cc.CSLoader:createNode("res/BqItem.csb")
end)

function ExpressItem:ctor(index, sex)
	self.index = index
	self.sex = sex

	self:setAnchorPoint(cc.p(0.5, 0.5))
	self:init()
end

function ExpressItem:init()
	self.panel = self:getChildByName("Panel_bq")
	self.panel:addTouchEventListener(handler(self, self.clickPanel))

	self.image = self.panel:getChildByName("Sprite_bq")
	self.image:setSpriteFrame(Constant.BattleExpConfig[self.index][self.sex].image)

	self.progress = self.panel:getChildByName("LoadingBar_bq")
	self.progress:setPercent(100)
	self.progress:setVisible(false)
end

function ExpressItem:clickPanel(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended then
		NetFunc.room:battleExp(self.index)
		MsgManager:sendMsg(GameMsg.MSG_CLICK_EXP, self.index)

		SoundManager:playEffect("button.mp3")
	end
end


return ExpressItem
