
local SkinItem = class("SkinItem", function()
	return ccui.Widget:create()
end)

function SkinItem:ctor(type, lineIndex, info)
	self:setAnchorPoint(cc.p(0, 0))
	self:setContentSize(1050, 225)

	--创建每一个横排条目
	for i = 1, #info do
		local node = require("src.app.game.Node.SkinNode"):create(type, lineIndex, i, info[i])
		node:setAnchorPoint(cc.p(0, 0))
		node:setPosition((i * 2 - 1) * 10 + (i - 1) * 190, 0)
		self:addChild(node)
	end
end


return SkinItem
