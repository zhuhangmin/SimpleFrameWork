
local PlayerInfoNode = class("PlayerInfoNode", function()
	return ccui.Widget:create()
end)

function PlayerInfoNode:ctor(params)
	self.params = params
	self:init(params)
end

function PlayerInfoNode:init(params)
	local rootNode = cc.CSLoader:createNode("res/SelfInformation.csb")
	self:addChild(rootNode)

	self:setAnchorPoint(0, 0)
	self:setContentSize(rootNode:getContentSize())
	self:setTouchEnabled(true)

	self.text_title = rootNode:getChildByName("Text_title")
	self.text_title:setFontSize(20)
	self.text_title:setString(params.name)

	self.text_msg = rootNode:getChildByName("Text_content")
	self.text_msg:setFontSize(20)
	self.text_msg:setString(params.det)
end


return PlayerInfoNode