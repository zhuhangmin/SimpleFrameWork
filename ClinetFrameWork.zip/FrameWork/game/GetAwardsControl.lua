local EngineControl = require  "EngineControl"
local GetAwardsControl = class("GetAwardsControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
}

--SYSTEM MSGS
local BTN_CONFIRM = "Button_receive"
local SYSTEM_MSGS = {
	BTN_CONFIRM
}

--OTHER NODE
local SPRITE_TITLESKIN2 = "Sprite_title_skin2"
local STR_TIP = GetAwardsControl:getConfigField("tips", "STAR_INVERT", "content")

function GetAwardsControl:ctor(model, view)
	GetAwardsControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function GetAwardsControl:onCreate(param)
	GetAwardsControl.super.onCreate(self, param)
	if isNil(param) then printStack() end

	self:init()
	local action = addCommonAnime(self:getNode(),"mj_huojiang1_1")
	action:gotoFrameAndPlay(0, 23, false)
	SoundManager:playEffect("draw_result.mp3")
end

function GetAwardsControl:init()
	local rewardData = self:getModel():getRewardData()

    local itemConfig = self:getTable("item")
    if isNil(itemConfig) then printStack() return end

	--添加动画法杖
	local sprAnime = self:getChildNode(SPRITE_TITLESKIN2)
	if isNil(sprAnime) then printStack() return end

	local action,anime = addCommonAnime(sprAnime,"mj_huojiang1_2")
	action:gotoFrameAndPlay(0, 23, true)


	for i=1,7 do
		local panel = self:getChildNode("Panel_award_"..i) 
		if isNil(panel) then printStack() return end

		panel:setVisible(false)
	end

	local len = table.nums(rewardData)
	if len > 7 then len = 7 end
	for i=1,len do
		local panel = self:getChildNode("Panel_award_"..i) 
		if isNil(panel) then printStack() return end

		local awardSpr = panel:getChildByName("Node_reward")
		if isNil(awardSpr) then printStack() return end

		if rewardData[i].item_num then
			addItmeNode(awardSpr,rewardData[i].item_id,rewardData[i].item_num)
			local action1 = cc.DelayTime:create(0.1*i)
			local action2 = cc.CallFunc:create(function()
				panel:setVisible(true)
			end)
			local action3 = cc.Sequence:create(action1, action2)
			panel:runAction(action3)

			panel:setPositionX(760/(len+1)*i)

			self:addSpecialAnime(rewardData[i].item_id,panel)
		end		
	end

	for i = 1, len do
		if itemConfig[rewardData[i].item_id] and itemConfig[rewardData[i].item_id].type == "SKIN" then
			local action1 = cc.DelayTime:create(0.1*i)
			local action2 = cc.CallFunc:create(function()
				local bestLayer = require("FrameWork.game.GachaBestLayer"):create(rewardData[i].item_id)
				self:getNode():addChild(bestLayer)
			end)
			local action3 = cc.Sequence:create(action1, action2)
			self:getNode():runAction(action3)
		end
	end
end

function GetAwardsControl:addSpecialAnime( id,panel )
	if id == nil then return end
	if panel == nil then return end
	local special = getIsRare(id)
	
	if special  then
		local action,anime = addCommonAnime(panel,"mj_jl_1")
		action:gotoFrameAndPlay(0, 19, true)
		anime:setPosition(cc.p(75,82))
	end
end

function GetAwardsControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_CONFIRM then
		self:detachFromParent()
	end
end

function GetAwardsControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

return GetAwardsControl


