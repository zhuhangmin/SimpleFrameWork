local EngineView = require "EngineView"
local CharacterView = class("CharacterView", EngineView)

local csbFilePath = "res/SkinNew.csb"
CHARACTER_CSB_NODE = 1000

function CharacterView:ctor(node)
	CharacterView.super.ctor(self, node)
end

function CharacterView:onCreate(param)
	CharacterView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	if isNil(csbNode) then printStack() return end
	
	csbNode:setTag(CHARACTER_CSB_NODE)
	self:getNode():addChild(csbNode)
	csbNode:setName("csbNode")
end

return CharacterView





