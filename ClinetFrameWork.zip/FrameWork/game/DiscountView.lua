local EngineView = require "EngineView"
local DiscountView = class("DiscountView", EngineView)

local csbFilePath = "res/DiscountedGift.csb"
DISCOUNT_CSB_NODE = 1000

function DiscountView:ctor(node)
	DiscountView.super.ctor(self, node)
end

function DiscountView:onCreate(param)
	DiscountView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	if isNil(csbNode) then printStack() return end
	
	csbNode:setTag(DISCOUNT_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return DiscountView





