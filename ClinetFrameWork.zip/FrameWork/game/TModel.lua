local EngineModel = require "EngineModel"
local TModel = class("TModel", EngineModel)

function TModel:ctor(data)
	TModel.super.ctor(self, data)
end

return TModel

