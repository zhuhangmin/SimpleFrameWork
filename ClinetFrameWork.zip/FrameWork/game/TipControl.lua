local EngineControl = require  "EngineControl"
local TipControl = class("TipControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
}

--SYSTEM MSGS
-- local BTN_RETURN = "Button_return"
local SYSTEM_MSGS = {
	-- BTN_RETUTN,
}

local LBL_TEXT = "Text"
local IMG_BG = "Image_bg"

function TipControl:ctor(model, view)
	TipControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
end

function TipControl:onCreate(param)
	TipControl.super.onCreate(self, param)

	local model = self:getModel()
	local str = model:getTipStr()

	local csbNode = self:getChildNode(CSB_NODE)
	
	local label = self:getChildNode(LBL_TEXT)
	label:setString(str)
	local textsize = label:getContentSize()
    local size = {}
    size.width = textsize.width+150
    size.height = textsize.height +30
    
    local image = self:getChildNode(IMG_BG)
    image:setContentSize(size)

	local action1 = cc.DelayTime:create(TIP_FADE_TIME)
	local action2 = cc.CallFunc:create(function()
		self:detachFromParent()
	end)
	local action3 = cc.Sequence:create(action1, action2)
	csbNode:runAction(action3)
	
	self:send(BASE_MSG.PLAY_SOUND, TIPS_SOUND)
end

function TipControl:onEnter(param)
	TipControl.super.onEnter(self, param)

end

function TipControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

end

function TipControl:recv(event)
	self.super.recv(self, event)
	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

return TipControl


