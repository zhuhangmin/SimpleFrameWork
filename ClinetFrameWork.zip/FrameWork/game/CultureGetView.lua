local EngineView = require "EngineView"
local CultureGetView = class("CultureGetView", EngineView)

local csbFilePath = "res/CultureGet.csb"
CULTUREGET_CSB_NODE = 1000

function CultureGetView:ctor(node)
	CultureGetView.super.ctor(self, node)
end

function CultureGetView:onCreate(param)
	CultureGetView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	csbNode:setTag(CULTUREGET_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return CultureGetView





