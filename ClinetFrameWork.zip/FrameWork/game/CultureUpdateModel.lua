local EngineModel = require "EngineModel"
local CultureUpdateModel = class("CultureUpdateModel", EngineModel)

function CultureUpdateModel:ctor(data)
	CultureUpdateModel.super.ctor(self, data)

	self.itemID = 0
	self.index = 0
	self.nextItemID = 0
end

function CultureUpdateModel:onCreate(param)
	CultureUpdateModel.super.onCreate(self, param)

	if notNumber(param.item_id) then printStack() return end
	self:setItemID(param.item_id)

	if notNumber(param.index) then printStack() return end
	self:setIndex(param.index)
end

function CultureUpdateModel:setItemID(itemID)
	self.itemID = itemID
end

function CultureUpdateModel:getItemID()
	return self.itemID
end

function CultureUpdateModel:setIndex(index)
	self.index = index
end

function CultureUpdateModel:getIndex()
	return self.index
end

function CultureUpdateModel:setNextItemID(nextItemID)
	self.nextItemID = nextItemID
end

function CultureUpdateModel:getNextItemID()
	return self.nextItemID
end

return CultureUpdateModel

