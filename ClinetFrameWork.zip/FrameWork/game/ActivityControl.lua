local EngineControl = require  "EngineControl"
local ActivityControl = class("ActivityControl", EngineControl)
--LUA MSGS
local LUA_MSGS = {
    GameMsg.SIGN_AWARD,
    GameMsg.SIGN_UPDATE,
    GameMsg.MSG_CONVERT_REWARD_RSP,
    GameMsg.MSG_GET_REDEEM_REWARD_RET
}

--SYSTEM MSGS
local BTN_RETURN 	= "Button_return"
local BTN_GET 		= "Button_receive"
local BTN_HELP 		= "Button_help"
local BTN_WEEK  	= "Button_weekly"
local BTN_DAY 		= "Button_daily"
local BTN_UPDATE    = "Button_update"
local BTN_UPDATERECV = "Button_update_receive"
local BTN_EXCHANGE = "Button_exchange"
local BTN_EXCHANGERECV = "Button_exchange_receive"
local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_GET,
	BTN_HELP,
	BTN_WEEK,
	BTN_DAY,
	BTN_UPDATE,
	BTN_UPDATERECV,
	BTN_EXCHANGE,
	BTN_EXCHANGERECV
}


local KEY_REWARD = "reward%d"
local KEY_NUM = "num%d"

function ActivityControl:ctor(model, view)
	ActivityControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
end

function ActivityControl:onCreate(param)
	ActivityControl.super.onCreate(self, param)
	
end

function ActivityControl:onEnter( param )
	self:initUI()
	self:getChildNode(BTN_HELP):setVisible(false)
	-- self.tabIndex = - 1
	self:setConvertAwards()

	self:judgeUserConvert()

	self:setExchangePanel()
end

function ActivityControl:setExchangePanel()
	local Panel_exchange = self:getChildNode("Panel_exchange")
	if isNil(Panel_exchange) then printStack() return end

	local textField_code = self:getChildNode("TextField_code")
	if textField_code then
		textField_code:setVisible(false)
		local editBox_code = ccui.EditBox:create(textField_code:getContentSize(),"js/js_bg4.png")
		editBox_code:setPosition(textField_code:getPosition())
		editBox_code:setAnchorPoint(0.5,0.5)
		editBox_code.setTextColor = textField_code.setFontColor
		editBox_code:setFontColor(display.COLOR_BLACK)
		editBox_code:setFontSize(textField_code:getFontSize())
		editBox_code:setPlaceHolder(textField_code:getPlaceHolder())
		editBox_code:setPlaceholderFontSize(textField_code:getFontSize())
		editBox_code:setPlaceholderFontColor(display.COLOR_BLACK)
		editBox_code:setFontName(textField_code:getFontName())
        editBox_code:setContentSize(textField_code:getContentSize())
        editBox_code:registerScriptEditBoxHandler(handler(self, self.onDeclarationEditEvent)) 
		Panel_exchange:addChild(editBox_code,0)
		editBox_code:setName("editBox_code")
	end
end

function ActivityControl:onDeclarationEditEvent(name, sender)
	local btn_exchange = self:getChildNode(BTN_EXCHANGERECV)
	if isNil(btn_exchange) then printStack() return end

	if name == "changed" then
		local giftcode = sender:getText()
		print("giftcode = ",giftcode)
		if giftcode == "" then
			setButtonEnable(btn_exchange,false)
		else
			setButtonEnable(btn_exchange,true)
		end
	end
end

function ActivityControl:judgeUserConvert()
    local btn_recv = self:getChildNode(BTN_UPDATERECV)
	local canclick = canUserConvert()

	--用户转换领奖判断
	local userConvert = require('src.app.userconvert.UserConvertCtrl'):getInstance()
	local btn_update = self:getChildNode(BTN_UPDATE)

	--未开启转换
	if userConvert._model:getConvertStatus() == userConvert.CONVERTSTATUS_NOSUPPORT then
		btn_update:setVisible(false)
		return
	end

	if (userConvert._model:isTcyappLaunched() or MCAgent:getInstance():getLaunchMode() == LaunchMode["PLATFORM"]) then
		btn_update:setVisible(false)

		userConvert._model:getUserAwardInfo( function(_awardInfo)
			if _awardInfo and _awardInfo.Status == userConvert.AWRADSTATUS_YES then
				canclick = true
				btn_recv:setTitleText("领 取")
				btn_update:setVisible(true)
			else
				canclick = false
				btn_recv:setTitleText("已领取")				
			end
			setButtonEnable(btn_recv,canclick)
		end)
	else
		if userConvert._optionConvertStatus == userConvert.OPTIONCONVERTSTATUS_NONE then
			canclick = false
		end
	end	
	setButtonEnable(btn_recv,canclick)
end

function ActivityControl:initUI( ... )
	local Panel_update = self:getChildNode("Panel_update")
	local Panel_activity_7 = self:getChildNode("Panel_activity_7")
	local Panel_exchange = self:getChildNode("Panel_exchange")
	if self.model.curTag == 3 then	--用户转化
		Panel_update:setVisible(true)
		Panel_activity_7:setVisible(false)
		Panel_exchange:setVisible(false)
		self:setTagBtn(self.model.curTag)
	elseif self.model.curTag == 4 then	--礼包兑换
		Panel_update:setVisible(false)
		Panel_activity_7:setVisible(false)
		Panel_exchange:setVisible(true)
	else
		Panel_activity_7:setVisible(true)
		Panel_update:setVisible(false)
		Panel_exchange:setVisible(false)

		self._Node_7 = {}
		for i = 1, 7, 1 do
			local node = self:getChildNode("Node_"..i)
			if node then
				node:removeAllChildren()
				if i <= 6 then
					self._Node_7[i] = self:createAwardNode(i,"res/ActivityItem1.csb")
				else
					self._Node_7[i] = self:createAwardNode(i,"res/ActivityItem2.csb")
				end
		       	node:addChild(self._Node_7[i])
		       	self:updateAwardNode(i)
		    end
		end
		self:setTagBtn(self.model.curTag)

		local can_receive = self.model:getCanReceive()
		setButtonEnable(self:getChildNode(BTN_GET),can_receive)
	end
	self:setRedPoint()
end

function ActivityControl:setConvertAwards()
	local giftInfo = self:getConfigRecord("giftPack", 19)
	if isNil(giftInfo) then printStack() return end

	for i=1,4 do
		local node = self:getChildNode("Node_"..(i+7))
		if isNil(node) then printStack() return end

		local itemID = giftInfo["reward"..i]
		if notNumber(itemID) then printStack() return end

		local itemNum = giftInfo["num"..i]
		if notNumber(itemNum) then printStack() return end

		if itemID~=0 and itemNum~=0 then
			addItmeNode(node,itemID,itemNum)
		end
	end
end

function ActivityControl:setRedPoint()
	local btnList = {BTN_WEEK,BTN_DAY,BTN_UPDATE,BTN_EXCHANGE} 
	for i = 1, #btnList, 1 do
		local flag = self.model:getRedData(i)
		local btn = self:getChildNode(btnList[i])
		btn:getChildByName("Image_red_point"):setVisible(flag)
	end
end 

function ActivityControl:initRewards( gift_id , csb )
	if notNumber(gift_id) then printStack() end
	if isNil(csb) then printStack() end
	local giftInfo = self:getConfigRecord("giftPack", gift_id)
	if isNil(giftInfo) then printStack() end
	local key2 = string.format(KEY_NUM,2)	
	if notNumber(giftInfo[key2]) then printStack() end
	local panel = {}
	if giftInfo[key2] ~= 0 then
		csb:getChildByName("Panel_two"):setVisible(true)
		csb:getChildByName("Panel_one"):setVisible(false)
		panel.parent = csb:getChildByName("Panel_two")
		panel[1] = {}
		panel[1].sprite = panel.parent:getChildByName("Node_reward1") 
		panel[2] = {}
		panel[2].sprite = panel.parent:getChildByName("Node_reward2") 
	else
		csb:getChildByName("Panel_two"):setVisible(false)
		csb:getChildByName("Panel_one"):setVisible(true)
		panel.parent = csb:getChildByName("Panel_one")
		panel[1] = {}
		panel[1].sprite = panel.parent:getChildByName("Node_reward") 
	end

	for i=1, 7 do
		if panel[i] then
			local keyReward = string.format(KEY_REWARD,i)
			if notNumber(giftInfo[keyReward]) then printStack() return end

			local keyNum = string.format(KEY_NUM,i)
			if notNumber(giftInfo[keyNum]) then printStack() return end

			local itemID = giftInfo[keyReward]
			local itemNum = giftInfo[keyNum]

			local isItem = (itemID~=0 and itemNum~=0)
			if isItem then
		        local itemConfig= self:getTable("item")
		        if isNil(itemConfig) then printStack() end	

		        local itemInfo = itemConfig[itemID]

				local imgReward = panel[i].sprite
				if isNil(imgReward) then printStack() end

				addItmeNode(imgReward,itemID,itemNum)
			end
		end
	end
end

function ActivityControl:setTagBtn( tag )
	local btnList = {BTN_WEEK,BTN_DAY,BTN_UPDATE,BTN_EXCHANGE} 
	self.model.curTag = tag
	for i = 1, #btnList, 1 do
		local btn = self:getChildNode(btnList[i])
		if i == tag then
			btn:getChildByName("Text_1"):setVisible(false)
			btn:getChildByName("Text_2"):setVisible(true)
		else
			btn:getChildByName("Text_1"):setVisible(true)
			btn:getChildByName("Text_2"):setVisible(false)
		end
		setButtonEnable(btn,i ~= tag)
	end
end


function ActivityControl:createAwardNode( i , csbName )
	local award = cc.Layer:create()
	-- award:setAnchorPoint(0.5,0.5)
	local csb = cc.CSLoader:createNode(csbName)
	local gift_id = self.model:getGiftData()
	if gift_id and gift_id[i] then
		self:initRewards(gift_id[i],csb)
	end
	csb:setName("csb")
	award:addChild(csb)
	return award
end

function ActivityControl:updateAwardNode( i )
	local node = self._Node_7[i]
	local csb  = self._Node_7[i]:getChildByName("csb")
	local no_r = csb:getChildByName("Panel_not_received")
	local is_r = csb:getChildByName("Panel_received")
	local finish = csb:getChildByName("Sprite_finished")
	local flag = self.model:getIsReceived(i)
	local flag2 = self.model:getIsSignDay(i)
	if i ~= 7 then
		local sp2 = is_r:getChildByName("Image_title")
		local sp1 = no_r:getChildByName("Image_title")
		print("====;=="..tostring(i))
		sp1:loadTexture("hd_new/hd_img_d"..i..".png", ccui.TextureResType.plistType)
		sp2:loadTexture("hd_new/hd_img_d"..i.."_y.png", ccui.TextureResType.plistType)
	end
	no_r:setVisible( not flag )
	is_r:setVisible( flag or flag2 )
	finish:setVisible( flag )
	local a_flag = self.model:getAnimeFlag(i)
	if a_flag then
		local Action = cc.CSLoader:createTimeline("res/ActivityItem1.csb")
		csb:runAction(Action)
		Action:play("light",true)
	end
end

function ActivityControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:backEventExt()
	end

	if senderName == BTN_GET then
		self:getReward()
	end

	if senderName == BTN_UPDATERECV then
		local userConvert = require('src.app.userconvert.UserConvertCtrl'):getInstance()
		userConvert:_convertBtnAction()
	end

	if senderName == BTN_HELP then
		self:addPop("game.ActivityRule")
	end

	if senderName == BTN_WEEK then
		self:setTagBtn(1)
		self:initUI()
	end

	if senderName == BTN_DAY then
		self:setTagBtn(2)
		self:initUI()
	end

	if senderName == BTN_UPDATE then
		self:setTagBtn(3)
		self:initUI()
	end

	if senderName == BTN_EXCHANGE then
		self:setTagBtn(4)
		self:initUI()
	end

	if senderName == BTN_EXCHANGERECV then
		--sendmsg
		local editBox_code = self:getChildNode("editBox_code")
		if isNil(editBox_code) then printStack() return end

		local code = editBox_code:getText()
		local params = {code = code}
		self:submitFormWait("redeem", params)

		editBox_code:setText("")
	end
end

function ActivityControl:getReward( ... )
	local data ={}
	self.model:initFormData(data)
	self:send(BASE_MSG.NET_FORM_WAIT, data)
end

function ActivityControl:backEventExt()

	-- --数据埋点(返回主页按钮，返回按钮，物理back按键，全部监听)
	-- SDKFunc.log:logEventData(Constant.LogEventName[12])
	self:send(BASE_MSG.GOHOME)
end


function ActivityControl:recv(event)
	if isNil(event) then printStack() end
	if isNil(event.name) then printStack() end
	if isNil(event.data) then printStack() end
	print("ActivityControl:recv name = " .. tostring(event.name))
	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

	if name == GameMsg.SIGN_AWARD then
		self:rewardAnimePop(data)
		self:updateUI()
		return
	end	

	if name == GameMsg.SIGN_UPDATE then
		self:initUI()
		-- self:updateUI()
	end

	if name == GameMsg.MSG_CONVERT_REWARD_RSP then
        self:rewardAnimePop(19)

        self:judgeUserConvert()
        return
	end

	if name == GameMsg.MSG_GET_REDEEM_REWARD_RET then
		self:rewardAnimePop(data.gift_id)
	end
end

function ActivityControl:updateUI(  )
	for i = 1, 7, 1 do
		self:updateAwardNode(i)
	end
	local can_receive = self.model:getCanReceive()
	setButtonEnable(self:getChildNode(BTN_GET),can_receive)
	self:setRedPoint()
end

function ActivityControl:rewardAnimePop( gift_id )
	local giftInfo = self:getConfigRecord("giftPack", gift_id)
	if isNil(giftInfo) then printStack() end	

	local rewardData = {}
	for i=1,7 do
		local itemID = giftInfo["reward"..i]
		local itemNum = giftInfo["num"..i]
		if itemID~=0 and itemNum~=0 then
			table.insert(rewardData,{item_id=itemID ,item_num=itemNum})
		end
	end

	local name = "game.GetAwards"
	local param = {modelParam = {rewardData = rewardData}}
	self:addPop(name,param)
end



return ActivityControl;