local EngineView = require "EngineView"
local BattleRewardView = class("BattleRewardView", EngineView)

function BattleRewardView:ctor(node)
	BattleRewardView.super.ctor(self, node)
end

function BattleRewardView:onCreate(param)
	BattleRewardView.super.onCreate(self, param)
	local csbNode = cc.CSLoader:createNode("res/Rank.csb")
	if isNil(csbNode) then printStack() return end
	self:getNode():addChild(csbNode)
	csbNode:setPosition(0, gScreenSize.height)
	UIManager:runPopupEnterAction(csbNode)
end


return BattleRewardView;
