local EngineControl = require  "EngineControl"
local BattleControl = class("BattleControl",EngineControl);
local entityManager = require("battle.Control.entityControlManager")
local entityFactory = require("battle.Control.entityControlFactory")
local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()
local voiceManager = require "VoiceManager"
local voiceManager = voiceManager.getInstance()
local GlobalStatus = require "GlobalStatus"
--LUA MSGS
local LUA_MSGS = {
	BattleMsg.UPDATE_THEME,
	BattleMsg.RANK_NOTIFY,
	BattleMsg.EXIT,
	BattleMsg.OVER,
	BattleMsg.DEAD,
	BattleMsg.SHOW_FPS,
	BattleMsg.START_AI,
	BattleMsg.STOP_AI,
	GameMsg.MSG_DOWNLOAD_VOICE_SUCCESS,
	GameMsg.PLAY_VOICE_END,
}

--SYSTEM MSGS
local BTN_RETURN = "Button_return"
local BTN_SET = "Button_set"
local BTN_SKILL1 = "Button_skill_1"
local BTN_SKILL2 = "Button_skill_2"
local BTN_SPEAK = "Button_record"
local PANEL_VOICE = "Panel_voice"
local BTN_MUTE = "Button_mute"
local BTN_UNMUTE = "Button_unmute"
local NODE_ANIME = "Node_record"

local armatureFileList = {	
}

local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_SET,
	BTN_SPEAK,
	BTN_MUTE,
	BTN_UNMUTE,
}

--GAME LABLES
local LBL_NICKNAME = "Text_name"

local QUIT_BATTLE = BattleControl:getConfigField("tips", "QUIT_BATTLE", "content")

function BattleControl:ctor(model, view)
	BattleControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function BattleControl:onCreate(param)
	BattleControl.super.onCreate(self, param)
end

function BattleControl:loadRes( ... )
	-- for i = 1, #armatureFileList do
	-- 	gArmatureManager:addArmatureFileInfo(armatureFileList[i])
	-- end
end

function BattleControl:onDestroy( )
	BattleControl.super.onDestroy(self)
	print("onDestroy")
	-- self:cancelFrameScheduler()
	GameData:resetGameData()
	require("battle.AIManager.AIManager"):getInstance():clear()
end


function BattleControl:onEnter(  )


	BattleControl.super.onEnter(self, param)
	self:initInfoData()
	voiceManager:reset()
	self:loadRes()



	self:setRoomLabel( )
	
	self:updateTheme()
	
	self:initEntityManager()

	self:enterBattleSucc()
			-- PrintNodeTree(self:getNode())

	--debug statistic

	self:getChildNode(PANEL_VOICE):setVisible(false)
	self:getChildNode(BTN_MUTE):setVisible(true)
	self:getChildNode(BTN_UNMUTE):setVisible(false)

	local cb = function(event) print("event cb = " .. event) end
	voiceManager:setPlayCallback(cb)

	local speakBtn = self:getChildNode(BTN_SPEAK)
	speakBtn:addTouchEventListener(handler(self, self.speakCB))

	-- local playBtn = self:getChildNode(BTN_PLAY_VOICE)
	-- playBtn:addTouchEventListener(handler(self, self.playCB))
	
end

local FPS_TAG = 100000
local NET_TAG = 200000
local TOTAL_NODES_TAG = 300000
function BattleControl:initStatistic()
	local fontName = "res/font/font1.ttf"
	local fontSize = 20
	local depth = 100000
	local xOrig = 600
	local yOrig = 640
	local xOffset = 100
	local yOffset = -20
	local keyTbl = {
						"FPS : \t",
						"NET_DELAY : \t",
						"TOTAL_NODES : \t",
					}

	local valueTbl = {
						"60.0",
						"50.0",
						"0",
					}

	
	local tags = {
					FPS_TAG,
					NET_TAG,
					TOTAL_NODES_TAG,
				}

	local loopNum = table.nums(keyTbl)
	for index = 1, loopNum do
		local keyName = keyTbl[index]
		local keyLabel = cc.Label:createWithTTF(keyName, fontName, fontSize)
		keyLabel:setPosition(xOrig, yOrig + yOffset * index)
		self:getNode():addChild(keyLabel)
		keyLabel:setLocalZOrder(depth)

		local valueName = valueTbl[index]
		local valueLabel = cc.Label:createWithTTF(valueName, fontName, fontSize)
		valueLabel:setPosition(xOrig + xOffset, yOrig + yOffset * index)
		self:getNode():addChild(valueLabel)
		valueLabel:setLocalZOrder(depth)
		valueLabel:setTag(tags[index])
	end
end

function BattleControl:initInfoData( ... )
	GameData.battleInfo.leftTime = GameData.matchData.roomInfo.continuedTime
	GameData.battleInfo.userID = tostring(PlayerDataBasic.id)
	GameData.enterTime = os.time()
	print("GameData.battleInfo==="..GameData.battleInfo.userID)
	GameData.battleInfo.roleDataManager = require("data.RoleDataManager"):create()
	GameData.battleScene = self

	self.isCanDivide = true
	self.isCanJet = true
	self.timeCD = 0
	self.isWarning = false
	self.scaleTable = {}
	self.arrowList = {}
	self.view.jetBtn:addTouchEventListener(handler(self, self.jetEvent))
	self.view.divideBtn:addTouchEventListener(handler(self, self.divideEvent))
	self.view.timeLabel:setString(Utils:getMiuSecStr(GameData.battleInfo.leftTime))

	--DEBUG
	self:initStatistic()
	self.show_fps = true
	self.fpsMin = 60
	self.fpsCount = 0

	
end

function BattleControl:enterBattleSucc(x, y)
	self.view.touchLayer.isValid = true
	-- self.view:updateCameraPos(x, y, self.fieldLayer:getScaleX())
	-- self.infoLayer:setEnterBattleSuccInfo()
	
	--播放音乐
	local musicName = GlobalStatus.getInstance():getMusicName()
	if isNil(musicName) then printStack() return end
	if musicName ~= BATTLE_MUSIC then
		GlobalStatus.getInstance():setMusicName(BATTLE_MUSIC)
		self:send(GameMsg.MSG_SWITCH_BGM)
	end

	self:startScheduler()
end


local fpsCacheTbl = {}
 
function BattleControl:updateNetStateImage(dt)
	local imageName = "zd/wifi/img_wifi1.png"

	if GameData.netDelta <= 50 then
		imageName = "zd/wifi/img_wifi1.png"
	elseif GameData.netDelta > 50 and GameData.netDelta <= 100 then
		imageName = "zd/wifi/img_wifi2.png"
	elseif GameData.netDelta > 100 and GameData.netDelta <= 500 then
		imageName = "zd/wifi/img_wifi3.png"
	elseif GameData.netDelta > 500 and GameData.netDelta <= 2000 then
		imageName = "zd/wifi/img_wifi4.png"
	else
		imageName = "zd/wifi/img_wifi5.png"
	end

	self.view.netStateImage:setSpriteFrame(imageName)
	
	if self.show_fps then
		local model = self:getModel()
		local queue = model:getQueue()

		local limitNum = 10
		local value = math.floor(1 / dt)
		local average = queueAverage(queue, limitNum, value)
		local fpsValueLbl = self:getChildNode(FPS_TAG)
		fpsValueLbl:setString(average)

		local netValueLbl = self:getChildNode(NET_TAG)
		netValueLbl:setString(GameData.netDelta .. "ms")

		local totalNodes = getTotalNode(self:getNode())
		local nodesValueLbl = self:getChildNode(TOTAL_NODES_TAG)
		nodesValueLbl:setString(totalNodes)
	end
end

function BattleControl:initEntityManager( ... )
	self.entityManager = entityManager:getInstance()
	local entityF = entityFactory:getInstance()
	entityF:setEntityNodeParent(self.view.foodLayer,self.view.ballLayer)
end

function BattleControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:exitBattle()
	end

	if senderName == BTN_SET then
		self:addPop("game.BattleSetting")
	end

	if senderName == BTN_MUTE then
		if self.speakerNow then
			print("mute speaker ===="..self.speakerNow)
			voiceManager:stopPlay()
			GameData.voiceFilter[self.speakerNow] = true
			self:getChildNode(BTN_MUTE):setVisible(false)
			self:getChildNode(BTN_UNMUTE):setVisible(true)
		end
	end

	if senderName == BTN_UNMUTE then
		if self.speakerNow then
			GameData.voiceFilter[self.speakerNow] = nil
			self:getChildNode(BTN_MUTE):setVisible(true)
			self:getChildNode(BTN_UNMUTE):setVisible(false)
		end
	end
	

end

--------------------------------技能--------------------------------------------
--分裂
function BattleControl:divideEvent(sender, touchEventType)
	-- print("divideEvent touchEventType==="..touchEventType)
	if touchEventType == ccui.TouchEventType.ended and self.isCanDivide then
		self:doDivide()
	end
end

function BattleControl:doDivide()
	local isDivide = false
	local list = Utils:getSelfBallList()
	local len = #list
    local DConfig = cfg:getConfigRecord("room",GameData.roomType)
	if len <= DConfig.max_divide_count then
		for k, v in pairs(list) do
			if v.score >= DConfig.min_divide_score then
				self.isCanDivide = false
				isDivide = true

				-- if GameData.mode == Constant.GameMode.ALIVE then
					NetFunc.netBattle:divide(GameData.battleInfo.userID)
					self:refreshDivideCD()
				-- else
				-- 	SingleFunc:division(GameData.battleInfo.userID)
				-- 	self.isCanDivide = true
				-- end

				SoundManager:playEffect("button.mp3")

				break
			end
		end
	end

	-- if not isDivide then
	-- 	if GameData.mode == Constant.GameMode.ALIVE then
	-- 		NetFunc.om:jetOrDivide(2)
	-- 	end
	-- end
end

function BattleControl:refreshDivideCD()
	local action1 = cc.DelayTime:create(2.0)
	local action2 = cc.CallFunc:create(function()
		self.isCanDivide = true
	end)
	local action3 = cc.Sequence:create(action1, action2)
	self.view.divideBtn:runAction(action3)
end

function BattleControl:overDivide()
	self.isCanDivide = true
	self.view.divideBtn:stopAllActions()
end

-- --喷射
function BattleControl:jetEvent(sender, touchEventType)
	-- print("jetEvent touchEventType==="..touchEventType)
	if touchEventType == ccui.TouchEventType.began and self.isCanJet then
		self:doJet()
		local action1 = cc.DelayTime:create(0.1)
		local action2 = cc.CallFunc:create(function()
			self:doJet()
		end)
		local action3 = cc.RepeatForever:create(cc.Sequence:create(action1, action2))
		self:getNode():runAction(action3)
	elseif touchEventType == ccui.TouchEventType.ended or touchEventType == ccui.TouchEventType.canceled then
		self:getNode():stopAllActions()
	end
end

function BattleControl:doJet()
	local isJet = false
	local list = Utils:getSelfBallList()
	local DConfig = cfg:getConfigRecord("room",GameData.roomType)
	-- print("list========"..#list)
	for k, v in pairs(list) do
		-- print("score ==="..v.score..";"..DConfig.min_jet_score)
		if v.score >= DConfig.min_jet_score then
			self.isCanJet = false
			isJet = true
			
			NetFunc.netBattle:jet(GameData.battleInfo.userID)
			self:refreshJetCD()

			SoundManager:playEffect("button.mp3")
			break
		end
	end

	-- if not isJet then
	-- 	if GameData.mode == Constant.GameMode.ALIVE then
	-- 		NetFunc.om:jetOrDivide(1)
	-- 	end
	-- end
end

function BattleControl:refreshJetCD()
	local action1 = cc.DelayTime:create(2.0)
	local action2 = cc.CallFunc:create(function()
		self.isCanJet = true
	end)
	local action3 = cc.Sequence:create(action1, action2)
	self.view.jetBtn:runAction(action3)
end

function BattleControl:overJet()
	self.isCanJet = true
	self.view.jetBtn:stopAllActions()
end


function BattleControl:recv(event)
	if isNil(event) then printStack() end
	if isNil(event.name) then printStack() end
	if isNil(event.data) then printStack() end
	print("BattleControl:recv name = " .. tostring(event.name))
	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

	if name == BattleMsg.UPDATE_THEME then
		self:updateTheme(event)
		return
	end	

	if name == BattleMsg.RANK_NOTIFY then
		self:refreshBattleRank(data)
	end

	if name == BattleMsg.EXIT then
		self:exitBattleSure()
	end

	if name == BattleMsg.OVER then
		self:gameOverNotify(data)
	end

	if name == BattleMsg.DEAD then
		self.view.cameraLayer:reset()
	end

	if name == BattleMsg.SHOW_FPS then
		self:initStatistic()
		self.show_fps = true
	end

	if name == BattleMsg.START_AI then
		require("battle.AIManager.AI_autorun"):getInstance():start()
	end

	if name == BattleMsg.STOP_AI then
		require("battle.AIManager.AI_autorun"):getInstance():stop()
	end

	if name == GameMsg.MSG_DOWNLOAD_VOICE_SUCCESS then
		self:startPlayVoice(data)
	end

	if name == GameMsg.PLAY_VOICE_END then
		self.speakerNow = nil
		self:getChildNode(PANEL_VOICE):setVisible(false)
	end
end

function BattleControl:startPlayVoice( data )
	print("startPlayVoice")
	dump(data)
	local nickname = string.urldecode(data.nickname)
	self:getChildNode(PANEL_VOICE):setVisible(true)
	self.speakerNow = data.userid
	self:getChildNode(LBL_NICKNAME):setString(nickname)
	voiceManager:startPlay()
end

function BattleControl:exitBattle( ... )
	local function okBtnClick()
		self.exitFlag = true
		NetFunc.netBattle:exitBattle()
	end

	local function cancelBtnClick()
		-- self.backEvent:register()
	end

	local contentStr = QUIT_BATTLE
	local confirmCB = handler(self, okBtnClick)
	local cancelCB = handler(self, cancelBtnClick)
	self:addMsgBox(contentStr, confirmCB, cancelCB)
end

function BattleControl:gameOverNotify(params)
	SoundManager:stopMusic()

    local name = "game.BattleOver"
    local modelParam = params
    local data = buildMsgData(name, modelParam)
	self:send(BASE_MSG.REPLACE, data)


end

function BattleControl:exitBattleSure()

	-- FightServer:clearCurrInfo()
	-- fightDisconnect()

	-- self:cancelFrameScheduler()
	GameData:resetGameData()
	require("battle.AIManager.AIManager"):getInstance():clear()
	print("go home")
	self:send(BASE_MSG.GOHOME)
end

----------------------------------帧刷新定时器--------------------------------------


function BattleControl:onUpdate(dt)
	BattleControl.super.onUpdate(dt)
	GameData.battleInfo.roleDataManager:updateFrame(dt)
	self:updateChildren(dt)
	self:updateBgScaleAndCameraPos(dt)
	self:syncServerTime(dt)
	self:updateNetStateImage(dt)
end

function BattleControl:updateWeight( dt )
	local score = Utils:getTotalBallScore()
	local weight = Utils:getWeightFromScore(score)
	local str, unitType = Utils:getWeightString(weight)
	local weightName = cfg:getConfigField("weightConfig",unitType,"str")
	self.view.weightLabel:setString(str ..weightName)
end

function BattleControl:updateTime(dt)
	if GameData.battleInfo.leftTime > 0 then
		self.timeCD = self.timeCD + dt

		if self.timeCD >= 1 then
			self.timeCD = self.timeCD - 1
			GameData.battleInfo.leftTime = GameData.battleInfo.leftTime - 1

			if GameData.battleInfo.leftTime <= 30 then
				if not self.isWarning then
					self.isWarning = true

					self.view.timeLabel:setFontSize(30)
					self.view.timeLabel:setTextColor(cc.c3b(255, 0, 0))

					--播放音乐
					local musicName = GlobalStatus.getInstance():getMusicName()
					if isNil(musicName) then printStack() return end
					if musicName ~= "battle_timeout.mp3" then
						GlobalStatus.getInstance():setMusicName("battle_timeout.mp3")
						self:send(GameMsg.MSG_SWITCH_BGM)
					end
				end
			end

			self.view.timeLabel:setString(Utils:getMiuSecStr(GameData.battleInfo.leftTime))
		end
	end
end

function BattleControl:updateChildren( dt )
	self.view.touchLayer:update(dt)
	self.view.fieldLayer:update(dt)
	self:updateWeight(dt)
	self:updateTime(dt)
end

--每2秒与服务器同步一次时间
function BattleControl:syncServerTime(dt)
	GameData.syncCD = GameData.syncCD + dt

	if GameData.syncCD >= 2 then
		if not GameData.isSyncTime then
			GameData.netDelta = 2001
		end

		GameData.syncCD = GameData.syncCD - 2
		GameData.isSyncTime = false
		NetFunc.netBattle:timeSync()
	end
end


function BattleControl:updateBgScaleAndCameraPos(dt)
	local l, r, t, b = Utils:getSelfField()
	-- Utils:showSelfField(self.view.fieldLayer.ballLayer)
	if l and r and t and b then
		local width = math.floor(r - l)
		local height = math.floor(t - b)
		-- print("width=="..width..";"..height.. ";lrb==="..tostring(l)..";"..tostring(r)..";"..tostring(b)..";"..tostring(t))
		--更新背景层的缩放比例
		local scale = Utils:getScaleFromField(width, height)
	
		self:updateFieldScale(scale)
		
		--更新摄像头的位置
		local x = l + width / 2 
		local y = b + height / 2
		-- print("width ======="..width..":"..height..";"..l..";"..b..";")
		local cur_scale = self.view.fieldLayer:getScaleX()
		self.view.cameraLayer:updateCameraPos(x, y, cur_scale,dt )
	end
end

function BattleControl:updateTheme()
	local themeType = GameData.settingInfo.battleBgValue
	local info = cfg:getConfigRecord("battlethemeConfig",themeType)
	self.view.shadowImage:setSpriteFrame(info.shadow)
	self.view.topBgImage:setSpriteFrame(info.topTitleBg)
	self.view.rankBgImage:setSpriteFrame(info.rankBg)
	self.view.jetBtn:loadTextureNormal(info.jetNormalBg, ccui.TextureResType.plistType)
	self.view.jetBtn:loadTexturePressed(info.jetPressBg, ccui.TextureResType.plistType)
	self.view.divideBtn:loadTextureNormal(info.divideNormalBg, ccui.TextureResType.plistType)
	self.view.divideBtn:loadTexturePressed(info.dividePressBg, ccui.TextureResType.plistType)
	self.view.settingBtn:loadTextureNormal(info.setNormalBg, ccui.TextureResType.plistType)
	self.view.settingBtn:loadTexturePressed(info.setPressBg, ccui.TextureResType.plistType)
	-- self.view.fieldLayer:setColor(info.color)

	self.view.fieldLayer:updateTheme()
	self.view.touchLayer:updateTheme()
	self.view:updateHandHabit()
	-- self.view.themeLayer:setCameraMask(2)

end


--------------------------------排行榜--------------------------------------------
function BattleControl:refreshBattleRank(info)
	local len = #info.datas

	for i = 1, 11 do
		if i == 11 then
			assert(info.myrank, "myrank data")
			local name = string.urldecode(PlayerDataBasic.nickname)
			if info.datas[info.myrank] then
				name = string.urldecode(info.datas[info.myrank].nickname)
			end	
			self.view:setMyRank(info.myrank,name)
		else
			if i <= len then
				self.view:setRankAndName(i,string.urldecode(info.datas[i].nickname))
			else
				self.view:setRankAndName(i,"")
			end
		end
	end
end

function BattleControl:stateNotify(enter, leave, move, dead)
	self.view.fieldLayer:modifyItem(enter, leave, move, dead)
end

function BattleControl:peerNotify( params )
	local viewsize = gDirector:getWinSize()
	local x = viewsize.width
	local y = viewsize.height 
	local rad_t = math.atan(y/x)
	for k , v in pairs(params.users) do
		local flag = Utils:peerInSight(v.userid)
		if not flag then
			if self.arrowList[v.userid] == nil then
				self.arrowList[v.userid] = cc.Sprite:createWithSpriteFrameName("zd_new/arrow.png")
				self:getNode():addChild(self.arrowList[v.userid])
				self.arrowList[v.userid]:setAnchorPoint(cc.p(0,0.5))
			end
			-- self.arrowList[v.userid]:
			self.arrowList[v.userid]:setVisible(true)
			local alpha = Utils:getPeerMoveDirection(v.x,v.y)
			local alpharad = math.rad(alpha)
			if alpharad >= (math.pi*2- rad_t) or alpharad < (0+ rad_t) then
				x = viewsize.width
				y = viewsize.width/2 * math.tan(alpharad) + viewsize.height/2
				anchor = cc.p(0,0.5)
			elseif alpharad >= (rad_t)  and alpharad < (math.pi- rad_t) then
				x = viewsize.height/2*(math.tan(math.pi/2-alpharad))+ viewsize.width/2
				y = viewsize.height
			elseif alpharad >= (math.pi- rad_t) and alpharad < (math.pi+ rad_t) then
				x = 0
				y = -viewsize.width/2 * math.tan(alpharad) + viewsize.height/2
			else
				x = -viewsize.height/2*(math.tan(math.pi/2-alpharad))+ viewsize.width/2
				y = 0
			end
			self.arrowList[v.userid]:setPosition(x,y)
			self.arrowList[v.userid]:setRotation(180-alpha)
		else
			if self.arrowList[v.userid] then
				self.arrowList[v.userid]:setVisible(false)
			end
		end
	end 
end

function BattleControl:foodNotify(enter, leave)
	self.view.fieldLayer:modifyFood(enter, leave)
end

function BattleControl:playBattleExp(params)
	self.view.fieldLayer:playExp(params.isNet, params.userID, params.sex, params.expID)
end

function BattleControl:setRoomLabel( )
	self:getChildNode("Text_test"):setVisible(false)
	self:getChildNode("Text_room"):setVisible(true)
	self:getChildNode("Text_room_number"):setVisible(true)
	self:getChildNode("Text_room_number"):setString("---")
	if GameData.matchData and GameData.matchData.roomInfo then
		self:getChildNode("Text_room_number"):setString(GameData.matchData.roomInfo.id)
	end
end


function BattleControl:updateFieldScale(scale)
	local fieldScale = self.model:getFieldScale()
	-- print("updateFieldScale==="..scale..";"..fieldScale)


	if fieldScale ~= scale then
		table.insert(self.scaleTable,scale)
		local temp_s = {self.scaleTable[1]}
		if self.scaleTable[1] > scale then
			for i , v in ipairs( self.scaleTable ) do
				if temp_s[#temp_s] > v then
					table.insert(temp_s, v)
				end
			end
		elseif self.scaleTable[1] < scale then
			for i , v in ipairs( self.scaleTable ) do
				if temp_s[#temp_s] < v then
					table.insert(temp_s, v)
				end
			end
		else

		end
		self.scaleTable = temp_s
		-- dump(self.scaleTable)
		self.model:setFieldScale(scale) 
		-- self.view.fieldLayer:setScale(scale)

		local function changeScale( )
			local action1 = cc.ScaleTo:create(1, self.scaleTable[1])
			local action2 = cc.CallFunc:create(function()
				table.remove(self.scaleTable, 1)
				if #self.scaleTable > 0 then
					changeScale()
				end
			end)
			local action5 = cc.Sequence:create(action1, action2)
			self.view.fieldLayer:runAction(action5)
		end
		changeScale()
		
		-- self.view.fieldLayer:stopAllActions()
		-- self.view.fieldLayer:setScale(scale)
		-- self.view.fieldLayer:runAction()
	end
end
	

function BattleControl:speakCB(sender, touchEventType)
	print("speakCB============"..touchEventType)
	if touchEventType == ccui.TouchEventType.began then
		local anime = ccs.Armature:create("yuyin")
		anime:getAnimation():play("yuyin", -1, 1)
		self:getChildNode(NODE_ANIME):addChild(anime)
		voiceManager:startSpeak()

	end

	if touchEventType == ccui.TouchEventType.canceled then
		self:getChildNode(NODE_ANIME):removeAllChildren()
		voiceManager:cancelSpeak()
	end

	if touchEventType == ccui.TouchEventType.ended then
		self:getChildNode(NODE_ANIME):removeAllChildren()
		voiceManager:stopSpeak()
	end
end


-- function BattleControl:playCB(sender, touchEventType)
-- 	if touchEventType == ccui.TouchEventType.began then
-- 		voiceManager:startPlay()
-- 	end
-- end

return BattleControl