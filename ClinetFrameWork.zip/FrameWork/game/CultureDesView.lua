local EngineView = require "EngineView"
local CultureDesView = class("CultureDesView", EngineView)

local csbFilePath = "res/CultureDes.csb"
CULTURE_CSB_NODE = 1000

function CultureDesView:ctor(node)
	CultureDesView.super.ctor(self, node)
end

function CultureDesView:onCreate(param)
	CultureDesView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	csbNode:setTag(CULTURE_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return CultureDesView





