local EngineGlobalStatus = require  "EngineGlobalStatus"
local GlobalStatus = class("GlobalStatus", EngineGlobalStatus)

function GlobalStatus.getInstance()
    if not GlobalStatus.instance then
        GlobalStatus.instance = GlobalStatus.new()
    end
    return GlobalStatus.instance
end

function GlobalStatus:ctor()
	self.super:ctor()

	self.memoryInfo = {}
	self.musicName = ""
	self.firstClick = true
	self.touchCount = 0
	self.touches = {} -- key:value , sender:triggerAble  -- 1 trigger, 0 not trigger, to implement single touch on UI
	self.lastestTouch = ""

	self.loginTime = os.time()
	self.cultureTime = os.time()
end

--  {
--  "availbytes" = 1417339207.02
--  "lowMemory"  = false
--  "threshold"  = 322122547.05
--  "totalbytes" = 2147483647
-- }
function GlobalStatus:setMemoryInfo(memoryInfo)
	self.memoryInfo = memoryInfo
end

function GlobalStatus:getMemoryInfo()
	return self.memoryInfo
end

function GlobalStatus:setLastestTouch(lastestTouch)
	self.lastestTouch = lastestTouch
end

function GlobalStatus:getLastestTouch()
	return self.lastestTouch
end


function GlobalStatus:printAllTouchesState()
	local touches = self.touches
	for sender, state in pairs(touches) do
		print("sender : " .. tostring(sender) .. " , state = " .. tostring(state))
	end
end

function GlobalStatus:setTouchState(sender, state)
	self.touches[sender] = state
end

function GlobalStatus:getTouchState(sender)
	return self.touches[sender]
end

function GlobalStatus:setAllTouchMute()
	local touches = self.touches
	for sender, state in pairs(touches) do
		self:setTouchState(sender, nil)
	end
end

function GlobalStatus:getMusicName()
	return self.musicName
end

function GlobalStatus:setMusicName(musicName)
	self.musicName = musicName
end

function GlobalStatus:getFirstClick()
	return self.firstClick
end

function GlobalStatus:setFirstClick(firstClick)
	self.firstClick = firstClick
end

function GlobalStatus:getTouchCount()
	return self.touchCount
end

function GlobalStatus:setTouchCount(val)
	self.touchCount = val
end

function GlobalStatus:getLoginTime()
	return self.loginTime
end

function GlobalStatus:setCultureTime(cultureTime)
	self.cultureTime = cultureTime
end

function GlobalStatus:getCultureTime()
	return self.cultureTime
end

return GlobalStatus

