local EngineView = require "EngineView"
local BrandView = class("BrandView", EngineView)

-- local csbFilePath = "res/BrandView.csb"

function BrandView:ctor(node)
	BrandView.super.ctor(self, node)
end

function BrandView:onCreate(param)
	BrandView.super.onCreate(self, param)

	-- local csbNode = cc.CSLoader:createNode(csbFilePath)
	-- if isNil(csbNode) then printStack() return end

	-- local node = self:getNode()
	-- if isNil(node) then printStack() return end	
	
	-- node:addChild(csbNode)

end

return BrandView





