local EngineView = require "EngineView"
local MatchingView = class("MatchingView", EngineView)

function MatchingView:ctor(node)
	MatchingView.super.ctor(self, node)
end

function MatchingView:onCreate(param)
	MatchingView.super.onCreate(self, param)
	local csbNode = cc.CSLoader:createNode("res/GameStart.csb")
	self:getNode():addChild(csbNode)

end


return MatchingView;