local EngineView = require "EngineView"
local BattleOverView = class("BattleOverView", EngineView)

function BattleOverView:ctor(node)
	BattleOverView.super.ctor(self, node)
end

function BattleOverView:onCreate(param)
	BattleOverView.super.onCreate(self, param)
	local csbNode = cc.CSLoader:createNode("res/Result.csb")
	if isNil(csbNode) then printStack() return end
	self:getNode():addChild(csbNode)
	csbNode:setName("csbNode")
end


return BattleOverView;