local EngineControl = require  "EngineControl"
local CharacterControl = class("CharacterControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
    GameMsg.MSG_SKIN_MERGE_RET,
    GameMsg.MSG_SKIN_CHANGE_RET
}

--SYSTEM MSGS
local BTN_RETURN = "Button_return"
local BTN_HAVE = "Button_recommend"
local BTN_EVOLUTION = "Button_teammate"
local BTN_FRAGMENT = "Button_followlist"
local IMAGE_SKIN = "Image_skin"
local BTN_SYN = "Button_syn"
local BTN_CHECK = "Button_check"

local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_HAVE,
	BTN_EVOLUTION,
	BTN_FRAGMENT,
	IMAGE_SKIN
}

--OTHER NODE
local PANEL_OWN = "Panel_own"
local PANEL_EVOLUTION = "Panel_evolution"
local PANEL_PIECE = "Panel_piece"
local PANEL_STAR = "Panel_star"
local PANEL_BLANK = "Panel_blank"
local LIST_VIEW1 = "ListView_1"
local LIST_VIEW2 = "ListView_2"
local LIST_VIEW3 = "ListView_3"
local PANEL_PROP = "Panel_prop"
local SPRITE_FINISHIED = "Sprite_finished"
local SPRITE_USING = "Sprite_using"
local TEXT_SKINNAME = "Text_skin_name"
local PANEL_SKIN = "Panel_skin"
local SPRITE_ITEM = "Sprite_item"
local SPRITE_PIECE = "Node_piece"
local SPRITE_STAR = "Node_star"
local PANEL_SYNNEED = "Panel_syn_need"
local TEXT_PROGRESS = "Text_progress"
local LOADING_BAR1 = "LoadingBar_1"
local LOADING_BAR2 = "LoadingBar_2"
local LOADING_BAR3 = "LoadingBar_3"
local SPRITE_PROP = "Node_prop"

 LEFT_NEED =
{
    PIECE = 1,--需要碎片的panel
    PROP =2,--需要道具的panel
    FINISH =3,--已合成的图片
    PIECE_AND_PROP =4,--需要道具的panel
    STAR =5,--需要道具的panel
    PIECE_AND_PROP_AND_STAR = 6--需要道具的panel
}

 LEFT_BTN =
{
    USE = 1,--使用按钮
    SYN =2,--合成按钮
    CHECK =3,--查看按钮
    FINISH =4,--使用中按钮
}

NAME_PAGE = {
    HAVE = 1,--拥有
    EVOLUTION =2,--进化
    FRAGMENT =3,--合成	
}

function CharacterControl:ctor(model, view)
	CharacterControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function CharacterControl:onCreate(param)
	CharacterControl.super.onCreate(self, param)
	if isNil(param) then printStack() return end

	local name = "game.Riches"
	self:addPanel(name)

	local backBtn = self:getChildNode(BTN_RETURN)
	if isNil(backBtn) then printStack() return end
	--用户转化入口
	-- Utils:checkUserConvert(cc.p(500, backBtn:getPositionY() - 10))

	self:initHave()
	self:initFragment()
	self:initEvolution()
	self:initHeadImage()
    local skinInfo = getUserSkinInfo()
    for i = 1, #skinInfo do
		if skinInfo[i].id == PlayerDataBasic.cur_skin then
            local leftskinindex = skinInfo[i].id
            self:getModel():setLeftskinindex(leftskinindex)

			local leftskindata = skinInfo[i]
			self:getModel():setLeftskindata(leftskindata)
            break
		end
	end
    self:updataHeadImage()
end

function CharacterControl:onEnter(param)
	CharacterControl.super.onEnter(self, param)

	local model = self:getModel()
	if isNil(model) then printStack() return end

	local menuList = model:getMenuList()
	if isNil(menuList) then printStack() return end

	local curPage = model:getCurPage()
	if notNumber(curPage) then printStack() return end

    local action1 = cc.DelayTime:create(0)
	local action2 = cc.CallFunc:create(function()
	    menuList[1].updateFunc()
        menuList[2].updateFunc()
        menuList[3].updateFunc()
        self:clickMenu(curPage)
    end)
	local action3 = cc.Sequence:create(action1, action2)
	self:getNode():runAction(action3)
end

function CharacterControl:initHave()
	local menuList = {}

	local btn = self:getChildNode(BTN_HAVE)
	if isNil(btn) then printStack() return end

	menuList.btn = btn
    menuList.btn:setBright(true)
    menuList.btn:setTitleColor(cc.c3b(197, 222, 255))

    local listPanel = self:getChildNode(PANEL_OWN)
    if isNil(listPanel) then printStack() return end

    menuList.listPanel = listPanel
    menuList.listPanel:setVisible(false)

    local panelBlank = listPanel:getChildByName(PANEL_BLANK)
    if isNil(panelBlank) then printStack() return end

    menuList.Panel_blank = panelBlank
    
    local listView = self:getChildNode(LIST_VIEW1)
    if isNil(listView) then printStack() return end

    menuList.listView = listView
	menuList.listView:setVisible(false)
	menuList.listView:removeAllItems()

	menuList.data = nil

	menuList.updateFunc = handler(self, self.updateHave)

	self:getModel():setHaveList(menuList)
end

function CharacterControl:initEvolution()
	local menuList = {}

	local btn = self:getChildNode(BTN_EVOLUTION)
	if isNil(btn) then printStack() return end

	menuList.btn = btn
    menuList.btn:setBright(true)
    menuList.btn:setTitleColor(cc.c3b(197, 222, 255))

    local listPanel = self:getChildNode(PANEL_EVOLUTION)
    if isNil(listPanel) then printStack() return end

    menuList.listPanel = listPanel
    menuList.listPanel:setVisible(false)

    local panelBlank = listPanel:getChildByName(PANEL_BLANK)
    if isNil(panelBlank) then printStack() return end

    menuList.Panel_blank = panelBlank
    
    local listView = self:getChildNode(LIST_VIEW2)
    if isNil(listView) then printStack() return end
    
    menuList.listView = listView
	menuList.listView:setVisible(false)
	menuList.listView:removeAllItems()

	menuList.data = nil

	menuList.updateFunc = handler(self, self.updateEvolution)

	self:getModel():setEvolutionList(menuList)
end

function CharacterControl:initFragment()
	local menuList = {}

	local btn = self:getChildNode(BTN_FRAGMENT)
	if isNil(btn) then printStack() return end

	menuList.btn = btn
    menuList.btn:setBright(true)
    menuList.btn:setTitleColor(cc.c3b(197, 222, 255))

    local csbNode = self:getChildNode("csbNode")
    local listPanel = csbNode:getChildByName(PANEL_PIECE)
    if isNil(listPanel) then printStack() return end

    menuList.listPanel = listPanel
    menuList.listPanel:setVisible(false)

    local panelBlank = listPanel:getChildByName(PANEL_BLANK)
    if isNil(panelBlank) then printStack() return end

    menuList.Panel_blank = panelBlank
    
    local listView = self:getChildNode(LIST_VIEW3)
    if isNil(listView) then printStack() return end
    
    menuList.listView = listView
	menuList.listView:setVisible(false)
	menuList.listView:removeAllItems()

	menuList.data = nil

	menuList.updateFunc = handler(self, self.updateFragment)

	self:getModel():setFragmentList(menuList)
end

function CharacterControl:initHeadImage()
	local headBgImage = self:getChildNode(IMAGE_SKIN)
	if isNil(headBgImage) then printStack() return end

    headBgImage:ignoreContentAdaptWithSize(true)
    headBgImage:setTouchEnabled(true)

    local panel_sysneed = self:getChildNode(PANEL_SYNNEED)
    if isNil(panel_sysneed) then printStack() return end

    local needPanel = {}
    needPanel[LEFT_NEED.PIECE] =panel_sysneed:getChildByName(PANEL_PIECE)
    if isNil(needPanel[LEFT_NEED.PIECE]) then printStack() return end

    needPanel[LEFT_NEED.PROP] = panel_sysneed:getChildByName(PANEL_PROP)
    if isNil(needPanel[LEFT_NEED.PROP]) then printStack() return end

    needPanel[LEFT_NEED.STAR] = panel_sysneed:getChildByName(PANEL_STAR)
    if isNil(needPanel[LEFT_NEED.STAR]) then printStack() return end

    needPanel[LEFT_NEED.FINISH] = panel_sysneed:getChildByName(SPRITE_FINISHIED)
    if isNil(needPanel[LEFT_NEED.FINISH]) then printStack() return end

    for i,v in pairs(LEFT_NEED) do
        if v == LEFT_NEED.FINISH then 
            needPanel[v]:setVisible(true)
        else
            if needPanel[v] then
                needPanel[v]:setVisible(false)
            end 
        end 
    end
    self:getModel():setNeedPanel(needPanel)

    local btnLeftList = {}
    btnLeftList[LEFT_BTN.FINISH] = self:getChildNode(SPRITE_USING)
    if isNil(btnLeftList[LEFT_BTN.FINISH]) then printStack() return end

    btnLeftList[LEFT_BTN.SYN] = self:getChildNode(BTN_SYN)
    if isNil(btnLeftList[LEFT_BTN.SYN]) then printStack() return end

    btnLeftList[LEFT_BTN.CHECK] = self:getChildNode(BTN_CHECK)
    if isNil(btnLeftList[LEFT_BTN.CHECK]) then printStack() return end

    for i,v in pairs(LEFT_BTN) do
        if v == LEFT_BTN.FINISH then 
            if btnLeftList[v] then
                btnLeftList[v]:setVisible(true)
            end 
        else
            if btnLeftList[v] then
                btnLeftList[v]:setVisible(false)
                local  function onBtnLeftList()
                    self:onHeadImage(v)
                end
                btnLeftList[v]:addClickEventListener(onBtnLeftList)
            end 
        end 
    end 
    self:getModel():setBtnLeftList(btnLeftList)
end

function CharacterControl:onHeadImage()
    local leftskindata = self:getModel():getLeftskindata()
    local leftskinindex = self:getModel():getLeftskinindex()

    local name = "game.SkinLevel"
    local param = {modelParam = {leftskindata = leftskindata,leftskinindex = leftskinindex}}
    self:addPanel(name,param)
end 

function CharacterControl:onClickItem(leftskindata,leftskinindex)
    local name = "game.SkinLevel"
    local param = {modelParam = {leftskinindex = leftskinindex,leftskindata = leftskindata}}
    self:addPanel(name,param)
end 

function CharacterControl:clickMenu(index)
	local model = self:getModel()
	local menuIndex = model:getCurPage()
	if isNil(menuIndex) then printStack() return end

	local menuList = model:getMenuList()
	if isNil(menuList) then printStack() return end

	if menuIndex ~= -1 then
		menuList[menuIndex].btn:setTouchEnabled(true)
		menuList[menuIndex].btn:setBright(true)
		menuList[menuIndex].listView:setVisible(false)
        menuList[menuIndex].listPanel:setVisible(false)
        menuList[menuIndex].btn:setTitleColor(display.COLOR_WHITE)
        menuList[menuIndex].btn:setTitleColor(cc.c3b(197, 222, 255))
	end

	menuIndex = index
    model:setCurPage(menuIndex)
	menuList[menuIndex].btn:setTouchEnabled(false)
    menuList[menuIndex].btn:setTitleColor(display.COLOR_WHITE)
	menuList[menuIndex].btn:setBright(false)
	menuList[menuIndex].listView:setVisible(true)
    menuList[menuIndex].listPanel:setVisible(true)
	menuList[menuIndex].updateFunc()
end

function CharacterControl:updataHeadImage()
    local itemConfig = self:getTable("item")
    if isNil(itemConfig) then printStack() return end

    local synthesisConfig = self:getTable("synthesis")
    if isNil(synthesisConfig) then printStack() return end

    local skinInfo = getUserSkinInfo()

	local model = self:getModel()

    local count = nil
    local count2 = nil
    local count3 = nil

    local leftskinindex = model:getLeftskinindex()
    if isNil(leftskinindex) then printStack() return end
    if isNil(itemConfig[leftskinindex]) then printStack() return end

    local leftskindata = {}
    for i = 1, #skinInfo do
		if skinInfo[i].id == leftskinindex then
		    leftskindata = skinInfo[i]
		    model:setLeftskindata(leftskindata)
		    break
		end
    end

    --判断使用的角色是不是同一角色begin
    if isNewRole(leftskinindex) then -- 如果是角色皮肤
        local templevel = 1
        for i = 1, #skinInfo do
            if skinInfo[i].id == PlayerDataBasic.cur_skin  then
                if self:getskintype(skinInfo[i].id) == self:getskintype(leftskinindex) then
                    templevel = getskinlevel(skinInfo[i].id)
                    if isNil(templevel) then printStack() return end

                    leftskindata,leftskinindex = getSkinInfoForLevel(templevel,leftskinindex)
                    if isNil(leftskindata) then printStack() return end
                    if isNil(leftskinindex) then printStack() return end
                end 
                break
            end 
        end
    end 
    --判断使用的角色是不是同一角色end
    --设置皮肤icon
    local panel_skin = self:getChildNode(PANEL_SKIN)
    if isNil(panel_skin) then printStack() return end

    local textskinname = panel_skin:getChildByName(TEXT_SKINNAME)
    if isNil(textskinname) then printStack() return end

    textskinname:setString(itemConfig[leftskinindex].name)

	local headBgImage = panel_skin:getChildByName(IMAGE_SKIN)
    if isNil(headBgImage) then printStack() return end
    setImgIconById(headBgImage, leftskinindex )

    --设置品质icon
    if itemConfig[leftskinindex].quality then
        --品质
        local node = panel_skin:getChildByName(PANEL_STAR):getChildByName(SPRITE_ITEM)
        if isNil(node) then printStack() return end

        local path = "jsjm/pf_txt"..itemConfig[leftskinindex].quality.."_1.png"
        setLocalSpriteFrame(node,path)
    end 

    if isNewRole(leftskinindex) then -- 如果是角色皮肤
        for k = 1, 4 do--如果当前角色已经是合成状态则显示下阶段需要合成的材料
            local skindata1 , leftskinindex1  = getSkinInfoForLevel(k,leftskinindex)--获取后一等级的数据
            if isNil(skindata1) then printStack() return end
            if isNil(leftskinindex1) then printStack() return end

            if not skindata1.count or skindata1.count ~= 0 then--后一等级没有合完成
                leftskinindex = leftskinindex1
                leftskindata = skindata1
                break
            end 
        end 
    end 

    --根据碎片跟道具数量设置按钮状态
    local needPanel = model:getNeedPanel()
    if isNil(needPanel) then printStack() return end

    local btnLeftList = model:getBtnLeftList()
    if isNil(btnLeftList) then printStack() return end
    
    if itemConfig[leftskinindex].b_synthesis==0 then
        for i,v in pairs(LEFT_NEED) do
            if v == LEFT_NEED.FINISH then 
                needPanel[v]:setVisible(true)
            else
                if needPanel[v] then
                    needPanel[v]:setVisible(false)
                end 
            end 
        end

        for i,v in pairs(LEFT_BTN) do
            if v == LEFT_BTN.FINISH then 
                if btnLeftList[v] then
                    btnLeftList[v]:setVisible(true)
                end 
            else
                if btnLeftList[v] then
                    btnLeftList[v]:setVisible(false)
                end 
            end 
        end 
        return 
    end
    local synthesisInfo = synthesisConfig[itemConfig[leftskinindex].compound]
    if isNil(synthesisInfo) then printStack() return end
    local level = getskinlevel(synthesisInfo.item1) or 1
    local giftnum = synthesisInfo.num2
    local totalNum = synthesisInfo.num1
    local giftid = synthesisInfo.item2
    local piecenum =getItemCountById(synthesisInfo.item1)
    local costid = synthesisInfo.item3
    local costnum = synthesisInfo.num3
    local itemBagCount = giftid~=0 and getItemCountById(giftid) or 0
    local itemBagCount2 = costid~=0 and getItemCountById(costid) or 0

    local needstate = 0
    local btnstate = 0
    if leftskindata.count and leftskindata.count == 0 then --已拥有的皮肤
		needstate = LEFT_NEED.FINISH
        if leftskindata.id and leftskindata.id == PlayerDataBasic.cur_skin then
            btnstate = LEFT_BTN.FINISH
        else
            btnstate = LEFT_BTN.CHECK
        end
    elseif piecenum >= totalNum then--条件一满足
	    count = piecenum
        if giftnum == 0 then--判断是否需要条件2
            needstate = LEFT_NEED.PIECE
            btnstate = LEFT_BTN.SYN
        else
            count2 = itemBagCount
            if itemBagCount >= giftnum then--条件2满足
                if costnum == 0 then
                    needstate = LEFT_NEED.PIECE_AND_PROP
                    btnstate = LEFT_BTN.SYN
                else
                    count3 = itemBagCount2
                    needstate = LEFT_NEED.PIECE_AND_PROP_AND_STAR
                    if itemBagCount2 >= costnum then--条件3满足
                        btnstate = LEFT_BTN.SYN
                    else
                        btnstate = LEFT_BTN.CHECK
                    end
                end
            else
                needstate = LEFT_NEED.PIECE_AND_PROP
                btnstate = LEFT_BTN.CHECK
            end 
        end 
    else
        count = piecenum
        needstate = LEFT_NEED.PIECE
        btnstate = LEFT_BTN.CHECK
        if giftnum ~= 0 then
            count2 = itemBagCount
            needstate = LEFT_NEED.PIECE_AND_PROP
        end
        if costnum ~= 0 then
            needstate = LEFT_NEED.PIECE_AND_PROP_AND_STAR
            count3 = itemBagCount2 
        end 
	end

    for i,v in pairs(LEFT_NEED) do
        if v == needstate then 
            if needPanel[v] then
                needPanel[v]:setVisible(true)
            end 
        else
            if needPanel[v] then
                needPanel[v]:setVisible(false)
            end 
        end 
        if needstate == LEFT_NEED.PIECE_AND_PROP then
            needPanel[LEFT_NEED.FINISH]:setVisible(false)
            needPanel[LEFT_NEED.PIECE]:setVisible(true)
            needPanel[LEFT_NEED.PROP]:setVisible(true)
            needPanel[LEFT_NEED.STAR]:setVisible(false)
        elseif needstate == LEFT_NEED.PIECE_AND_PROP_AND_STAR then
            needPanel[LEFT_NEED.FINISH]:setVisible(false)
            needPanel[LEFT_NEED.PIECE]:setVisible(true)
            needPanel[LEFT_NEED.PROP]:setVisible(true)
            needPanel[LEFT_NEED.STAR]:setVisible(true)
        end 
    end 

    for i,v in pairs(LEFT_BTN) do
        if v == btnstate then 
            if btnLeftList[v] then
                btnLeftList[v]:setVisible(true)
            end 
        else
            if btnLeftList[v] then
                btnLeftList[v]:setVisible(false)
            end 
        end 
    end 

    --设置进度条
    local panel_sysneed = self:getChildNode(PANEL_SYNNEED)
    if isNil(panel_sysneed) then printStack() return end

    local Panel_piece = panel_sysneed:getChildByName(PANEL_PIECE)
    if isNil(Panel_piece) then printStack() return end

    local Panel_prop = panel_sysneed:getChildByName(PANEL_PROP)
    if isNil(Panel_piece) then printStack() return end

    local Panel_star = panel_sysneed:getChildByName(PANEL_STAR)
    if isNil(Panel_star) then printStack() return end
    if count then
        local str = tostring(count).."/"..tostring(totalNum)

        local progress1 = Panel_piece:getChildByName(TEXT_PROGRESS)
        if isNil(progress1) then printStack() return end
        progress1:setString(str)

        local loadingBar1 = self:getChildNode(LOADING_BAR1)
        if isNil(loadingBar1) then printStack() return end

        loadingBar1:setPercent(count/totalNum*100)  
        if count2 then
            local str2 = tostring(count2).."/"..tostring(giftnum)

	        local progress2 = Panel_prop:getChildByName(TEXT_PROGRESS)
	        if isNil(progress2) then printStack() return end
	        progress2:setString(str2)

	        local loadingBar2 = self:getChildNode(LOADING_BAR2)
	        if isNil(loadingBar2) then printStack() return end
            loadingBar2:setPercent(count2/giftnum*100)
            if count3 then
                local str3 = tostring(count3).."/"..tostring(costnum)

                local progress3 = Panel_star:getChildByName(TEXT_PROGRESS)
                if isNil(progress3) then printStack() return end
                progress3:setString(str3)

                local loadingBar3 = self:getChildNode(LOADING_BAR3)
                if isNil(loadingBar3) then printStack() return end
                loadingBar3:setPercent(count3/costnum*100)

                Panel_piece:setPositionY(75)
                Panel_prop:setPositionY(30)
            else
                Panel_piece:setPositionY(60)
                Panel_prop:setPositionY(0)
            end
        else
            Panel_piece:setPositionY(30)
        end  
    end

    --设置碎片跟道具的icon
    local node = Panel_piece:getChildByName(SPRITE_PIECE)
    if isNil(node) then printStack() return end

    local node2 = Panel_prop:getChildByName(SPRITE_PROP)
    if isNil(node2) then printStack() return end

    local node3 = Panel_star:getChildByName(SPRITE_STAR)
    if isNil(node3) then printStack() return end

    addItmeNode(node,synthesisInfo.item1)
    if giftid ~= 0 then
        addItmeNode(node2,giftid)
    end 

    if costid ~= 0 then
        addItmeNode(node3,costid)
    end 
end

function CharacterControl:updateHave()
	local haveList = self:getModel():getHaveList()
	if isNil(haveList) then printStack() return end

	if not haveList.data then
		self:sepHaveData()
		self:addNodeToListView(1)
	end
end

function CharacterControl:updateEvolution()
	local evolutionList = self:getModel():getEvolutionList()
	if isNil(evolutionList) then printStack() return end

	if not evolutionList.data then
		self:sepEvolutionData()
		self:addNodeToListView(2)
	end
end

function CharacterControl:updateFragment()
	local fragmentList = self:getModel():getFragmentList()
	if isNil(fragmentList) then printStack() return end

	if not fragmentList.data then
		self:sepFragmentData()
		self:addNodeToListView(3)
	end
end

function CharacterControl:sepHaveData()
    local skinInfo = getUserSkinInfo()

    local itemConfig = self:getTable("item")
    if isNil(itemConfig) then printStack() return end

    local synthesisConfig = self:getTable("synthesis")
    if isNil(synthesisConfig) then printStack() return end

	local model = self:getModel()
	local haveList = model:getHaveList()
	if isNil(haveList) then printStack() return end

	haveList.data = {}

	--分离数据
    local skinInfo = self:getskinInfo()
    if isNil(skinInfo) then printStack() return end

	for i = 1, #skinInfo do
		if skinInfo[i].count == 0  then
			local index = skinInfo[i].id
			if notNumber(index) then printStack() return end

            local count = skinInfo[i].count
            if notNumber(count) then printStack() return end

			if index > 0 then
                haveList.data[#haveList.data + 1] = {skinIndex = 1,isuse = 0,issyn = 0,count = 0}
				haveList.data[#haveList.data].skinIndex = index
			end
		end
	end

    --判断是否能合成 begin
    for i , v in pairs(haveList.data) do
        local data  = {}
        local tempskinIndex = v.skinIndex
        for i = 1, #skinInfo do
		    if skinInfo[i].id == tempskinIndex then
			    data = skinInfo[i]
			    break
		    end
	    end

        local tempdata = data
        if data then
            if isNewRole(tempskinIndex) then--可进化的角色
                for k = 1, 4 do--如果当前角色已经是合成状态则显示下阶段需要合成的材料
                    local skindata1 , leftskinindex1  = getSkinInfoForLevel(k,tempskinIndex)--获取后一等级的数据
                    if isNil(skindata1) then printStack() return end
                    if isNil(leftskinindex1) then printStack() return end

                    if not skindata1.count or skindata1.count ~= 0 then--后一等级没有合完成
                        tempskinIndex = leftskinindex1
                        tempdata = skindata1
                        break
                    end 
                end 

                if itemConfig[tempskinIndex].b_synthesis==1 then
                    local synthesisInfo = synthesisConfig[itemConfig[tempskinIndex].compound]
                    if isNil(synthesisInfo) then printStack() return end
                    local level = getskinlevel(synthesisInfo.item1) or 1
                    local gifttotalnum = synthesisInfo.num2
                    local totalnum = synthesisInfo.num1
                    local giftid = synthesisInfo.item2
                    local itembagnum = getItemCountById(giftid)
                    local piecenum = getItemCountById(synthesisInfo.item1)

    		        if piecenum >= totalnum and tempdata.count ~= 0 then
                        if gifttotalnum == 0 or itembagnum >= gifttotalnum then
                            v.issyn = 1
                        end    
    		        end
                end
            end 

            if data.id == PlayerDataBasic.cur_skin then
		        v.isuse = 1
            end  
	    end
    end 
    --判断是否能合成 end

	--排序
	local syndata  = {}
    local notsyndata  = {}
    for i , v in pairs(haveList.data) do
        if v.issyn == 1 then
            syndata[#syndata+1] = v
        else
            notsyndata[#notsyndata+1] = v
        end  
    end  

    table.sort(syndata, function(a, b)
		return itemConfig[a.skinIndex].sort > itemConfig[b.skinIndex].sort 
	end)

    table.sort(notsyndata, function(a, b)
		return itemConfig[a.skinIndex].sort > itemConfig[b.skinIndex].sort 
	end)

    for i , v in pairs(notsyndata) do
        syndata[#syndata+1] = v
    end 

    haveList.data = syndata

    model:setHaveList(haveList)
end

function CharacterControl:sepEvolutionData()
	local model = self:getModel()
	local evolutionList = model:getEvolutionList()
	if isNil(evolutionList) then printStack() return end

    local itemConfig = self:getTable("item")
    if isNil(itemConfig) then printStack() return end

    local synthesisConfig = self:getTable("synthesis")
    if isNil(synthesisConfig) then printStack() return end

	evolutionList.data = {}

    local skinInfo = self:getskinInfo()
    if isNil(skinInfo) then printStack() return end
	for i,v in pairs(itemConfig) do
		if isNewRole(i) and v.type =="SKIN" then
            local inhave = false 
            for j = 1, #skinInfo do --判断已拥有里是否有同一角色
		        if skinInfo[j].id and self:getskintype(skinInfo[j].id) == self:getskintype(i)  then
                    inhave = true
		        end
	        end

            for j = 1, #evolutionList.data do--判断能进化里是否已经加入同一角色
                if evolutionList.data[j].skinIndex then
                    local type1,level1 = self:getskintype(evolutionList.data[j].skinIndex)
                    if isNil(type1) then printStack() return end
                    if notNumber(level1) then printStack() return end

                    local type2,level2 = self:getskintype(i)
                    if isNil(type2) then printStack() return end
                    if notNumber(level2) then printStack() return end

                    if type1 == type2  then
                        if level1 > level2 then --如果是同一角色，且阶段比较低，则重新赋值
                            evolutionList.data[j].skinIndex = i 
                        end 
                        inhave = true
		            end
                end 
            end 

            if inhave == false then
                evolutionList.data[#evolutionList.data + 1] = {skinIndex = 1,isuse = 0,issyn = 0,}
                evolutionList.data[#evolutionList.data].skinIndex = i
            end 
		end
	end

    --判断是否能合成 begin
    for i , v in pairs(evolutionList.data) do
        local tempskinIndex = v.skinIndex
        if itemConfig[tempskinIndex].b_synthesis==1 then
            local synthesisInfo = synthesisConfig[itemConfig[tempskinIndex].compound]
            if isNil(synthesisInfo) then printStack() return end
            local level = getskinlevel(synthesisInfo.item1) or 1
            local gifttotalnum = synthesisInfo.num2
            local totalnum = synthesisInfo.num1
            local giftid = synthesisInfo.item2
            local itembagnum = getItemCountById(giftid)
            local piecenum = getItemCountById(synthesisInfo.item1)
                
    	    if piecenum >= totalnum then
                if gifttotalnum == 0 or itembagnum >= gifttotalnum then
                    v.issyn = 1
                end   
            end 
        end
    end 
    --判断是否能合成 end

	local syndata  = {}
    local notsyndata  = {}
    for i , v in pairs(evolutionList.data) do
        if v.issyn == 1 then
            syndata[#syndata+1] = v
        else
            notsyndata[#notsyndata+1] = v
        end  
    end  

    table.sort(syndata, function(a, b)
		return itemConfig[a.skinIndex].sort > itemConfig[b.skinIndex].sort 
	end)

    table.sort(notsyndata, function(a, b)
		return itemConfig[a.skinIndex].sort > itemConfig[b.skinIndex].sort 
	end)

    for i , v in pairs(notsyndata) do
        syndata[#syndata+1] = v
    end 

    evolutionList.data = syndata

    model:setEvolutionList(evolutionList)
end

function CharacterControl:sepFragmentData()
	local model = self:getModel()
	local fragmentList = model:getFragmentList()
	if isNil(fragmentList) then printStack() return end

    local itemConfig = self:getTable("item")
    if isNil(itemConfig) then printStack() return end

    local synthesisConfig = self:getTable("synthesis")
    if isNil(synthesisConfig) then printStack() return end

	fragmentList.data = {}

	local haveList = model:getHaveList()
	if isNil(haveList) then printStack() return end

    local skinInfo = self:getskinInfo()
    if isNil(skinInfo) then printStack() return end

    local evolutionList = self:getModel():getEvolutionList()
    if isNil(evolutionList) then printStack() return end
    
    for i,v in pairs(itemConfig) do
        if v.b_synthesis == 1 and v.type =="SKIN" then
            local inhave = false 
            for j = 1, #skinInfo do --判断已拥有里是否有同一角色
                if i == skinInfo[j].id then
                    inhave = true
                end
            end

            for j = 1, #evolutionList.data do --判断已拥有里是否有同一角色
                if i == evolutionList.data[j].skinIndex then
                    inhave = true
                end
            end

            if v.pre_order ~= 0 then
                inhave = true
            elseif isNewRole(i) then --是否可进化
                for index=1,4 do
                    local _,id = getSkinInfoForLevel(index,i)
                    for j = 1, #skinInfo do --判断是否有进化前的形态
                        if id == skinInfo[j].id then
                            inhave = true
                        end
                    end                   
                end
            end

            if inhave == false then
                fragmentList.data[#fragmentList.data + 1] = {skinIndex = 1,isuse = 0,issyn = 0,}
                fragmentList.data[#fragmentList.data].skinIndex = i
            end 
        end
    end

    --判断是否能合成 begin
    for i , v in pairs(fragmentList.data) do
        local tempskinIndex = v.skinIndex
        -- if itemConfig[tempskinIndex].b_synthesis==1 then
            local synthesisInfo = synthesisConfig[itemConfig[tempskinIndex].compound]
            if isNil(synthesisInfo) then printStack() return end
            local level = getskinlevel(synthesisInfo.item1)
            local gifttotalnum = synthesisInfo.num2
            local totalnum = synthesisInfo.num1
            local giftid = synthesisInfo.item2
            local itembagnum = getItemCountById(giftid)
            local piecenum = getItemCountById(synthesisInfo.item1)
                
            if piecenum >= totalnum then
                if gifttotalnum == 0 or itembagnum >= gifttotalnum then
                    v.issyn = 1
                end   
            end 
        -- end
    end

    --判断是否能合成 end
    local syndata  = {}
    local notsyndata  = {}
    for i , v in pairs(fragmentList.data) do
        if v.issyn == 1 then
            syndata[#syndata+1] = v
        else
            notsyndata[#notsyndata+1] = v
        end  
    end  

    table.sort(syndata, function(a, b)
		return itemConfig[a.skinIndex].sort > itemConfig[b.skinIndex].sort 
	end)

    table.sort(notsyndata, function(a, b)
		return itemConfig[a.skinIndex].sort > itemConfig[b.skinIndex].sort 
	end)

    for i , v in pairs(notsyndata) do
        syndata[#syndata+1] = v
    end 

    fragmentList.data = syndata

    model:setFragmentList(fragmentList)
end

function CharacterControl:addNodeToListView(index)
	local model = self:getModel()
	local menuList = model:getMenuList()
	if isNil(menuList) then printStack() return end

	if notNumber(index) then printStack() return end

	local temp  = {}
	local len = table.nums(menuList[index].data)

	for i = 1, len do
        temp[#temp + 1] = menuList[index].data[i]

		local isCan = false
		local lineIndex = 0
        if i % 3 == 0 then
            isCan = true
            lineIndex = i / 3
        elseif i == len then
            isCan = true
            lineIndex = math.ceil(i / 3)
        end

        if isCan then
            local item = require("FrameWork.game.SkinItem"):create(index, lineIndex, temp,self)
            menuList[index].listView:pushBackCustomItem(item)

            isCan = false
            temp = {}
        end
	end

    if menuList[index].listView:getItem(0) then
        if menuList[index].Panel_blank then
            menuList[index].Panel_blank:setVisible(false)
        end 
    else
        if menuList[index].Panel_blank then
            menuList[index].Panel_blank:setVisible(true)
        end 
    end  
	menuList[index].listView:jumpToTop()
end


function CharacterControl:getskintype(skinID)--
    local value = tonumber(skinID)

	local type = math.floor(value / 10000)
	local temp = value % 10000
	local type2 = math.floor(temp / 10)
    local type3 = temp % 10
	return type2, type3
end

function CharacterControl:getskinInfo()
    local skinInfo = getUserSkinInfo()

    local skininfo ={}
    local isusing = {}
    isusing.id = 0
    for i = 1, #skinInfo do
        if skinInfo[i].id == PlayerDataBasic.cur_skin  then
            isusing = skinInfo[i]
        end 

        local issametype =  false
        if skinInfo[i].id and skinInfo[i].id <= 40000 and skinInfo[i].id >= 31000 then
            for j = 1,  #skininfo do
                local type1,level1 = self:getskintype(skinInfo[i].id)
                local type2,level2 = self:getskintype(skininfo[j].id)

                local type3,level3 = self:getskintype(isusing.id)
            
                if type1 == type2 and skinInfo[i].count == 0 then
                    issametype =  true
                    if level1 > level2 and type1 ~= type3 then
                        skininfo[j] = skinInfo[i]
                    end 

                    if type1 == type3 then
                        skininfo[j] = isusing
                    end 
                end  
            end 
        end 

        if issametype == false then 
            skininfo[#skininfo+1] = skinInfo[i]
        end 
    end 
    return skininfo
end 

function CharacterControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:send(BASE_MSG.POP)
	end

	if senderName == IMAGE_SKIN then
		self:onHeadImage()
	end

	if senderName == BTN_HAVE then
		self:clickMenu(NAME_PAGE.HAVE)
	end

	if senderName == BTN_EVOLUTION then
		self:clickMenu(NAME_PAGE.EVOLUTION)
	end

	if senderName == BTN_FRAGMENT then
		self:clickMenu(NAME_PAGE.FRAGMENT)
	end

end

function CharacterControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

    if name == GameMsg.MSG_SKIN_MERGE_RET then
        local bestLayer = require("FrameWork.game.GachaBestLayer"):create(data.future_item_id)
        self:getNode():addChild(bestLayer)

        self:mergeSkinRet()
        return
    end

    if name == GameMsg.MSG_SKIN_CHANGE_RET then
        self:getModel():setLeftskinindex(PlayerDataBasic.cur_skin)
        self:changeSkinRet()
        return
    end
end

function CharacterControl:mergeSkinRet()
	local menuList = self:getModel():getMenuList()
	if isNil(menuList) then printStack() return end

    self:updataHeadImage()
    
	menuList[1].data = nil
	menuList[1].listView:removeAllItems()
    menuList[2].data = nil
	menuList[2].listView:removeAllItems()
    menuList[3].data = nil
	menuList[3].listView:removeAllItems()

	local action1 = cc.DelayTime:create(0)
	local action2 = cc.CallFunc:create(function()
		menuList[1].updateFunc()
        menuList[2].updateFunc()
        menuList[3].updateFunc()
	end)
	local action3 = cc.Sequence:create(action1, action2)
	self:getNode():runAction(action3)
end

function CharacterControl:changeSkinRet()
	local haveList = self:getModel():getHaveList()
	if isNil(haveList) then printStack() return end

    self:updataHeadImage()

    haveList.data = nil
	haveList.listView:removeAllItems()

	local action1 = cc.DelayTime:create(0)
	local action2 = cc.CallFunc:create(function()
        haveList.updateFunc()
	end)
	local action3 = cc.Sequence:create(action1, action2)
	self:getNode():runAction(action3)
end

function CharacterControl:closeLevelLayer()
    if self.skinlevellayer then
        self.skinlevellayer:removeSelf()
        self.skinlevellayer = nil
    end 
end 

return CharacterControl


