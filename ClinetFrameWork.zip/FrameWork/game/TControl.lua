local EngineControl = require  "EngineControl"
local TControl = class("TControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
}

--SYSTEM MSGS
-- local BTN_RETURN = "Button_return"
local SYSTEM_MSGS = {
	-- BTN_RETURN,
}

--NODE TAG
-- local LBL_NICKNAME = "Text_name"

function TControl:ctor(model, view)
	TControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)
end

function TControl:onCreate(param)
	TControl.super.onCreate(self, param)

	-- local name = "game.Riches"
	-- self:addPanel(name)

	-- local nickNameLbl = self:getChildNode(LBL_NICKNAME)
	-- if isNil(nickNameLbl) then printStack() return end
	-- nickNameLbl:setString(PlayerDataBasic.nickname)
end

function TControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	-- if senderName == BTN_RETURN then
	-- 	self:send(BASE_MSG.POP)
	-- end

	-- if senderName == BTN_PLAYER_INFO then
	-- 	local data = {}
	-- 	data.name = "game.PlayerInfo"
	-- 	self:send(BASE_MSG.PUSH, data)
	-- end

	-- if senderName == BTN_AD then
	-- 	local data ={}
	-- 	data.func = "ADEventTracking"
	-- 	data.params = {event_name = "open_ad"}
	-- 	self:send(BASE_MSG.NET_FORM, data)
	-- 	self:addPop("game.Ad")
	-- end

	-- if senderName == BTN_MAIL then
	--     local name = "game.Mail"
	--     local modelParam = {curIndex = table.nums(MailData)}
	--     local data = buildMsgData(name, modelParam)
	--     self:send(BASE_MSG.PUSH, data)
	-- end

	-- if senderName == BTN_TIMECHARGE then
	-- 	local name = "game.TimeGift"
	-- 	self:addPop(name)
	-- end

end

function TControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

end

return TControl


