local baseView = class("baseView",require("battle.interface.viewInterface"))

function baseView:ctor( node ) -- render node
	------------------------数据-------------------------------
	-- print("baseView~~~~~~~~~~~~~~~~~~~~~"..tostring(node))
	self.parent_node = node
end

function baseView:getNode( ... )
	return self.parent_node
end

function baseView:setNode( renderNode )
	self.parent_node = renderNode
end

function baseView:onEnter(param)
	
end
function baseView:onDestroy(param)
	
end
function baseView:onUpdate(param)
	
end

return baseView
