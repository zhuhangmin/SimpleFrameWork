local baseControl = class("baseControl",require("battle.interface.controlInterface"))

function baseControl:ctor( model, view )
	self.super:ctor( model , view )
end

function baseControl:getEntityNode()
	local view = self:getView()
	if isNil(view) then printStack() return nil end
	
	local node = view:getEntityNode()
	if isNil(node) then printStack() return nil end

 	return node
end

function baseControl:onEnter(param)
	
end
function baseControl:onDestroy(param)
	
end
function baseControl:onUpdate(param)
	
end

return baseControl
