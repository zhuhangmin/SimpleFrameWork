local baseModel = class("baseModel",require("battle.interface.modelInterface")) 

-- ctor(){eid}

-- setData(data) -- netData

-- sendMsg()

-- recvMsg



-- ===========================
local baseModel = class("baseModel")
 
function baseModel:ctor( eid )
	self.eid = eid
end

function baseModel:getEid()
	return self.eid
end

function baseModel:setEid(parameter)
	if type(parameter) ~= "number" then return end
	self.eid = parameter
end

function baseModel:setData( data )
	if type(data) ~= "table" then return end
	self:setEid(data.eid)
end

function baseModel:onEnter(param)
	
end
function baseModel:onDestroy(param)
	
end
function baseModel:onUpdate(param)
	
end


return baseModel