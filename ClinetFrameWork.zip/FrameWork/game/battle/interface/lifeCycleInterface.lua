local lifeCycleInterface = class("lifeCycleInterface")


function lifeCycleInterface:ctor( )

end

function lifeCycleInterface:onCreate(param)
	error("should be override by subClass", 2)
end
function lifeCycleInterface:onEnter(param)
	error("should be override by subClass", 2)
end
function lifeCycleInterface:onDestroy(param)
	error("should be override by subClass", 2)
end


return lifeCycleInterface
