local lifeCycleInterface = "battle.interface.lifeCycleInterface"
local modelInterface = class("modelInterface",require(lifeCycleInterface))


function modelInterface:ctor( param )

end

function modelInterface:setData() 
	return nil
end

function modelInterface:getData() 
	return nil
end




return modelInterface


