local lifeCycleInterface = "battle.interface.lifeCycleInterface"
local viewInterface = class("viewInterface",require(lifeCycleInterface))

function viewInterface:ctor( param ) -- render node
	return nil
end


return viewInterface
