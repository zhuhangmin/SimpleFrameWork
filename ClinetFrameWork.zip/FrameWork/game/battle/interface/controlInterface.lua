local lifeCycleInterface = "battle.interface.lifeCycleInterface"
local controlInterface = class("controlInterface",require(lifeCycleInterface))

function controlInterface:ctor( model, view )
	self.model = model
	self.view = view
end

function controlInterface:getModel() 
	return self.model
end

function controlInterface:setModel(parameter)
	if type(parameter) ~= "table" then return end
	assert(parameter, "setModel data")
	self.model = parameter
end

function controlInterface:getView()
	return self.view
end

function controlInterface:setView(parameter)
	if type(parameter) ~= "table" then return end
	self.view = parameter
end

-------------------------------------------帧刷新--------------------------------------------------
function controlInterface:update( param )
	return nil
end

return controlInterface
