
local CameraLayer = class("CameraLayer", function()
	return cc.LayerColor:create(cc.c4b(0, 0, 0, 0))
end)

function CameraLayer:ctor(x, y)
	self.x = x or 0
	self.y = y or 0
	self.sx,self.sy =0,0
	self.dx,self.dy =0,0
	self.frameMove = {c = 0 , dx = 0 ,dy = 0}
	self:init()
end

function CameraLayer:init()
	local sx, sy = Utils:serverPosToCamerPos(self.x, self.y, 1.0)

	self.camera = cc.Camera:createOrthographic(gScreenSize.width, gScreenSize.height, 0, 1)
	-- self.camera = cc.Camera:createPerspective(30, 1136/640, 0, 1)
	self.camera:setCameraFlag(cc.CameraFlag.USER1)
	self.camera:setPosition3D(cc.vec3(sx, sy, 0))
	self:addChild(self.camera)

	self.camera:setName("cccamera")
end


function CameraLayer:updateCameraPos(x, y, scale,dt)
	local function getDxy(a,b)
		local x,y = a,b
		if self.frameMove.c and self.frameMove.c > 0 then
			-- if self.frameMove.c == 60 then
				x = x + self.frameMove.dx
				y = y + self.frameMove.dy
			-- end
			self.frameMove.c = self.frameMove.c - 1
		end
		return x,y
	end

	local s = scale or 1.0
	local sx, sy = Utils:serverPosToCamerPos(x, y, s)
	local fx, fy = self.frameMove.c*self.frameMove.dx, self.frameMove.c*self.frameMove.dy
	
	local dx = sx-(self.sx + fx)
	local dy = sy-(self.sy + fy)

	local t1 = dx - self.dx
	local t2 = dy - self.dy 
	-- if dt > 0.02 then
	-- 	if t1 ~= 0 or t2 ~= 0 then
	-- 		print("dt==="..dt)
	-- 		print("CameraLayer dx====="..math.round(t1)..";"..math.round(t2)..";"..math.round(self.dx)..";"..math.round(self.dy)..";"..math.round(self.sx)..";"..math.round(self.sy))
	-- 	end
	-- end
	local total_score = Utils:getTotalBallScore()
	local min_num = 20
	if total_score > 500 then
		min_num = 5
	end

	local dtx = math.max(min_num,math.abs(self.dx)*2)
	local dty = math.max(min_num,math.abs(self.dy)*2)
	if math.abs(t1) < dtx and math.abs(t2) < dty  then
		self.dx,self.dy = dx,dy
		sx,sy = self.sx+self.dx,self.sy+self.dy
		sx,sy = getDxy(sx,sy)
		self.sx,self.sy = sx,sy
		self.camera:setPosition3D(cc.vec3(sx, sy, 0))
	else
		if self.sx == 0 and self.sy == 0 and self.dx == 0 and self.dy == 0 then
			self.dx,self.dy = 0,0
			self.sx,self.sy = sx,sy
			self.camera:setPosition3D(cc.vec3(sx, sy, 0))
		else
			self.frameMove = {c = 60,dx = (-self.dx + dx+fx)/60,dy = (-self.dy + dy+fy)/60 }
			-- dump(self.frameMove)
			self.dx,self.dy =  getDxy(self.dx,self.dy)
			sx,sy = self.sx+self.dx,self.sy+self.dy
			self.sx,self.sy = sx,sy
			self.camera:setPosition3D(cc.vec3(sx, sy, 0))
		end
	end
 
end

function CameraLayer:reset(  )
	self.sx,self.sy =0,0
	self.dx,self.dy =0,0
	self.frameMove = {c = 0 , dx = 0 ,dy = 0}
end
			

return CameraLayer
