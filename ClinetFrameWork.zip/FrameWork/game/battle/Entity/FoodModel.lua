local FoodModel = class("FoodModel",require("battle.Entity.gameObjectModel"))

function FoodModel:ctor(eid)
	self.super:ctor(eid)
end

function FoodModel:onEnter( data )
	self:setData(data)
end

function FoodModel:setData( data )
	if type(data) ~= "table" then return end
	--super()
	self.super:setData(data)


end

return FoodModel