local FoodControl = class("FoodControl",require("battle.Entity.gameObjectControl"))
local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()

function FoodControl:ctor( data,node )
	self.super:ctor( data , node)
end

function FoodControl:initUI(  )

	local food_cfg = cfg:getTable("foodConfig")
	local len = #food_cfg
	local key = math.random(1,len)
	local imageName = "food/" .. food_cfg[key]["imgName"] ..".png"
	local minScale = food_cfg[key]["minScale"]
	local maxScale = food_cfg[key]["maxScale"]
	self.view:createNode(imageName)
	self.eid = self.model:getEid()
	
	local x,y = self.model:getPosition()
	local pos = cc.p(x,y)
	local node = self:getEntityNode()
	node:setCameraMask(2)
	node:setTag(self.eid)
	node:setPosition(pos)
	node:setScale(math.random(minScale, maxScale) / 100)


	-- print("x="..node:getPositionX()..";"..node:getPositionY())
	-- print("vis="..tostring(node:isVisible()))
	-- print("par="..tostring(node:getParent():getName()))
	-- print("food="..tostring(node:getParent():isVisible()))
	
end



function FoodControl:clearData()
	self:setTag(-1)
	self:setVisible(false)
end





function FoodControl:update()

end



return FoodControl
