local JetfoodControl = class("JetfoodControl",require("src.app.game.UI.battle.control.gameObjectControl"))

function JetfoodControl:ctor( data , node )
	self.super:ctor( data , node)
end



return JetfoodControl
