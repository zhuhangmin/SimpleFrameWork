local FoodView = class("FoodView", require("battle.Entity.gameObjectView"))
--普通养分图片
local	FoodImageName = {
	[1] = "food/food1.png",
	[2] = "food/food2.png",
	[3] = "food/food3.png",
	[4] = "food/food4.png",
	[5] = "food/food5.png",
	[6] = "food/food6.png",
	[7] = "food/food7.png",
	[8] = "food/food8.png",
	[9] = "food/food9.png",
	[10] = "food/food10.png",
}
function FoodView:ctor(node) -- render node
	self.super:ctor(node)
end

function FoodView:onEnter()
	
end

function FoodView:createNode( name )
	local node = cc.Sprite:createWithSpriteFrameName(name)
	self:addEntityNode(node)
end

return FoodView
