local GrassControl = class("GrassControl",require("battle.Entity.gameObjectControl"))

function GrassControl:ctor( data , node )
	self.super:ctor( data , node)
end

function GrassControl:initUI(  )
	print("Grass init ui")
	self.super:initUI( )

	local score = self.model:getScore()
	local scale = self:calScale(score)
	local node = self:getEntityNode()
	node:setScale(scale)

	-- node:getAnimation():setMovementEventCallFunc(function(armature, type, movementID)
	-- 	if type == ccs.MovementEventType.complete then
	-- 		self:playAnim()
	-- 	end
	-- end)
	-- self:playAnim()
end

function GrassControl:playAnim()
	local random = math.random(1, 7)
	local animName = "mj_grass_" .. random

	self:getEntityNode():getAnimation():play(animName, -1, 0)
end

--计算缩放比例
function GrassControl:calScale(score)
	local scale = 1.0
	if score == 60 then
		scale = 0.83
	elseif score == 100 then
		scale = 1.07
	elseif score == 140 then
		scale = 1.27
	end
	return scale
end



function GrassControl:clearData()
	self:setTag(-1)
	self:setVisible(false)
end

return GrassControl
