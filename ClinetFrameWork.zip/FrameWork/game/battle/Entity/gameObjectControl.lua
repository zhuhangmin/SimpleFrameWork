local gameObjectControl = class("gameObjectControl",require("battle.engine.controlEngine"))
local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()

function gameObjectControl:ctor( model, view )
	self.super:ctor( model , view )
end

function gameObjectControl:onEnter( ... )
	-- print("onEnter init ui")
	self:initUI()
end

--实体方向改变
function gameObjectControl:changeDir(dir)
	self.model.turnDir = dir / 10000

	if self.model.turnDir >= 0 then
		self.model.isTogether = false
	end
end

--设置中心点位置
function gameObjectControl:setCenter(x, y)
	self.model.centerX = x
	self.model.centerY = y

	self.model.isTogether = true
end



function gameObjectControl:useSkill( ... )
	
end

function gameObjectControl:initUI()
	self.eid = self.model:getEid()
	self.userID = self.model:getUserid()

	local x,y = self.model:getPosition()
	local pos = cc.p(x,y)
	local score = self.model:getWeight()
	local node = self:getEntityNode()
	node:setCameraMask(2)
	node:setTag(self.eid)
	node:setAnchorPoint(cc.p(0.5, 0.5))
	node:setPosition(pos)
	node:setLocalZOrder(score)
end

function gameObjectControl:update( dt )
	print("gameObjectControl;update"..self.model:getEntityId()..";"..self.model:getEid() )
end

function gameObjectControl:updateRotation()
	local angle = self.model.rotation - self.model.destDir

	if math.abs(angle) > 180 then
		if angle > 0 then
			angle = self.model.rotation - (self.model.destDir + 360)
		else
			angle = self.model.rotation + 360 - self.model.destDir
		end
	end

	--判断是否达到目标角度(这边用乘法判断原因是：判断是否有可能超过)
	if angle * self.model.angleVec < 0 then
		self.model.rotation = self.model.rotation + self.model.angleVec
	else
		self.model.rotation = self.model.destDir
	end
end

function gameObjectControl:updatePos(dt)
	local sx, sy, vx, vy = self:calcMove(dt)
	self.model.x = self.model.x + sx
	self.model.y = self.model.y + sy
	-- print("sx==="..sx..";"..sy..";==="..self.model.x..";"..self.model.y)
	-- self.speedx = vx
	-- self.speedy = vy

	--补帧
	-- self:calcIncreMove(sx,sy)

	--边界判断
	-- self:boundaryJudge()
end


function gameObjectControl:onUpdate( param )
	print("onUpdate==========")
	self.model:setData(param)
end

function gameObjectControl:move( netData )
	local node = self:getNode()
	local data = self:getData()
	-- local netData = entityNetData:getDataById(eid)
	data:setX(netData.x)
	data:setY(netData.y)

	---补帧之后设置x+t*v+1/2*a*t*t ，y
	local x1,y1 = self:frameMove(x,y,vx,vy,ax,ay,time)
	node:setPosition(x,y)


end


--计算位移
function gameObjectControl:calcMove(dt)
	local sx, sy, vx, vy = 0, 0, 0, 0
	print("self.model.turnDir==="..self.model.turnDir..";"..self.model.actDir..";"..tostring(self.model.isTogether))
	if self.model.turnDir >= 0 or self.model.isTogether then
		local velocity = 0
		local userid = self.model:getUserid()
		if userid and tonumber(userid) > 0 then
			local radius = Utils:getBallDia(self.model:getScore()) * 0.5
			velocity = Utils:getVelocity(radius)
		end
		print("score ===="..self.model:getScore()..";"..tostring(userid)..";"..velocity)
		sx, sy, vx, vy = Utils:getDeltaMove(self.model:getVx(), self.model:getVy(), velocity, self.model.actDir, dt)
	end

	return sx, sy, vx, vy
end

--更新方向
function gameObjectControl:updateDir()
	if self.model.isTogether then
		-- if #self.parent.userList[self.userID].balls <= 1 then
		-- 	self.turnDir = -1
		-- 	self.isTogether = false
		-- else
		-- 	if math.floor(self.x) ~= self.centerX or math.floor(self.y) ~= self.centerY then
		-- 		local direct = Utils:getMoveDirection(cc.p(self.x, self.y), cc.p(self.centerX, self.centerY))

		-- 		if direct then
		-- 			direct = math.floor(direct)
		-- 			self.actDir = direct
		-- 		end
		-- 	end
		-- end
	else
		if self.model.turnDir >= 0 then
			-- if self.eid ~= self.primaryEid then
			-- 	local dir = Utils:getMoveDirection(cc.p(self.x, self.y), cc.p(self.primaryX, self.primaryY))

			-- 	if dir then
			-- 		dir = math.floor(dir)
			-- 		local angle = math.abs(dir - self.turnDir)

			-- 		if angle >= 180 then
			-- 			self.actDir = ((self.turnDir + dir + 360) / 2) % 360
			-- 		else
			-- 			self.actDir = (self.turnDir + dir) / 2
			-- 		end
			-- 	else
			-- 		self.actDir = self.turnDir
			-- 	end
			-- else
				self.model.actDir = self.model.turnDir
			-- end
		end
	end

	if self.model.destDir ~= self.model.actDir then
		self.model.destDir = self.model.actDir
		self:calcRotationAngle()
	end
end
--计算箭头旋转速度
function gameObjectControl:calcRotationAngle()
	local angle = self.model.destDir - self.model.rotation
	local frameCount = cfg:getConfigField("netBattle",1,"TURN_FRAME_COUNT")

	if math.abs(angle) > 180 then
		if angle > 0 then
			self.model.angleVec = (self.model.destDir - (self.model.rotation + 360)) / frameCount
		else
			self.model.angleVec = (self.model.destDir + 360 - self.model.rotation) / frameCount
		end
	else
		self.model.angleVec = angle / frameCount
	end
end



return gameObjectControl
