local gameObjectNode = class("gameObjectNode", require("battle.engine.viewEngine"))

function gameObjectNode:ctor(node) -- render node
	self.super:ctor(node)
end

function gameObjectNode:onEnter()
	self:createNode()
end

return gameObjectNode
