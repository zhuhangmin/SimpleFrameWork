local gameObjectData = class("gameObjectData",require("battle.Model.baseMoveData"))

function gameObjectData:ctor(eid)
	self.super:ctor(eid)
	self.weight = 0
	self.userid = nil
	self.entityId = 0

	self.buff = {}

	self.turnDir = 0
	--保护时间状态 | 是否聚拢标志
	self.isSafe = 1
	self.isTogether = false

	--中心点坐标
	self.centerX = 0
	self.centerY = 0

	--移动方向 | 箭头旋转角度
	self.rotation = 0
	self.destDir = 0
	self.angleVec = 0
	self.actDir = 0

end

function gameObjectData:getWeight()
	return self.weight
end

function gameObjectData:getScore()
	return self.weight
end

function gameObjectData:setWeight(parameter)
	if type(parameter) ~= "number" then return end
	-- print("setWeight========="..parameter)
	self.weight = parameter
end

function gameObjectData:getbuff()
	return self.buff
end

function gameObjectData:setbuff(parameter)
	if type(parameter) ~= "table" then return end
	self.buff = parameter
end

function gameObjectData:getEntityId()
	return self.entityId
end

function gameObjectData:setEntityId(parameter)
	if type(parameter) ~= "number" then return end
	if self.entityId ~= 0 then
		print("setEntityId error========="..self.entityId..";"..parameter)
	end
	self.entityId = parameter
end

function gameObjectData:setData( data )
	if type(data) ~= "table" then return end
	self.super:setData(data)
	self:setWeight(data.weight)
	self:setUserid(data.userid)
	self:setEntityId(data.entity_id)
end

function gameObjectData:setUserid(parameter)
	if type(parameter) ~= "string" then return end
	self.userid = parameter
end

function gameObjectData:getUserid( )
	return self.userid
end



return gameObjectData