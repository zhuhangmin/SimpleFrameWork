local BallModel = class("BallModel",require("battle.Entity.gameObjectModel"))

function BallModel:ctor(eid)
	self.super:ctor(eid)
	--移动目标方向 | 箭头旋转角度
	self.destDir = 0 
	self.angleVec = 0
	self.cityid = 0
	self.skinid = 0
	self.rotation = 0
	self.nickname = ""

end

function BallModel:onEnter( data )
	self:setData(data)
end


function BallModel:setData( data )
	if type(data) ~= "table" then return end
	--super()
	self.super:setData(data)
	self:setNickname(data.nickname)
	self:setSkinid(data.skinid)
	self:setCityid(data.cityid)
end

function BallModel:getRotation()
	return self.rotation
end

function BallModel:setRotation(parameter)
	if type(parameter) ~= "number" then return end
	self.rotation = parameter
end

function BallModel:getDestDir()
	return self.destDir
end

function BallModel:setDestDir(parameter)
	if type(parameter) ~= "number" then return end
	self.destDir = parameter
end

function BallModel:getAngleVec()
	return self.angleVec
end

function BallModel:setAngleVec(parameter)
	if type(parameter) ~= "number" then return end
	self.angleVec = parameter
end

function BallModel:getCityid()
	return self.cityid
end

function BallModel:setCityid(parameter)
	if type(parameter) ~= "number" then return end
	self.cityid = parameter
end

function BallModel:getSkinid()
	return self.skinid
end

function BallModel:setSkinid(parameter)
	if type(parameter) ~= "number" then return end
	self.skinid = parameter
end

function BallModel:getNickname()
	return self.nickname
end

function BallModel:setNickname(parameter)
	if type(parameter) ~= "string" then return end
	self.nickname = parameter
end

--net
--m setscore
--c al(score)->dia 
--m setDia
--c getDia



-- function BallModel:getVelocityNum( radius )
-- 	local d = self:getDia()
-- 	if type(radius) == "number" then
-- 		d = 2 * radius
-- 	end
-- 	return 9500 / math.pow(math.log(math.floor(d)), 2.5) 
-- end



return BallModel
