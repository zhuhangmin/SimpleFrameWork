
local BallView = class("BallView", require("battle.Entity.gameObjectView"))

function BallView:ctor(node)
	self.super:ctor(node)
	
end


-------------------------------------------初始化--------------------------------------------------
function BallView:onEnter()
	self:createNode()
end

function BallView:createNode(  )
	local node = cc.Node:create()
	self:addEntityNode(node)
end




function BallView:updatePos()
	self:setPosition(self:getXY())
end

function BallView:updateArrowRotation()
	if self.arrow then
		self.arrow:setRotation(self:getArrowRotation())
	end
end

function BallView:updateSafe()
	if self:getIsSafe() == 1 then
		if not self.safeLight:isVisible() then
			self.safeLight:setVisible(true)

			local action1 = cc.FadeOut:create(0.5)
			local action2 = cc.FadeIn:create(0.5)
			local action3 = cc.Sequence:create(action1, action2)
			local action4 = cc.RepeatForever:create(action3)
			self.safeLight:runAction(action4)
		end
	else
		if self.safeLight:isVisible() then
			self.safeLight:stopAllActions()
			self.safeLight:setVisible(false)
		end
	end
end

function BallView:updateBase(score)
	local dia = FuncConfig:getballNodeDia(score)
	self.size.width = dia
	self.size.height = dia

	self:setLocalZOrder(score)
	self:setContentSize(self.size)
end

function BallView:updateUI(score)
	local isChange = self:getQuality()

	local x = self.size.width / 2
	local y = self.size.height / 2

	--根据品质变换
	if isChange then
		if self.faceAnim then
			self.faceAnim:getAnimation():play(self:getFaceAnimName(), -1, 0)
			self.faceAnim:stopAllActions()
			self.faceAnim:setScale(self.size.width / self.quality)
		end

		if self.arrow then
			self.arrow:setSpriteFrame(self:getArrowImageName())
			self.arrow:stopAllActions()
			self.arrow:setScale(self.size.width / self.quality)
		end
	else
		if self.faceAnim then
			self.faceAnim:stopAllActions()
			self.faceAnim:runAction(cc.ScaleTo:create(0.3, self.size.width / self.quality))
		end

		if self.arrow then
			self.arrow:stopAllActions()
			self.arrow:runAction(cc.ScaleTo:create(0.3, self.size.width / self.quality))
		end
	end

	--球体
	if self.faceAnim then
		self.faceAnim:setPosition(x, y)
	end

	--方向箭头
	if self.arrow then
		self.arrow:setPosition(x, y)
	end

	--保护时间
	if self.safeLight:isVisible() then
		self.safeLight:setPosition(x, y)
		self.safeLight:setScale(self.size.width / self.safeSize.width * 1.5)
	end

	--名字和城市
	self.nameLabel:setPosition(x, self.size.height)
	self.nameLabel:stopAllActions()
	self.nameLabel:runAction(cc.ScaleTo:create(0.3, FuncConfig:getTextScale(score)))

	--表情
	if self.exp then
		self.exp:setPosition(self.size.width, self.size.height)
	end
end


-----------------------------------播放面部动画，表情----------------------------------------------
function BallView:playFaceAnim(type)
	if self.faceAnimType == Constant.ballNodeFaceAnim.RUN then
		self.faceAnimType = type

		if self.faceAnimType == Constant.ballNodeFaceAnim.HAPPY
						and self.userID == GameData.battleInfo.userID then
			SoundManager:playEffect("kill.mp3")
		end

		if self.faceAnim then
			self.faceAnim:getAnimation():play(self:getFaceAnimName(), -1, 0)
		end
	end
end



return BallView
