local JetfoodModel = class("JetfoodModel",require("src.app.game.UI.battle.data.baseBallData"))

function JetfoodModel:ctor()
	self.dia = 0
end



function JetfoodModel:getDia()
	return self.dia
end

function JetfoodModel:setDia(parameter)
	if type(parameter) ~= "number" then return end
	self.dia = parameter
end

function JetfoodModel:setData( data )
	if type(data) ~= "table" then return end
	--super()
	self.super:setData(data)
end
return JetfoodModel