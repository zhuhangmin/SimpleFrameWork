local BallControl = class("BallControl",require("battle.Entity.gameObjectControl"))
local RUN = "run_"
local HAPPY = "happy_"
local FULL = "full_"
local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()

function BallControl:ctor( data , node )
	self.super:ctor( data , node)
end

function BallControl:getFaceAnimFileName()
	local skinid = self.model:getSkinid()
	local a_id = cfg:getConfigField("item", skinid, "animation")
	local fileName = cfg:getConfigField("actionConfig",a_id,"file")
	self.actionCfg = cfg:getConfigRecord("actionConfig",a_id)
	return fileName
end

function BallControl:getFaceAnimName(  )
	local newkey = self.faceAnimType .. self.quality 
	-- print("newkey ==="..newkey)
	local name = self.actionCfg[newkey]
	return name
end

function BallControl:getArrowImageName()
	return "zd/" .. self.quality .. ".png"
end

function BallControl:getArrowRotation()
	local rotation = self.model:getRotation()
	return rotation * -1 - 90
end

function BallControl:update( dt )
	local userid = self:getModel():getUserid()
	print("now ball =="..tostring(self)..":"..tostring(self:getModel()) .."tostring"..tostring(userid)..";"..type(userid)..";"..self.model:getEntityId()..";"..self.model:getEid() )
	if userid and tonumber(userid) > 0 then 
		self:updateRotation()
		self:updateDir()
		self:updatePos(dt)

		local x,y = self.model:getPosition()
		local pos = cc.p(x,y)
		local score = self.model:getWeight()
		local node = self:getEntityNode()
		node:setPosition(pos)
		node:setLocalZOrder(score)
	end
end

function BallControl:initUI()
	self.super:initUI( )
	self.quality = 64
	self.faceAnimType = RUN
	self:getQuality()
	self.size = cc.size(0, 0)
	self.userID = self.model:getUserid()
	self.nickname = self.model:getNickname()
	self.city = self.model:getCityid()
	local score = self.model:getScore()
	local dia = self:getBallDia(score)
	self.size.width = dia
	self.size.height = dia
	--球体
	local faceAnimFileName = self:getFaceAnimFileName()
	print("faceAnimFileName==="..faceAnimFileName)
	print("self.size.height==="..dia..";"..tostring(Utils:isExistArmatureAndAnim(faceAnimFileName)))
	if Utils:isExistArmatureAndAnim(faceAnimFileName) then
		self.faceAnim = ccs.Armature:create(faceAnimFileName)
		self.faceAnim:setAnchorPoint(cc.p(0.5, 0.5))
		self.faceAnim:setPosition(self.size.width / 2, self.size.height / 2)
		self.faceAnim:setScale(self.size.width / self.quality)

		self.faceAnim:getAnimation():setMovementEventCallFunc(function(armature, type, movementID)
			if type == ccs.MovementEventType.complete then
				self.faceAnimType = RUN
				if self.faceAnim then
					self.faceAnim:getAnimation():play(self:getFaceAnimName(), -1, 0)
				end
			end
		end)
		self.faceAnim:getAnimation():play(self:getFaceAnimName(), -1, 0)
		self:getEntityNode():addChild(self.faceAnim)

		self.faceAnim:setName("faceAnim")
	end

	

	--方向箭头

	if self.userID == PlayerDataBasic.id then
		self.arrow = cc.Sprite:createWithSpriteFrameName(self:getArrowImageName())
		self.arrow:setAnchorPoint(cc.p(0.5, 0.5))
		self.arrow:setPosition(self.size.width / 2, self.size.height / 2)
		self.arrow:setScale(self.size.width / self.quality)
		self.arrow:setRotation(self:getArrowRotation())
		self:getEntityNode():addChild(self.arrow)

		self.arrow:setName("arrow")
	end

	--保护时间动作
	-- self.safeLight = cc.Sprite:createWithSpriteFrameName("zd/zd_bg_safe.png")
	-- self.safeLight:setAnchorPoint(cc.p(0.5, 0.5))
	-- self.safeLight:setPosition(self.size.width / 2, self.size.height / 2)
	-- self.safeLight:setVisible(false)
	-- self:getEntityNode():addChild(self.safeLight)

	-- self.safeSize = self.safeLight:getContentSize()
	-- self.safeLight:setScale(self.size.width / self.safeSize.width * 1.5)

	--名字和城市
	local cityName = cfg:getConfigField("city",self.city,"name")
	local name = self.nickname .. "  (" .. cityName .. ")"
	self.nameLabel = cc.Label:createWithTTF(name, "res/font/font1.ttf", 30)
	self.nameLabel:setAnchorPoint(cc.p(0.5, 0.5))
	self.nameLabel:setPosition(self.size.width / 2, self.size.height)
	self.nameLabel:setScale(self:getTextScale(score))
	self.nameLabel:setTextColor(cc.c3b(255, 255, 255))
	self.nameLabel:enableShadow(cc.c4b(0, 0, 0, 255), cc.size(2, 2))
	self:getEntityNode():addChild(self.nameLabel)

	self.nameLabel:setName("nameLabel")

end

function BallControl:getBallDia(score)
	local dia = 0
	if type(score) == "number" then
		dia = math.floor(math.pow(score * 78, 0.5) * 2)
	end
	return dia
end

--根据分数获取名字显示比例
function BallControl:getTextScale(score)
	local dia = self:getBallDia(score)
	local scale = math.floor(math.log(dia)) / 5
	return scale
end


function BallControl:getQuality()
	local isChange = false
	if BattleData.settingInfo.qualityValue == 1 then
		--低品质
		if self.quality ~= 64 then
			self.quality = 64
			isChange = true
		end
	elseif BattleData.settingInfo.qualityValue == 2 then
		--中品质
		local score = self.model:getScore()
		local QUALITY_MID_SCORE = cfg:getConfigField("netBattle",1,"QUALITY_MID_SCORE")
		if score <= QUALITY_MID_SCORE then
			if self.quality ~= 64 then
				self.quality = 64
				isChange = true
			end
		else
			if self.quality ~= 256 then
				self.quality = 256
				isChange = true
			end
		end
	end
	return isChange
end


return BallControl
