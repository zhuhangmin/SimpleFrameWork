
local JetfoodView = class("JetfoodView", function()
	return ccs.Armature:create("mj_grass")
end)

function JetfoodView:ctor(params)
	
	self:init(params)
end



return JetfoodView
