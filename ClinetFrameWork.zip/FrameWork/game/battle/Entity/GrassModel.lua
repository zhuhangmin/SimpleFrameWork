local GrassModel = class("GrassModel",require("battle.Entity.gameObjectModel"))

function GrassModel:ctor(eid)
	self.super:ctor(eid)
	self.dia = 0
end


function GrassModel:onEnter( data )
	self:setData(data)
end

function GrassModel:getDia()
	return self.dia
end

function GrassModel:setDia(parameter)
	if type(parameter) ~= "number" then return end
	self.dia = parameter
end

function GrassModel:setData( data )
	if type(data) ~= "table" then return end
	--super()
	self.super:setData(data)
end
return GrassModel