local GrassView = class("GrassView", require("battle.Entity.gameObjectView"))

function GrassView:ctor(node) -- render node
	self.super:ctor(node)
end

function GrassView:createNode( renderNode )
	local node = ccs.Armature:create("mj_grass")
	print("node ===="..tostring(node))
	self:addEntityNode(node)
end

function GrassView:onEnter()
	self:createNode()
end

return GrassView


