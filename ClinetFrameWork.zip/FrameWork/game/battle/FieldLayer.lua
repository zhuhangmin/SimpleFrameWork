local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()

local FieldLayer = class("FieldLayer", function()
	local roomCfg = cfg:getConfigRecord("room",GameData.roomType) 
	local width = roomCfg.battlefield_wide + roomCfg.battlefield_outside_wide * 2
	local height = roomCfg.battlefield_high + roomCfg.battlefield_outside_high * 2
	local color = cc.c4b(0, 0, 0, 0)
	return cc.LayerColor:create(color, width, height)
end)

function FieldLayer:ctor()
	self.scale = 1
	self.gridList = nil

	self:updateTheme()
	self:init()
end

function FieldLayer:updateTheme()
	local themeType = GameData.settingInfo.battleBgValue
	local info = cfg:getConfigRecord("battlethemeConfig",themeType)
	local imageName = info.fieldBg
	local roomCfg = cfg:getConfigRecord("room",GameData.roomType) 
	if self.gridList == nil then
		self.gridList = {}
		local width = roomCfg.battlefield_wide + roomCfg.battlefield_outside_wide * 2
		local height = roomCfg.battlefield_high + roomCfg.battlefield_outside_high * 2
		local hCount = math.ceil(width / 4000)
		local vCount = math.ceil(height / 4000)
		for i = 1, vCount do
			for j = 1, hCount do
				local gridImage = cc.Sprite:createWithSpriteFrameName(imageName)
				gridImage:setAnchorPoint(cc.p(0, 0))
				gridImage:setPosition((j - 1) * (4000-1), (i - 1) * (4000-1))
				gridImage:setScale(2)
				self:addChild(gridImage)
				self.gridList[#self.gridList + 1] = gridImage

				gridImage:setName("gridImage"..i..j)
			end
		end
	else
		for i = 1, #self.gridList do
			self.gridList[i]:setSpriteFrame(imageName)
		end
	end
	self:setCameraMask(2)
end

function FieldLayer:init()
	local roomCfg = cfg:getConfigRecord("room",GameData.roomType) 
	local width = roomCfg.battlefield_wide + roomCfg.battlefield_outside_wide * 2
	local height = roomCfg.battlefield_high + roomCfg.battlefield_outside_high * 2
	self.foodLayer = require("battle.FoodLayer"):create()
	self.foodLayer:setPosition(roomCfg.battlefield_outside_wide, roomCfg.battlefield_outside_high)
	self:addChild(self.foodLayer)
	self.foodLayer:setName("foodLayer")

	self.ballLayer = require("battle.BallLayer"):create()
	self.ballLayer:setPosition(roomCfg.battlefield_outside_wide, roomCfg.battlefield_outside_high)
	self:addChild(self.ballLayer)
	self.ballLayer:setName("ballLayer")
end

function FieldLayer:update(dt)
	self.ballLayer:update(dt)
end

function FieldLayer:updateSelfScale(scale)
	if self.scale ~= scale then
		self.scale = scale

		self:stopAllActions()
		self:runAction(cc.ScaleTo:create(0.6, scale))
	end
end

function FieldLayer:modifyFood(enter, leave)
	self.foodLayer:modifyFood(enter, leave)
end

function FieldLayer:modifyItem(enter, leave, move, dead)
	self.ballLayer:modifyItem(enter, leave, move, dead)
end

function FieldLayer:playExp(isNet, userID, sex, expIndex)
	self.ballLayer:playExp(isNet, userID, sex, expIndex)
end


return FieldLayer
