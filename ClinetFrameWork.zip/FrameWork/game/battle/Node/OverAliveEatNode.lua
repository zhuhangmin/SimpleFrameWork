
local OverAliveEatNode = class("OverAliveEatNode", function()
	return ccui.Widget:create()
end)

function OverAliveEatNode:ctor(info)
	self:init(info)
end

function OverAliveEatNode:ctor(info)
	local rootNode = cc.CSLoader:createNode("res/ResultItem_2.csb")
	self:addChild(rootNode)

	rootNode:setName("ResultItem_2")

	self:setAnchorPoint(cc.p(0, 0))
	self:setContentSize(rootNode:getContentSize())

	--头像

	local skinImage = rootNode:getChildByName("Image_skin")
	local iconName = getSkinIcon(info.headurl).. ".png"
	--print("skin ===="..tostring(iconName))
	if  gFrameCache:getSpriteFrame(iconName) then
		skinImage:loadTexture(iconName, ccui.TextureResType.plistType)
	end


	--性别
	local sexImage = rootNode:getChildByName("Image_sex")
	if info.sex == 1 then
		sexImage:loadTexture("tongyong/men.png", ccui.TextureResType.plistType)
	else
		sexImage:loadTexture("tongyong/woman.png", ccui.TextureResType.plistType)
	end

	--昵称
	local nameLabel = rootNode:getChildByName("Text_name")
	nameLabel:setString(string.urldecode(info.nickname))

	--次数
	local countLabel = rootNode:getChildByName("Text_city")
	countLabel:setString(info.count .. "次")
end


return OverAliveEatNode
