local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()
local OverAliveRankNode = class("OverAliveRankNode", function()
	return ccui.Widget:create()
end)

function OverAliveRankNode:ctor(index, isMy, info)

	self.index = info.rank
	self.isMy = isMy
	self.info = info

	self:init()
	self:setInfo()
end

function OverAliveRankNode:init()
	local rootNode = cc.CSLoader:createNode("res/ResultItem_1.csb")
	self:addChild(rootNode)

	rootNode:setName("ResultItem_1")

	self:setAnchorPoint(cc.p(0, 0))
	self:setContentSize(rootNode:getContentSize())

	self.rankImage = rootNode:getChildByName("Image_rank")
	self.rankLabel = rootNode:getChildByName("Text_rank")

	self.skinImage = rootNode:getChildByName("Image_skin")
	self.sexImage = rootNode:getChildByName("Image_sex")
	self.nameLabel = rootNode:getChildByName("Text_name")

	self.cityLabel = rootNode:getChildByName("Text_city")

	self.mvpImage = rootNode:getChildByName("Image_mvp")

	self.weightImage = rootNode:getChildByName("Image_weight")
	self.weightLabel = rootNode:getChildByName("Text_weight")

	self.eatLabel = rootNode:getChildByName("Text_kill")
	self.starLabel = rootNode:getChildByName("Text_star")
end

function OverAliveRankNode:setInfo()
	local imageName = nil
	local color = nil

	if self.isMy then
		imageName = "paihangbang/phb_zj.png"
		color = cc.c3b(121, 57, 0)

		self.rankLabel:setPositionY(self.rankLabel:getPositionY() + 3)
	else
		if self.index == 1 then
			imageName = "paihangbang/phb_1.png"
			color = cc.c3b(234, 0, 72)
		elseif self.index == 2 then
			imageName = "paihangbang/phb_2.png"
			color = cc.c3b(0, 98, 161)
		elseif self.index == 3 then
			imageName = "paihangbang/phb_3.png"
			color = cc.c3b(185, 69, 0)
		else
			imageName = "paihangbang/phb_other.png"
			color = cc.c3b(121, 57, 0)

			self.rankLabel:setPositionY(self.rankLabel:getPositionY() + 3)
		end
	end

	--名次图片
	self.rankImage:loadTexture(imageName, ccui.TextureResType.plistType)
	self.rankImage:ignoreContentAdaptWithSize(true)

	--名次文本
	if self.index <= 50 then
		self.rankLabel:setString(self.index)
	else
		self.rankLabel:setString("50+")
	end

	--头像
	local iconName = getSkinIcon(self.info.headurl).. ".png"
	-- print("skin ===="..tostring(iconName))
	if  gFrameCache:getSpriteFrame(iconName) then
		self.skinImage:loadTexture(iconName, ccui.TextureResType.plistType)
	end
	--性别
	if self.info.sex == 1 then
		self.sexImage:loadTexture("tongyong/men.png", ccui.TextureResType.plistType)
	else
		self.sexImage:loadTexture("tongyong/woman.png", ccui.TextureResType.plistType)
	end

	--姓名
	self.nameLabel:setString(string.urldecode(self.info.nickname))
	self.nameLabel:setTextColor(color)
	local city = self.info.cityid
	if city == nil or city == 0 then
		city = 1
	end
	local city_name = cfg:getConfigField("city",city,"name")
	--城市
	self.cityLabel:setString(city_name)
	self.cityLabel:setTextColor(color)

	--mvp
	if self.info.mvp == 1 then
		self.mvpImage:setVisible(true)
	else
		self.mvpImage:setVisible(false)
	end
	--重量
	local weight = Utils:getWeightFromScore(self.info.weight)

	local str, index = Utils:getWeightString(weight)
	local weightConfig = cfg:getConfigRecord("weightConfig",index) 
	self.weightLabel:setString(str)
	self.weightLabel:setTextColor(color)
	self.weightImage:loadTexture(weightConfig.imgName, ccui.TextureResType.plistType)

	--吞噬
	self.eatLabel:setString(self.info.kill)
	self.eatLabel:setTextColor(color)

	--星星
	self.starLabel:setString(self.info.star)
	self.starLabel:setTextColor(color)
end


return OverAliveRankNode
