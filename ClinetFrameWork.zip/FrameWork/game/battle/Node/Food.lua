local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()
local food_cfg = cfg:getTable("foodConfig")
local minScale = food_cfg[1]["minScale"]
local maxScale = food_cfg[1]["maxScale"]

local Food = class("Food", function()

	local len = #food_cfg
	local key = math.random(1,len)
	local imageName = "food/" .. food_cfg[key]["imgName"] ..".png"

	return cc.Sprite:createWithSpriteFrameName(imageName)
end)

function Food:ctor()
	self:setScale(math.random(minScale, maxScale) / 100)
	self:setCameraMask(2)
end

function Food:setData(eid)
	self:setTag(eid)
	self:setVisible(true)

	local dm = GameData.battleInfo.roleDataManager
	local userID = GameData.battleInfo.userID

	local x = dm.roleDataList[userID].foodList[eid].x
	local y = dm.roleDataList[userID].foodList[eid].y
	self:setPosition(x, y)
end

function Food:clearData()
	self:setTag(-1)
	self:setVisible(false)
end


return Food
