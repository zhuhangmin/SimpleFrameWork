local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()
local JetFood = class("JetFood", function() 
	local themeType = GameData.settingInfo.battleBgValue
	local info = cfg:getConfigRecord("battlethemeConfig",themeType)
	return cc.Sprite:createWithSpriteFrameName(info.Spore)
end)

function JetFood:ctor()


	self:setCameraMask(2)

end

function JetFood:setData( params )
	self.eid = params.eid
	self.userID = params.userid
	self.entity_id = params.entity_id
	self:init()
end

function JetFood:clearData( ... )
	self:setTag(-1)
	self:setVisible(false)
end



function JetFood:init()
	self:setAnchorPoint(cc.p(0.5, 0.5))
	self:setTag(self.eid)
	self:setVisible(true)
	self:setPosition(self:getPos())

	local score = self:getScore()
	self:setLocalZOrder(score)

	local dia = Utils:getBallDia(score)
	local size = self:getContentSize()
	local scale = dia / size.width
	self:setScale(scale)

	local random = math.random(360, 540)
	local action1 = cc.RotateBy:create(0.7, random)
	local action2 = cc.Repeat:create(action1, 2)
	self:runAction(action2)
end

function JetFood:getPos()
	local dm = GameData.battleInfo.roleDataManager
	local userID = GameData.battleInfo.userID
	local obj = dm.roleDataList[userID].elementList[self.eid]
	if obj then
		return obj.x, obj.y
	end
end

function JetFood:getScore()
	local dm = GameData.battleInfo.roleDataManager
	local userID = GameData.battleInfo.userID
	local obj = dm.roleDataList[userID].elementList[self.eid]

	return obj.score
end

function JetFood:update()
	local x,y = self:getPos()
	if x and y then
		self:setPosition(x,y)
	end
end


return JetFood
