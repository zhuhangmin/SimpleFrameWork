
local Grass = class("Grass", function()
	return ccs.Armature:create("grass_animation")
end)

function Grass:ctor()
	self:setCameraMask(2)
end

function Grass:setData(params)
	-- startProFi()

	self.eid = params.eid
	self.userID = params.userid
	self.entity_id = params.entity_id
	self:setTag(self.eid)
	self:setVisible(true)
	self:setAnchorPoint(cc.p(0.5, 0.5))

	local dm = GameData.battleInfo.roleDataManager
	local userID = GameData.battleInfo.userID
	local obj = dm.roleDataList[userID].elementList[self.eid]

	self:setLocalZOrder(obj.score)
	self:setScale(self:calScale(obj.score))
	self:setPosition(obj.x, obj.y)

	self:getAnimation():setMovementEventCallFunc(function(armature, type, movementID)
		if type == ccs.MovementEventType.complete then
			self:playAnim()
		end
	end)
	self:playAnim()
	-- stopProFiWithName("grass")
end

function Grass:clearData( )
	self:setTag(-1)
	self:setVisible(false)
end

function Grass:playAnim()
	-- local random = math.random(1, 7)
	-- local animName = "mj_grass_" .. random
	local animName = "grass"
	self:getAnimation():play(animName, -1, 0)
end

--计算缩放比例
function Grass:calScale(score)
	local scale = 1.0

	if score == 60 then
		scale = 0.83
	elseif score == 100 then
		scale = 1.07
	elseif score == 140 then
		scale = 1.27
	end

	return scale
end


return Grass
