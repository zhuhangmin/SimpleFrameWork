
local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()

local NConfig = cfg:getConfigRecord("netBattle",1) 

local Ball = class("Ball", function()
	return cc.Node:create()
end)

---------------------------------功能方法-------------------------------------------------
function Ball:getXY()
	local rdm = GameData.battleInfo.roleDataManager
	local id = GameData.battleInfo.userID

	local x = 0
	local y = 0

	if rdm.roleDataList[id] then
		if rdm.roleDataList[id].elementList[self.eid] then
			x = math.ceil(rdm.roleDataList[id].elementList[self.eid].x)
			y = math.ceil(rdm.roleDataList[id].elementList[self.eid].y)
		end
	end

	return x, y
end

function Ball:getScore()
	local rdm = GameData.battleInfo.roleDataManager
	local id = GameData.battleInfo.userID
	local score = 3

	if rdm.roleDataList[id] then
		if rdm.roleDataList[id].elementList[self.eid] then
			score = rdm.roleDataList[id].elementList[self.eid].score
		end
	end

	return score
end

function Ball:getIsSafe()
	local rdm = GameData.battleInfo.roleDataManager
	local id = GameData.battleInfo.userID
	local isSafe = 0

	if rdm.roleDataList[id] then
		if rdm.roleDataList[id].elementList[self.eid] then
			isSafe = rdm.roleDataList[id].elementList[self.eid].isSafe
		end
	end

	return isSafe
end

function Ball:getArrowRotation()
	local rdm = GameData.battleInfo.roleDataManager
	local id = GameData.battleInfo.userID
	local rotation = 0

	if rdm.roleDataList[id] then
		if rdm.roleDataList[id].elementList[self.eid] then
			rotation = rdm.roleDataList[id].elementList[self.eid].rotation
		end
	end

	return rotation * -1 - 90
end

function Ball:getArrowImageName()
	return "zd/" .. self.quality .. ".png"
end

function Ball:getFaceAnimFileName()
	local skinid = self.skinid
	-- print("self.skinid==="..skinid)
	local a_id = cfg:getConfigField("item", skinid, "animation")
	local fileName = cfg:getConfigField("actionConfig",a_id,"file")
	-- print("fileName==="..fileName)
	self.actionCfg = cfg:getConfigRecord("actionConfig",a_id)
	return fileName
end

function Ball:getFaceAnimName(  )
	local newkey = self.faceAnimType .. self.quality 
	local name = self.actionCfg[newkey]
	-- local name = self.quality .. "_01_run"
	-- print("name ==="..tostring(newkey)..";"..tostring(name)..";" ..self.quality..";"..self.skinid)
	return name
end


function Ball:getQuality()
	local isChange = false

	if GameData.settingInfo.qualityValue == 1 then
		--低品质
		if self.quality ~= 64 then
			self.quality = 64
			self.key = "scale_small"
			isChange = true
		end
	elseif GameData.settingInfo.qualityValue == 2 then
		--中品质
		local score = self:getScore()
		-- print("NConfig.QUALITY_MID_SCORE===="..score..";"..NConfig.QUALITY_MID_SCORE..";"..self.eid)
		if score <= NConfig.QUALITY_MID_SCORE then
			if self.quality ~= 64 then
				self.quality = 64
				self.key = "scale_small"
				isChange = true
			end
		else
			if self.quality ~= 256 then
				self.quality = 256
				self.key = "scale_big"
				isChange = true
			end
		end
	elseif GameData.settingInfo.qualityValue == 3 then
		--高品质
		local score = self:getScore()
		if score <= NConfig.QUALITY_MID_SCORE then
			if self.quality ~= 64 then
				self.quality = 64
				isChange = true
			end
		else		
			if self.quality ~= 256 then
				self.quality = 256
				isChange = true
			end
		end
	end

	return isChange
end

local function checkSkinID(skinID)
	local temp = Constant.DEFAULT_SKIN_ID
	local sid = tonumber(skinID)
	local isRight = false

	for i = 1, #ToolConfig do
		if sid == ToolConfig[i].did or sid == ToolConfig[i].tid then
			temp = sid
			isRight = true
			break
		end
	end

	if not isRight then
		print("--------checkSkinID------, ball failed skinID = " .. tostring(skinID))
	end

	return temp
end


function Ball:ctor(info)
	------------------------协议数据-------------------------------
	self.eid = info.eid
	self.userID = info.userid
	self.city = info.cityid
	self.nickname = string.urldecode(info.nickname)

	if self.city <= 0 then
		self.city = 1
	end

	------------------------自定义数据-------------------------------
	self.size = cc.size(0, 0)
	self.quality = 64
	self.key = "scale_small"
	self.skinid = info.skinid
	if self.skinid == 0 then
		self.skinid = 30101
	end
	-- self.type, self.theme, self.index = Utils:sepSkinID(checkSkinID())

	self.faceAnimType = BattleMsg.RUN

	self.safeSize = cc.size(0, 0)

	self:init()
	self:setCameraMask(2)
end


-------------------------------------------初始化--------------------------------------------------
function Ball:init()
	self:initBase()
	self:initUI()
end

function Ball:initBase()
	local score = self:getScore()
	local dia =  Utils:getBallDia(score)
	self.size.width = dia
	self.size.height = dia

	self:setTag(self.eid)
	self:setAnchorPoint(cc.p(0.5, 0.5))

	self:setPosition(self:getXY())
	self:setLocalZOrder(score)
	self:setContentSize(self.size)
end

function Ball:initUI()
	self:getQuality()

	--球体
	local faceAnimFileName = self:getFaceAnimFileName()
	-- print("faceAnimFileName==="..faceAnimFileName..";"..tostring(Utils:isExistArmatureAndAnim(faceAnimFileName)))
	if not Utils:isExistArmatureAndAnim(faceAnimFileName) then
		local file = string.format("res/armature/%s/%s.ExportJson",faceAnimFileName,faceAnimFileName)
		gArmatureManager:addArmatureFileInfo(file)
	end

	if Utils:isExistArmatureAndAnim(faceAnimFileName) then
		self.faceAnim = ccs.Armature:create(faceAnimFileName)
		self.faceAnim:setAnchorPoint(cc.p(0.5, 0.5))
		self.faceAnim:setPosition(self.size.width / 2, self.size.height / 2)
		self.faceAnim:setScale(self.size.width / self.actionCfg[self.key])--self.quality)
		self.faceAnim:getAnimation():setMovementEventCallFunc(function(armature, type, movementID)
			if type == ccs.MovementEventType.complete then
				self.faceAnimType = BattleMsg.RUN

				if self.faceAnim then
					self.faceAnim:getAnimation():play(self:getFaceAnimName(), -1, 0)
				end
			end
		end)
		self.faceAnim:getAnimation():play(self:getFaceAnimName(), -1, 0)
		self:addChild(self.faceAnim)		
		self.faceAnim:setName("faceAnim")
	end

	--方向箭头
	if self.userID == GameData.battleInfo.userID then
		self.arrow = cc.Sprite:createWithSpriteFrameName(self:getArrowImageName())
		self.arrow:setAnchorPoint(cc.p(0.5, 0.5))
		self.arrow:setPosition(self.size.width / 2, self.size.height / 2)
		self.arrow:setScale(self.size.width / self.quality)
		self.arrow:setRotation(self:getArrowRotation())
		self:addChild(self.arrow)
		self.arrow:setName("arrow")
	end

	--保护时间动作
	self.safeLight = cc.Sprite:createWithSpriteFrameName("zd/zd_bg_safe.png")
	self.safeLight:setAnchorPoint(cc.p(0.5, 0.5))
	self.safeLight:setPosition(self.size.width / 2, self.size.height / 2)
	self.safeLight:setVisible(false)
	self:addChild(self.safeLight)
	self.safeLight:setName("safeLight")


	self.safeSize = self.safeLight:getContentSize()
	self.safeLight:setScale(self.size.width / self.safeSize.width * 1.5)

	--名字和城市
	local city_name = cfg:getConfigField("city",self.city,"name")
	local name = self.nickname .. "  (" .. city_name .. ")"
	self.nameLabel = cc.Label:createWithTTF(name, "res/font/font1.ttf", 30)
	self.nameLabel:setAnchorPoint(cc.p(0.5, 0.5))
	self.nameLabel:setPosition(self.size.width / 2, self.size.height)
	self.nameLabel:setScale(Utils:getTextScale(self:getScore()))
	self.nameLabel:setTextColor(cc.c3b(255, 255, 255))
	self.nameLabel:enableShadow(cc.c4b(0, 0, 0, 255), cc.size(2, 2))
	self:addChild(self.nameLabel)

	self.nameLabel:setName("nameLabel")
end



-------------------------------------------帧刷新--------------------------------------------------
function Ball:update(dt)
	local rdm = GameData.battleInfo.roleDataManager
	local id = GameData.battleInfo.userID

	if rdm and rdm.roleDataList[id] then
		self:updatePos()
		self:updateArrowRotation()
		self:updateSafe()

		local score = self:getScore()
		local zOrder = self:getLocalZOrder()
		if score ~= zOrder then
			self:updateBase(score)
			self:updateUI(score)
		end
	end
end

function Ball:updatePos()
	local x, y  = self:getXY()
	self:setPosition(self:getXY())
end

function Ball:updateArrowRotation()
	if self.arrow then
		self.arrow:setRotation(self:getArrowRotation())
	end
end

function Ball:updateSafe()
	if self:getIsSafe() == 1 then
		if not self.safeLight:isVisible() then
			self.safeLight:setVisible(true)

			local action1 = cc.FadeOut:create(0.5)
			local action2 = cc.FadeIn:create(0.5)
			local action3 = cc.Sequence:create(action1, action2)
			local action4 = cc.RepeatForever:create(action3)
			self.safeLight:runAction(action4)
		end
	else
		if self.safeLight:isVisible() then
			self.safeLight:stopAllActions()
			self.safeLight:setVisible(false)
		end
	end
end

function Ball:updateBase(score)
	local dia = Utils:getBallDia(score)
	self.size.width = dia
	self.size.height = dia
	self:setLocalZOrder(score)
	self:setContentSize(self.size)
end

function Ball:updateUI(score)
	local isChange = self:getQuality()

	local x = self.size.width / 2
	local y = self.size.height / 2

	--根据品质变换
	if isChange then
		if self.faceAnim then
			self.faceAnim:getAnimation():play(self:getFaceAnimName(), -1, 0)
			self.faceAnim:stopAllActions()
			self.faceAnim:setScale(self.size.width / self.actionCfg[self.key])--self.quality)
		end

		if self.arrow then
			self.arrow:setSpriteFrame(self:getArrowImageName())
			self.arrow:stopAllActions()
			self.arrow:setScale(self.size.width / self.quality)
		end
	else
		if self.faceAnim then
			-- print("self.size.width====="..self.size.width / self.quality..";"..self.quality..";"..self.eid)
			self.faceAnim:stopAllActions()
			self.faceAnim:runAction(cc.ScaleTo:create(0.3, self.size.width / self.actionCfg[self.key]))--self.quality))
		end

		if self.arrow then
			self.arrow:stopAllActions()
			self.arrow:runAction(cc.ScaleTo:create(0.3, self.size.width / self.quality))
		end
	end

	--球体
	if self.faceAnim then
		self.faceAnim:setPosition(x, y)
	end

	--方向箭头
	if self.arrow then
		self.arrow:setPosition(x, y)
	end

	--保护时间
	if self.safeLight:isVisible() then
		self.safeLight:setPosition(x, y)
		self.safeLight:setScale(self.size.width / self.safeSize.width * 1.5)
	end

	--名字和城市
	self.nameLabel:setPosition(x, self.size.height)
	self.nameLabel:stopAllActions()
	self.nameLabel:runAction(cc.ScaleTo:create(0.3, Utils:getTextScale(score)))

	--表情
	if self.exp then
		self.exp:setPosition(self.size.width, self.size.height)
	end
end


-----------------------------------播放面部动画，表情----------------------------------------------
function Ball:playFaceAnim(type)
	if self.faceAnimType == BattleMsg.RUN then
		self.faceAnimType = type

		if self.faceAnimType == BattleMsg.HAPPY
						and self.userID == GameData.battleInfo.userID then
			SoundManager:playEffect("kill.mp3")
		end

		if self.faceAnim then
			self.faceAnim:getAnimation():play(self:getFaceAnimName(), -1, 0)
		end
	end
end

return Ball
