local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()

-- avoid_probability = 4000,
-- chase_probability = 1000,
-- spray_probability = 500,
-- grass_probability = 1000,
-- turn_probability = 5000,
-- division_probability = 0,
-- move_probability = 7000,
-- devour_probability = 0,
-- digestibility = 10000,
local AI = class("AI")

function AI:ctor(id, type, isCreate, isBegin)
	self.dia = 0

	self.id = id
	self.type = type
	self.AIConfig = cfg:getConfigRecord("aiConfig",self.type)

	if isCreate then
		if GameData.battleInfo.roleDataManager then
			GameData.battleInfo.roleDataManager:addRoleData(self.id)
		end
	end

	if isBegin then
		self:start()
	end
	self.DConfig = cfg:getConfigRecord("room",GameData.roomType) 
end

function AI:getRandom()
	return math.random(1, 10000)
end

function AI:start()
	if not self.schedulerID then
		self.schedulerID = gScheduler:scheduleScriptFunc(handler(self, self.dataAnalysis), 1, false)
	end
end

function AI:clear()
	if self.schedulerID then
		gScheduler:unscheduleScriptEntry(self.schedulerID)
		self.schedulerID = nil
	end

	if GameData.battleInfo.roleDataManager then
		GameData.battleInfo.roleDataManager:delRoleData(self.id)
	end
end

--数据分析
function AI:dataAnalysis()
	if GameData.battleInfo.roleDataManager then
		local data = GameData.battleInfo.roleDataManager.roleDataList[self.id]
		-- print("#(data.userList[self.id].balls)=="..#(data.userList[self.id].balls))
		if data and data.userList[self.id].balls and #(data.userList[self.id].balls) > 0 then
			--找主球
			local mainEid = data.elementList[data.userList[self.id].balls[1]].primaryEid
			local mainBall = data.elementList[mainEid]

			if mainBall then
				--记录主球的直径
				self.dia = Utils:getBallDia(mainBall.score)

				--寻找距离主球最近的其他玩家的球
				local otherBall = nil
				local dis = -1
				for k, v in pairs(data.userList) do
					--寻找其他玩家距离主球最近的球
					if k ~= self.id then
						for m, n in pairs(v.balls) do
							local ball = data.elementList[n]
							local d = cc.pGetDistance(cc.p(mainBall.x, mainBall.y), cc.p(ball.x, ball.y))
							if dis == -1 then
								dis = d
								otherBall = ball
							else
								if d < dis then
									dis = d
									otherBall = ball
								end
							end
						end
					end
				end

				if otherBall then
					if mainBall.score < otherBall.score then
						--走躲避流程
						self:process1(mainBall, otherBall)
					elseif mainBall.score > otherBall.score then
						--走追击流程
						self:process2(mainBall, otherBall)
					elseif mainBall.reserve1 and otherBall.reserve1 and mainBall.reserve1 == otherBall.reserve1 then
						--吐包子流程
						self:process4(mainBall, otherBall)
					else
						--走移动流程
						self:process3(mainBall)
					end
				else
					--走移动流程
					self:process3(mainBall)
				end
			end
		end
	end
end

--计算躲避流程中的角度(主要是在边界附近的角度计算)
function AI:calProcess1Rotation(mainBall, rotation)
	local dir = rotation
	local x = mainBall.x
	local y = mainBall.y
	local d = self.dia * 0.5 * 0.5 + 20
	local random = math.random(15, 30)

	if x <= d then
		if dir >= 90 and dir <= 180 then
			dir = 90 - random
		elseif dir > 180 and dir <= 270 then
			dir = 270 + random
		end
	elseif x >= self.DConfig.battlefield_wide - d then
		if dir >= 0 and dir <= 90 then
			dir = 90 + random
		elseif dir >= 270 then
			dir = 270 - random
		end
	end

	if y <= d then
		if dir >= 180 and dir <= 270 then
			dir = 180 - random
		elseif dir > 270 or dir == 0 then
			dir = random
		end
	elseif y >= self.DConfig.battlefield_high - d then
		if dir >= 0 and dir <= 90 then
			dir = 360 - random
		elseif dir > 90 and dir <= 180 then
			dir = 180 + random
		end
	end

	return dir
end

--躲避流程
function AI:process1(mainBall, otherBall)
	-- print("process1===="..self.id)
	local data = GameData.battleInfo.roleDataManager.roleDataList[self.id]

	--计算危险范围(半径 * 5 + 200)
	local dangerousDis = self.dia * 2.5 + 200

	--计算mainBall和otherBall之间的距离
	local dis = cc.pGetDistance(cc.p(mainBall.x, mainBall.y), cc.p(otherBall.x, otherBall.y))

	if dis <= dangerousDis then
		--在危险范围之内，继续分析
		local random1 = self:getRandom()
		if random1 <= self.AIConfig["avoid_probability"] then
			--进入躲避
			local rotation = Utils:getMoveDirection(cc.p(otherBall.x, otherBall.y), cc.p(mainBall.x, mainBall.y))
			if rotation then
				--边界判断(更改rotation的方向)
				rotation = self:calProcess1Rotation(mainBall, rotation)

				--设置新的移动方向
				self:sendChangeDirect(rotation)

				--判断是否使用喷射技能
				if mainBall.score >= self.DConfig.min_jet_score then
					local random3 = self:getRandom()
					if random3 <= self.AIConfig["spray_probability"] then
						self:sendJet()
					end
				end
			end
		else
			--不躲避，直接走移动流程
			self:process3(mainBall)
		end
	else
		--不在危险范围之内，直接走移动流程
		self:process3(mainBall)
	end
end

-- 吐孢子流程
function AI:process4(mainBall, otherBall)
	local random1 = self:getRandom()
	if random1 <= self.AIConfig["vomit_team_probability"] then
		--吐孢子 to ally
		local rotation = Utils:getMoveDirection( cc.p(mainBall.x, mainBall.y),cc.p(otherBall.x, otherBall.y))
		if rotation then
			--边界判断(更改rotation的方向)
			rotation = self:calProcess1Rotation(mainBall, rotation)

			--设置新的移动方向
			self:sendChangeDirect(rotation)

			--判断是否使用喷射技能
			if mainBall.score >= self.DConfig.min_jet_score then
				self:sendJet()
			end
		end
	else
		--不躲避，直接走移动流程
		self:process3(mainBall)
	end
end

--追击流程
function AI:process2(mainBall, otherBall)
		-- print("process2===="..self.id)
	local data = GameData.battleInfo.roleDataManager.roleDataList[self.id]

	--计算可追击范围(半径 * 3 + 200)
	local pursueDis = self.dia * 1.5 + 200

	--计算mainBall和otherBall之间的距离
	local dis = cc.pGetDistance(cc.p(mainBall.x, mainBall.y), cc.p(otherBall.x, otherBall.y))

	if dis <= pursueDis then
		--在追击范围之内，继续分析
		local random2 = self:getRandom()
		if random2 <= self.AIConfig["chase_probability"] then
			--进入追击
			local rotation = Utils:getMoveDirection(cc.p(mainBall.x, mainBall.y), cc.p(otherBall.x, otherBall.y))
			if rotation then
				--设置新的移动方向
				self:sendChangeDirect(rotation)

				--判断是否使用分裂技能
				local random6 = self:getRandom()
				if random6 <= self.AIConfig["division_probability"] then
					--[[
					满足三个条件：
					1.主球分数达到可分裂的分数
					2.主球分数 > 2 * 追击目标的分数
					3.两球距离 < 主球半径 * 2.5
					]]
					if mainBall.score >= self.DConfig.min_divide_score
								and mainBall.score > otherBall.score * 2
								and dis < self.dia * 0.5 * 2.5 then
						self:sendDivision()
					end
				end
			end
		else
			--不追击，直接走移动流程
			self:process3(mainBall)
		end
	else
		--不在追击范围之内，直接走移动流程
		self:process3(mainBall)
	end
end

--移动流程
function AI:process3(mainBall)
			-- print("process3===="..self.id)
	local rotation = -1

	local random7 = self:getRandom()
	if random7 <= self.AIConfig["move_probability"] then
		--是否吞噬养分判断
		local random8 = self:getRandom()
		if random8 <= self.AIConfig["move_team_probability"] then
			-- self.AIConfig["devour_probability"]
			--寻找距离最近的系统养分
			-- local dis = -1
			-- local nutrient = nil

			-- local data = GameData.RoleDataManager.roleDataList[self.id]
			-- for k, v in pairs(data.nutrientList) do
			-- 	local d = cc.pGetDistance(cc.p(mainSelfBall.x, mainSelfBall.y), cc.p(v.x, v.y))
			-- 	if dis == -1 then
			-- 		dis = d
			-- 		nutrient = v
			-- 	else
			-- 		if d < dis then
			-- 			dis = d
			-- 			nutrient = v
			-- 		end
			-- 	end
			-- end

			-- if nutrient then
			-- 	rotation = Utils:getMoveDirection(cc.p(mainSelfBall.x, mainSelfBall.y), cc.p(nutrient.x, nutrient.y))
			-- 	rotation = math.floor(rotation)
			-- end


			rotation = Utils:getAiPeerDirection(mainBall.userID)
			rotation = self:calProcess1Rotation(mainBall, rotation)
		else
			--0---360中随机一个方向移动
			rotation = math.random(0, 360)
			rotation = self:calProcess1Rotation(mainBall, rotation)
		end
	end
	if rotation ~= -1 then
		self:sendChangeDirect(rotation)
	end
end


--------------------------------------------------------------------------------
function AI:sendChangeDirect(dir)
	NetFunc.netBattle:changeDir( self.id, math.floor(dir) )
	-- if GameData.mode == Constant.GameMode.ALIVE then
	-- 	NetFunc.room:changeDir(self.id, math.floor(dir))
	-- elseif GameData.mode == Constant.GameMode.GATE
	-- 			or GameData.mode == Constant.GameMode.CUSTOM then
	-- 	SingleFunc:changeDirect(self.id, math.floor(dir))
	-- end
end

function AI:sendJet()
	-- if GameData.mode == Constant.GameMode.ALIVE then
	-- 	NetFunc.room:jet(self.id)
	-- elseif GameData.mode == Constant.GameMode.GATE
	-- 			or GameData.mode == Constant.GameMode.CUSTOM then
	-- 	SingleFunc:jet(self.id)
	-- end
	NetFunc.netBattle:jet(self.id)
end

function AI:sendDivision()
	-- if GameData.mode == Constant.GameMode.ALIVE then
	-- 	NetFunc.room:divide(self.id)
	-- elseif GameData.mode == Constant.GameMode.GATE
	-- 			or GameData.mode == Constant.GameMode.CUSTOM then
	-- 	SingleFunc:division(self.id)
	-- end
	NetFunc.netBattle:divide(self.id)
end


return AI
