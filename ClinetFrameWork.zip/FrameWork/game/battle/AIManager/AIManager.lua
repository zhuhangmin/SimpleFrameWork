local AIManager = class("AIManager")
AIManager.instance = nil

function AIManager.getInstance()
    if not AIManager.instance then
        AIManager.instance = AIManager.new()
    end
    return AIManager.instance
end

function AIManager:ctor()
	self.ai_list = {}
end

function AIManager:createAI(id, type, isCreateData, isStar)
	if id then
		local ai_type = type or 1
		local isCreate = isCreateData or true
		local isBegin = isStar or true

		local ai = require("battle.AIManager.AI"):create(id, ai_type, isCreate, isBegin)
		self.ai_list[#self.ai_list + 1] = ai
	end
end

function AIManager:deleteAI(id)
	if id then
		for i = 1, #self.ai_list do
			if self.ai_list[i].id == id then
				self.ai_list[i]:clear()
				table.remove(self.ai_list, i)
				break
			end
		end
	end
end

function AIManager:deleteAllAI()
	for i = 1, #self.ai_list do
		self.ai_list[i]:clear()
	end

	self.ai_list = {}
end

function AIManager:starAITimer(id)
	if id then
		for i = 1, #self.ai_list do
			if self.ai_list[i].id == id then
				self.ai_list[i]:start()
				break
			end
		end
	end
end

function AIManager:startAllAITimer()
	for i = 1, #self.ai_list do
		self.ai_list[i]:start()
	end
end

function AIManager:clear()
	self:deleteAllAI()
end


return AIManager
