local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()

local AI_autorun = class("AI_autorun")
AI_autorun.instance = nil

function AI_autorun:ctor()
	self.dia = 0
	self.id = GameData.battleInfo.userID
	self.rotation = 1
	self.DConfig = cfg:getConfigRecord("room",GameData.roomType) 
	self:start()
end

function AI_autorun:getRandom()
	return math.random(1, 100)
end

function AI_autorun.getInstance()
    if not AI_autorun.instance then
        AI_autorun.instance = AI_autorun.new()
    end
    return AI_autorun.instance
end


function AI_autorun:start()
	if not self.schedulerID then
		self.schedulerID = gScheduler:scheduleScriptFunc(handler(self, self.dataAnalysis), 1, false)
	end
end

function AI_autorun:stop()
	if self.schedulerID then
		gScheduler:unscheduleScriptEntry(self.schedulerID)
		self.schedulerID = nil
	end
end

--数据分析
function AI_autorun:dataAnalysis()
	print("12312")
	if GameData.battleInfo.roleDataManager then
		local data = GameData.battleInfo.roleDataManager.roleDataList[self.id]
		if data and data.userList[self.id].balls and #(data.userList[self.id].balls) > 0 then
			--找主球
			local mainEid = data.elementList[data.userList[self.id].balls[1]].primaryEid
			local mainBall = data.elementList[mainEid]

			if mainBall then
				--记录主球的直径
				self.dia = Utils:getBallDia(mainBall.score)

				--寻找距离主球最近的其他玩家的球
				local otherBall = nil
				local dis = -1
				for k, v in pairs(data.userList) do
					--寻找其他玩家距离主球最近的球
					if k ~= self.id then
						for m, n in pairs(v.balls) do
							local ball = data.elementList[n]
							local d = cc.pGetDistance(cc.p(mainBall.x, mainBall.y), cc.p(ball.x, ball.y))
							if dis == -1 then
								dis = d
								otherBall = ball
							else
								if d < dis then
									dis = d
									otherBall = ball
								end
							end
						end
					end
				end

				local count = 0
				for k, v in pairs( data.elementList ) do
					if v.score > self.DConfig.min_jet_score and v.primaryEid == mainEid then 
						count = count + 1
					end
				end
				if otherBall then
					if mainBall.score < otherBall.score then
						--走躲避流程
						self:process1(mainBall, otherBall)
					elseif mainBall.score > otherBall.score then
						--走追击流程
						self:process2(mainBall, otherBall)
					else
						--走移动流程
						self:process3(mainBall)
					end
				else
					--走移动流程
					if count > 3 then
						self:sendChangeDirect(-1)
						self:sendJet()
						self:process3(mainBall)
					else
						self:process3(mainBall)
					end
				end
			end
		end
	end
end

--计算躲避流程中的角度(主要是在边界附近的角度计算)
function AI_autorun:calProcess1Rotation(mainBall, rotation)
	local dir = rotation
	local x = mainBall.x
	local y = mainBall.y
	local d = self.dia * 0.5 * 0.5 + 20
	local random = math.random(15, 30)

	if x <= d then
		if dir >= 90 and dir <= 180 then
			dir = 90 - random
		elseif dir > 180 and dir <= 270 then
			dir = 270 + random
		end
	elseif x >= self.DConfig.battlefield_wide - d then
		if dir >= 0 and dir <= 90 then
			dir = 90 + random
		elseif dir >= 270 then
			dir = 270 - random
		end
	end

	if y <= d then
		if dir >= 180 and dir <= 270 then
			dir = 180 - random
		elseif dir > 270 or dir == 0 then
			dir = random
		end
	elseif y >= self.DConfig.battlefield_high - d then
		if dir >= 0 and dir <= 90 then
			dir = 360 - random
		elseif dir > 90 and dir <= 180 then
			dir = 180 + random
		end
	end

	return dir
end

--躲避流程
function AI_autorun:process1(mainBall, otherBall)
			print("process1")
	local data = GameData.battleInfo.roleDataManager.roleDataList[self.id]

	--计算危险范围(半径 * 5 + 200)
	local dangerousDis = self.dia * 2.5 + 200

	--计算mainBall和otherBall之间的距离
	local dis = cc.pGetDistance(cc.p(mainBall.x, mainBall.y), cc.p(otherBall.x, otherBall.y))

	if dis <= dangerousDis then
		--在危险范围之内，继续分析
		local random1 = true --self:getRandom() <= AIConfig[self.type][1]
		if random1 then
			--进入躲避
			local rotation = Utils:getMoveDirection(cc.p(otherBall.x, otherBall.y), cc.p(mainBall.x, mainBall.y))
			if rotation then
				--边界判断(更改rotation的方向)
				rotation = self:calProcess1Rotation(mainBall, rotation)

				--设置新的移动方向
				self:sendChangeDirect(rotation)

				--判断是否使用喷射技能
				if mainBall.score >= self.DConfig.min_jet_score then
					-- local random3 = self:getRandom()
					-- if random3 <= AIConfig[self.type][3] then
						-- self:sendJet()
					-- end
				end
			end
		else
			--不躲避，直接走移动流程
			self:process3(mainBall)
		end
	else
		--不在危险范围之内，直接走移动流程
		self:process3(mainBall)
	end
end

--追击流程
function AI_autorun:process2(mainBall, otherBall)
		print("process2")
	local data = GameData.battleInfo.roleDataManager.roleDataList[self.id]

	--计算可追击范围(半径 * 3 + 200)
	local pursueDis = self.dia * 1.5 + 200

	--计算mainBall和otherBall之间的距离
	local dis = cc.pGetDistance(cc.p(mainBall.x, mainBall.y), cc.p(otherBall.x, otherBall.y))
	if dis <= pursueDis then
		--在追击范围之内，继续分析
		local random2 = true--self:getRandom() random2 <= AIConfig[self.type][2]
		if random2 then
			--进入追击
			local rotation = Utils:getMoveDirection(cc.p(mainBall.x, mainBall.y), cc.p(otherBall.x, otherBall.y))
			if rotation then
				--设置新的移动方向
				self:sendChangeDirect(rotation)

				--判断是否使用分裂技能
				local random6 = true--self:getRandom()random6 <= AIConfig[self.type][6]
				if random6 then
					--[[
					满足三个条件：
					1.主球分数达到可分裂的分数
					2.主球分数 > 2 * 追击目标的分数
					3.两球距离 < 主球半径 * 2.5
					]]
					if mainBall.score >= self.DConfig.min_divide_score
								and mainBall.score > otherBall.score * 2
								and dis < self.dia * 0.5 * 2.5 then
						self:sendDivision()
					end
				end
			end
		else
			--不追击，直接走移动流程
			self:process3(mainBall)
		end
	else
		--不在追击范围之内，直接走移动流程
		self:process3(mainBall)
	end
end

--移动流程
function AI_autorun:process3(mainBall)
	print("process3")
	local rotation = -1

	local random7 = true--self:getRandom() random7 <= AIConfig[self.type][7]
	if random7 then
		local data = GameData.battleInfo.roleDataManager.roleDataList[self.id]
		local food = data.foodList
		--是否吞噬养分判断
		-- local random8 = self:getRandom()
		-- if random8 <= AIConfig[self.type][8] then
		-- 	rotation = math.random(0, 360)
		-- else
			--0---360中随机一个方向移动
		rotation = self.rotation
		local disMin = 3000
		for k , v in pairs(food) do
			-- dump(food)
			local dis = cc.pGetDistance(cc.p(mainBall.x, mainBall.y), cc.p(v.x, v.y))
			-- print("dis==="..dis)
			if dis < disMin then
				disMin = dis
				rotation =  Utils:getMoveDirection(cc.p(mainBall.x, mainBall.y), cc.p(v.x, v.y))
			end
		end
		rotation = self:calProcess1Rotation(mainBall, rotation)
		-- end
	end
	self.rotation = rotation
	self:sendChangeDirect(rotation)
end


--------------------------------------------------------------------------------
function AI_autorun:sendChangeDirect(dir)
	NetFunc.netBattle:changeDir(self.id, math.floor(dir))
end

function AI_autorun:sendJet()
	NetFunc.netBattle:jet(self.id)
end

function AI_autorun:sendDivision()
	NetFunc.netBattle:divide(self.id)
end

return AI_autorun
