local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()

local VJoyStick = class("VJoyStick", function()
	return cc.Sprite:create()
end)

function VJoyStick:ctor()
	self.radius = nil
	self.centerPos = nil
	self:updateBg()
	self:init()
end

function VJoyStick:init()
	self:setAnchorPoint(cc.p(0.5, 0.5))

	local size = self:getContentSize()
	self.radius = size.width / 2
	self.centerPos = cc.p(size.width / 2, size.height / 2)

	self:updateSlider()
end

--设置滑块的位置
function VJoyStick:setSliderPosition(dis, dir)
	local value = dis

	if value < 0 then
		value = 0
	elseif value > self.radius then
		value = self.radius
	end

	local rot = dir
	if rot < 0 then
		rot = 0
	end
 
	local rad = math.rad(rot)
	local x = self.centerPos.x + value * math.cos(rad)
	local y = self.centerPos.y + value * math.sin(rad)

	self.slider:setPosition(x, y)
end

function VJoyStick:updateBg()
	local themeType = GameData.settingInfo.battleBgValue
	self.cfg = cfg:getConfigRecord("battlethemeConfig",themeType)
	local imageName = self.cfg.vjoyBg
	self:setSpriteFrame(imageName)
end

function VJoyStick:updateSlider()
	local imageName = self.cfg.vjoy

	if not self.slider then
		self.slider = cc.Sprite:createWithSpriteFrameName(imageName)
		self.slider:setPosition(self.centerPos)
		self:addChild(self.slider)

		self.slider:setName("slider")
	else
		self.slider:setSpriteFrame(imageName)
	end
end

function VJoyStick:updateTheme()
	self:updateBg()
	self:updateSlider()
end


return VJoyStick
