
local battleRankItem = class("battleRankItem", function()
	return cc.CSLoader:createNode("res/BattleRank.csb")
end)

function battleRankItem:ctor( p_isSelf, p_index)
	self:setData(p_isSelf, p_index)
end

function battleRankItem:setData( p_isSelf, p_index )
	local isSelf = false
	local index = 1
	local isVisible = false
	local imageName = "zd/zd_ph1.png" 
	local color = cc.c3b(255, 255, 255)
	local imagePosX = 0
	local rankLabelPosX = 0
	local rankLabelPosY = 0
	local nickname = ""
	

	if p_isSelf then
		isSelf = p_isSelf
	end
	if p_index then
		index = p_index
	end
	local rankIndex = index
	if isSelf then
		isVisible = true
		imageName = "zd/zd_ph_zj.png"
		color = cc.c3b(255, 186, 0)
		imagePosX = -2
		rankIndex = ""
		nickname = 	PlayerDataBasic.nickname
	else
		imagePosX = 0
		rankLabelPosX = 2
		rankLabelPosY = 0
		if index > 3 then
			isVisible = false
			color = cc.c3b(255, 255, 255)
		else
			rankLabelPosY = 4
			isVisible = true
			if index == 1 then
				imageName = "zd/zd_ph1.png"
				color = cc.c3b(255, 88, 88)
			elseif index == 2 then
				imageName = "zd/zd_ph2.png"
				color = cc.c3b(78, 207, 255)
			elseif index == 3 then
				imageName = "zd/zd_ph3.png"
				color = cc.c3b(255, 170, 132)
			end
		end
	end

	self:setAnchorPoint(cc.p(0.5, 0.5))
	local rankBgImage = self:getChildByName("Sprite_rank_bg")
	local rankLabel = self:getChildByName("Text_rank")
	local nickLabel = self:getChildByName("Text_name")
	rankBgImage:setVisible(isVisible)
	rankBgImage:setPositionX(rankBgImage:getPositionX() + imagePosX)
	rankBgImage:setSpriteFrame(imageName)
	rankLabel:setString(rankIndex)
	local posX = rankLabel:getPositionX() + rankLabelPosX
	local posY = rankLabel:getPositionY() - rankLabelPosY
	rankLabel:setPosition(posX,posY)
	nickLabel:setTextColor(color)
	nickLabel:setString(nickname)
end

function battleRankItem:setRank(rank)
	if rank == nil then return end
	if self:getChildByName("Text_rank") == nil then return end
	self:getChildByName("Text_rank"):setString(rank)
end

function battleRankItem:setNickname(nickname)
	if nickname == nil then return end
	if self:getChildByName("Text_name") == nil then return end
	self:getChildByName("Text_name"):setString(nickname)
end


return battleRankItem
