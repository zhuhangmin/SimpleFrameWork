local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()

local FoodLayer = class("FoodLayer", function()
	local DConfig = cfg:getConfigRecord("room",GameData.roomType) 
	local layer = cc.Layer:create()
	layer:setContentSize(cc.size(DConfig.battlefield_wide, DConfig.battlefield_high))
	return layer
end)

function FoodLayer:ctor()
	self.freeFoodList = {}
	for i = 1, 300 , 1 do
		local child = require("battle.Node.Food"):create()
		child:retain()
		self.freeFoodList[#self.freeFoodList + 1] = child
	end
end

function FoodLayer:modifyFood(enter, leave)
	-- dump(enter,"===================")
	if leave then
		for k, v in pairs(leave) do
			if v.entities then
				for m, n in pairs(v.entities) do
					local child = self:getChildByTag(n)
					if child then
						child:clearData()
						child:retain()
						child:removeFromParent()
						self.freeFoodList[#self.freeFoodList + 1] = child
					end
				end
			end
		end
	end

	if enter then
		for k, v in pairs(enter) do
			local len = #self.freeFoodList

			if len > 0 then
				local child = self.freeFoodList[len]
				child:setData(v.eid)
				self:addChild(child)
				child:release()

				child:setName("food"..v.eid)

				table.remove(self.freeFoodList, len)
			else
				local child = require("battle.Node.Food"):create()
				child:setData(v.eid)
				self:addChild(child)

				child:setName("food"..v.eid)
			end
		end
	end
end


return FoodLayer
