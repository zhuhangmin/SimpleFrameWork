local viewEngine = class("viewEngine",require("battle.base.baseView"))
 
function viewEngine:ctor(node)
	self.super:ctor(node)
end

function viewEngine:addEntityNode( renderNode )

	self.node = renderNode
	-- print("addEntityNode~~~~~~~~~~~~~~~~~~~~~"..tostring(self:getNode())..";"..tostring(renderNode))
	self:getNode():addChild(renderNode)
end

function viewEngine:getEntityNode( renderNode )
	return self.node
end

return viewEngine