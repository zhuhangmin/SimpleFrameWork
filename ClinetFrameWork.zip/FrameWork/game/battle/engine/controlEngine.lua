local controlEngine = class("controlEngine",require("battle.base.baseControl"))
 
function controlEngine:ctor(model, view)
	self.super:ctor(model, view)
end

return controlEngine