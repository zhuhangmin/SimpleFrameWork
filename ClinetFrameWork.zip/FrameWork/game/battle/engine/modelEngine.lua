local modelEngine = class("modelEngine",require("battle.base.baseModel"))
 
function modelEngine:ctor(eid)
	self.super:ctor(eid)
end

return modelEngine