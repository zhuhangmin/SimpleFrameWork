local entityNetManager = class("entityNetManager")
local entityControlManager = require("battle.Control.entityControlManager")
entityNetManager.instance = nil
--manager
function entityNetManager:ctor()
	print("entityNetManager ctor")
	self.entityList = {} --只存原始未处理数据
	self.roleDataList = {}
	self.entityManager = entityControlManager:getInstance()
	print("self.entityManager==="..tostring(self.entityManager))
end

function entityNetManager.getInstance()
    if not entityNetManager.instance then
        entityNetManager.instance = entityNetManager.new()
    end
    return entityNetManager.instance
end

function entityNetManager:enterItem( parameter )
	
	if type(parameter) ~= "table" then return end
	-- if type(parameter.eid) ~= "string" then return end
	print("enter item ==="..parameter.eid)
	local eid = parameter.eid
	self:setItemById(eid,parameter)
	self:doFuncWithName("enter_entity",{eid = eid, param = parameter})
end

function entityNetManager:enterFood( parameter )
	
	if type(parameter) ~= "table" then return end
	-- if type(parameter.eid) ~= "string" then return end
	-- print("enter food ==="..parameter.eid)
	local eid = parameter.eid
	self:setItemById(eid,parameter)
	self:doFuncWithName("enter_food",{eid = eid, param = parameter})
end

function entityNetManager:moveItem( parameter )
	if type(parameter) ~= "table" then return end
	if type(parameter.eid) ~= "string" then return end
	local eid = parameter.eid
	self:updateItemById(eid,parameter)
	self:doFuncWithName("move_update",{eid = eid, param = parameter})
end

function entityNetManager:leaveItem( eid )
	if type(eid) ~= "string" then return end
	self:setItemById(eid,nil)
	self:doFuncWithName("leave_update",{eid = eid, param = nil})
end

function entityNetManager:deadItem( eid )
	if type(eid) ~= "string" then return end
	self:setItemById(eid,nil)
	self:doFuncWithName("dead_update",{eid = eid, param = nil})
end

function entityNetManager:updateItemById( eid, parameter )
	if type(eid) ~= "string" then return end
	if type(parameter) ~= "table" then return end
	if type(self.entityList[eid]) ~= "table" then return end
	local item = self.entityList[eid]
	for k , v in pairs(parameter) do
		item[k] = v
	end
end

function entityNetManager:setItemById( eid, parameter )
	-- if type(eid) ~= "string" then return end
	-- if type(parameter) ~= "table" then return end
	self.entityList[eid] = parameter
	if type(parameter.userid) == "string" then 
	-- dump(self.roleDataList)
		dump(parameter)
		if self.roleDataList[parameter.userid] == nil then
			self.roleDataList[parameter.userid] = {parameter.eid}
		else
			table.insert(self.roleDataList[parameter.userid],parameter.eid)
		end
	end
end

function entityNetManager:getItemById( eid )
	-- if type(eid) ~= "string" then return end
	local item = self.entityList[eid]
	return item
end

function entityNetManager:centerNotify( parameter )
	dump(parameter)
end

function entityNetManager:doFuncWithName( name ,params )
	if name ~= "enter_food" then
		print("do function============="..name)
	end
	

	-- self.entityManager = entityControlManager:getInstance()
	-------------------------BattleMsg---------------------------------
	if name == "enter_entity" then
		-- if self.entityManager.ctrlList[params.eid] ~= nil then 
		-- 	self.entityManager:updateEntity( params )
		-- else
			self.entityManager:addEntity( params )
		-- end
	end

	if name == "enter_food" then
		self.entityManager:addFood( params )
	end

	if name == "leave_update" then
		self.entityManager:leaveEntity( params )	
	end

	if name == "dead_update" then
		self.entityManager:removeEntity( params )	
	end

	if name == "move_update" then
		self.entityManager:updateEntity( params )	
	end

	if name == "buff_notify" then

	end
end


function entityNetManager:changeDirection( params )
	dump(self.roleDataList)
	local userid = params.touserid
	local tbl = self.roleDataList[userid]
	for k , v in pairs(tbl) do
		self.entityManager:changeDir(v,params.rotation)
	end
end

return entityNetManager
