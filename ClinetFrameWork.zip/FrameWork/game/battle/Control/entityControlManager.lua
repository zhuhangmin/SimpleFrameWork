local entityControlManager = class("entityControlManager")
entityControlManager.instance = nil

function entityControlManager.getInstance()
    if not entityControlManager.instance then
        entityControlManager.instance = entityControlManager.new()
    end
    return entityControlManager.instance
end

local entityControlFactory = require("battle.Control.entityControlFactory")

--TODO VIEW MANAGER
-- local LISTENER_NAME		= "battle" 


function entityControlManager:ctor()
	self.ctrlList = {}
	self.foodList = {}
end


-- function entityControlManager.getInstance()
--     if not entityControlManager.instance then
--         entityControlManager.instance = entityControlManager.new()
--     end
--     return entityControlManager.instance
-- end

-- FirstLevel

function entityControlManager:getControl(eid)
	return self.ctrlList[eid]
end

function entityControlManager:setControl(eid, control)
	self.ctrlList[eid] = control
end

function entityControlManager:getFoodControl(eid)
	return self.foodList[eid]
end

function entityControlManager:setFoodControl(eid, control)
	self.foodList[eid] = control
end

-- SecondLevel API INTERFACE (C -> M, V)
function entityControlManager:setEntityControl(eid, control)
	self:setControl(eid, control)
end

function entityControlManager:getEntityControl(eid)
	return self:getControl(eid)
end

function entityControlManager:getModel(eid)
	return self:getControl(eid):getModel()
end

function entityControlManager:setModel(eid, model)
	self:getControl(eid):setModel(model)
end

function entityControlManager:getView(eid)
	return self:getControl(eid):getView()
end

function entityControlManager:setView(eid,view)
	self:getControl(eid):setView(view)
end

-- ThirdLevel API 
function entityControlManager:getData(eid)
	self:getModel(eid):getData()
end

function entityControlManager:setData(eid,data)
	self:getModel(eid):setData(data)
end

function entityControlManager:getNode(eid)
	self:getModel(eid):getView().getNode()
end

function entityControlManager:setNode(eid, node)
	self:getModel(eid):getView().setNode(node)
end

--FouthLevel Life Cycle Control
--**NOTE only highLevel API can couple other modules
function entityControlManager:addEntity(msg)
	local eid = msg.eid
	local ECF = entityControlFactory:getInstance()
	print("addEntity eid ===="..eid)
	local entityControl = ECF:createEntityControl(msg)
	
	self:setEntityControl(eid, entityControl)
end

function entityControlManager:addFood(msg)
	local eid = msg.eid
	local ECF = entityControlFactory:getInstance()
	print("addfood eid ===="..eid)
	local entityControl = ECF:createEntityControl(msg)
	
	self:setFoodControl(eid, entityControl)
end

function entityControlManager:removeEntity(msg)
	local eid = msg.eid
	local entityControl = self:getControl(eid)
	local ECF = entityControlFactory:getInstance()
	ECF:destroyEntityControl(entityControl, ENTITY_MSG.DESTROY_BEFORE)
	
	self:setEntityControl(eid, nil)
end

function entityControlManager:updateEntity(msg)
	local eid = msg.eid
	local entityControl = self:getControl(eid)
	
	entityControl:onUpdate(msg)
end

function entityControlManager:leaveEntity(msg)
	-- local eid = msg.eid
	-- local entityControl = self:getEntityControl(eid)
	-- local ECF = entityControlFactory:getInstance()
	-- ECF:destroyEntityControl(entityControl, ENTITY_MSG.EXIT_BEFORE)

	-- self:setEntityControl(eid, nil)
end

function entityControlManager:update( dt )
	for eid, entity_c in pairs(self.ctrlList) do
		print("update eid=========="..eid)
		entity_c:update(dt)
	end

end


function entityControlManager:getBallList( ownid )
	local list = {}
	if type(ownid) ~= "string" then 
		print("error ========"..tostring(ownid)..";"..type(ownid))
		return
	end
	-- dump(self.ctrlList)
	if self.ctrlList then
		for k , v in pairs(self.ctrlList) do
			local userid = v.model:getUserid()
			-- print("userid==="..tostring(userid)..";"..tostring(ownid))
			if tostring(userid) == tostring(ownid) then	
				table.insert(list,v)
			end
		end
	end
	return list
end

function entityControlManager:getSelfBallList( )
	-- print("entityControlManager="..tostring(self.ctrlList)..";````"..#self.ctrlList)
	local list = self:getBallList(PlayerDataBasic.id)
	return list
end

function entityControlManager:changeDir( eid , rotation )
	local control = self:getControl(eid)
	control:changeDir(rotation)
end



return entityControlManager
