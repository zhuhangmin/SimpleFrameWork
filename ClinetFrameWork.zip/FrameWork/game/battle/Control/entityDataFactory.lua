local entityDataFactory = class("entityDataFactory")
local ball = require("src.app.game.UI.battle.data.ballData")
local grass = require("src.app.game.UI.battle.data.GrassData")
-- local jet = require("src.app.game.UI.battle.data.baseJetData")
-- local entity_config ={
-- 	[1] = ball,
-- 	[2] = grass,
-- 	[3] = jet,
-- } -- config table

function entityDataFactory:ctor()

end

function entityDataFactory:createEntityData( eid, parameter)
	if type(parameter) ~= "table" then return end
	if type(eid) ~= "string" then return end
	if type(parameter.entity_id) ~= "number" then return end
	if entity_config[parameter.entity_id] then return end

	local entity = entity_config[parameter.entity_id]:create()
	entity:setData(parameter) 
	return entity
end

return entityDataFactory