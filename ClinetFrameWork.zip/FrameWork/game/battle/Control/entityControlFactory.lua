local entityControlFactory = class("entityControlFactory")
local BEFORE_NAME = "battle.Entity."
local AFTER_M_NAME = "Model"
local AFTER_C_NAME = "Control"
local AFTER_V_NAME = "View"
local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()
entityControlFactory.instance = nil

function entityControlFactory:ctor()

end

function entityControlFactory:getInstance()
    if not entityControlFactory.instance then
        entityControlFactory.instance = entityControlFactory.new()
    end
    return entityControlFactory.instance
end


function entityControlFactory:setEntityNodeParent( food , ball )
	self.ballLayer = ball
	self.foodLayer = food
end


function entityControlFactory:getMVCNameById( eid )
	local TYPE_NAME_S = cfg:getConfigField("entityConfig",eid,"type")
	-- local TYPE_NAME_S = cfg:getConfigField("entityType",TYPE_ID,"type")
	local TYPE_NAME = string.sub(TYPE_NAME_S,1,1)..string.lower(string.sub(TYPE_NAME_S,2))
	local result = {}
	result.modelName = BEFORE_NAME .. TYPE_NAME .. AFTER_M_NAME
	result.viewName = BEFORE_NAME .. TYPE_NAME .. AFTER_V_NAME
	result.controlName = BEFORE_NAME .. TYPE_NAME .. AFTER_C_NAME
	if TYPE_NAME == "Food" then
		result.node = self.foodLayer
	else
		result.node = self.ballLayer
	end
	-- dump(result)
	return result
end


function entityControlFactory:createEntityControl( msg )
	-- dump(msg)
	-- if type(msg.data) ~= "table" then return end
	-- if type(msg.eid) ~= "string" then return end
	-- if type(parameter.entity_id) ~= "number" then return end
	-- if entity_config[parameter.entity_id] then return end
	local eid = msg.eid
	local data = msg.param
	local result = self:getMVCNameById(data.entity_id)

	local node = result.node
	local modelClassName = result.modelName
	local viewClassName = result.viewName
	local controlClassName = result.controlName

	local model = require(modelClassName):create(eid)
	-- model:onCreate(param)
	local view = require(viewClassName):create(node)
	-- view:onCreate(param)
	local control = require(controlClassName):create(model, view)
	-- control:onCreate(param)
	local modelParam = {}
	model:onEnter(data)
	local viewParam = {}
	view:onEnter(viewParam)
	local controlParam = {}
	control:onEnter(viewParam)


	return control
end

function entityControlFactory:destroyEntityControl(entityControl, triggerType)
	local param = {}

	local model = entityControl:getModel()
	if triggerType == ENTITY_MSG.EXIT_BEFORE then
		model:onDestroy(param)
	else
		model:onExit(param)
	end
	model:destroy()

	local view = entityControl:getView()
	if triggerType == ENTITY_MSG.EXIT_BEFORE then
		view:onDestroy(param)
	else
		view:onExit(param)
	end
	view:destroy()

	local control = entityControl
	if triggerType == ENTITY_MSG.EXIT_BEFORE then
		control:onExit(param)
	else
		control:onDestroy(param)
	end
	control:destroy()
end





return entityControlFactory