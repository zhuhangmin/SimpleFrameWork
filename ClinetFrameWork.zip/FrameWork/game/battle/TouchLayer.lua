local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()

local TouchLayer = class("TouchLayer", function()
	return cc.Layer:create()
end)

function TouchLayer:ctor()
	self.isValid = false
	self.frameCount = 0

	self.isDown = false
	self.isMove = false
	self.downPos = nil

	self.moveDir = -1

	self:init()
	self:addTouchEvent()
end

function TouchLayer:init()
	self.stick = require("battle.VJoyStick"):create()
	self.stick:setVisible(false)
	self:addChild(self.stick)

	self.stick:setName("VJoyStick")
end

function TouchLayer:updateTheme()
	self.stick:updateTheme()
end

function TouchLayer:addTouchEvent()
	local listener = cc.EventListenerTouchOneByOne:create()
	listener:registerScriptHandler(handler(self, self.onTouchBegan), cc.Handler.EVENT_TOUCH_BEGAN)
	listener:registerScriptHandler(handler(self, self.onTouchMoved), cc.Handler.EVENT_TOUCH_MOVED)
	listener:registerScriptHandler(handler(self, self.onTouchEnded), cc.Handler.EVENT_TOUCH_ENDED)
	self:getEventDispatcher():addEventListenerWithSceneGraphPriority(listener, self)
end

function TouchLayer:onTouchBegan(touch, event)
	if self.isValid then
		if touch:getId() > 0 then
			--多点触控
			return false
		else
			self.isDown = true
			self.downPos = touch:getLocation()

			self.stick:setVisible(true)
			self.stick:setPosition(self.downPos)
		end
	end

	return self.isValid
end

function TouchLayer:onTouchMoved(touch, event)
	

	local movePos = touch:getLocation()
	local dis = Utils:getMoveDistance(self.downPos, movePos)
	--print("dis-===="..dis)
	if dis < 5 then
		self.isMove = false
	else
		self.isMove = true
	end
	local dir = Utils:getMoveDirection(self.downPos, movePos)
	if dir then
		self.moveDir = math.floor(dir)
	end

	local dis = cc.pGetDistance(self.downPos, movePos)
	self.stick:setSliderPosition(dis, self.moveDir)
end

function TouchLayer:onTouchEnded(touch, event)
	if self.isDown and not self.isMove then
		self.moveDir = -1
	end

	self.stick:setVisible(false)

	self.isDown = false
	self.isMove = false
	self.downPos = nil
end

function TouchLayer:update(dt)
	if self.isValid then
		self.frameCount = self.frameCount + 1

		if self.frameCount >= cfg:getConfigField("netBattle",1,"CAPTURE_TOUCH_FRAME") then  
			self.frameCount = 0

			if GameData.joyDir ~= self.moveDir then
				GameData.joyDir = self.moveDir

				NetFunc.netBattle:changeDir(GameData.battleInfo.userID,GameData.joyDir )
			end
		end
	end
end


return TouchLayer
