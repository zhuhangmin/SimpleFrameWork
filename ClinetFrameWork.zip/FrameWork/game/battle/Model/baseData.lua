local baseData = class("baseData",require("battle.Engine.modelEngine"))
 
function baseData:ctor()
	self.x = 0
    self.y = 0 
end

function baseData:getX()
	return self.x
end

function baseData:setX(parameter)
	if type(parameter) ~= "number" then return end
	self.x = parameter
end

function baseData:getY()
	return self.y
end

function baseData:setY(parameter)
	if type(parameter) ~= "number" then return end
	self.y = parameter
end

function baseData:setPosition(x, y)
	self:setX(x)
	self:setY(y)
end

function baseData:getPosition( )
	return self:getX(),self:getY()
end

function baseData:setData( data )
	if type(data) ~= "table" then return end
	self.super:setData(data)
	self:setX(data.x)
	self:setY(data.y)
end

return baseData