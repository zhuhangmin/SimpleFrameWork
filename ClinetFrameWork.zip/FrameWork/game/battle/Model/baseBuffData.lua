local baseBuff = class("baseBuff")

function baseBuff:ctor( eid, buff )
	self.eid = eid
	self.buff = buff
end

function baseBuff:getEid()
	return self.eid
end

function baseBuff:setEid(parameter)
	if type(parameter) ~= "string" then return end
	self.eid = parameter
end

function baseBuff:getBuff()
	return self.buff
end

function baseBuff:setBuff(parameter)
	if type(parameter) ~= "table" then return end
	self.buff = parameter
end

return baseBuff
