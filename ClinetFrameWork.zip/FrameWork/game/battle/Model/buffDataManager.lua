local buffDataManager = class("buffDataManager")
buffDataManager.bufflist = {}

function buffDataManager:ctor()
	self.bufflist = {}
end

function buffDataManager:getBufflist()
	return self.bufflist
end

function buffDataManager:setBufflist(parameter)
	if type(parameter) ~= "table" then return end
	self.bufflist = parameter
end

function buffDataManager:setBuffWithEid( eid , buff )
	if type(buff) ~= "table" then return end
	if type(eid) ~= "string" then return end
	self.bufflist[eid] = buff
end

function buffDataManager:getBuffWithEid( eid )
	if type(eid) ~= "string" then return end
	return self.bufflist[eid]
end

return buffDataManager