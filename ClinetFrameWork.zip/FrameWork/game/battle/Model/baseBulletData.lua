local baseBulletData = class("baseBulletData",require("src.app.game.UI.battle.data.baseMoveData"))

function baseBulletData:ctor()

end






return baseBulletData
