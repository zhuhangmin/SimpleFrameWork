local baseMoveData = class("baseMoveData",require("battle.Model.baseData"))

function baseMoveData:ctor()
	self.super:ctor() --调用父类的构造函数
	-- self.time = 0 -- TODO CLIENT TIMESTAMP
	self.vx = 0 --速度
	self.vy = 0 --速度
	self.ax = 0 --加速度
	self.ay = 0 --加速度
	-- self.dir = 0 --速度方向【0,360】
end

-- function baseMoveData:getTime()
-- 	return self.time
-- end

-- function baseMoveData:setTime(parameter)
-- 	if type(parameter) ~= "number" then return end
-- 	self.time = parameter
-- end

function baseMoveData:getVx()
	return self.vx
end

function baseMoveData:setVx(parameter)
	if type(parameter) ~= "number" then return end
	self.vx = parameter
end

function baseMoveData:getVy()
	return self.vy
end

function baseMoveData:setVy(parameter)
	if type(parameter) ~= "number" then return end
	self.vy = parameter
end

function baseMoveData:getAx()
	return self.ax
end

function baseMoveData:setAx(parameter)
	if type(parameter) ~= "number" then return end
	self.ax = parameter
end

function baseMoveData:getAy()
	return self.ay
end

function baseMoveData:setAy(parameter)
	if type(parameter) ~= "number" then return end
	self.ay = parameter
end

-- function baseMoveData:getDir()
-- 	return self.dir
-- end

-- function baseMoveData:setDir(parameter)
-- 	if type(parameter) ~= "number" then return end
-- 	self.dir = parameter
-- end


function baseMoveData:setVelocityXY( vx, vy )
	self:setVx(vx)
	self:setVy(vy)	
end

function baseMoveData:setAccelerationXY( ax , ay )
	self:setAx(ax)
	self:setAy(ay)
	-- self.a = math.sqrt(ax*ax+ay*ay)	
end

function baseMoveData:setData( data )
	if type(data) ~= "table" then return end
	self.super:setData(data)
	self:setVx(data.speedx)
	self:setVy(data.speedy)
	-- self:setAx(data.ax)
	-- self:setAy(data.ay)
end

return baseMoveData


