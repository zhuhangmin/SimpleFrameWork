local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()
local EConfig = cfg:getTable("entityConfig") 
local BallLayer = class("BallLayer", function()
	local DConfig = cfg:getConfigRecord("room",GameData.roomType)
	local layer = cc.Layer:create()
	layer:setContentSize(cc.size(DConfig.battlefield_wide, DConfig.battlefield_high)) 
	return layer
end)

function BallLayer:ctor()
	self.preAddList = {} 				--加入缓冲队列
	self.preRemoveList = {}				--删除缓冲队列
	self.freeGrassList = {}
	self.freeJetList = {}
end

function BallLayer:update(dt)
	local children = self:getChildren()

	for k, v in pairs(children) do
		v:update(dt)
	end
end

function BallLayer:addGrass( v )
	local len = #self.freeGrassList
	if len > 0 then
		local child = self.freeGrassList[len]
		child:setData(v)
		self:addChild(child)
		child:release()
		table.remove(self.freeGrassList, len)
	else
		local grass = require("battle.Node.Grass"):create()
		grass:setData(v)
		self:addChild(grass)
	end
end

function BallLayer:addJet( v )
	local len = #self.freeJetList
	print("jet free====="..#self.freeJetList)
	if len > 0 then
		local child = self.freeJetList[len]
		child:setData(v)
		self:addChild(child)
		child:release()
		table.remove(self.freeJetList, len)
	else
		local jet = require("battle.Node.JetFood"):create()
		jet:setData(v)
		self:addChild(jet)
	end
end

function BallLayer:deleteGrass( child )
	
	if child then
		child:clearData()
		child:retain()
		child:removeFromParent()
		self.freeGrassList[#self.freeGrassList + 1] = child
	end
end

function BallLayer:deleteJet( child )
	print("deleteJet."..tostring(child)..";"..#self.freeJetList)
	if child then
		child:clearData()
		child:retain()
		print("deleteGrass."..tostring(child)..";"..#self.freeJetList)
		child:removeFromParent()
		
		
		self.freeJetList[#self.freeJetList + 1] = child
		print("deleteGrass."..tostring(child)..";"..#self.freeJetList)
	end
end

function BallLayer:modifyItem(enter, leave, move, dead)
	-- dump(move)
	if enter then
		for k , v in pairs( enter ) do
			self.preAddList[v.eid] = v
			self.preRemoveList[v.eid] = nil
		end
	end

	if leave then
		for k , v in pairs( leave ) do
			self.preRemoveList[v] = v
			self.preAddList[v] = nil
		end
	end
	if dead then
		for k , v in pairs( dead ) do
			local dEid, kEid = Utils:sepInt32ToInt16(v)
			self.preAddList[dEid] = nil
		end
	end

	if table.nums(self.preAddList) > 0 then
		local count = 8

		for k, v in pairs(self.preAddList) do
			if count > 0 then

				local e_type = EConfig[v.entity_id].type
				if e_type == "JETFOOD" then
					--喷射养分
					-- local jetFood = require("battle.Node.JetFood"):create(v.eid, v.userid)
					-- self:addChild(jetFood)
					-- jetFood:setName("jetFood"..v.eid)

					self:addJet(v)
				elseif e_type == "GRASS" then
					--草丛
					-- local grass = require("battle.Node.Grass"):create(v.eid, v.userid)
					-- self:addChild(grass)
					-- grass:setName("grass"..v.eid)
					self:addGrass(v)
				elseif e_type == "BALL" then
					local ball = require("battle.Node.Ball"):create(v)
					self:addChild(ball)
					ball:setName("ball"..v.eid)
				end
				self.preAddList[k] = nil
				count = count - 1
			else 
				break
			end
		end
	end

	if table.nums(self.preRemoveList) > 0 then
		local count = 8
		for k,v in pairs(self.preRemoveList) do
			if count > 0 then
				local child = self:getChildByTag(v)
				if child then
					if child.entity_id then
						if EConfig[child.entity_id].type == "GRASS" then
							self:deleteGrass(child)
						end

						if EConfig[child.entity_id].type == "JETFOOD" then
							self:deleteJet(child)
						end

					else
						child:removeFromParent()
					end
				end
				count = count - 1
				self.preRemoveList[v] = nil
			else 
				break
			end
		end
	end

	if dead then
		for k, v in pairs(dead) do
			local dEid, kEid = Utils:sepInt32ToInt16(v)
			local dChild = self:getChildByTag(dEid)
			local kChild = self:getChildByTag(kEid)

			if dChild then
				if kChild then
					if dChild.userID == "-1" then
						--吞噬喷射养分
						kChild:playFaceAnim(BattleMsg.FULL)
					elseif dChild.userID ~= "0" and dChild.userID ~= kChild.userID then
						--玩家被其他玩家吞噬
						kChild:playFaceAnim(BattleMsg.HAPPY)
					end
				end
				if dChild.entity_id then
					print("e_type==="..EConfig[dChild.entity_id].type)
					if EConfig[dChild.entity_id].type == "GRASS" then
						self:deleteGrass(dChild)
					end

					if EConfig[dChild.entity_id].type == "JETFOOD" then
						self:deleteJet(dChild)
					end
				else
					dChild:removeFromParent()
				end
			end
		end
	end
end

function BallLayer:playExp(isNet, userID, sex, expIndex)
	if isNet and userID == GameData.battleInfo.userID then
		return
	end

	local rdm = GameData.battleInfo.roleDataManager
	local data = rdm.roleDataList[GameData.battleInfo.userID]

	if data and data.userList[userID] and data.userList[userID].balls then
		if #data.userList[userID].balls then
			local eid = data.userList[userID].balls[1]
			if eid then
				if data.elementList then
					if  data.elementList[eid] then
						local pEid = data.elementList[eid].primaryEid
						--print("pEid==="..pEid)
						local child = self:getChildByTag(pEid)
						if child then
							child:playExpression(expIndex, sex)
						end
					end
				end
			end
		end
	end
end


return BallLayer
