local EngineControl = require  "EngineControl"
local GMControl = class("GMControl", EngineControl)
local KeyBoardMixin = require "KeyBoardMixin"
EngineControl:include(KeyBoardMixin)
--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
}

--SYSTEM MSGS
local BTN_SEND = "Button_1"
local BTN_RETURN = "Button_2"
local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_SEND,
}

--GAME LABLES
local LBL_INPUT = "TextField_1"
local PANEL_INPUT = "Panel_1"
local INPUT_RES = "tongyong/yxgz_shurukuang.png"
local TAG_EDITBOX = 20000

function GMControl:ctor(model, view)
	GMControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)
end

function EngineControl:onKeyReleased(code, event)
		print("[CODE] = " .. code)
		local node = self:getChildNode(GM_CSB_NODE)
		if code == 59 then -- space key
			local value = node:isVisible()
			node:setVisible(not value)    		        
		end

		if code == 35 then -- enter key
			self:sendGMCommand()
		end
		
		if code == 6 then -- back 
			
			local model = self:getModel()
			local lastTime = model:getLastBackTime()
			local now = socket.gettime() * 1000
			local delta = now - lastTime
			local interval = model:getBackTimeInterval()
			model:setLastBackTime(now)
			if delta < interval then
				if DEBUG == 1 then
					print("DEVICE GM CONTROL")
					local value = node:isVisible()
					node:setVisible(not value)    		        
				else
					print("DEVICE BACK")
					self:send(GameMsg.MSG_TRY_EXIT_GAME)
				end
			end
		end
end


function GMControl:onCreate(param)
	GMControl.super.onCreate(self, param)
	if isNil(param) then printStack() end
	
	local inputText = self:getChildNode(LBL_INPUT)
	if inputText then
		inputText:setVisible(false)
		local contentSize = inputText:getContentSize()
		local editBox = ccui.EditBox:create(contentSize, INPUT_RES)
		editBox:setTag(TAG_EDITBOX)
		editBox:setPosition(inputText:getPosition())
		editBox:setAnchorPoint(0,1)
		editBox.setTextColor = inputText.setFontColor
		editBox:setFontColor(display.COLOR_BLACK)
		editBox:setFontSize(inputText:getFontSize())
		editBox:setPlaceHolder(inputText:getPlaceHolder())
        editBox:setText(inputText:getPlaceHolder())
		editBox:setPlaceholderFontSize(inputText:getFontSize())
		editBox:setPlaceholderFontColor(display.COLOR_BLACK)
		editBox:setFontName(inputText:getFontName())
        -- editBox:setMaxLength(global[1].MAX_DECLARATION_LENGTH)
        editBox:setContentSize(inputText:getContentSize())
        editBox:registerScriptEditBoxHandler(handler(self, self.onDeclarationEditEvent)) 
      	local panel = self:getChildNode(PANEL_INPUT)
		panel:addChild(editBox,0)
	end

	-- local function onKeyReleased(code, event)
		-- print("[CODE] = " .. code)
		-- if code == 59 then -- space key
		-- 	local value = node:isVisible()
		-- 	node:setVisible(not value)    		        
		-- end

		-- if code == 35 then -- enter key
		-- 	self:sendGMCommand()
		-- end
		
		-- if code == 6 then -- back 
			
		-- 	local model = self:getModel()
		-- 	local lastTime = model:getLastBackTime()
		-- 	local now = socket.gettime() * 1000
		-- 	local delta = now - lastTime
		-- 	local interval = model:getBackTimeInterval()
		-- 	model:setLastBackTime(now)
		-- 	if delta < interval then
		-- 		if DEBUG == 1 then
		-- 			print("DEVICE GM CONTROL")
		-- 			local value = node:isVisible()
		-- 			node:setVisible(not value)    		        
		-- 		else
		-- 			print("DEVICE BACK")
		-- 			self:send(GameMsg.MSG_TRY_EXIT_GAME)
		-- 		end
		-- 	end
		-- end
	-- end

	-- local listener = cc.EventListenerKeyboard:create()
	-- listener:registerScriptHandler(onKeyReleased, cc.Handler.EVENT_KEYBOARD_RELEASED)
 --    local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
	-- eventDispatcher:addEventListenerWithSceneGraphPriority(listener, node)


	self:registerKeyBoard(self:getNode())
	local node = self:getChildNode(GM_CSB_NODE)
	node:setVisible(false)
end

function GMControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		-- self:getNode():setVisible(false)
		local node = self:getChildNode(GM_CSB_NODE)
		if isNil(node) then return end
		node:setVisible(false)
		return
	end

	if senderName == BTN_SEND then
		self:sendGMCommand()
	end

end

function GMControl:sendGMCommand()
	local editBox = self:getChildNode(TAG_EDITBOX)
	local str = editBox:getText()
    if not str or str == "" then return end

    --CLIENT @@
    local commandPrefix = string.sub(str,1,2)
    if commandPrefix then
    	if commandPrefix == "@@" then
    		local clientCommand = string.sub(str,3)
    		if clientCommand == "dump" then
    			dump(PlayerDataSystem)
    			dump(PlayerDataBasic)
    			dump(PlayerDataCustom)
    			dump(ItemData)
    		end

    		if clientCommand == "mail" then
    			dump(MailData)
    			dump(MailData_unReadMailExist)
    		end

    		if clientCommand == "charge" then
    			dump(ChargeData)
    		end

    		if clientCommand == "fps" then
			  	local name = BattleMsg.SHOW_FPS
			  	local event = {}
			    self:send(name,event)
    		end

    		if clientCommand == "startai" then
			  	local name = BattleMsg.START_AI
			  	local event = {}
			    self:send(name,event)
    		end

    		if clientCommand == "stopai" then
			  	local name = BattleMsg.STOP_AI
			  	local event = {}
			    self:send(name,event)
    		end
    	return
    	end
    end

    --SERVER @
	local func = "setGmCommand"
	local params = {gmStr = str}
    self:submitForm(func, params)
end

function GMControl:recv(event)
	self.super.recv(self, event)
	
	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

function GMControl:destroy()
	GMControl.super.destroy(self)
	self:unregisterKeyBoard()	
end

return GMControl


