PRELOAD_PLIST = "preloadPlist"
PRELOAD_ARMATURE = "preloadArmature"

--VOICE STATE
SPEAK_EVENT = {
    START   = "onStart",
    STOP    = "onStop",
}

PLAY_EVENT  = {
    START   = "onStart",
    STOP    = "onStop",
}

UPLOAD_EVENT = {
    SUCCESS = "onSuccess",
    PROGRESS = "onProgress",
    ERROR   = "onError", 
}

DOWNLOAD_EVENT = {
    SUCCESS = "onSuccess",
    PROGRESS = "onProgress",
    ERROR   = "onError",       
}

SPEAK_STATE = {
    MUTE = 1,
    SPEAKING = 2,
}

PLAY_STATE = {
    MUTE = 1,
    PLAYING = 2,
}

--NET STATE
MSG_STATE = {
    SUCCESS = 0,
    FAIL = 1,
}
DEBUG_FLAG = true

--SOUND
DEFAULT_BUTTON_SOUND = "button.mp3"
TIPS_SOUND = "tips.mp3"

--MUSIC
DEFAULT_MUSIC = "main.mp3"
BATTLE_MUSIC = "battle.mp3"

--GAME PARAM
TIP_FADE_TIME = 3

--POPUP BTN TITLE
POPUP_CANCEL_TITLE = "取消"
POPUP_CONFIRM_TITLE = "确定"

----TOUCH STATE
TOUCH_ABLE = 1
TOUCH_DISABLE = 0

--WIDGET TAG
LIST_NODE_TAG = 3333

--UICONTROL DATAMODE
NATIVE_MODE = 0
BRIDGE_MODE = 1

HEART_DICONNECT_TIME = 600

GameMsg = {
	MSG_TRY_EXIT_GAME = "msg_try_exit_game",

	--语音
	MSG_RECEIVE_VOICE = "msg_recv_voice",

	--通用
	MSG_RES_LOAD_OVER = "msg_res_load_over",
	
	MSG_LOGIN_GAME_RET = "msg_login_game_ret",
	MSG_EXIT_GAME_RET = "msg_exit_game_ret",
	MSG_LOGOUT_SDK_ACCOUNT = "msg_logout_sdk_account",

	MSG_GET_AWARD_SUCC = "msg_get_award_succ",

	--角色
	MSG_ADD_CITY_LAYER = "msg_add_city_layer",
	MSG_CHANGE_SELECT_CITY = "msg_change_select_city",
	MSG_MODIFY_CITY = "msg_modify_city",

	--战斗
	MSG_ENTER_BATTLE_RET = "msg_enter_battle_ret",
	MSG_EXIT_BATTLE_RET = "msg_exit_battle_ret",
	MSG_ROLE_DIVIDE = "msg_role_divide",
	MSG_ROLE_JET = "msg_role_jet",
	MSG_CLICK_EXP = "msg_click_exp",
	-- MSG_ROLE_DEAD = "msg_role_dead",
	-- MSG_ROLE_REVIVE = "msg_role_revive",
	-- MSG_ROLE_REVIVE_RET = "msg_role_revive_ret",

	MSG_NOTIFY_STATE = "msg_notify_state",
	MSG_NOTIFY_FOOD = "msg_notify_food",
	MSG_NOTIFY_RANK = "msg_notify_rank",
	MSG_NOTIFY_EXP = "msg_notify_exp",
	MSG_NOTIFY_GAME_OVER = "msg_notify_game_over",

	--排行
	MSG_GET_RANK_RET = "msg_get_rank_ret",

	--兑换码
	MSG_GET_REDEEM_REWARD_RET = "msg_get_redeem_reward_ret",

	--支付
	MSG_GET_PAY_ORDER_ID_RET = "msg_get_pay_order_id_ret",
	MSG_GET_PAY_ACTIVITY_ORDER_ID_RET = "msg_get_pay_activity_order_id_ret", 
	MSG_PLATFORM_PAY_RET = "msg_platform_pay_ret",
	MSG_PAY_SUCC_NOTIFY = "msg_pay_succ_notify",
	MSG_PAY_SUCC_AWARD = "msg_pay_succ_award",
    MSG_FIRSTCHARGE_RESP = "msg_firstcharge_resp",
    MSG_CHARGEACTIVITY_RESULT = "msg_chargeactivity_result",
    MSG_TIMECHARGEACTIVITY_INFO = "msg_timechargeactivity_info",

	--皮肤
	MSG_SKIN_MERGE_RET = "msg_skin_merge_ret",
	MSG_SKIN_CHANGE_RET = "msg_skin_change_ret",
	MSG_SKIN_ADD_INFO_LAYER = "msg_skin_add_info_layer",
	MSG_SKIN_ADD_SURE_PAY_LAYER = "msg_skin_add_sure_pay_layer",
    MSG_SKIN_ON_SKIN_ITEM = "msg_skin_on_skin_item",
    MSG_SKIN_REPATE = "msg_skin_repate",

	--游戏恢复到前台
	MSG_GAME_RESUME = "msg_game_resume",

	--显现等待界面
	MSG_SHOW_WAITING = "msg_show_waiting", 
	MSG_SHOW_WAITING_COMMON = "msg_show_waiting_common",
	MSG_SHOW_WAITING_WITH_DELAY = "msg_show_waiting_with_delay",
	
	--消除等待界面
	MSG_CANCEL_WAITING = "msg_cancal_waiting",
	MSG_CANCEL_WAITING_COMMON = "msg_cancel_waiting_common",

	 
    MSG_VIP_CHANGE_RSP = "msg_vip_change_rsp",
    MSG_CONVERT_REWARD_RSP = "msg_convert_reward_rsp",

     --商城道具消息
    MSG_NEWSHOP_BUY    = "msg_newshop_buy",
    MSG_NEWSHOP_BUY_RESP    = "msg_newshop_buy_resp",

    --修改平台昵称
    MSG_MODIFY_PLATFORM_NICKNAME = "msg_modify_platform_nickname",

    --培养液相关
    MSG_GET_CULTURE_RET = "msg_get_culture_ret",
    MSG_GOTO_CULTUREROOM = "msg_goto_cultureroom",
    MSG_CULTURE_UPDATE = "msg_culture_update",
    MSG_GET_CULTURE_REWARD_RET = "msg_get_culture_reward_ret",
    MSG_START_CULTURE_RET = "msg_start_culture_ret",

    --gacha 扭蛋相关
    MSG_SHOW_GACHA = "msg_show_gacha",
    MSG_DO_GACHA = "msg_do_gacha",
    MSG_DO_GACHA_AGAIN = "msg_do_gacha_again",
    MSG_DO_GACHA_DOUBLE = "msg_do_gacha_double",

    --获得新道具的通知
    MSG_NEW_TOOL_NOTIFY    = "new_tool_notify",
    MSG_ADD_CHARM 		= "msg_add_charm",
    MSG_ADD_FRIEND		= "msg_add_friend",

    --NET FORM MSG
    GET_PLAYER_SYSTEM_DATA = "notify_player_system_data",
    GET_PLAYER_DATA = "notify_player_game_data",
    GET_ITEM_DATA = "notify_item_data",
    GET_GACHA_DATA = "notify_gacha_data",
    GET_SOCAL_DATA = "notify_social_data",
    GET_TASK_DATA = "notify_task_data",
    GET_GET_AWARD_SUCC = "msg_get_award_succ",
    GET_MAIL_DATA = "mails_data",
    COLLECT_MAIL_REWARD = "collectMailReward",
    GET_NEW_MAIL = "get_new_mail",

    --新手引导
    MSG_GUIDE_STEP_RET= "msg_guide_step_ret",

    --PLAYER INFO DATA
    SET_PLAYER_INFO_DATA = "setPlayerInfoData",

    --BUY STAR
    BUY_STAR_SUCCESS = "butStarSuccess",

    --MUSIC
    MSG_SWITCH_BGM = "msg_switch_bgm",

    SIGN_AWARD  = "msg_sign_awrd",
    SIGN_UPDATE = "msg_sign_update",

    --REPEAT LOGIN
    REPEAR_LOGIN = "msg_repeat_login",

	DO_PRAISE = "do_praise",

	MSG_DOWNLOAD_VOICE_SUCCESS = "download_voice_success",
	PLAY_VOICE_END = "play_voice_end",

	SHOW_AD_SUCCESS = "show_ad_return1_success",
	SHOW_AD_FAIL = "show_ad_return2_fail",
	SHOW_AD_CLICK = "show_ad_return3_click",
	SHOW_AD_LOAD_SUCCESS = "show_ad_return4_load_success",
	SHOW_AD_CLOSE = "show_ad_return5_close",
	DO_LOTTERY = "do_lottery",
	SHOW_AD_LOOT_BTN = "show_ad_loot_btn",
	SHOW_AD_LOOk_BTN = "show_ad_look_btn",
	SHOW_AD_ENTER_BTN = "show_ad_enter_btn",
}

BattleMsg = {
	UPDATE_THEME = "update_theme",
	MATCH_DATA = "match_data",
	RANK_NOTIFY = "rank_notify",
	RUN = "run_",
	HAPPY = "happy_",
	FULL = "full_",
	EXIT = "exit_battle",
	OVER = "game_over",
	DEAD = "player_dead",
	SHOW_FPS = "show_fps",
	START_AI = "start_ai",
	STOP_AI = "stop_ai",
	UP_RANK = "up_rank_notify",
	DOWN_RANK = "down_rank_notify",
	UP_STAR = "up_star_notify",
	DOWN_STAR = "down_star_notify",
	NONE_STAR = "none_star_notify",
	USER_COUNT_NOTIFY = "user_count_notify",
	MATCH_PEER_DATA = "match_peer_data",
}