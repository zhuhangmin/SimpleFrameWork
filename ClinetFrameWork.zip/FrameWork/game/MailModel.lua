local EngineModel = require "EngineModel"
local MailModel = class("MailModel", EngineModel)

function MailModel:ctor(data)
	MailModel.super.ctor(self, data)

	self.itemNodes = {}
	self.curIndex = nil
end

function MailModel:onCreate(param)
	MailModel.super.onCreate(self, param)

	if notNumber(param.curIndex) then printStack() return end
	self:setCurIndex(param.curIndex)
end

function MailModel:getItemNodes()
	return self.itemNodes
end

function MailModel:setItemNodes(itemNodes)
	self.itemNodes = itemNodes
end

function MailModel:getCurIndex()
	return self.curIndex
end

function MailModel:setCurIndex(curIndex)
	self.curIndex = curIndex
end

return MailModel

