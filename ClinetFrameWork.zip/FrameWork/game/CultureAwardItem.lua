
local CultureAwardItem = class("CultureAwardItem", function()
	return ccui.Widget:create()
end)

function CultureAwardItem:ctor(info)
	self:setContentSize(720, 100)

	--创建每一个横排条目
	for i = 1, #info do
		local node = addItmeNode(self,info[i].item_id,nil,nil,true)
		node:setPosition((i-1) * 120+60, 50)
		self:setTouchEnabled(false)
	end
end

return CultureAwardItem
