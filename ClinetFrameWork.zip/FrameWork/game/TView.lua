local EngineView = require "EngineView"
local TView = class("TView", EngineView)

local csbFilePath = "res/TView.csb"

function TView:ctor(node)
	TView.super.ctor(self, node)
end

function TView:onCreate(param)
	TView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	if isNil(csbNode) then printStack() return end

	local node = self:getNode()
	if isNil(node) then printStack() return end	
	
	node:addChild(csbNode)

end

return TView





