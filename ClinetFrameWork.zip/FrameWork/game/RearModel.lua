local EngineModel = require "EngineModel"
local RearModel = class("RearModel", EngineModel)

function RearModel:ctor(data)
	RearModel.super.ctor(self, data)
end

return RearModel

