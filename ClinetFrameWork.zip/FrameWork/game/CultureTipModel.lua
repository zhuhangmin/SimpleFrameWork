local EngineModel = require "EngineModel"
local CultureTipModel = class("CultureTipModel", EngineModel)

function CultureTipModel:ctor(data)
	CultureTipModel.super.ctor(self, data)

	self.showAgain = true
end

function CultureTipModel:onCreate(param)
	CultureTipModel.super.onCreate(self, param)
end

function CultureTipModel:setShowAgain(showAgain)
	self.showAgain = showAgain
end

function CultureTipModel:getShowAgain()
	return self.showAgain
end

return CultureTipModel

