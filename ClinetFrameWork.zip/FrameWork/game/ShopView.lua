local EngineView = require "EngineView"
local ShopView = class("ShopView", EngineView)

local csbFilePath = "res/ShopGoods.csb"
SHOPVIEW_CSB_NODE = 1000

function ShopView:ctor(node)
	ShopView.super.ctor(self, node)
end

function ShopView:onCreate(param)
	ShopView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	if isNil(csbNode) then printStack() return end
	
	csbNode:setTag(SHOPVIEW_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return ShopView





