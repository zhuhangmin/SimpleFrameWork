-- EX: 
-- local VoiceManager = require "VoiceManager"
-- local voiceManager = VoiceManager.getInstance()
-- voiceManager:reset()
-- local cb = function(event) print("event cb = " .. event) end
-- voiceManager:setPlayCallback(cb)

-- local speakBtn = self:getChildNode(BTN_RETURN)
-- speakBtn:addTouchEventListener(handler(self, self.speakCB))

-- local playBtn = self:getChildNode(BTN_PLAYER_INFO)
-- playBtn:addTouchEventListener(handler(self, self.playCB))

-- function HomeControl:speakCB(sender, touchEventType)
-- if touchEventType == ccui.TouchEventType.began then
--     voiceManager:startSpeak()
-- end

-- if touchEventType == ccui.TouchEventType.canceled then
--     voiceManager:cancelSpeak()
-- end

-- if touchEventType == ccui.TouchEventType.ended then
-- voiceManager:stopSpeak()
-- end
-- end

-- function HomeControl:playCB(sender, touchEventType)
-- if touchEventType == ccui.TouchEventType.began then
--     voiceManager:startPlay()
-- end
-- end

-- EXIT ROOM : voiceManager:reset()


-- ******* PROCESS *********
-- datastruture ： infoStack， pathStack

-- CLIENT 1 SEND
-- 1 speak to record voice
-- 2 auto upload voice and callback got url
-- 3 upload url to GAME SERVER

-- GAME SERVER send url to CLIENT 2

-- CLIENT 2 RECV
-- 1 recv voice info, store on infoStack
-- 2.1 if there is no info on pathStack , then pop infoStack and auto download
-- 2.2 if there is some voice on pathStack, do nothing (to keep only one voice steam on device)
-- 3 download voice success or fail, then store on pathStack
-- 4 user trigger btn to play voice, pop out pathStack to get path to play
-- 5 play end trigger to pop infoStack and auto download

-- NOTE NEED TO LOCK THE BTN FOR WHILE LIKE 2 SECONDS 

local Stack = require "Stack"
local baseMessageMixin = require "BaseMessageMixin"
local schedulerMixin = require "SchedulerMixin"
local VoiceManager   = class("VoiceManager")
VoiceManager:include(schedulerMixin)
VoiceManager:include(baseMessageMixin)

local SpeakSDK = SDKFunc.speak

VoiceManager.instance = nil

function VoiceManager.getInstance()
    if not VoiceManager.instance then
        VoiceManager.instance = VoiceManager.new()
    end
    return VoiceManager.instance
end


function VoiceManager:ctor()
    print("VoiceManager:ctor")
    self.speakState = SPEAK_STATE.MUTE
    self.playState = PLAY_STATE.MUTE
    self.maxLength = 5                -- 录音上限长度 30s
    self.minLength = 0.5                 -- 录音下限长度 0.5s
    self.tryMax = 3                    -- 上传 下载 尝试次数
    self.uploadTryMap = {}             -- 上传尝试次数记录
    self.downloadTryMap = {}           --  下载尝试次数记录
    self.playCallback = nil            -- 播放回调 PLAY_EVENT
    self.urlStack = Stack.create()      -- 收到的语音URL地址列表 data = {url}
    self.pathStack = Stack.create()     -- 下载的语音文件本地路径
    self:register(GameMsg.MSG_RECEIVE_VOICE, self.recv)

    SpeakSDK:setPlayVoiceCallback(handler(self, self.onVoicePlayHandler))
end

function VoiceManager:onVoicePlayHandler(filePath, event)
        print("VoiceManager  ", string.format("%s  %s", event, filePath))
        if event == PLAY_EVENT.START  then
            -- self:addTip("开始播放", POP_PRIORITY.PREEMPTIVE)
            self:pauseSound()

        elseif event == PLAY_EVENT.STOP then
            -- self:addTip("停止播放", POP_PRIORITY.PREEMPTIVE)
            self:resumeSound()  
            self:dispatch(GameMsg.PLAY_VOICE_END)
            self:conditionDownload()
        else
            print("unknow event")
        end

        local playCallback = self:getPlayCallback()
        if playCallback then
            print("playCallback event = " .. event)
            playCallback(event)
        end
end
--功能 API
--开始录音
function VoiceManager:startSpeak()
    print("VoiceManager:startSpeak")
    local speakState = self:getSpeakState()
    if speakState == SPEAK_STATE.SPEAKING then print("SPEAK_STATE.SPEAKING") return end
    self:setSpeakState(SPEAK_STATE.SPEAKING)

    local maxLength = self:getMaxLength()
    self:startScheduler(maxLength, self.onUpdate)
    self:pauseSound()
    -- self:addTip("开始录音", POP_PRIORITY.PREEMPTIVE)

    SpeakSDK:speak()

end

--停止录音
function VoiceManager:stopSpeak()
    print("VoiceManager:stopSpeak")
    local speakState = self:getSpeakState()
    if speakState == SPEAK_STATE.MUTE then print("SPEAK_STATE.MUTE") return end
    self:setSpeakState(SPEAK_STATE.MUTE)
    
    self:cancelScheduler()
    self:resumeSound()

    local recordInfo = SpeakSDK:speakEnd()
    local check = self:filterVoice(recordInfo)
    if not check then 
        print("VOICE_RECORD_TIME_SHORT")
        -- self:addTip("录音太短", POP_PRIORITY.PREEMPTIVE)
    else
        self:conditionUpload(recordInfo)
        -- self:addTip("录音结束", POP_PRIORITY.PREEMPTIVE)
    end
end

--撤销录音
function VoiceManager:cancelSpeak()
    print("VoiceManager:cancelSpeak")
    local speakState = self:getSpeakState()
    if speakState == SPEAK_STATE.MUTE then print("SPEAK_STATE.MUTE") return end
    self:setSpeakState(SPEAK_STATE.MUTE)

    SpeakSDK:speakCancel()    

    self:cancelScheduler()
    self:resumeSound()
    -- self:addTip("取消录音", POP_PRIORITY.PREEMPTIVE)
end

--开始播放
function VoiceManager:startPlay()
    print("VoiceManager:startPlay")
    local playState = self:getPlayState()
    if playState == PLAY_STATE.SPEAKING then print("PLAY_STATE.SPEAKING") return end
    self:setSpeakState(PLAY_STATE.SPEAKING)

    local pathStack = self:getPathStack()
    local info = pathStack:pop()
    if isNil(info) then print("no info ") return end

    local filePath = info.path
    if isNil(filePath) then print("no filePath ") return end

    print("info")
    dump(info)

    print("filePath = " .. filePath)  
    SpeakSDK:playVoice(filePath)
    -- self:addTip("开始播放", POP_PRIORITY.PREEMPTIVE)
end

--停止播放
function VoiceManager:stopPlay()
    print("VoiceManager:stopPlay")
    local playState = self:getPlayState()
    if playState == PLAY_STATE.MUTE then print("PLAY_STATE.MUTE") return end
    self:setSpeakState(PLAY_STATE.MUTE)
    SpeakSDK:stopPlayVoice()
    -- self:addTip("停止播放", POP_PRIORITY.PREEMPTIVE)
end



--get set
function VoiceManager:getSpeakState()
    return self.speakState
end

function VoiceManager:setSpeakState(speakState)
    self.speakState = speakState
end

function VoiceManager:getPlayState()
    return self.playState
end

function VoiceManager:setPlayState(playState)
    self.playState = playState
end

function VoiceManager:getPathStack()
    return self.pathStack
end

function VoiceManager:setPathStack(pathStack)
    self.pathStack = pathStack
end

function VoiceManager:getUrlStack()
    return self.urlStack
end

function VoiceManager:setUrlStack(urlStack)
    self.urlStack = urlStack
end

function VoiceManager:getMaxLength()
    return self.maxLength
end

function VoiceManager:setMaxLength(maxLength)
    self.maxLength = maxLength
end

function VoiceManager:getMinLength()
    return self.minLength
end

function VoiceManager:setMinLength(minLength)
    self.minLength = minLength
end

function VoiceManager:getPlayCallback()
    return self.playCallback
end

function VoiceManager:setPlayCallback(playCallback)
    self.playCallback = playCallback
end

function VoiceManager:getTryMax()
    return self.tryMax
end

function VoiceManager:setTryMax(tryMax)
    self.tryMax = tryMax
end

-- MUSIC
function VoiceManager:pauseSound()
    self:dispatch(BASE_MSG.PAUSE_SOUND_MUSIC)
end

function VoiceManager:resumeSound()
    self:dispatch(BASE_MSG.RESUME_SOUND_MUSIC)    
end

-- NET FUNC
function VoiceManager:upload(recordInfo)
    print("VoiceManager:upload()")
    print("recordInfo")
    dump(recordInfo)

    local path  = recordInfo.path
    if isNil(path) then print("recordInfo.path is nil") return end   

    local uploadCallBack = function (event, uploadInfo)
        print("VoiceManager:uploadCallBack")
        print("event")
        dump(event)
        print("uploadInfo")
        dump(uploadInfo)
        if event == UPLOAD_EVENT.SUCCESS then
            -- self:sendVoice(uploadInfo.url, recordInfo.duration)
            if isNil(uploadInfo) then printStack() return end
            if isNil(uploadInfo.url) then printStack() return end

                local params = {url = uploadInfo.url,time =recordInfo.duration} 
                -- self:submitFormWait("uploadVoiceInfo", params)
                NetFunc.netBattle:sendVoice(params)
                -- self:addTip("发送成功", POP_PRIORITY.PREEMPTIVE)

        elseif event == UPLOAD_EVENT.PROGRESS then
                print("发送中")

        else 
                print("msg = " .. tostring(event.msg))
                -- self:addTip("发送失败", POP_PRIORITY.PREEMPTIVE)

                self:conditionUpload(recordInfo)
        end
    end

    SpeakSDK:uploadVoice(path, uploadCallBack)
    -- self:addTip("开始发送...", POP_PRIORITY.PREEMPTIVE)
end

function VoiceManager:conditionUpload(recordInfo)
    local path  = recordInfo.path
    if isNil(path) then print("recordInfo.path is nil") return end   

    if isNil(self.uploadTryMap[path]) then  
        self.uploadTryMap[path] = 1
    else 
        self.uploadTryMap[path] = self.uploadTryMap[path] + 1
    end
    dump(self.uploadTryMap[path])

    if self.uploadTryMap[path] > self:getTryMax() then 
        print("reach the max try times") 
        return
    end
    
    self:upload(recordInfo)
end

function VoiceManager:download(url,info_data)
    print("VoiceManager:download() url = " .. tostring(url)..";"..tostring(userid))

    local downloadCallBack = function(event, info)
        print("VoiceManager:downloadCallBack")
        print("event = " .. tostring(event))
        dump(event)
        print("info = " .. tostring(info))
        dump(info)
        if event == DOWNLOAD_EVENT.SUCCESS then
            print("下载成功")
            if isNil(info) then printStack() return end
            if isNil(info.path) then printStack() return end

            local pathStack = self:getPathStack()
            pathStack:push(info)-- info.path

            -- self:addTip("下载成功", POP_PRIORITY.PREEMPTIVE)

            local name = GameMsg.MSG_DOWNLOAD_VOICE_SUCCESS 
            local event = {}
            event.data = info_data
            self:dispatch(name,event)

        elseif event == DOWNLOAD_EVENT.PROGRESS then

            print("下载中")

        elseif event == DOWNLOAD_EVENT.ERROR then
            print("下载失败")
            -- self:addTip("下载失败", POP_PRIORITY.PREEMPTIVE)
        else
            print("unknow download result")
        end
    end


    SpeakSDK:downloadVoice(url, downloadCallBack)
    -- self:addTip("开始下载...", POP_PRIORITY.PREEMPTIVE)
end

function VoiceManager:conditionDownload()
    print("VoiceManager:conditionDownload")

    local pathStack = self:getPathStack()
    if pathStack:getLen() ~= 0 then print("pathStack:getLen()") return end
   
    local urlStack = self:getUrlStack()
    local info = urlStack:pop()
    if isNil(info) then print("info nil") return  end

    local url = info.url
    if isNil(url) then print("url nil") return end
            
    self:download(url,info)
end


-- MESSAGE
function VoiceManager:recv(event)
    print("VoiceManager:recv()")
    if isNil(event) then printStack() return end
    if isNil(event.name) then printStack() return end
    if isNil(event.data) then printStack() return end
    dump(event)

    local data = event.data
    if event.name == GameMsg.MSG_RECEIVE_VOICE then
        local urlStack = self:getUrlStack()
        if GameData.voiceFilter[data.userid] == true then print("player "..tostring(data.userid).." is mute") return end
        urlStack:push(data)        
        self:conditionDownload()
    end
end

-- HELPER FUNC
function VoiceManager:reset()
    print("VoiceManager:reset()")
    self:setSpeakState(SPEAK_STATE.MUTE)
    self:setPlayState(PLAY_STATE.MUTE)
    self:setPlayCallback(nil)
    self:getUrlStack():clean()
    self:getPathStack():clean()
    self:stopPlay()
    self:cancelSpeak()
    self:resumeSound()
    self:cancelScheduler()
    self.uploadTryMap = {}             
    self.downloadTryMap = {}           
end

function VoiceManager:onUpdate(dt)
    print("VoiceManager:onUpdate() CANCEL Scheduler")
    self:stopSpeak()
    self:cancelScheduler()
end

function VoiceManager:filterVoice(recordInfo)
    if isNil(recordInfo) then print("no recordInfo") return false end
    if isNil(recordInfo.duration) then print("no recordInfo.duration") return false end
    if recordInfo.duration <= self:getMinLength() then return false end
    return true
end

return VoiceManager


-- test case
    -- manager:startSpeak()
    -- manager:stopSpeak()
    -- manager:cancelSpeak()
    -- manager:startPlay()
    -- manager:stopPlay()
    -- manager:playVoiceCallback("test/path", PLAY_EVENT.START)
    -- manager:playVoiceCallback("test/path", PLAY_EVENT.STOP)
    -- manager:pauseSound()
    -- manager:resumeSound()
    -- manager:upload({path = "path"})
    -- manager:uploadCallBack(UPLOAD_EVENT.SUCCESS, {url = "http://testurl1.com"})
    -- manager:uploadCallBack(UPLOAD_EVENT.PROCESS, {url = "http://testurl2.com"})
    -- manager:uploadCallBack(UPLOAD_EVENT.ERROR, {url = "http://testurl3.com"})
    -- manager:download("TEST URL")
    -- manager:downloadCallBack(DOWNLOAD_EVENT.SUCCESS, {url = "http://download.com"})
    -- manager:downloadCallBack(DOWNLOAD_EVENT.PROGRESS, {url = "http://download.com"})
    -- manager:downloadCallBack(DOWNLOAD_EVENT.ERROR, {url = "http://download.com"})
    -- manager:recv({name = GameMsg.MSG_RECEIVE_VOICE, data = {url = "http://testurl3.com"}})
    -- manager:conditionDownload()
    -- manager:reset()
