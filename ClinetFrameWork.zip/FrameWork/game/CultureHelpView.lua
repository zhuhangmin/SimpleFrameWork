local EngineView = require "EngineView"
local CultureHelpView = class("CultureHelpView", EngineView)

local csbFilePath = "res/CultureHelp.csb"
CULTUREHELP_CSB_NODE = 1000

function CultureHelpView:ctor(node)
	CultureHelpView.super.ctor(self, node)
end

function CultureHelpView:onCreate(param)
	CultureHelpView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	csbNode:setTag(CULTUREHELP_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return CultureHelpView





