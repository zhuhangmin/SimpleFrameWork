local EngineView = require "EngineView"
local QAView = class("QAView", EngineView)

function QAView:ctor(node)
	QAView.super.ctor(self, node)
end

function QAView:onCreate(param)
	QAView.super.onCreate(self, param)
	local csbNode = cc.CSLoader:createNode("res/Help.csb")
	if isNil(csbNode) then printStack() return end
	self:getNode():addChild(csbNode)
	csbNode:setName("csbNode")
end


return QAView;