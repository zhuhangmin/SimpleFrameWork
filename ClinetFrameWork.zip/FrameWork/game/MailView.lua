local EngineView = require "EngineView"
local MailView = class("MailView", EngineView)

local csbFilePath = "res/Mail.csb"
MAIL_CSB_NODE = 1000

function MailView:ctor(node)
	MailView.super.ctor(self, node)
end

function MailView:onCreate(param)
	MailView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	if isNil(csbNode) then printStack() return end
	
	csbNode:setTag(MAIL_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return MailView





