local EngineView = require "EngineView"
local BattleView = class("BattleView", EngineView)
local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()

local csbFilePath = "res/Battle.csb"

local RankItemPos = {
	[1] = cc.p(109, 353),
	[2] = cc.p(109, 320),
	[3] = cc.p(109, 287),
	[4] = cc.p(109, 254),
	[5] = cc.p(109, 221),
	[6] = cc.p(109, 189),
	[7] = cc.p(109, 156),
	[8] = cc.p(109, 124),
	[9] = cc.p(109, 91),
	[10] = cc.p(109, 59),
	[11] = cc.p(109, 20),
}

local battleRankItem = require("battle.battleRankItem")

function BattleView:ctor(node)
	BattleView.super.ctor(self, node)
end


function BattleView:onCreate( param )
	BattleView.super.onCreate(self, param)

   
	self:initFieldView()
	self:initCameraView()
	self:initTouchLayer()
	self:initInfoView()

end

function BattleView:initCameraView( ... )
	local data = GameData.matchData.roomInfo
	self.cameraLayer = require("battle.CameraLayer"):create(data.x, data.y)
	self:getNode():addChild(self.cameraLayer)

	self.cameraLayer:setName("CameraLayer")
end

function BattleView:initTouchLayer( ... )
	self.touchLayer = require("battle.TouchLayer"):create()
	self.touchLayer:setName("touch")
	self:getNode():addChild(self.touchLayer)

	self.touchLayer:setName("TouchLayer")
end


function BattleView:initFieldView( ... )
	-- local roomCfg = cfg:getConfigRecord("room",GameData.roomType)
	-- local width = roomCfg.battlefield_wide + roomCfg.battlefield_outside_wide * 2
	-- local height = roomCfg.battlefield_high + roomCfg.battlefield_outside_high * 2
	-- local color = cc.c4b(0, 0, 0, 0)
	-- self.fieldLayer = cc.LayerColor:create(color, width, height)
	-- self.fieldLayer:setAnchorPoint(cc.p(0, 0))

	-- self.scale = 1 --fieldLayer size

	-- self.themeLayer = cc.LayerColor:create(color, width, height)
	-- self.themeLayer:setAnchorPoint(cc.p(0, 0))
	-- self.themeLayer:setPosition(0, 0)
	-- self.fieldLayer:addChild(self.themeLayer)
	-- self.themeLayer:setCameraMask(2)
	-- self.foodLayer = cc.LayerColor:create(cc.c4b(0, 0, 0, 0), roomCfg.battlefield_wide, roomCfg.battlefield_high)
	-- self.foodLayer:setPosition(roomCfg.battlefield_outside_wide, roomCfg.battlefield_outside_high)
	-- self.fieldLayer:addChild(self.foodLayer)

	-- self.ballLayer = cc.LayerColor:create(cc.c4b(0,0, 0, 0), roomCfg.battlefield_wide, roomCfg.battlefield_high)
	-- self.ballLayer:setPosition(roomCfg.battlefield_outside_wide, roomCfg.battlefield_outside_high)
	-- self.fieldLayer:addChild(self.ballLayer)
	-- self.fieldLayer:setName("field")
	-- self.ballLayer:setName("ball")
	-- self.foodLayer:setName("food")
	-- self:getNode():addChild(self.fieldLayer)

	self.fieldLayer = require("battle.FieldLayer"):create()
	self.fieldLayer:setAnchorPoint(cc.p(0, 0))
	self:getNode():addChild(self.fieldLayer)

	self.fieldLayer:setName("FieldLayer")
end


function BattleView:initInfoView( ... )
	self.shadowImage = cc.Sprite:create()
	self.shadowImage:setPosition(gScreenSize.width / 2, gScreenSize.height / 2)
	self:getNode():addChild(self.shadowImage)

	self.shadowImage:setName("shadowImage")


    local node = cc.CSLoader:createNode(csbFilePath)
	self:getNode():addChild(node)
	
	node:setName("csbNode")

	
 
	self.expPanel = node:getChildByName("Panel_bq")
	self.expPanel:setVisible(false) --暂时不添加表情

	local backBtn = node:getChildByName("Button_return")

	self.settingBtn = node:getChildByName("Button_set")

	self.topBgImage = node:getChildByName("Sprite_top_bg")

	--房间号
	self.roomTestLabel = node:getChildByName("Text_test")
	self.roomTitleLabel = node:getChildByName("Text_room")
	self.roomLabel = node:getChildByName("Text_room_number")

	--重量
	self.weightLabel = node:getChildByName("Text_weight")
	self.weightLabel:setString("------")

	--网络状态(网络模式才会显示)
	self.netStateImage = node:getChildByName("Sprite_wifi")
	-- self.netStateImage:setVisible(false)

	--战斗时间
	self.timeLabel = node:getChildByName("Text_time")
	self.timeLabel:setString("--:--")

	self.jetBtn = node:getChildByName("Button_skill_2")
	self.jetBtnX = self.jetBtn:getPositionX()

	self.divideBtn = node:getChildByName("Button_skill_1")
	self.divideBtnX = self.divideBtn:getPositionX()

	self:initRankPanel(node)


	--debug state info
	-- local name = "heheheehjjjjjjjjjjjjjjjjjjjjjjjjjjjj"
	-- local nameLabel = cc.Label:createWithTTF(name, "res/font/font1.ttf", 30)
	-- nameLabel:setAnchorPoint(cc.p(0.5, 0.5))
	-- nameLabel:setPosition(100, 100)
	-- nameLabel:setTextColor(cc.c3b(255, 255, 255))
	-- self:getNode():addChild(self.nameLabel)
	-- nameLabel:setLocalZorder(10000)

	-- local name = "heheheehjjjjjjjjjjjjjjjjjjjjjjjjjjjj"
	-- local nameLabel = cc.Label:createWithTTF(name, "res/font/font1.ttf", 30)
	-- nameLabel:setAnchorPoint(cc.p(0.5, 0.5))
	-- nameLabel:setPosition(500, 500)
	-- nameLabel:setTextColor(cc.c3b(255, 255, 255))
	-- self:getNode():addChild(self.nameLabel)
	-- nameLabel:setLocalZorder(10000)

	-- local name = "heheheehjjjjjjjjjjjjjjjjjjjjjjjjjjjj"
	-- local nameLabel = cc.Label:createWithTTF(name, "res/font/font1.ttf", 30)
	-- nameLabel:setAnchorPoint(cc.p(0.5, 0.5))
	-- nameLabel:setPosition(600, 600)
	-- nameLabel:setTextColor(cc.c3b(255, 255, 255))
	-- self:getNode():addChild(self.nameLabel)
	-- nameLabel:setLocalZorder(10000)

	-- local name = "heheheehjjjjjjjjjjjjjjjjjjjjjjjjjjjj"
	-- local nameLabel = cc.Label:createWithTTF(name, "res/font/font1.ttf", 30)
	-- nameLabel:setAnchorPoint(cc.p(0.5, 0.5))
	-- nameLabel:setPosition(700, 700)
	-- nameLabel:setTextColor(cc.c3b(255, 255, 255))
	-- self:getNode():addChild(self.nameLabel)
	-- nameLabel:setLocalZorder(10000)

	-- local name = "heheheehjjjjjjjjjjjjjjjjjjjjjjjjjjjj"
	-- local nameLabel = cc.Label:createWithTTF(name, "res/font/font1.ttf", 30)
	-- nameLabel:setAnchorPoint(cc.p(0.5, 0.5))
	-- nameLabel:setPosition(800, 800)
	-- nameLabel:setTextColor(cc.c3b(255, 255, 255))
	-- self:getNode():addChild(self.nameLabel)
	-- nameLabel:setLocalZorder(10000)
	-- --debug state info

end

function BattleView:updateHandHabit()
	if GameData.settingInfo.handValue == 1 then
		--左手
		self.jetBtn:setPositionX(gScreenSize.width - self.jetBtnX)
		self.divideBtn:setPositionX(gScreenSize.width - self.divideBtnX)
	elseif GameData.settingInfo.handValue == 2 then
		--右手
		self.jetBtn:setPositionX(self.jetBtnX)
		self.divideBtn:setPositionX(self.divideBtnX)
	end
end


--------------------------------排行榜--------------------------------------------
function BattleView:initRankPanel(node)
	self.rankList = {}
	self.rankBgImage = node:getChildByName("Sprite_rank_bg")
	for i = 1, 11 do
		local isSelf = false
		if i == 11 then
			isSelf = true
		end

		local item = battleRankItem:create(isSelf, i)
		item:setPosition(RankItemPos[i])
		self.rankBgImage:addChild(item)
		self.rankList[i] = item

		item:setName("rankItem"..i)
	end
end

function BattleView:setMyRankName(name)
	if name == nil then return end
	if self.rankList == nil then return end
	if self.rankList[11] == nil then return end
	self.rankList[11]:setNickname(name)
end

function BattleView:setRankAndName(rank,name)
	if rank == nil then return print("rank nil") end
	if name == nil then return end
	if self.rankList == nil then print("rankList nil") return end
	if self.rankList[rank] == nil then print("rankList"..rank.." nil") return end
	self.rankList[rank]:setNickname(name)
end

function BattleView:setMyRank(rank,name)
	if self.rankList == nil then return end
	if self.rankList[11] == nil then return end
	self.rankList[11]:setRank(rank)
	self.rankList[11]:setNickname(name)
end


 
--点击左上角的角色panel
function BattleView:playerPanelEvent(sender, touchEventType)
	print("1231")
	if touchEventType == ccui.TouchEventType.ended then
		SoundManager:playEffect("button.mp3")
		self:sendMsg("playerPanel")
	end
end

--喷射
function BattleView:jetEvent(sender, touchEventType)
	-- print("touchEventType==="..touchEventType)
	if touchEventType == ccui.TouchEventType.began and self.isCanJet then
		self:sendMsg("doJet")
		local action1 = cc.DelayTime:create(0.1)
		local action2 = cc.CallFunc:create(function()
			self:sendMsg("doJet")
		end)
		local action3 = cc.RepeatForever:create(cc.Sequence:create(action1, action2))
		self:runAction(action3)
	elseif touchEventType == ccui.TouchEventType.ended or touchEventType == ccui.TouchEventType.canceled then
		self:stopAllActions()
	end
end

--------------------------------基础信息------------------------------------------
function BattleView:backEvent(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended then
		self:sendMsg("back")
		SoundManager:playEffect("button.mp3")
	end
end

function BattleView:settingEvent(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended then
		self:sendMsg("setting")
		SoundManager:playEffect("button.mp3")
	end
end

function BattleView:onEnter(  )
   
end

return BattleView