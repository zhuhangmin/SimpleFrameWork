
local GachaRuleLayer = class("GachaRuleLayer", function()
	return cc.LayerColor:create(cc.c4b(0, 0, 0, 165))
end)

function GachaRuleLayer:ctor(  )

	self:init( )
	
end

function GachaRuleLayer:init( )
	local layer_bg = ccui.Widget:create()
	layer_bg:setAnchorPoint(cc.p(0, 0))
	layer_bg:setTouchEnabled(true)
	layer_bg:setContentSize(self:getContentSize())
	self:addChild(layer_bg)

	self.rootNode = cc.CSLoader:createNode("res/DrawRule.csb")
	self:addChild(self.rootNode)

	local closeBtn = self.rootNode:getChildByName("Button_close")
	closeBtn:addTouchEventListener(handler(self, self.closePanel))
end

function GachaRuleLayer:closePanel(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended then
		SoundManager:playEffect("button.mp3")
		self:removeFromParent()
	end
end

return GachaRuleLayer
