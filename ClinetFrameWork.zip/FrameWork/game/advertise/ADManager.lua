local ADManager = class("ADManager")
local baseMessageMixin = require "BaseMessageMixin"
local CODE1 = 1 --渠道广告展示成功
local CODE2 = 2 --渠道广告加载失败
local CODE3 = 3 --渠道广告被点击，跳转详情界面
local CODE4 = 4 --广告加载成功
local CODE5 = 5 --用户关闭广告
local AD_SHOW_TYPE2 = 2 --全屏广告

ADManager:include(baseMessageMixin)
ADManager.instance = nil

function ADManager.getInstance( )
    if not ADManager.instance then
        ADManager.instance = ADManager.new()
    end
    return ADManager.instance
end

function ADManager:ctor()
	self.AdPlugin = plugin.AgentManager:getInstance():getAdsPlugin()
end

function ADManager:isAdValid()
	local flag = 0
	if self.AdPlugin and self.AdPlugin.loadChannelAd then
		flag = 1
	end
	print("isAdValid====="..tostring(flag))
	return flag
end

function ADManager:showAd( )
	local function adTestCallback( code, msg )
	    print("ad callback code="..code..", msg="..msg)
	    if code == CODE1 then --渠道广告展示成功
	     	self:dispatch(GameMsg.SHOW_AD_SUCCESS)
	    end
	    
	    if code == CODE2 then --渠道广告加载失败
	    	self:dispatch(GameMsg.SHOW_AD_FAIL)
	    end

     	if code == CODE3 then --渠道广告被点击，跳转详情界面
	    	self:dispatch(GameMsg.SHOW_AD_CLICK)
	    end

	    if code == CODE4 then --广告加载成功
			self:dispatch(GameMsg.SHOW_AD_LOAD_SUCCESS)
	    end

	    if code == CODE5 then --用户关闭广告
	    	self:dispatch(GameMsg.SHOW_AD_CLOSE)
	    end
	end 
	self.AdPlugin:setCallback( adTestCallback )
	self.AdPlugin:loadChannelAd(AD_SHOW_TYPE2, {})
	self.AdPlugin:showChannelAd(AD_SHOW_TYPE2, {})
end


return ADManager
