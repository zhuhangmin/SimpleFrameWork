local EngineView = require "EngineView"
local FirstChargeView = class("FirstChargeView", EngineView)

local csbFilePath = "res/FirstCharge.csb"
FIRSTRECHARGE_CSB_NODE = 1000

function FirstChargeView:ctor(node)
	FirstChargeView.super.ctor(self, node)
end

function FirstChargeView:onCreate(param)
	FirstChargeView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	if isNil(csbNode) then printStack() return end
	
	csbNode:setTag(FIRSTRECHARGE_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return FirstChargeView





