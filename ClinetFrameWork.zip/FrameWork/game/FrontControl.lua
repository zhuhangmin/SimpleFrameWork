local EngineControl = require  "EngineControl"
local FrontControl = class("FrontControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
}

--SYSTEM MSGS
local SYSTEM_MSGS = {
}

function FrontControl:ctor(model, view)
	FrontControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)
end

function FrontControl:recv(event)
	
end

return FrontControl


