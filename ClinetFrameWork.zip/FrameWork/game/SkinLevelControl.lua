local EngineControl = require  "EngineControl"
local SkinLevelControl = class("SkinLevelControl", EngineControl)
local ConfigManager = require "ConfigManager"

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
    GameMsg.MSG_SKIN_MERGE_RET,
    GameMsg.MSG_SKIN_CHANGE_RET
}

--SYSTEM MSGS
local BTN_RETURN = "Button_close"
local BTN_SYN = "Button_syn"
local BTN_USE = "Button_use"
local BTN_GET1 = "Button_get_1"
local BTN_GET2 = "Button_get_2"


local SYSTEM_MSGS = {
	BTN_RETURN,
    BTN_SYN = "Button_syn",
    BTN_USE = "Button_use",
    BTN_GET1 = "Button_get_1",
    BTN_GET2 = "Button_get_2",
}


function SkinLevelControl:ctor(model, view)
	SkinLevelControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function SkinLevelControl:onCreate(param)
	SkinLevelControl.super.onCreate(self, param)
	if isNil(param) then printStack() end


	self:setinfo()

end

function SkinLevelControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:detachFromParent()
	end

end

function SkinLevelControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

    if name == GameMsg.MSG_SKIN_MERGE_RET then
        self:setinfo()
        return
    end

    if name == GameMsg.MSG_SKIN_CHANGE_RET then
        self:setinfo()
        return
    end
end

function SkinLevelControl:setinfo()
    local itemConfig = self:getTable("item")
    if isNil(itemConfig) then printStack() return end

    local skinIndex = self:getModel():getLeftskinindex()
    if isNil(skinIndex) then printStack() return end

    self.skinnodelist = {}

    local skinpanel_1 = self:getChildNode("Panel_skin_1")
    local skinpanel_4 = self:getChildNode("Panel_skin_4")

	if isNewRole(skinIndex) then
        skinpanel_1:setVisible(false)
        skinpanel_4:setVisible(true)
        for i = 1,4 do
            self.skinnodelist[i] = skinpanel_4:getChildByName("FileNode_"..i)
            self:shownode(i)
        end 
    else
        skinpanel_1:setVisible(true)
        skinpanel_4:setVisible(false)
        self.skinnodelist[1] = skinpanel_1:getChildByName("FileNode_6")
        self:shownode(1,true)
    end 
end

function SkinLevelControl:shownode(index,show1)
    local itemConfig = self:getTable("item")
    if isNil(itemConfig) then printStack() return end

    local synthesisConfig = self:getTable("synthesis")
    if isNil(synthesisConfig) then printStack() return end

    local count = nil
    local count2 = nil
    local count3 = nil

    local skinindex = self:getModel():getLeftskinindex()
    local skindata  = self:getModel():getLeftskindata()
    local skinInfo = getUserSkinInfo()
    for k,v in pairs(skinInfo) do
        if v.id == skinindex then
            skindata = v
        end
    end

    --设置等级跟品质
    local tempuseing = nil
    if  show1 then--做角色跟普通皮肤的区别对待
        self.skinnodelist[index]:getChildByName("Panel_quality"):setVisible(true)
        self.skinnodelist[index]:getChildByName("Panel_star"):setVisible(false)
        if itemConfig[skinindex].quality then
            local node = self.skinnodelist[index]:getChildByName("Panel_quality"):getChildByName("Sprite_level")
            local path = "jsjm/pf_txt"..itemConfig[skinindex].quality..".png"
            setLocalSpriteFrame(node,path)
        end 

        if skinindex == PlayerDataBasic.cur_skin then
            tempuseing = true
        end
        if tempuseing--[[self.skinindex == skinindex]] then--是否是当前点击的皮肤
            self.skinnodelist[index]:getChildByName("Panel_skin_item"):getChildByName("Image_frame_light"):setVisible(true)
        else
            self.skinnodelist[index]:getChildByName("Panel_skin_item"):getChildByName("Image_frame_light"):setVisible(false)
        end  
        self:getChildNode("Button_close"):setPositionX(933)
        self:getChildNode("Panel_bg"):setScaleX(0.73)
    else
        skindata , skinindex  = getSkinInfoForLevel(index,skinindex)
        --判断使用的角色是不是同一角色begin
        if skinindex == PlayerDataBasic.cur_skin then
            tempuseing = true
        end

        --判断使用的角色是不是同一角色end
        if tempuseing then
            self.skinnodelist[index]:getChildByName("Panel_skin_item"):getChildByName("Image_frame_light"):setVisible(true)
        else
            self.skinnodelist[index]:getChildByName("Panel_skin_item"):getChildByName("Image_frame_light"):setVisible(false)
        end  
        self:getChildNode("Button_close"):setPositionX(1083)
        self:getChildNode("Panel_bg"):setScaleX(1)
    end  

    --设置皮肤名称跟icon
    local rootnodelevel = self.skinnodelist[index]:getChildByName("Panel_skin_item")
    rootnodelevel:getChildByName("Text_skin_name"):setString(itemConfig[skinindex].name)
    setImgIconById(rootnodelevel:getChildByName("Image_skin"), skinindex )
    rootnodelevel:getChildByName("Image_skin"):ignoreContentAdaptWithSize(true)
    rootnodelevel:getChildByName("Image_skin"):setScale(0.7)

    --设置按钮的状态及需要打碎片道具
    self.btnList = {}
    self.btnstate =  LEFT_BTN.FINISH
    self.needstate = LEFT_NEED.FINISH
    self.btnList[LEFT_BTN.USE] = self.skinnodelist[index]:getChildByName("Panel_skin_item"):getChildByName("Button_use")
    self.btnList[LEFT_BTN.SYN] = self.skinnodelist[index]:getChildByName("Panel_skin_item"):getChildByName("Button_syn")
    self.btnList[LEFT_BTN.FINISH] = self.skinnodelist[index]:getChildByName("Panel_skin_item"):getChildByName("Sprite_using")

    self.needList = {}
    self.needList[LEFT_NEED.PIECE] = self.skinnodelist[index]:getChildByName("Panel_skin_item"):getChildByName("Panel_btn_need"):getChildByName("Panel_piece")
    self.needList[LEFT_NEED.PROP] = self.skinnodelist[index]:getChildByName("Panel_skin_item"):getChildByName("Panel_btn_need"):getChildByName("Panel_prop")
    self.needList[LEFT_NEED.FINISH] = self.skinnodelist[index]:getChildByName("Panel_skin_item"):getChildByName("Panel_btn_need"):getChildByName("Sprite_using")
    self.needList[LEFT_NEED.STAR] = self.skinnodelist[index]:getChildByName("Panel_skin_item"):getChildByName("Panel_btn_need"):getChildByName("Panel_star")

    local starID = ConfigManager.getInstance():getConfigField("global",1,"STAR_ITEM_ID")
    if isNil(starID) then printStack() return end
    
    local level = 1
    local giftnum = 0
    local totalNum = 0
    local giftid = 0
    local synthesisInfo = {}
    local piecenum = 0
    local costid = 0
    local costnum = 0
    if itemConfig[skinindex].b_synthesis == 1 then
        synthesisInfo = synthesisConfig[itemConfig[skinindex].compound]
        if isNil(synthesisInfo) then printStack() return end
	    level = getskinlevel(synthesisInfo.item1)
	    giftnum = synthesisInfo.num2
	    totalNum = synthesisInfo.num1
	    giftid = synthesisInfo.item2
        piecenum = getItemCountById(synthesisInfo.item1)
        costid = synthesisInfo.item3
        costnum = synthesisInfo.num3
    end
    local itemBagCount = giftid~=0 and getItemCountById(giftid) or 0
    local itemBagCount2 = costid~=0 and getItemCountById(costid) or 0

    if skindata.count and skindata.count == 0 then--根据角色信息获取按钮的状态跟需要的物品
        self.needstate = LEFT_NEED.FINISH
        if skindata.id == PlayerDataBasic.cur_skin then
            self.btnstate =  LEFT_BTN.FINISH
        else
            self.btnstate = LEFT_BTN.USE
        end 
    elseif piecenum >= totalNum then
        self.needstate = LEFT_NEED.PIECE
        count = piecenum
        if giftnum == 0 then
            self.btnstate = LEFT_BTN.SYN
        else
            self.needstate = LEFT_NEED.PIECE_AND_PROP
            count2 = itemBagCount
            if itemBagCount >= giftnum then
                if costnum == 0 then
                    self.btnstate = LEFT_BTN.SYN
                else
                    self.needstate = LEFT_NEED.PIECE_AND_PROP_AND_STAR
                    count3 = itemBagCount2
                    if itemBagCount2>=costnum then
                        self.btnstate = LEFT_BTN.SYN
                    else
                        self.btnstate = LEFT_BTN.CHECK
                    end
                end
            else
                self.btnstate = LEFT_BTN.CHECK
            end  
        end 
    else
        count = piecenum
        self.btnstate = LEFT_BTN.CHECK
        self.needstate = LEFT_NEED.PIECE
        if giftnum ~= 0 then
            self.needstate = LEFT_NEED.PIECE_AND_PROP
            count2 = itemBagCount 
        end 
        if costnum ~= 0 then
            self.needstate = LEFT_NEED.PIECE_AND_PROP_AND_STAR
            count3 = itemBagCount2 
        end 
    end 

    for i,v in pairs(LEFT_NEED) do--根据需要什么的状态隐藏跟显示
        if v == self.needstate then 
            if self.needList[v] then
                self.needList[v]:setVisible(true)
            end 
        else
            if self.needList[v] then
                self.needList[v]:setVisible(false)
            end 
        end 

        if self.needstate == LEFT_NEED.PIECE_AND_PROP then
            self.needList[LEFT_NEED.FINISH]:setVisible(false)
            self.needList[LEFT_NEED.PIECE]:setVisible(true)
            self.needList[LEFT_NEED.PROP]:setVisible(true)
            self.needList[LEFT_NEED.STAR]:setVisible(false)
        elseif self.needstate == LEFT_NEED.PIECE_AND_PROP_AND_STAR then
            self.needList[LEFT_NEED.FINISH]:setVisible(false)
            self.needList[LEFT_NEED.PIECE]:setVisible(true)
            self.needList[LEFT_NEED.PROP]:setVisible(true)
            self.needList[LEFT_NEED.STAR]:setVisible(true)
        end 
    end 

    for i,v in pairs(LEFT_BTN) do--根据按钮的状态隐藏跟显示
        if v == self.btnstate then 
            if self.btnList[v] then
                self.btnList[v]:setVisible(true)
                local btnstate = self.btnstate
                local skinindex2 = skinindex
                local function onBtnUseSkin()
                    self:onBtnUseSkin(btnstate,skinindex2) 
                end
                self.btnList[v]:addClickEventListener(onBtnUseSkin)
            end 
        else
            if self.btnList[v] then
                self.btnList[v]:setVisible(false)
            end 
        end 
    end 

    --根据按钮的状态隐藏跟显示相关的图标begin
    rootnodelevel:getChildByName("Button_get_1"):setVisible(false)
    rootnodelevel:getChildByName("Button_get_2"):setVisible(false)
    if self.btnstate == LEFT_BTN.CHECK then
        -- rootnodelevel:getChildByName("Button_get_1"):setVisible(true)
        -- rootnodelevel:getChildByName("Button_get_2"):setVisible(true)
        rootnodelevel:getChildByName("Sprite_tag_syn"):setVisible(false)
        rootnodelevel:getChildByName("Sprite_skin_using1"):setVisible(false)
        rootnodelevel:getChildByName("Sprite_tag_using2"):setVisible(false)

        rootnodelevel:getChildByName("Button_syn"):setVisible(true)
        setButtonEnable(rootnodelevel:getChildByName("Button_syn"),false)
    end

    if self.btnstate == LEFT_BTN.FINISH then
        rootnodelevel:getChildByName("Sprite_tag_syn"):setVisible(false)
        rootnodelevel:getChildByName("Sprite_skin_using1"):setVisible(true)
        rootnodelevel:getChildByName("Sprite_tag_using2"):setVisible(true)
    end

    if self.btnstate == LEFT_BTN.SYN then
        rootnodelevel:getChildByName("Sprite_tag_syn"):setVisible(true)
        rootnodelevel:getChildByName("Sprite_skin_using1"):setVisible(false)
        rootnodelevel:getChildByName("Sprite_tag_using2"):setVisible(false)
        rootnodelevel:getChildByName("Sprite_skin_bg"):setSpriteFrame("jsjm/pf_bg_khc.png")
    end

    if self.btnstate == LEFT_BTN.USE then
        rootnodelevel:getChildByName("Sprite_tag_syn"):setVisible(false)
        rootnodelevel:getChildByName("Sprite_skin_using1"):setVisible(false)
        rootnodelevel:getChildByName("Sprite_tag_using2"):setVisible(false)
        rootnodelevel:getChildByName("Sprite_skin_bg"):setSpriteFrame("jsjm/pf_bg_zc.png")
    end
    --根据按钮的状态隐藏跟显示相关的图标end

    if not show1 then
        self.skinnodelist[index]:getChildByName("Panel_quality"):setVisible(false)
        self.skinnodelist[index]:getChildByName("Panel_star"):setVisible(true)
        for i = 1,4 do
            local Sprite_level_bg = self.skinnodelist[index]:getChildByName("Panel_star"):getChildByName("Sprite_level"..i.."_bg")
            local Sprite_level = self.skinnodelist[index]:getChildByName("Panel_star"):getChildByName("Sprite_level"..i)

            if i <= getskinlevel(skinindex) then
                Sprite_level_bg:setVisible(false)
                Sprite_level:setVisible(true) 
            else
                Sprite_level_bg:setVisible(true)
                Sprite_level:setVisible(false)
            end
            if self.btnstate == LEFT_BTN.SYN then
                setLocalSpriteFrame(Sprite_level_bg,"jsjm/pf_bg_khc_xing.png")
            else
                setLocalSpriteFrame(Sprite_level_bg,"jsjm/pf_bg_zc_xing.png")
            end 
        end
    end 

    if index >= 2 then
        local skindata1 , _  = getSkinInfoForLevel(index-1,skinindex)--获取前一等级的数据
        if not skindata1.count or skindata1.count ~= 0 then--前一等级没有合完成，后面等级的按钮不可见
            -- rootnodelevel:getChildByName("Button_get_1"):setVisible(false)
            -- rootnodelevel:getChildByName("Button_get_2"):setVisible(false)
            rootnodelevel:getChildByName("Button_syn"):setVisible(false)
            setButtonEnable(rootnodelevel:getChildByName("Button_syn"),true)
            --self.needList[LEFT_NEED.PIECE]:setVisible(false)
            --self.needList[LEFT_NEED.PROP]:setVisible(false)
            if self.btnList[self.btnstate] then
                self.btnList[self.btnstate]:setVisible(false)
            end 
        end 
    end 

     --处理第四阶的特殊情况
    local levelicon = self.skinnodelist[index]:getChildByName("Panel_skin_level4")
    if index == 4 then 
        if skindata and skindata.count == 0  then
            levelicon:setVisible(false)
            rootnodelevel:getChildByName("Image_skin"):setVisible(true)
        else
            levelicon:setVisible(true)
            rootnodelevel:getChildByName("Image_skin"):setVisible(false)
        end  
    else
        levelicon:setVisible(false)
    end  
    
    for k = 1,2 do
        local function onGetSkin()
            self:onGetSkin(k) 
        end
        if rootnodelevel:getChildByName("Button_get_"..k):isVisible() then
            rootnodelevel:getChildByName("Button_get_"..k):addClickEventListener(onGetSkin)
        end 
    end 

    --设置碎片跟道具的icon
    local synthesisInfo = synthesisConfig[itemConfig[skinindex].compound]
    if synthesisInfo then
        local node = self.needList[LEFT_NEED.PIECE]:getChildByName("Node_piece")
        addItmeNode(node,synthesisInfo.item1)
    end
    if giftid ~= 0 then
        local node = self.needList[LEFT_NEED.PROP]:getChildByName("Node_prop")
        addItmeNode(node,giftid)
    end 
    if costid ~= 0 then
        local node = self.needList[LEFT_NEED.STAR]:getChildByName("Node_star")
        addItmeNode(node,costid)
    end 
    --显示进度相关
    if count then
        local str = tostring(count).."/"..tostring(totalNum)
        local panel_syn = self.needList[LEFT_NEED.PIECE]:getChildByName("Panel_syn")

        panel_syn:getChildByName("Text_progress"):setString(str)
        panel_syn:getChildByName("LoadingBar_1"):setPercent(count/totalNum*100)
        if count2 then
            local str2 = tostring(count2).."/"..tostring(giftnum)
            local panel_prop = self.needList[LEFT_NEED.PROP]:getChildByName("Panel_syn")

            panel_prop:getChildByName("Text_progress"):setString(str2)
            panel_prop:getChildByName("LoadingBar_1"):setPercent(count2/giftnum*100)
            if count3 then
                local str3 = tostring(count3).."/"..tostring(costnum)
                local panel_prop = self.needList[LEFT_NEED.STAR]:getChildByName("Panel_syn")

                panel_prop:getChildByName("Text_progress"):setString(str3)
                panel_prop:getChildByName("LoadingBar_1"):setPercent(count3/costnum*100)
            else
                local panel = self.needList[LEFT_NEED.PIECE]
                panel:setPositionY(35)
                local panel2 = self.needList[LEFT_NEED.PROP]
                panel2:setPositionY(-25)
            end
        else
            local panel = self.needList[LEFT_NEED.PIECE]
            panel:setPositionY(5)
        end   
    end 
end 

function SkinLevelControl:onBtnUseSkin(state,index)
    if not state or not index then return end 
    if state == LEFT_BTN.SYN then
        local future_item_id = index
        if notNumber(future_item_id) then printStack() return end
        self:submitFormWait("convertItem", {future_item_id = future_item_id})
        return
    elseif state == LEFT_BTN.USE then
        local item_id = index
        if notNumber(item_id) then printStack() return end
        self:submitFormWait("applyItem", {item_id = item_id})
        return
    end 
end 

function SkinLevelControl:onGetSkin(index)
    if index == 1 then
        local data = {}
        data.name = "game.Shop"
        self:send(BASE_MSG.PUSH, data)
    elseif index == 2 then
        local data = {}
        data.name = "game.Gacha"
        self:send(BASE_MSG.PUSH, data)
    end
end 

return SkinLevelControl


