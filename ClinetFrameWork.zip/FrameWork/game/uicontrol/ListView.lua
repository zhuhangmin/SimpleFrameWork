local EngineView = require "EngineView"
local ListView = class("ListView", EngineView)

function ListView:ctor(node)
	ListView.super.ctor(self, node)
end

function ListView:onCreate(param)
	ListView.super.onCreate(self, param)
	if isNil(param.ccListView) then param.ccListView = ccui.ListView:create() end
	local ccListView = param.ccListView
	ccListView:setTag(LIST_NODE_TAG)
	self:replaceRootRenderNode(ccListView)
end

function ListView:attach(view)
	if isNil(view) then return printStack() end
	local widget = view:getNode()
	print("type = " .. widget:getDescription())
	local ccListView = self:getNode()
	print(ccListView:getDescription())
	ccListView:pushBackCustomItem(widget) 
end

return ListView





