local EngineView = require "EngineView"
local ListItemView = class("ListItemView", EngineView)

function ListItemView:ctor(node)
	ListItemView.super.ctor(self, node)
end

function ListItemView:onCreate(param)
	ListItemView.super.onCreate(self, param)
	if isNil(param.widget) then param.widget = ccui.Widget:create() end

	print("type = " .. param.widget:getDescription())
	self:replaceRootRenderNode(param.widget)
end

return ListItemView





