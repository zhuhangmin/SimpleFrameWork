local ListView = require "ListView"
local TableView = class("TableView", ListView)

function TableView:ctor(node)
	TableView.super.ctor(self, node)
end

function TableView:onCreate(param)
	TableView.super.onCreate(self, param)	
end


return TableView





