local EngineModel = require "EngineModel"
local ListItemModel = class("ListItemModel", EngineModel)

function ListItemModel:ctor(data)
	ListItemModel.super.ctor(self, data)
	-- self.index = 0
	self.size = 0
end

function ListItemModel:onCreate(param)
	ListItemModel.super.onCreate(self, param)
	-- if isNil(param.index) then printStack() return end
	-- self:setIndex(param.index)
	if isNil(param.size) then printStack() return end
	self:setSize(param.size)
end

-- function ListItemModel:getIndex()
-- 	return self.index
-- end

-- function ListItemModel:setIndex(index)
-- 	self.index = index
-- end

function ListItemModel:getSize()
	return self.size
end

function ListItemModel:setSize(size)
	self.size = size
end

return ListItemModel

