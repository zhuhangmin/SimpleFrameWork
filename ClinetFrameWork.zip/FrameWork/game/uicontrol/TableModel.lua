-- local Queue = require "Queue"
local ListModel = require "ListModel"
local TableModel = class("TableModel", ListModel)

local DEFAULT_LIST_NAME = "game.uicontrol.List"

function TableModel:ctor(data)
	TableModel.super.ctor(self, data)
	self.widthNum = 0
	self.heightNum = 0
	self.clipSize = {} --> table size -> list width
	self.listControlName = ""
	self.parentListDir = ccui.ListViewDirection.vertical
	self.childListDir = ccui.ListViewDirection.horizontal
	-- self.itemSize = {}
	self.curTotalNum = 0
end

function TableModel:onCreate(param)
	TableModel.super.onCreate(self, param)
	if isNil(param.widthNum) then printStack() return end
	self:setWidthNum(param.widthNum)

	if isNil(param.heightNum) then printStack() return end
	self:setHeightNum(param.heightNum)

	if isNil(param.clipSize) then printStack() return end
	self:setClipSize(param.clipSize)

	if isNil(param.listControlName) then param.listControlName = DEFAULT_LIST_NAME end
	self:setListControlName(param.listControlName)

	if isNil(param.parentListDir) then param.parentListDir =  ccui.ListViewDirection.vertical end
	self:setParentListDir(param.parentListDir)

	if isNil(param.childListDir) then param.childListDir = ccui.ListViewDirection.horizontal end
	self:setChildListDir(param.childListDir)

	if isNil(param.itemSize) then printStack() return end
	self:setItemSize(param.itemSize)

end

function TableModel:getWidthNum()
	return self.widthNum
end

function TableModel:setWidthNum(widthNum)
	self.widthNum = widthNum
end

function TableModel:getHeightNum()
	return self.heightNum
end

function TableModel:setHeightNum(heightNum)
	self.heightNum = heightNum
end

function TableModel:getClipSize()
	return self.clipSize
end

function TableModel:setClipSize(clipSize)
	self.clipSize = clipSize
end

function TableModel:getListControlName()
	return self.listControlName
end

function TableModel:setListControlName(listControlName)
	self.listControlName = listControlName
end

function TableModel:getParentListDir()
	return self.parentListDir
end

function TableModel:setParentListDir(parentListDir)
	self.parentListDir = parentListDir
end

function TableModel:getChildListDir()
	return self.childListDir
end

function TableModel:setChildListDir(childListDir)
	self.childListDir = childListDir
end

-- function TableModel:getItemSize()
-- 	return self.itemSize
-- end

-- function TableModel:setItemSize(itemSize)
-- 	self.itemSize = itemSize
-- end

function TableModel:getCurTotalNum()
	return self.curTotalNum
end

function TableModel:setCurTotalNum(curTotalNum)
	self.curTotalNum = curTotalNum
end

-- compound api

-- function TableModel:getItemWidth()
-- 	local size = self:getItemSize()
-- 	local width = size.width
-- 	return width
-- end

-- function TableModel:getItemHeight()
-- 	local size = self:getItemSize()
-- 	local height = size.height
-- 	return height
-- end

function TableModel:getFullNum()
	local widthNum = self:getWidthNum()
	local heightNum = self:getHeightNum()
	local fullNum = widthNum * heightNum
	return fullNum
end

function TableModel:getListWidth()
	local size = self:getClipSize()
	local width = size.width
	return width
end

function TableModel:getListHeight()
	local size = self:getClipSize()
	local height = size.height
	return height
end

return TableModel
