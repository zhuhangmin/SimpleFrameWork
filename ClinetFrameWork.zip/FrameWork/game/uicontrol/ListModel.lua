local EngineModel = require "EngineModel"
local ListModel = class("ListModel", EngineModel)

function ListModel:ctor(data)
	ListModel.super.ctor(self, data)
	self.dir = 0
	self.bounce = false
	self.bg = ""
	self.scale9 = true
	self.size = {}
	self.pos = {}
    self.listViewEvent = {}
	self.scrollViewEvent = {}
	self.dataMode = BRIDGE_MODE
end

function ListModel:onCreate(param)
	ListModel.super.onCreate(self, param)

	if isNil(param.dataMode) then printStack() return end
	self:setDataMode(param.dataMode)
	local dataMode = self:getDataMode()
	
	if dataMode == NATIVE_MODE then
		if param.dir then 
			self:setDir(param.dir)
		end

		if param.bounce then 
			self:setBounce(param.bounce)
		end

		if param.bg then 
			self:setBg(param.bg)
		end

		if param.scale9 then 
			self:setScale9(param.scale9)
		end

		if param.size then 
			self:setSize(param.size)
		end

		if param.pos then 
			self:setPos(param.pos)
		end

		if param.listViewEvent then 
			self:setListViewEvent(param.listViewEvent)
		end

		if param.scrollViewEvent then 
			self:setScrollViewEvent(param.scrollViewEvent)
		end
	end

	
end

function ListModel:getDataMode()
	return self.dataMode
end

function ListModel:setDataMode(val)
	self.dataMode = val
end

function ListModel:getDir()
	return self.dir
end

function ListModel:setDir(val)
	self.dir = val
end

function ListModel:getBounce()
	return self.bounce
end

function ListModel:setBounce(val)
	self.bounce = val
end

function ListModel:getBg()
	return self.bg
end

function ListModel:setBg(val)
	self.bg = val
end

function ListModel:getScale9()
	return self.scale9
end

function ListModel:setScale9(val)
	self.scale9 = val
end

function ListModel:getSize()
	return self.size
end

function ListModel:setSize(val)
	self.size = val
end

function ListModel:getPos()
	return self.pos
end

function ListModel:setPos(val)
	self.pos = val
end

function ListModel:getListViewEvent()
	return self.listViewEvent
end

function ListModel:setListViewEvent(val)
	self.listViewEvent = val
end

function ListModel:getScrollViewEvent()
	return self.scrollViewEvent
end

function ListModel:setScrollViewEvent(val)
	self.scrollViewEvent = val
end


return ListModel

