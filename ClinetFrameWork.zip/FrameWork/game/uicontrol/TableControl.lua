local ListControl = require "ListControl"
local TableControl = class("TableControl", ListControl)

local LUA_MSGS = {
}

local SYSTEM_MSGS = {
}

function TableControl:ctor(model, view)
	TableControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function TableControl:onCreate(param)
	TableControl.super.onCreate(self, param)
	local ccListView = self:getNode()

	local model = self:getModel()

	local parentDir = model:getParentListDir()
	if isNil(parentDir) then printStack() return end
	ccListView:setDirection(parentDir)

	local clipSize = model:getClipSize()
	if isNil(clipSize) then printStack() return end
	ccListView:setContentSize(clipSize)
	

	local childDir = model:getChildListDir()
	if isNil(childDir) then printStack() return end

	local fullNum = model:getFullNum()
	if isNil(fullNum) then printStack() return end

	local listWidth = model:getListWidth()
	if isNil(listWidth) then printStack() return end

	local listHeight = model:getListHeight()
	if isNil(listHeight) then printStack() return end

	local childListNum = model:getHeightNum()
	if isNil(childListNum) then printStack() return end

	local listControlName = model:getListControlName()
	if isNil(listControlName) then printStack() return end

--TODO TEST
	-- self:getNode():setPositionX(440)
	-- self:getNode():setPositionY(440)
--TODO TEST
-- set
	print("fullNum = " .. fullNum)
	print("********* childListNum = " .. childListNum)
	for index = 1, childListNum do 
		print("TableControl attach create list index = " .. index)
		local ccListView = ccui.ListView:create()
		
		
		local size = cc.size(listWidth, listHeight)
		local param = {}
		param.viewParam = {ccListView = ccListView}
		param.controlParam = {
    						  listViewEvent = listViewEvent,
    				   		  scrollViewEvent = scrollViewEvent,
    				   		  size = cc.size(240, 130),
    				   		  pos = cc.p(100, 200),
    				   		  bg = "cocosui/green_edit.png",
    				   		  scale9 = true,
    				   		  dir = childDir
    				   		}


		local alias = tostring(index)
		self:addPanel(listControlName, param, alias)
	end
end

function TableControl:attachItem(control)
	print("TableControl:attachItem(control)")
	if isNil(control) then printStack() return end
	local fd = control:getModel():getFD()
	local view = control:getView()

	local model = self:getModel()
	
	local fullNum = model:getFullNum()
	if isNil(fullNum) then printStack() return end

	local childListNum = model:getHeightNum()
	if isNil(childListNum) then printStack() return end

	local widthNum = model:getWidthNum()
	if isNil(widthNum) then printStack() return end	

	local heightNum = model:getWidthNum()
	if isNil(heightNum) then printStack() return end	

	local curTotalNum = model:getCurTotalNum()
	if isNil(curTotalNum) then printStack() return end	

	print("fullNum = " .. fullNum)
	print("cur totalItemNum = " .. curTotalNum)


-- set

	if curTotalNum >= fullNum then
		print("cannot add more item , enlarge your design width or height num")

	else
		local listIndex = math.ceil((curTotalNum + 1) / widthNum)
		print("listIndex = " .. listIndex)
		local alias = tostring(listIndex)

		local listControlName = model:getListControlName()
		if isNil(listControlName) then printStack() return end



		local childListControl = self:getChildControlByAlias(listControlName, alias)
		if isNil(childListControl) then printStack() return end

		local fd = control:getModel():getFD()
		childListControl:setChild(fd, control)
		childListControl:getView():attach(view)
		control:setParent(childListControl)

		model:setCurTotalNum(curTotalNum + 1)
	end

	print("TableControl attach end")
end

return TableControl




	    -- local listView = ccui.ListView:create()
    	-- local param = {}
    	-- param.controlParam = {
    	-- 			   		  size = cc.size(240, 130),
    	-- 			   		  scale9 = true,
    	-- 			   		}
    	-- local listName = "game.uicontrol.List"
    	-- tableControl:addPanel(listName, param) -- > 

