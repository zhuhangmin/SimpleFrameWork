--EX BRIDGE MODEL
	-- local model = self:getModel()
	-- local shopID = model:getShopID()

	-- local listControl = self:getChildControlByName(LIST_CONTROL_NAME)
 --   	listControl:removeAllItems()
 --   	local name = "game.ShopListItem"
 --   	for i = 1, 4 do
 --   		local param = {}
 --   		local index = i
 --   		local goodIndex = i
 --   		param.modelParam = {index = index, goodIndex = goodIndex, shopID = 1,size = cc.size(250,250)}
 --   		listControl:addPanel(name, param)
 --   	end


local EngineControl = require  "EngineControl"
local ListControl = class("ListControl", EngineControl)

local LUA_MSGS = {
}

local SYSTEM_MSGS = {
}

function ListControl:ctor(model, view)
	ListControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function ListControl:onCreate(param)
	ListControl.super.onCreate(self, param)

	local ccListView = self:getNode()
	local model = self:getModel()
	local dataMode = model:getDataMode()
	if dataMode == NATIVE_MODE then
		print("NATIVE_MODE")
		local dir = model:getDir()
		local bounce = model:getBounce()
		local bg = model:getBg()
		local scale9 = model:getScale9()
		local size = model:getSize()
		local pos = model:getPos()
		local listViewEvent = model:getListViewEvent()
		local scrollViewEvent = model:getScrollViewEvent()

		ccListView:setDirection(dir)
		ccListView:setBounceEnabled(bounce)
		ccListView:setBackGroundImage(bg)
		ccListView:setBackGroundImageScale9Enabled(scale9)
		ccListView:setContentSize(size)
		ccListView:setPosition(pos)
	else
		print("BRIDGE_MODE")
	end

end

function ListControl:removeAllItems()
	local ccListView = self:getNode()
	print(ccListView:getDescription())
	ccListView:removeAllItems()
end

return ListControl


