local EngineControl = require  "EngineControl"
local ListItemControl = class("ListItemControl", EngineControl)

function ListItemControl:ctor(model, view)
	ListItemControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function ListItemControl:onCreate(param)
	ListItemControl.super.onCreate(self, param)
	if isNil(param) then printStack() return end
	
	local model = self:getModel()
	local size = model:getSize()
	self:getNode():setContentSize(size)
	
end


return ListItemControl


