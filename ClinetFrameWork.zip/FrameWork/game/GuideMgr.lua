local BaseGuideMgr = require "BaseGuideMgr"
GuideMgr = class("GuideMgr", BaseGuideMgr)
GuideMgr.instance = nil

local ConfigManager = require "ConfigManager"
local EngineControlManager = require "EngineControlManager"
local GuideClipLayer = require "GuideClipLayer"

local baseMessageMixin = require "BaseMessageMixin"
GuideMgr:include(baseMessageMixin)

--LUA MSGS
local LUA_MSGS = {
    BASE_MSG.ENTER_AFTER,
    BASE_MSG.DESTROY_BEFORE,
    BASE_MSG.GET_BUTTON_INFO,
    GameMsg.MSG_GUIDE_STEP_RET,
}

function GuideMgr.getInstance()
    if not GuideMgr.instance then
        GuideMgr.instance = GuideMgr.new()
    end
    return GuideMgr.instance
end

function GuideMgr:ctor()
    GuideMgr.super.ctor(self)

    self.ctrlStack = {} --打开的ui界面
    self.clip = nil --当前遮罩
    self:registerMsgs()
end

function GuideMgr:registerMsgs()
    for k,msgName in pairs(LUA_MSGS) do
        self:register(msgName, self.recv)
    end
end

function GuideMgr:recv(event)
    if isNil(event) then printStack() return end
    if isNil(event.name) then printStack() return end
    if isNil(event.data) then printStack() return end

    local name = event.name
    local data = event.data

    if name == BASE_MSG.GET_BUTTON_INFO then
        self:checkConditionAndRun(data)
    end

    if name == GameMsg.MSG_GUIDE_STEP_RET then
        self:addGuideQueue()
        self:startGuide()
    end

    if name == BASE_MSG.ENTER_AFTER then
        local engineControlManager = EngineControlManager.getInstance()
        local control = engineControlManager:getControl(data)
        if isNil(control) then printStack() return end

        self:startAfterAddCtrl(control:getModel():getName(),control)
        return
    end

    if name == BASE_MSG.DESTROY_BEFORE then
        local engineControlManager = EngineControlManager.getInstance()
        local control = engineControlManager:getControl(data)
        if isNil(control) then printStack() return end

        self:removeCtrl(control:getModel():getName())
        return
    end
end

function GuideMgr:getGuide()
    local guideConfig = ConfigManager.getInstance():getTable("guide")
    if isNil(guideConfig) then printStack() return end
    traceInfo("PlayerDataCustom.guide_step = ",PlayerDataCustom.guide_step)
    for k,v in pairs(guideConfig) do
        if v.pre_guide == PlayerDataCustom.guide_step then
            return k,v
        end
    end

    return nil
end

function GuideMgr:getClip()
    return self.clip
end

function GuideMgr:setClip(clip)
    self.clip = clip
end

function GuideMgr:getCtrlStack()
    return self.ctrlStack
end

function GuideMgr:setCtrlStack(ctrlStack)
    self.ctrlStack = ctrlStack
end

function GuideMgr:addCtrl(uiname,ctrl)  
    local ctrlStack = self:getCtrlStack()
    table.insert(ctrlStack,{uiname = uiname,ctrl = ctrl})
end  

function GuideMgr:removeCtrl(uiname)
    local ctrlStack = self:getCtrlStack()
    for k,v in pairs(ctrlStack) do
        if v.uiname == uiname then
            table.remove(ctrlStack,k)
            break
        end
    end
end

function GuideMgr:getTopCtrl()  
    local ctrlStack = self:getCtrlStack()
    local len = table.nums(ctrlStack)
    return ctrlStack[len]
end

function GuideMgr:addGuideQueue()
    local _,curGuide = self:getGuide()
    if isNil(curGuide) then return end

    for i=1,5 do
        if curGuide["step"..i]~=0 then
            local stepInfo = ConfigManager.getInstance():getConfigRecord("guideStep",curGuide["step"..i])
            if isNil(stepInfo) then printStack() return end
            self:addStep(stepInfo)
        end
    end
end

function GuideMgr:startAfterAddCtrl(uiname,ctrl)  
    self:addCtrl(uiname,ctrl)
    self:startGuide()
end

function GuideMgr:addClipLayer()
    local guideInfo = self:getInfo()
    if isNil(guideInfo) then printStack() return end

    local topCtrl = self:getTopCtrl()
    if isNil(topCtrl) then printStack() return end

    local parentNode = topCtrl.ctrl:getNode()
    if isNil(parentNode) then printStack() return end

    local node = getNodeHelper(parentNode,guideInfo.widgetName)
    if isNil(node) then printStack() return end

    local block = true
    if guideInfo.guideType == "WEAK" then
        block = false
    end

    local clip = GuideClipLayer:create(node,block)
    if isNil(clip) then printStack() return end

    if guideInfo.message~="" then
        local posX = gScreenSize.width*guideInfo.pencent_posx
        local posY = gScreenSize.height*guideInfo.pencent_posy
        clip:addDialogView(guideInfo.message,posX,posY)
    end

    clip:retain()
    parentNode:addChild(clip)
    self:setClip(clip)
end

function GuideMgr:removeClipLayer()
    local clip = self:getClip()
    if clip then
        clip:removeFromParent()
        clip:release()
        self:setClip(nil)
    end
end

function GuideMgr:startGuide()
    if not self:isGuiding() then
        return
    end

    local guideInfo = self:getInfo()
    if isNil(guideInfo) then printStack() return end

    local topCtrl = self:getTopCtrl()  
    if isNil(topCtrl) then printStack() return end

    if topCtrl.uiname == guideInfo.layerName then
        print("GuideMgr:startGuide():",guideInfo.layerName)
        if self:judgeAllowGuide() then
            self:addClipLayer()
        else
            self:finishGuide()
        end
    end
end

function GuideMgr:judgeAllowGuide()
    local _,curGuide = self:getGuide()--验证登录次数条件
    if isNil(curGuide) then return end
    if curGuide.condition_count~=0 then
        if PlayerDataSystem.login_count > curGuide.condition_count then
            return false
        end
    end
    return true
end

function GuideMgr:finishGuide()
    print("GuideMgr:finishGuide()")
    self:resetData()

    local guideIndex = self:getGuide()
    if isNil(guideIndex) then printStack() return end

    self:submitFormWait("guideStep", {step = guideIndex})
end

function GuideMgr:checkConditionAndRun(name)
    if self:isGuiding() == false then
        return 
    end

    local guideInfo = self:getInfo()
    if isNil(guideInfo) then printStack() return end

    if isNil(name) then printStack() return end
    if name ~= guideInfo.widgetName then
        print("not click this btn")
        return
    end

    self:removeClipLayer()

    self:processGuide()
end

return GuideMgr