local EngineControl = require  "EngineControl"
local CheckControl = class("CheckControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	GameMsg.MSG_LOGIN_GAME_RET,
}

--SYSTEM MSGS
local IMG_BG = "Image_bg"
local REVERSE_LB1 = "Text_info2"
local REVERSE_LB2 = "Text_info1"  
local BTN_HELP = "Button_Help"
local BTN_RETURN = "Button_return" 
local PANEL_START = "Panel_start"
local PANEL_LOADING = "Panel_loading"
local LOADING_BAR = "LoadingBar"
local LBL_PROGRESS = "Text_detail"
local LBL_HINT = "Text_6"
 
local SYSTEM_MSGS = {
	IMG_BG,
	BTN_RETURN,
	BTN_HELP,
}

--NODE TAG
-- local LBL_NICKNAME = "Text_name"

function CheckControl:ctor(model, view)
	CheckControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)
end

function CheckControl:onCreate(param)
	CheckControl.super.onCreate(self, param)

	local bgImage = self:getChildNode(IMG_BG)
	if isNil(bgImage) then printStack() return end

	local exitBtn = self:getChildNode(BTN_RETURN)
	if isNil(exitBtn) then printStack() return end

	--版署版号
	local info = GameSwitch:getReverseInfo()
	if isNil(info) then printStack() return end

	local reverseLabel1 = self:getChildNode(REVERSE_LB1)
	if isNil(reverseLabel1) then printStack() return end
	reverseLabel1:setString(info[1])

	local reverseLabel2 = self:getChildNode(REVERSE_LB2)
	if isNil(reverseLabel2) then printStack() return end
	reverseLabel2:setString(info[2])

	local helpBtn = self:getChildNode(BTN_HELP)
	if isNil(reverseLabel2) then printStack() return end
	helpBtn:setVisible(true)

	local startPanel = self:getChildNode(PANEL_START)
	if isNil(startPanel) then printStack() return end
	startPanel:setVisible(true)

	--进度panel
	local progressPanel = self:getChildNode(PANEL_LOADING)
	if isNil(progressPanel) then printStack() return end
	progressPanel:setVisible(false)


	startPanel:stopAllActions()
	local action1 = cc.FadeIn:create(0.5)
	local action2 = cc.DelayTime:create(0.2)
	local action3 = cc.FadeOut:create(0.5)
	local action4 = cc.DelayTime:create(0.2)
	local action5 = cc.Sequence:create(action1, action2, action3, action4)
	local seq 	  = cc.RepeatForever:create(action5)
	startPanel:runAction(seq)
end

function CheckControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:send(GameMsg.MSG_TRY_EXIT_GAME)
	end

	if senderName == BTN_HELP then
		local data = {}
		data.name = "game.QA"
		self:send(BASE_MSG.PUSH, data)
	end

	if senderName == IMG_BG then
		local exitBtn = self:getChildNode(BTN_RETURN)
		if isNil(exitBtn) then printStack() return end
		exitBtn:setVisible(false)

		local startPanel = self:getChildNode(PANEL_START)
		if isNil(startPanel) then printStack() return end
		startPanel:setVisible(false)
		startPanel:stopAllActions()

		local progressPanel = self:getChildNode(PANEL_LOADING)
		if isNil(progressPanel) then printStack() return end
		progressPanel:setVisible(true)

		local helpBtn = self:getChildNode(BTN_HELP)
		if isNil(helpBtn) then printStack() return end
		helpBtn:setVisible(false)

		local loadingBar = self:getChildNode(LOADING_BAR)
		if isNil(loadingBar) then printStack() return end
		loadingBar:setPercent(0)
		loadingBar:stopAllActions()

		local progressLbl = self:getChildNode(LBL_PROGRESS)
		if isNil(progressLbl) then printStack() return end
		progressLbl:setString("0%")

		local hintLabel = self:getChildNode(LBL_HINT)
		if isNil(hintLabel) then printStack() return end
		hintLabel:setString("正在打开萌菌实验室，请稍候......")

		local action1 = cc.DelayTime:create(0.2)
		local action2 = cc.CallFunc:create(function()
			local progress = math.floor(loadingBar:getPercent())
			if progress == 100 then
				progress = 0
			else
				progress = progress + math.random(1, 4)
				if progress > 100 then
					progress = 100
				end
			end
			loadingBar:setPercent(progress)

			progressLbl:setString(progress .. "%")
		end)
		local seq = cc.Sequence:create(action1, action2)
		local repeatAction = cc.RepeatForever:create(seq)
		loadingBar:runAction(repeatAction)
		-- LoginManager:login() TODO

	end
end

-- function LoadLayer:resetLogin()
-- 	local action1 = cc.DelayTime:create(2.0)
-- 	local action2 = cc.CallFunc:create(function()
-- 		self:getParent().backEvent:register()

-- 		self.isClick = false
-- 		self.exitBtn:setVisible(true)
--         	self._HelpLoading:setVisible(true)
-- 		self.startPanel:setVisible(true)
-- 		self:startAction()
-- 	end)
-- 	local action3 = cc.Sequence:create(action1, action2)
-- 	self:runAction(action3)

-- 	self.progressPanel:setVisible(false)
-- 	self.progressBar:stopAllActions()
-- end

-- function LoadLayer:gotoMainScene()
-- 	self.progressBar:setPercent(100)
-- 	self.progressBar:stopAllActions()

-- 	self.progressLabel:setString("100%")
-- 	self.hintLabel:setString("正在进入萌菌实验室，请稍候......")

-- 	local action1 = cc.DelayTime:create(0.5)
-- 	local action2 = cc.CallFunc:create(function()
-- 		self:mvc()
-- 	end)
-- 	local action3 = cc.Sequence:create(action1, action2)
-- 	self:runAction(action3)
-- end

function CheckControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

	if name == GameMsg.MSG_LOGIN_GAME_RET then
		traceInfo("GameMsg.MSG_LOGIN_GAME_RET==="..value.params)
		-- if value.params == 0 then
			-- self.loadLayer:gotoMainScene() TODO
		-- elseif value.params == -1 and not PlatformOK and self.resetLoginCount < 1 then
            -- self.resetLoginCount  = self.resetLoginCount + 1
            -- LoginManager:login()
        -- else
            -- if self.resetLoginCount == 1 then
            --     self.resetLoginCount = 10
            -- end 
			-- self.loadLayer:resetLogin()
			-- local str = "打开萌菌实验室失败，请稍候重试！[" .. value.params .. "]"
			-- local time = 2
			-- UIManager:showGameMsgTips(str, time)
		-- end
	end
end

return CheckControl


