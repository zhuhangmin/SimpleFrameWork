local EngineControl = require  "EngineControl"
local BattleTeamOverControl = class("BattleTeamOverControl", EngineControl)
--LUA MSGS
local LUA_MSGS = {
	GameMsg.DO_PRAISE
}

--SYSTEM MSGS
local BTN_MORE = "Button_onemore"
local BTN_BACK = "Button_return_down"
local BTN_DETAIL = "Button_detail"
local BTN_VOTE1 = "Button_vote"
local BTN_VOTE2 = "Button_vote1"
local BTN_VOTE3 = "Button_vote2"
local BTN_VOTE4 = "Button_vote3"
local BTN_VOTE5 = "Button_vote4"
local RANK_STR = "你的队伍排名：第%s名！"
local VOTE_STR = "%s个赞"
local VOTE_LIST = {
	"",
	"duiwujiesuan/nice_1.png",
	"duiwujiesuan/nice_1.png",
	"duiwujiesuan/nice_2.png",
	"duiwujiesuan/nice_3.png",
	"duiwujiesuan/nice_3.png",
	"duiwujiesuan/nice_3.png",
	"duiwujiesuan/nice_3.png",
	"duiwujiesuan/nice_3.png",
	"duiwujiesuan/nice_3.png",
}
local SEX = {
	"duiwujiesuan/img_sex_1.png",
	"duiwujiesuan/img_sex_2.png",
}

local PANEL_LIST  = {
	"Panel_teammate",
	"Panel_teammate1",
	"Panel_teammate2",
	"Panel_teammate3",
	"Panel_teammate4",
}

local SYSTEM_MSGS = {
	BTN_DETAIL,
	BTN_BACK,
	BTN_VOTE1,
	BTN_VOTE2,
	BTN_VOTE3,
	BTN_VOTE4,
	BTN_VOTE5,
}

function BattleTeamOverControl:ctor(model, view)
	BattleTeamOverControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
end

function BattleTeamOverControl:onCreate(param)
	BattleTeamOverControl.super.onCreate(self, param)
	
end

function BattleTeamOverControl:onEnter( param )
	self:initUi()
end

function BattleTeamOverControl:updatePraise( data )
	-- dump(data)
	local tmp = self.model:getTeamData()
	for i , v in ipairs( tmp ) do
		if v.userid == data.dstuid then
			self.model:addVote(i)
			local vote_num = self.model:getVoteNum(i)
			
			self.voteList[i].count:setString(string.format(VOTE_STR,vote_num))
			if VOTE_LIST[vote_num] ~= "" then
				self.voteList[i].show:setVisible(true)
				self.voteList[i].show:loadTexture(VOTE_LIST[vote_num], ccui.TextureResType.plistType)
			end
			break
		end
	end
end


function BattleTeamOverControl:initUi()
	local data = self.model:getTeamData()
	self.voteList = {}
	for i , v in ipairs( PANEL_LIST ) do
		local panel = self:getChildNode(v)
		if data[i] then
			--头像
			local head_icon = panel:getChildByName("Image_head")
			local iconName = getSkinIcon(data[i].headurl).. ".png"
			if  gFrameCache:getSpriteFrame(iconName) then
				head_icon:loadTexture(iconName, ccui.TextureResType.plistType)
			end
			--性别
			local sexImage = panel:getChildByName("Image_sex")
			if data[i].sex == 1 then
				sexImage:loadTexture(SEX[1], ccui.TextureResType.plistType)
			else
				sexImage:loadTexture(SEX[2], ccui.TextureResType.plistType)
			end
			--姓名
			local nameLabel = panel:getChildByName("Text_name")
			nameLabel:setString(string.urldecode(data[i].nickname))
			-- self.nameLabel:setTextColor(color)
			local voteShow = panel:getChildByName("Image_nice")
			local voteCount = panel:getChildByName("Text_votecount")
			self.voteList[i] = {}
			self.voteList[i].show = voteShow
			self.voteList[i].count = voteCount
			self.voteList[i].show:setVisible(false)
			local vote_num = self.model:getVoteNum(i)
			self.voteList[i].count:setString(string.format(VOTE_STR,vote_num))
		else
			panel:setVisible(false)
		end
	end

	local rank = self.model:getRank()
	self:getChildNode("Text_title"):setString(string.format(RANK_STR,rank))
end


function BattleTeamOverControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	print("systemRecv name = " .. tostring(senderName))
	if senderName == BTN_BACK then
		self:backEventExt()
	end


	if senderName == BTN_DETAIL then
		self:detachFromParent()
	end

	if senderName == BTN_VOTE1 then
		self:doPraise(1,sender)
	end

	if senderName == BTN_VOTE2 then
		self:doPraise(2,sender)
	end

	if senderName == BTN_VOTE3 then
		self:doPraise(3,sender)
	end

	if senderName == BTN_VOTE4 then
		self:doPraise(4,sender)
	end

	if senderName == BTN_VOTE5 then
		self:doPraise(5,sender)
	end
	
end

function BattleTeamOverControl:doPraise( num,btn )
	local data = self.model:getTeamData()
	local dst = data[num].userid
	local uid_list = {}
	for i , v in ipairs(data) do
		table.insert(uid_list,v.userid)
	end

	local data ={}
	data.func = "doPraise"
	data.params = {uids = uid_list,dstuid = dst}
	self:send(BASE_MSG.NET_FORM, data)
	btn:setEnabled(false)
end

function BattleTeamOverControl:recv(event)
	if isNil(event) then printStack() end
	if isNil(event.name) then printStack() end
	if isNil(event.data) then printStack() end
	print("BattleTeamOverControl:recv name = " .. tostring(event.name))
	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

	if name == GameMsg.DO_PRAISE then
		self:updatePraise(data)
		return
	end
end


function BattleTeamOverControl:backEventExt()

	self:send(BASE_MSG.GOHOME)
end

return BattleTeamOverControl;