local EngineView = require "EngineView"
local AdView = class("AdView", EngineView)

local csbFilePath = "res/AdSlot.csb"
T_CSB_NODE = 1000

function AdView:ctor(node)
	AdView.super.ctor(self, node)
end

function AdView:onCreate(param)
	AdView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	if isNil(csbNode) then printStack() return end
	csbNode:setTag(T_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return AdView





