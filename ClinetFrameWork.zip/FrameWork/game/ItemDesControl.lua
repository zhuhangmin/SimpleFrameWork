local EngineControl = require  "EngineControl"
local ItemDesControl = class("ItemDesControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
}

--SYSTEM MSGS
local BTN_RETURN = "Panel_close"
local SYSTEM_MSGS = {
	BTN_RETURN,
}


function ItemDesControl:ctor(model, view)
	ItemDesControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function ItemDesControl:onCreate(param)
	ItemDesControl.super.onCreate(self, param)
	if isNil(param) then printStack() end

	local image_bg = self:getChildNode("Image_itemdes_bg")
	image_bg:setTouchEnabled(true)

	self:setItemInfo()
end

function ItemDesControl:setItemInfo()
	local itemID = self:getModel():getItemID()
	if notNumber(itemID) then printStack() return end

	local text_name = self:getChildNode("Text_content")
	if isNil(text_name) then printStack() return end

	local text_des = self:getChildNode("Text_des")
	if isNil(text_des) then printStack() return end
	
	local text_get = self:getChildNode("Text_get")
	if isNil(text_get) then printStack() return end
	
    local starID = self:getConfigField("global",1,"STAR_ITEM_ID")
    if isNil(starID) then printStack() return end

    local diamondID = self:getConfigField("global",1,"DIAMOND_ITEM_ID")
    if isNil(diamondID) then printStack() return end

    local lolipopID = self:getConfigField("global",1,"LOLLIPOP_ITEM_ID")
    if isNil(lolipopID) then printStack() return end

    local name = ""
    local comment = ""
    local achieve = ""
    if itemID == starID then
    	name = self:getConfigField("global",1,"STAR_ITEM_NAME")
    	comment = self:getConfigField("global",1,"STAR_ITEM_DES")
    	achieve = self:getConfigField("global",1,"STAR_ITEM_GET")
    elseif itemID == diamondID then
    	name = self:getConfigField("global",1,"DIAMOND_ITEM_NAME")
    	comment = self:getConfigField("global",1,"DIAMOND_ITEM_DES")
    	achieve = self:getConfigField("global",1,"DIAMOND_ITEM_GET")
    elseif itemID == lolipopID then
        name = self:getConfigField("global",1,"LOLLIPOP_ITEM_NAME")
        comment = self:getConfigField("global",1,"LOLLIPOP_ITEM_DES")
        achieve = self:getConfigField("global",1,"LOLLIPOP_ITEM_GET")
    else
		local itemInfo = self:getConfigRecord("item",itemID)
		if isNil(itemInfo) then printStack() return end

		name = itemInfo.name
		comment = itemInfo.comment
		achieve = itemInfo.achieve
    end
	text_name:setString(name)
	text_des:setString(comment)
	text_get:setString(achieve)

    local Image_role = self:getChildNode("Image_role")
    if isNil(Image_role) then printStack() return end

    local Image_rewarditem = self:getChildNode("Image_good_item")
    if isNil(Image_rewarditem) then printStack() return end

    local Image_sp = self:getChildNode("Image_sp")
    if isNil(Image_sp) then printStack() return end

    if itemID == diamondID or itemID == starID or itemID == lolipopID then
        setImgIconById(Image_rewarditem,itemID)
        Image_rewarditem:setVisible(true)
        Image_role:setVisible(false)
        Image_sp:setVisible(false)
    else
        local itemInfo = self:getConfigRecord("item",itemID)
        if isNil(itemInfo) then printStack() return end
        if itemInfo.type == "SKIN" then--皮肤
            setImgIconById(Image_role,itemID)
            Image_rewarditem:setVisible(false)
            Image_role:setVisible(true)
            Image_sp:setVisible(false)
        elseif itemInfo.type == "ROLEPIECE" then--碎片
            setImgIconById(Image_role,itemID)
            Image_rewarditem:setVisible(true)
            Image_role:setVisible(true)
            Image_sp:setVisible(true)
        else--道具
            setImgIconById(Image_rewarditem,itemID)
            Image_rewarditem:setVisible(true)
            Image_role:setVisible(false)
            Image_sp:setVisible(false)
        end
    end
end

function ItemDesControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:detachFromParent()
	end

end

function ItemDesControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

return ItemDesControl


