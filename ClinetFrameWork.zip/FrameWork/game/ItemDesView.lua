local EngineView = require "EngineView"
local ItemDesView = class("ItemDesView", EngineView)

local csbFilePath = "res/ItemDes.csb"
ITEMDES_CSB_NODE = 1000

function ItemDesView:ctor(node)
	ItemDesView.super.ctor(self, node)
end

function ItemDesView:onCreate(param)
	ItemDesView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	csbNode:setTag(ITEMDES_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return ItemDesView





