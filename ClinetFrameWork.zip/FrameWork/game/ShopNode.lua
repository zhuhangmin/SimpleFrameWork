local ConfigManager = require "ConfigManager"
local c = ConfigManager.getInstance()


local ShopNode = class("ShopNode", function()
	return cc.CSLoader:createNode("res/GoodsItem.csb")
end)

function ShopNode:ctor(index, goodIndex,ctrl)
	self.index = index
	self.goodkey = "shop_item_"..goodIndex
	self.goodIndex = goodIndex

	self.ctrl = ctrl

	self.name = ""
	self.shopItemInfo ={}

	self:updateInfo()
end

function ShopNode:updateInfo()
    





    local itemInfo = c:findDstRecordWithField("shop", 1, self.goodkey, "item")
	if isNil(itemInfo) then printStack() return end	

	local image_goods = self:getChildByName("Node_goods")
	local text_price = self:getChildByName("Text_price")
	local text_name = self:getChildByName("Text_name")
	text_name:setVisible(true)
	
	local btn_price = self:getChildByName("Button_price")
	btn_price:addTouchEventListener(handler(self, self.clickGood))

	local sprite_coin = self:getChildByName("Sprite_coin")

	local notHave = true
	
	local shopItemInfo = c:findDstRecordWithField("shop", 1, self.goodkey, "shopItem")
	if isNil(shopItemInfo) then printStack() return end
	if itemInfo.type == "SKIN" then --皮肤
        
        text_name:setString(itemInfo.name)

        local skinInfo = getUserSkinInfo()
        for i = 1, #skinInfo do
	        if skinInfo[i].id == tonumber(shopItemInfo.item_id)
            and  skinInfo[i].count == 0 then
            	notHave = false
                btn_price:setTitleText("已拥有")
                text_price:setVisible(false)
                sprite_coin:setVisible(false)
		        break
	        end
        end
    end
    addItmeNode(image_goods,shopItemInfo.item_id,nil,true)
    text_name:setString(itemInfo.name)

	if shopItemInfo.sell == "DIAMOND" then
		sprite_coin:setSpriteFrame("home/icon_zuanshi.png")
	else
		sprite_coin:setSpriteFrame("home/icon_star.png")
	end
	text_price:setString(shopItemInfo.price)

	setButtonEnable(btn_price,notHave)

	self.shopItemInfo = shopItemInfo
end

function ShopNode:clickGood(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended then
		if isNil(self.goodIndex) then printStack() return end

		local data = {}
		data.modelParam = {index = self.goodIndex,name = self.name,shopItemInfo = self.shopItemInfo}
	    self.ctrl:addPop("game.ShopBuy",data)

	    SoundManager:playEffect("button.mp3")
	end
end

return ShopNode
