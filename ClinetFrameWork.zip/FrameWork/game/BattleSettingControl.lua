local EngineControl = require  "EngineControl"
local BattleSettingControl = class("BattleSettingControl", EngineControl)
--LUA MSGS
local LUA_MSGS = {
}

--SYSTEM MSGS
local BTN_CLOSE = "Button_close"
local BTN_M_ON  = "Button_music_on"
local BTN_M_OFF = "Button_music_off"
local BTN_S_ON  = "Button_sound_on"
local BTN_S_OFF = "Button_sound_off"
local BTN_Q1    = "Panel_quality_1"
local BTN_Q2    = "Panel_quality_2"
local BTN_H1 	= "Panel_habit_1"
local BTN_H2  	= "Panel_habit_2"
-- local BTN_B1	= "Panel_backgroung_1"
-- local BTN_B2	= "Panel_backgroung_2"

local SYSTEM_MSGS = {
	BTN_CLOSE,
	BTN_M_ON,
	BTN_M_OFF,
	BTN_S_ON,
	BTN_S_OFF,
	BTN_Q1,
	BTN_Q2,
	BTN_H1,
	BTN_H2,
	-- BTN_B1,
	-- BTN_B2,
}




function BattleSettingControl:ctor(model, view)
	BattleSettingControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)
end

function BattleSettingControl:onCreate(param)
	BattleSettingControl.super.onCreate(self, param)

	self:init()
end

function BattleSettingControl:init( ... )
	self.music = GameData.settingInfo.musicEnable
	self.effect = GameData.settingInfo.effectEnable
	self.quality = GameData.settingInfo.qualityValue
	self.hand = GameData.settingInfo.handValue
	self.theme = GameData.settingInfo.battleBgValue

	self:updateMusic()
	self:updateEffect()
	self:updateQuality()
	self:updateHand()
	-- self:updateTheme()
end

function BattleSettingControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()
	print("BattleSettingControl:recv name = " .. tostring(senderName))
	if senderName == BTN_CLOSE then
		self:detachFromParent()
	end

	if senderName == BTN_M_ON then
		self.music = false
		self:updateMusic()
	end

	if senderName == BTN_M_OFF then
		self.music = true
		self:updateMusic()
	end


	if senderName == BTN_S_ON then
		self.effect = false
		self:updateEffect()

	end


	if senderName == BTN_S_OFF then
		self.effect = true
		self:updateEffect()
	end

	if senderName == BTN_Q1 then
		self.quality = 1
		self:updateQuality()
	end

	if senderName == BTN_Q2 then
		self.quality = 2
		self:updateQuality()
	end

    if senderName == BTN_H1 then
		self.hand = 1
		self:updateHand()
	end

   	if senderName == BTN_H2 then
		self.hand = 2
		self:updateHand()
	end

    if senderName == BTN_B1 then
		self.theme = 1
		self:updateTheme()
	end	
	if senderName == BTN_B2 then
		self.theme = 1
		self:updateTheme()
	end


end

function BattleSettingControl:recv(event)
	if isNil(event) then printStack() end
	if isNil(event.name) then printStack() end
	if isNil(event.data) then printStack() end
	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

function BattleSettingControl:updateMusic()
	if self.music then
		self:getChildNode(BTN_M_ON):setVisible(true)
		self:getChildNode(BTN_M_OFF):setVisible(false)
	else
		self:getChildNode(BTN_M_ON):setVisible(false)
		self:getChildNode(BTN_M_OFF):setVisible(true)
	end

	self:writeData()
end


function BattleSettingControl:updateEffect()
	if self.effect then
		self:getChildNode(BTN_S_ON):setVisible(true)
		self:getChildNode(BTN_S_OFF):setVisible(false)
	else
		self:getChildNode(BTN_S_ON):setVisible(false)
		self:getChildNode(BTN_S_OFF):setVisible(true)
	end

	self:writeData()
end


function BattleSettingControl:updateQuality()
	if self.quality == 1 then
		self:getChildNode(BTN_Q1):getChildByName("Image_choose"):setVisible(true)
		self:getChildNode(BTN_Q2):getChildByName("Image_choose"):setVisible(false)
	elseif self.quality == 2 then
		self:getChildNode(BTN_Q1):getChildByName("Image_choose"):setVisible(false)
		self:getChildNode(BTN_Q2):getChildByName("Image_choose"):setVisible(true)
	end

	self:writeData()
end

function BattleSettingControl:updateHand()
	if self.hand == 1 then
		self:getChildNode(BTN_H1):getChildByName("Image_choose"):setVisible(true)
		self:getChildNode(BTN_H2):getChildByName("Image_choose"):setVisible(false)
	elseif self.hand == 2 then
		self:getChildNode(BTN_H1):getChildByName("Image_choose"):setVisible(false)
		self:getChildNode(BTN_H2):getChildByName("Image_choose"):setVisible(true)
	end

	self:writeData()
end


function BattleSettingControl:updateTheme()
	if self.theme == 1 then
		self:getChildNode(BTN_B1):getChildByName("Image_choose"):setVisible(true)
		self:getChildNode(BTN_B2):getChildByName("Image_choose"):setVisible(false)
	elseif self.theme == 2 then
		self:getChildNode(BTN_B1):getChildByName("Image_choose"):setVisible(false)
		self:getChildNode(BTN_B2):getChildByName("Image_choose"):setVisible(true)
	end

	self:writeData()
end

function BattleSettingControl:writeData()
	UDManager:setSettingConfig(self.music,
								self.effect,
								GameData.settingInfo.skinEnable,
								GameData.settingInfo.talkEnable,
								self.quality,
								self.theme,
								self.hand,
								"GameScene" )
	self:send(BattleMsg.UPDATE_THEME, data)
end




return BattleSettingControl;