local EngineModel = require "EngineModel"
local AdModel = class("AdModel", EngineModel)

function AdModel:ctor(data)
	AdModel.super.ctor(self, data)
end

function AdModel:onCreate(param)
	AdModel.super.onCreate(self, param)
	self.show_reward_index = math.floor(math.random(1,10))
	self.step = 20
end

function AdModel:getShowIndex( )
	return self.show_reward_index
end

function AdModel:addShowIndex( )
	self.show_reward_index = self.show_reward_index + 1
	if self.show_reward_index == 11 then
		self.show_reward_index = 1
	end
end

function AdModel:getStep( )
	return self.step
end

function AdModel:setStep( step )
	if type(step) ~= "number" then return end
	self.step = step
end


return AdModel

