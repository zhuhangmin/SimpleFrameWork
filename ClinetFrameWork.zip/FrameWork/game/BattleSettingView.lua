local EngineView = require "EngineView"
local BattleSettingView = class("BattleSettingView", EngineView)

function BattleSettingView:ctor(node)
	BattleSettingView.super.ctor(self, node)
end

function BattleSettingView:onCreate(param)
	BattleSettingView.super.onCreate(self, param)
	local csbNode = cc.CSLoader:createNode("res/SetupBattle.csb")
	if isNil(csbNode) then printStack() return end
	self:getNode():addChild(csbNode)
	csbNode:setPosition(0, gScreenSize.height)
	UIManager:runPopupEnterAction(csbNode)
end


return BattleSettingView;
