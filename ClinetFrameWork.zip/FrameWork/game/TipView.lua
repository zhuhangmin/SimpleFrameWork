local EngineView = require "EngineView"
local TipView = class("TipView", EngineView)

local csbFilePath = "res/Tips.csb"
CSB_NODE = 1000

function TipView:ctor(node)
	TipView.super.ctor(self, node)
end

function TipView:onCreate(param)
	TipView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	csbNode:setTag(CSB_NODE)
	self:getNode():addChild(csbNode)

end

return TipView





