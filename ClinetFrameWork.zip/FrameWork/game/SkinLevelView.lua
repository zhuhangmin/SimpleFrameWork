local EngineView = require "EngineView"
local SkinLevelView = class("SkinLevelView", EngineView)

local csbFilePath = "res/SkinLevel.csb"
SKINLEVEL_CSB_NODE = 1000

function SkinLevelView:ctor(node)
	SkinLevelView.super.ctor(self, node)
end

function SkinLevelView:onCreate(param)
	SkinLevelView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	if isNil(csbNode) then printStack() return end
	
	csbNode:setTag(SKINLEVEL_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return SkinLevelView





