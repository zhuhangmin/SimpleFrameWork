local EngineControl = require  "EngineControl"
local RichesControl = class("RichesControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	GameMsg.GET_PLAYER_DATA,
}

local BUTTON_ADD_DIAMOND = "Button_add"
local BUTTON_ADD_STAR = "Button_add_star"
local BUTTON_ADD_LOLIPOP = "Button_add_lolipop"
--SYSTEM MSGS
local SYSTEM_MSGS = {
	BUTTON_ADD_DIAMOND,
	BUTTON_ADD_STAR,
	BUTTON_ADD_LOLIPOP
}

local IMG_DIAMOND = "Image_diamond"
local TEXT_DIAMOND = "Text_diamond"
local TEXT_STAR = "Text_star"
local TEXT_CANDY = "Text_lolipop"


function RichesControl:ctor(model, view)
	RichesControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
end

function RichesControl:onCreate(param)
	RichesControl.super.onCreate(self, param)

	--init
	local csbNode = self:getChildNode(RICHES_CSB)

	local diamondImg = self:getChildNode(IMG_DIAMOND)
	local x,y = diamondImg:getPosition() 
	local diamondArmature = self:getChildNode(RICHES_DIAMOND_ARMATURE)
	diamondArmature:setPosition(x,y)
	local anim = diamondArmature:getAnimation()
	anim:play("mjzjm_diamonds", -1, 1)
	
	self:updateRiches()
end

function RichesControl:onEnter(param)
	RichesControl.super.onEnter(self, param)
end

function RichesControl:recv(event)
	self.super.recv(self, event)
	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
	if name == GameMsg.GET_PLAYER_DATA  then

		self:updateRiches()
		return
	end
end

function RichesControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BUTTON_ADD_DIAMOND then
		local name = "game.ChargeShop"
		local modelParam = {pageIndex = 2}
		local data = buildMsgData(name, modelParam)
		self:send(BASE_MSG.PUSH, data)
	end

	if senderName == BUTTON_ADD_STAR then
		local name = "game.ChargeShop"
		local modelParam = {pageIndex = 1}
		local data = buildMsgData(name, modelParam)
		self:send(BASE_MSG.PUSH, data)
	end

	if senderName == BUTTON_ADD_LOLIPOP then
        local DISABLE_FUNCTION_STR = self:getConfigField("tips", "NOT_OPEN", "content")
        self:addTip(DISABLE_FUNCTION_STR)
	end
end

function RichesControl:updateRiches()
	local diamondLabel = self:getChildNode(TEXT_DIAMOND)
	diamondLabel:setString(PlayerDataBasic.cur_diamond)

	local starlabel = self:getChildNode(TEXT_STAR)
	starlabel:setString(PlayerDataBasic.cur_star)

	local candylabel = self:getChildNode(TEXT_CANDY)
	candylabel:setString(PlayerDataBasic.cur_lollipop)
	
end

return RichesControl


