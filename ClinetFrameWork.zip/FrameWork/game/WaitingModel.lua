local EngineModel = require "EngineModel"
local WaitingModel = class("WaitingModel", EngineModel)

function WaitingModel:ctor(data)
	WaitingModel.super.ctor(self, data)
	self.delay = 0.5
	self.timeout = 3
end

function WaitingModel:onCreate(param)
	WaitingModel.super.onCreate(self, param)
end

function WaitingModel:getDelay()
	return self.delay
end

function WaitingModel:setDelay(delay)
	self.delay = delay
end

function WaitingModel:getTimeout()
	return self.timeout
end

function WaitingModel:setTimeout(timeout)
	self.timeout = timeout
end

return WaitingModel

