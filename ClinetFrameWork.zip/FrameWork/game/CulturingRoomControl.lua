local EngineControl = require  "EngineControl"
local CulturingRoomControl = class("CulturingRoomControl", EngineControl)
local GlobalStatus = require "GlobalStatus"

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
	GameMsg.MSG_CULTURE_UPDATE,
	GameMsg.MSG_GET_CULTURE_REWARD_RET,
	GameMsg.MSG_SKIN_CHANGE_RET,
	GameMsg.MSG_START_CULTURE_RET
}

--SYSTEM MSGS
local BTN_RETURN = "Button_return"
local BTN_HELP = "Button_Help"
local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_HELP,
}

function CulturingRoomControl:ctor(model, view)
	CulturingRoomControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function CulturingRoomControl:onCreate(param)
	CulturingRoomControl.super.onCreate(self, param)
	if isNil(param) then printStack() end

	local name = "game.Riches"
	self:addPanel(name)

	local panel_Shader = self:getChildNode("Panel_Shader")
	if isNil(panel_Shader) then printStack() return end
	panel_Shader:setVisible(false)

	self:addCulture()
end

function CulturingRoomControl:addCulture()
	local cultures = {}
	for i=1,4 do
		local cultureNode = self:getChildNode("Node_Culture"..i)
		if isNil(cultureNode) then printStack() return end

		local culture = require("FrameWork.game.CultureOpenNode"):create(self,i)
		if isNil(culture) then printStack() return end

		cultureNode:addChild(culture)

		cultures[i] = culture
	end

	self:getModel():setCultures(cultures)

	self:updateCulture()
end

function CulturingRoomControl:updateCulture()
	local cultures = self:getModel():getCultures()
	if isNil(cultures) then printStack() return end

	for i=1,4 do
		if isNil(CultureData) then printStack() return end
		local info = nil
		for k,v in pairs(CultureData) do
			if v.index == i then
				info = v
			end
		end
		cultures[i]:updateInfo(info)
	end
end

function CulturingRoomControl:onUpdate()
	local cultures = self:getModel():getCultures()
	if isNil(cultures) then printStack() return end

	for k,v in pairs(CultureData) do
		if v.isStart == 1 and v.timeout>0 then
			cultures[v.index]:updateTime()
			return
		end
	end
end

function CulturingRoomControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:send(BASE_MSG.POP)
	end

	if senderName == BTN_HELP then
		self:addPop("game.CultureHelp")
	end
end

function CulturingRoomControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

	if name == GameMsg.MSG_CULTURE_UPDATE then
		self:updateCulture()
		GlobalStatus.getInstance():setCultureTime(os.time())
	end

	if name == GameMsg.MSG_GET_CULTURE_REWARD_RET then
		self:getModel():setReward(data)
	end

	if name == GameMsg.MSG_SKIN_CHANGE_RET then
		local itemID = data.item_id
		if isNil(itemID) then printStack() return end

		local itemConfig = self:getTable("item")
		if isNil(itemConfig) then printStack() return end

		local itemInfo = itemConfig[itemID]
		local aniName = string.split(itemInfo.img,"_")[1]

		local armatureNode = self:getNode()
		if isNil(armatureNode) then printStack() return end

		local panel_Shader = self:getChildNode("Panel_Shader")
		if isNil(panel_Shader) then printStack() return end
		panel_Shader:setVisible(true)

		local armature = ccs.Armature:create("lingyedakai")
		armature:getAnimation():play(aniName, -1, 0)
		armatureNode:addChild(armature)
		armature:setPosition(display.width/2,display.height/2)
		armature:getAnimation():setMovementEventCallFunc(function( ... )
			panel_Shader:setVisible(false)
			armature:removeFromParent()
			self:showReward()
		end)	
	end

	-- if name == GameMsg.MSG_START_CULTURE_RET then
	-- 	GlobalStatus.getInstance():setCultureTime(os.time())
	-- end
end

function CulturingRoomControl:showReward()
	local reward = self:getModel():getReward()
	if isNil(reward) then printStack() return end

	local rewardData = {}
	if reward.gift_id~=0 then
        local giftInfo = self:getConfigRecord("giftPack", reward.gift_id)
        if isNil(giftInfo) then printStack() end    

        for i=1,7 do
            local itemID = giftInfo["reward"..i]
            local itemNum = giftInfo["num"..i]
            if itemID~=0 and itemNum~=0 then
                table.insert(rewardData,{item_id=itemID ,item_num=itemNum})
            end
        end
	else
		for k,v in pairs(reward.items) do
			table.insert(rewardData,{item_id=tonumber(k) ,item_num=tonumber(v)})
		end
	end
    local name = "game.GetAwards"
    local param = {modelParam = {rewardData = rewardData}}
    self:addPop(name,param)
end

return CulturingRoomControl


