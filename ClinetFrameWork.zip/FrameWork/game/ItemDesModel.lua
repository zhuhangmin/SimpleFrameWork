local EngineModel = require "EngineModel"
local ItemDesModel = class("ItemDesModel", EngineModel)

function ItemDesModel:ctor(data)
	ItemDesModel.super.ctor(self, data)

	self.itemID = 0
end

function ItemDesModel:onCreate(param)
	ItemDesModel.super.onCreate(self, param)

	if notNumber(param.itemID) then printStack() return end
	self:setItemID(param.itemID)
end

function ItemDesModel:setItemID(itemID)
	self.itemID = itemID
end

function ItemDesModel:getItemID()
	return self.itemID
end

return ItemDesModel

