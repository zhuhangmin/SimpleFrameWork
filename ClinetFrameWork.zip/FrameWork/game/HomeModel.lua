local EngineModel = require "EngineModel"
local HomeModel = class("HomeModel", EngineModel)

function HomeModel:ctor(data)
	HomeModel.super.ctor(self, data)
	self.testData = 1
	self.showCharge = true
end

function HomeModel:getTestData()
	return self.testData
end

function HomeModel:setTestData(val)
	self.testData = val
end

function HomeModel:getShowCharge()
	return self.showCharge
end

function HomeModel:setShowCharge(showCharge)
	self.showCharge = showCharge
end

return HomeModel

