
local MailItemNode = class("MailItemNode", function()
	return ccui.Widget:create()
end)

local STATE = {
    NEWMAIL = 1,--置顶邮件
    READMAIL = 2,--已读邮件
    READINGMAIL = 3,--未读邮件
}
function MailItemNode:ctor(data)
    self._Data = data
    self._MailState = {}
	self:init()
    self:setInfo()
end

function MailItemNode:init()
	self._LoadMailItemNode = cc.CSLoader:createNode("res/MailItem.csb")
	self:addChild(self._LoadMailItemNode)

    self._MailState     = self._LoadMailItemNode:getChildByName("Panel_mail_new")
    self._MailBg        = self._MailState:getChildByName("Sprite_mail_bg")
    self._MailSign      = self._MailState:getChildByName("Sprite_up_sign")
    self._MailTitle     = self._MailState:getChildByName("Tex_ttitle")
    self._MailTime      = self._MailState:getChildByName("Text_time")
    self._MailTitle:setAnchorPoint(0,0.5)
    self._MailTitle:setPositionX(self._MailTitle:getPositionX()-55)
    self._MailTitle:setFontSize(22)
end

function MailItemNode:setInfo()
    if self._Data then
        if self._Data.istop and self._Data.istop == 1 then
            self._MailSign:setSpriteFrame("yj/yj_star1.png")
            if self._Data.isread == 1 then
                self._MailBg:setSpriteFrame("yj/yj_yiduqu.png")
                self._MailTitle:setColor(cc.c3b(45,101,144))
                self._MailTime:setColor(cc.c3b(45,101,144))
            else
                self._MailBg:setSpriteFrame("yj/yj_xinyoujian.png")
                self._MailTitle:setColor(cc.c3b(217,58,92))--2,143,255
                self._MailTime:setColor(cc.c3b(217,58,92))
            end 
        else
            self._MailSign:setSpriteFrame("yj/yj_star2.png")
            if self._Data.isread == 1 then
                self._MailBg:setSpriteFrame("yj/yj_yiduqu.png")
                self._MailTitle:setColor(cc.c3b(45,101,144))
                self._MailTime:setColor(cc.c3b(45,101,144))
            else
                self._MailBg:setSpriteFrame("yj/yj_xinyoujian.png")
                self._MailTitle:setColor(cc.c3b(217,58,92))
                self._MailTime:setColor(cc.c3b(217,58,92))
            end 
        end 
    
        self._MailTitle:setString(self._Data.title)
        self._MailTime:setString(Utils:getDateFromTime(self._Data.sendtime))
    end
end 

function MailItemNode:setClickInfo()
    self._MailBg:setSpriteFrame("yj/yj_dianji.png")
    self._MailTitle:setColor(cc.c3b(2,143,255))
    self._MailTime:setColor(cc.c3b(2,143,255))

end

function MailItemNode:getPanelMail()
    return self._MailState
end

return MailItemNode
