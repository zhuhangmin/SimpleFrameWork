local EngineView = require "EngineView"
local WaitingView = class("WaitingView", EngineView)

WAITING_IMG_TAG = 10000

function WaitingView:ctor(node)
	WaitingView.super.ctor(self, node)
end

function WaitingView:onCreate(param)
	WaitingView.super.onCreate(self, param)

	local frameName = "tongyong/loading.png"
	local waitImg = cc.Sprite:createWithSpriteFrameName(frameName)
	self:getNode():addChild(waitImg)
	waitImg:setTag(WAITING_IMG_TAG)
	
end

return WaitingView





