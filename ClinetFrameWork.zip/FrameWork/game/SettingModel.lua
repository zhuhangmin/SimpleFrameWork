local EngineModel = require "EngineModel"
local SettingModel = class("SettingModel", EngineModel)

function SettingModel:ctor(data)
	SettingModel.super.ctor(self, data)

	self.music = true
	self.effect = true
	self.quality = 1
end

function SettingModel:onCreate(param)
	SettingModel.super.onCreate(self, param)

	if isNil(param.music) then printStack() end
	self:setMusicEnable(param.music)
	
	if isNil(param.effect) then printStack() end
	self:setEffectEnable(param.effect)
	
	if isNil(param.quality) then printStack() end
	self:setQualityValue(param.quality)
end

function SettingModel:getMusicEnable()
	return self.music
end

function SettingModel:setMusicEnable(music)
	self.music = music
end

function SettingModel:getEffectEnable()
	return self.effect
end

function SettingModel:setEffectEnable(effect)
	self.effect = effect
end

function SettingModel:getQualityValue()
	return self.quality
end

function SettingModel:setQualityValue(quality)
	self.quality = quality
end

return SettingModel

