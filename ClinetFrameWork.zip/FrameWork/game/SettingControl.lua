local EngineControl = require  "EngineControl"
local SettingControl = class("SettingControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
}

--SYSTEM MSGS
local BTN_RETURN = "Button_close"
local BTN_MUSICON = "Button_music_on"
local BTN_MUSICOFF = "Button_music_off"
local BTN_SOUNDON = "Button_sound_on"
local BTN_SOUNDOFF = "Button_sound_off"
local BTN_QUALITY1 = "Panel_quality_1"
local BTN_QUALITY2 = "Panel_quality_2"
local BTN_IDCHANGE = "Button_idchange"
local BTN_IDMANAGE = "Button_idmanage"
local BTN_REALNAME = "Button_realname"
local BTN_ANTIADDICTION = "Button_antiaddiction"
local BTN_MOREGAME = "Button_moregame"
local BTN_QA = "Button_QA"
local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_MUSICON,
	BTN_MUSICOFF,
	BTN_SOUNDON,
	BTN_SOUNDOFF,
	BTN_QUALITY1,
	BTN_QUALITY2,
	BTN_IDCHANGE,
	BTN_IDMANAGE,
	BTN_REALNAME,
	BTN_ANTIADDICTION,
	BTN_MOREGAME,
	BTN_QA,
}

--GAME LABLES
local LBL_VERSION = "Text_1"
local LBL_USERID = "Text_player"


local TICK_QUALITY = "Image_choose"

function SettingControl:ctor(model, view)
	SettingControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)
end

function SettingControl:onCreate(param)
	SettingControl.super.onCreate(self, param)
	if isNil(param) then printStack() end

	self:initBtnsPos()
	self:updateMusic()
	self:updateEffect()
	self:updateQuality()
end

function SettingControl:onEnter(param)
	SettingControl.super.onEnter(self, param)

end

function SettingControl:initBtnsPos()
	--账号管理，切换账号
	local versionLbl = self:getChildNode(LBL_VERSION)
	if isNil(versionLbl) then printStack() return end
	versionLbl:setString(SDKFunc.versionName .. ", " .. SDKFunc.versionCode)

	local userIDLbl = self:getChildNode(LBL_USERID)
	if isNil(userIDLbl) then printStack() return end
	userIDLbl:setString(PlayerDataSystem.bind_name)

	local ase = SDKFunc.account:isSupportAccountSwitch()
	if isNil(ase) then printStack() end

	local ame = false --不支持帐号切换
	-- local ame = SDKFunc.account:isSupportAccountManage()
	if isNil(ame) then printStack() end

	local switchBtn = self:getChildNode(BTN_IDCHANGE)
	if isNil(switchBtn) then printStack() end	

	local managerBtn = self:getChildNode(BTN_IDMANAGE)
	if isNil(managerBtn) then printStack() end

	switchBtn:setVisible(ase)
	managerBtn:setVisible(ame)

	if not ase and ame then
		managerBtn:setPositionY(switchBtn:getPositionY())
	end

	--实名注册，防沉迷查询，更多游戏
	local re = SDKFunc.account:isSupportRealNameRegister()
	if isNil(re) then printStack() end

	local ae = SDKFunc.account:isSupportAntiAddictionQuery()
	if isNil(ae) then printStack() end

	local me = SDKFunc.account:isSupportMoreGame()
	if isNil(me) then printStack() end

	local realNameBtn = self:getChildNode(BTN_REALNAME)
	if isNil(realNameBtn) then printStack() end

	local antiQueryBtn = self:getChildNode(BTN_ANTIADDICTION)
	if isNil(antiQueryBtn) then printStack() end

	local moreGameBtn = self:getChildNode(BTN_MOREGAME)
	if isNil(moreGameBtn) then printStack() end

	realNameBtn:setVisible(re)
	antiQueryBtn:setVisible(ae)
	moreGameBtn:setVisible(me)

	if re then
		if ae then
			if not me then
				antiQueryBtn:setPositionX(moreGameBtn:getPositionX())
			end
		else
			if not me then
				realNameBtn:setPositionX(antiQueryBtn:getPositionX())
			end
		end
	else
		if ae then
			if me then
				antiQueryBtn:setPositionX(realNameBtn:getPositionX())
			end
		else
			if me then
				moreGameBtn:setPositionX(antiQueryBtn:getPositionX())
			end
		end
	end
end

function SettingControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:detachFromParent()
	end

	if senderName == BTN_MUSICON then
		self:musicOnEvent()
	end

	if senderName == BTN_MUSICOFF then
		self:musicOffEvent()
	end

	if senderName == BTN_SOUNDON then
		self:effectOnEvent()
	end

	if senderName == BTN_SOUNDOFF then
		self:effectOffEvent()
	end

	if senderName == BTN_QUALITY1 then
		self:normalQualityEvent()
	end

	if senderName == BTN_QUALITY2 then
		self:highQualityEvent()
	end

	if senderName == BTN_IDCHANGE then
		self:asEvent()
	end

	if senderName == BTN_IDMANAGE then
		self:amEvent()
	end

	if senderName == BTN_REALNAME then
		self:rnEvent()
	end

	if senderName == BTN_ANTIADDICTION then
		self:aqEvent()
	end

	if senderName == BTN_MOREGAME then
		self:mgEvent()
	end

	if senderName == BTN_QA then
	   	local data = {}
		data.name = "game.QA"
		self:send(BASE_MSG.PUSH, data)
	end
end

 

function SettingControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

--音乐
function SettingControl:musicOnEvent()
	self:getModel():setMusicEnable(false)
	self:updateMusic()
end

function SettingControl:musicOffEvent()
	self:getModel():setMusicEnable(true)
	self:updateMusic()
end

function SettingControl:updateMusic()
	local music = self:getModel():getMusicEnable()
	if isNil(music) then printStack() end
	
	toggleNodesVisibleByName(self:getNode(),BTN_MUSICON,BTN_MUSICOFF,music)

	self:writeData()
end

--音效
function SettingControl:effectOnEvent()
	self:getModel():setEffectEnable(false)
	self:updateEffect()
end

function SettingControl:effectOffEvent()
	self:getModel():setEffectEnable(true)
	self:updateEffect()
end

function SettingControl:updateEffect()
	local effect = self:getModel():getEffectEnable()
	if isNil(effect) then printStack() end

	toggleNodesVisibleByName(self:getNode(),BTN_SOUNDON,BTN_SOUNDOFF,effect)

	self:writeData()
end

--品质
function SettingControl:normalQualityEvent()
	local quality = self:getModel():getQualityValue()
	if isNil(quality) then printStack() end

	if self.quality ~= 1 then
		self:getModel():setQualityValue(1)
		self:updateQuality()
	end
end

function SettingControl:highQualityEvent()
	local quality = self:getModel():getQualityValue()
	if isNil(quality) then printStack() end

	if quality ~= 2 then
		self:getModel():setQualityValue(2)
		self:updateQuality()
	end
end

function SettingControl:updateQuality()
	local quality1 = self:getChildNode(BTN_QUALITY1)
	if isNil(quality1) then printStack() end

	local normalTick = quality1:getChildByName(TICK_QUALITY)
	if isNil(normalTick) then printStack() end

	local quality2 = self:getChildNode(BTN_QUALITY2)
	if isNil(quality2) then printStack() end

	local highTick = quality2:getChildByName(TICK_QUALITY)
	if isNil(highTick) then printStack() end

	local quality = self:getModel():getQualityValue()
	if isNil(quality) then printStack() end

	local isNormal = (quality == 1)
	toggleNodesVisible(normalTick,highTick,isNormal)

	self:writeData()
end

--切换账号
function SettingControl:asEvent()
	LoginManager:accountSwitch()
end

--账号管理
function SettingControl:amEvent()
	SDKFunc.account:accountManage()
end

--实名注册
function SettingControl:rnEvent()
	SDKFunc.account:realNameRegister()
end

--防沉迷查询
function SettingControl:aqEvent()
	SDKFunc.account:antiAddictionQuery()
end

--更多游戏
function SettingControl:mgEvent()
	SDKFunc.account:moreGame()
end

function SettingControl:writeData()
	local music = self:getModel():getMusicEnable()
	if isNil(music) then printStack() end

	local effect = self:getModel():getEffectEnable()
	if isNil(effect) then printStack() end

	local quality = self:getModel():getQualityValue()
	if isNil(quality) then printStack() end

	UDManager:setSettingConfig(music,
								effect,
								GameData.settingInfo.skinEnable,
								GameData.settingInfo.talkEnable,
								quality,
								GameData.settingInfo.battleBgValue,
								GameData.settingInfo.handValue,
								"Main")
end

return SettingControl


