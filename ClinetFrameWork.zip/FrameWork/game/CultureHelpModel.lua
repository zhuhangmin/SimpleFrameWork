local EngineModel = require "EngineModel"
local CultureHelpModel = class("CultureHelpModel", EngineModel)

function CultureHelpModel:ctor(data)
	CultureHelpModel.super.ctor(self, data)
end

function CultureHelpModel:onCreate(param)
	CultureHelpModel.super.onCreate(self, param)
end

return CultureHelpModel

