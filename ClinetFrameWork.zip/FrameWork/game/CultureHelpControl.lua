local EngineControl = require  "EngineControl"
local CultureHelpControl = class("CultureHelpControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
}

--SYSTEM MSGS
local BTN_RETURN = "Button_close"
local SYSTEM_MSGS = {
	BTN_RETURN,
}

function CultureHelpControl:ctor(model, view)
	CultureHelpControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function CultureHelpControl:onCreate(param)
	CultureHelpControl.super.onCreate(self, param)
	if isNil(param) then printStack() end
end

function CultureHelpControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:detachFromParent()
	end

end

function CultureHelpControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

return CultureHelpControl


