local EngineControl = require  "EngineControl"
local ShopBuyControl = class("ShopBuyControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
}

--SYSTEM MSGS
local BTN_RETURN = "Button_cancel"
local BTN_CONFIRM = "Button_confirm"
local BTN_REDUCE = "Button_reduce"
local BTN_ADD = "Button_add"
local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_CONFIRM,
	BTN_REDUCE,
	BTN_ADD
}

--GAME LABLES
local LBL_NICKNAME = "Text_name"

--OTHER NODE
local NUMTOOMUCH_STR = ShopBuyControl:getConfigField("tips", "OVER_UPLIMIT", "content")

function ShopBuyControl:ctor(model, view)
	ShopBuyControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function ShopBuyControl:onCreate(param)
	ShopBuyControl.super.onCreate(self, param)
	if isNil(param) then printStack() end

	local text_content = self:getChildNode("Text_content")
	if isNil(text_content) then printStack() end

	local name = self:getModel():getName()
	if isNil(name) then printStack() end

	text_content:setString(name)

	local sprite_good_item = self:getChildNode("Node_goods")
	if isNil(sprite_good_item) then printStack() end
	
	local shopItemInfo = self:getModel():getShopItemInfo()
	if isNil(shopItemInfo) then printStack() end

	addItmeNode(sprite_good_item,shopItemInfo.item_id,nil,true)

	local sprite_price_item = self:getChildNode("Sprite_price_item")
	if isNil(sprite_price_item) then printStack() end

	if shopItemInfo.sell == "DIAMOND" then
		sprite_price_item:setSpriteFrame("home/icon_zuanshi.png")
	else
		sprite_price_item:setSpriteFrame("home/icon_star.png")
	end

	self:updateBuyNum()
end

function ShopBuyControl:updateBuyNum()
	local text_amount = self:getChildNode("Text_amount")
	if isNil(text_amount) then printStack() end

	local buyNum = self:getModel():getBuyNum()
	if notNumber(buyNum) then printStack() end

	text_amount:setString(buyNum)

	local text_total_Cost = self:getChildNode("Text_total_Cost")
	if isNil(text_total_Cost) then printStack() end

	local shopItemInfo = self:getModel():getShopItemInfo()
	if isNil(shopItemInfo) then printStack() end

	text_total_Cost:setString(shopItemInfo.price*buyNum)
end

function ShopBuyControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:detachFromParent()
	end

	if senderName == BTN_ADD then
		local buyNum = self:getModel():getBuyNum()
		if notNumber(buyNum) then printStack() end

		local shopItemInfo = self:getModel():getShopItemInfo()
		if isNil(shopItemInfo) then printStack() end

		local itemConfig = self:getTable("item")
		if isNil(itemConfig) then printStack() return end

		local itemInfo = itemConfig[shopItemInfo.item_id]
		if isNil(itemInfo) then printStack() return end

		if buyNum<itemInfo.stack then
			buyNum = buyNum + 1

			self:getModel():setBuyNum(buyNum)
			self:updateBuyNum()
		else
			self:addTip(NUMTOOMUCH_STR)
		end
	end

	if senderName == BTN_REDUCE then
		local buyNum = self:getModel():getBuyNum()
		if notNumber(buyNum) then printStack() end

		if buyNum>1 then
			buyNum = buyNum - 1

			self:getModel():setBuyNum(buyNum)
			self:updateBuyNum()
		end
	end

	if senderName == BTN_CONFIRM then
		local shopItemInfo = self:getModel():getShopItemInfo()
		if isNil(shopItemInfo) then printStack() end

		local data ={}
		local index = self:getModel():getIndex()
		if notNumber(index) then printStack() end

		local buyNum = self:getModel():getBuyNum()
		if notNumber(buyNum) then printStack() end

		local isMoneyEnough = true
		if shopItemInfo.sell == "DIAMOND" then
			isMoneyEnough = buyJudgement(2,shopItemInfo.price*buyNum)
		else
			isMoneyEnough = buyJudgement(1,shopItemInfo.price*buyNum)
		end

		if isMoneyEnough then
			data.func = "purchaseShopItem"
			data.params = {shop_id = 1,index = index,item_count = buyNum}
			self:send(BASE_MSG.NET_FORM_WAIT, data)

			self:detachFromParent()
		end
	end

end

function ShopBuyControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

return ShopBuyControl


