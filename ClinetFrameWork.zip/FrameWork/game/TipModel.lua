local EngineModel = require "EngineModel"
local TipModel = class("TipModel", EngineModel)

function TipModel:ctor(data)
	TipModel.super.ctor(self, data)
	self.tipStr = ""
end

function TipModel:getTipStr()
	return self.tipStr
end

function TipModel:setTipStr(tipStr)
	self.tipStr = tipStr
end

function TipModel:onCreate(param)
	TipModel.super.onCreate(self, param)
	if isNil(param) then printStack() end
	if notString(param.str) then printStack() end
	local str = param.str
	self:setTipStr(str)
end


return TipModel

