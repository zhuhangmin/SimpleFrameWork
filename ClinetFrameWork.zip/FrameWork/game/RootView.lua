local EngineView = require "EngineView"
local RootView = class("RootView", EngineView)

function RootView:ctor(node)
	RootView.super.ctor(self, node)
end

return RootView





