local EngineModel = require "EngineModel"
local DiscountModel = class("DiscountModel", EngineModel)

function DiscountModel:ctor(data)
	DiscountModel.super.ctor(self, data)
end

function DiscountModel:onCreate(param)
	DiscountModel.super.onCreate(self, param)

	self:setCallback(param.callback)
end

function DiscountModel:getCallback()
	return self.callback
end

function DiscountModel:setCallback(callback)
	self.callback = callback
end

return DiscountModel

