local EngineView = require "EngineView"
local BattleTeamOverView = class("BattleTeamOverView", EngineView)

function BattleTeamOverView:ctor(node)
	BattleTeamOverView.super.ctor(self, node)
end

function BattleTeamOverView:onCreate(param)
	print("BattleTeamOverView")
	BattleTeamOverView.super.onCreate(self, param)
	local csbNode = cc.CSLoader:createNode("res/Result_team.csb")
	if isNil(csbNode) then printStack() return end
	self:getNode():addChild(csbNode)
	csbNode:setName("csbNode")
end


return BattleTeamOverView;