local EngineModel = require "EngineModel"
local PlayerInfoModel = class("PlayerInfoModel", EngineModel)

function PlayerInfoModel:ctor(data)
	PlayerInfoModel.super.ctor(self, data)
	self.score = PlayerDataBasic.score
end

function PlayerInfoModel:getScore( )
	return self.score
end

function PlayerInfoModel:setScore( score )
	if type(score) ~= "number" then return end
	self.score = score
end




return PlayerInfoModel

