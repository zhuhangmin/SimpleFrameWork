
local ShopItem = class("ShopItem", function()
	return ccui.Widget:create()
end)

function ShopItem:ctor(info,ctrl)
	self:setAnchorPoint(cc.p(0, 0))
	self:setContentSize(750, 250)

	--创建每一个横排条目
	for i = 1, #info do
		local node = require("FrameWork.game.ShopNode"):create(i, info[i],ctrl)
		node:setAnchorPoint(cc.p(0, 0))
		node:setPosition((i-1) * 200, 0)
		self:addChild(node)
		self:setTouchEnabled(false)
	end
end


return ShopItem
