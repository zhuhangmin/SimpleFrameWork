local EngineView = require "EngineView"
local FrontView = class("FrontView", EngineView)

function FrontView:ctor(node)
	FrontView.super.ctor(self, node)
end

return FrontView





