local EngineModel = require "EngineModel"
local ActivityModel = class("ActivityModel", EngineModel)

function ActivityModel:onCreate( data )
	ActivityModel.super.onCreate(self, data)
	self.curTag = 1
end


function ActivityModel:ctor(data)
	ActivityModel.super.ctor(self, data)
end

function ActivityModel:getNetData( )
	if isNil(ActivityData) then printStack() end
	if self.curTag == 1 then
		if isNil(ActivityData.ac) then printStack() end
		return ActivityData.ac
	elseif self.curTag == 2 then
		if isNil(ActivityData.ne) then printStack() end
		return ActivityData.ne
	end
end

function ActivityModel:getGiftData( )
	local netData = self:getNetData()
	if isNil(netData) then printStack() end
	if isNil(netData.gifts) then printStack() end
	return netData.gifts
end

function ActivityModel:getIsReceived( i )
	local netData = self:getNetData()
	if isNil(netData) then printStack() end
	if notNumber(netData.signed) then printStack() end
	return netData.signed >= i
end

function ActivityModel:getIsSignDay( i )
	local netData = self:getNetData()
	if isNil(netData) then printStack() end
	if notNumber(netData.signed) then printStack() end
	local flag = false
	if netData.able == 1 and netData.signed + 1 == i then
		flag = true
	end
	return flag
end

function ActivityModel:getAnimeFlag( i )
	local netData = self:getNetData()
	if isNil(netData) then printStack() end
	if notNumber(netData.signed) then printStack() end
	return netData.signed + 1 == i
end

function ActivityModel:initFormData( data )
	if isNil(data) then printStack() end
	local netData = self:getNetData()
	if isNil(netData) then printStack() end
	if self.curTag == 1 then
		data.func = "setAcSign"
		data.params = {sign_id = netData.signed+1}
	else
		data.func = "setNeSign"
		data.params = {sign_id = netData.signed+1}
	end
end

function ActivityModel:getCanReceive(  )
	local netData = self:getNetData()
	if notNumber(netData.able) then printStack() end
	return netData.able == 1
end

function ActivityModel:getRedData( i )
	if ActivityData.ac and ActivityData.ne then
		if i == 1 then
			return ActivityData.ac.able == 1 
		elseif i == 2 then
			return ActivityData.ne.able == 1 
		elseif i == 3 then
			return canUserConvert()
		end
	end
end


function ActivityModel:onEnter( data )
	-- self.netData = data
end


return ActivityModel; 