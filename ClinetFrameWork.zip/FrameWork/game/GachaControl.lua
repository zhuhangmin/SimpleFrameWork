local EngineControl = require  "EngineControl"
local GachaControl = class("GachaControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
	GameMsg.MSG_DO_GACHA_AGAIN,
	GameMsg.MSG_DO_GACHA_DOUBLE,
	GameMsg.MSG_DO_GACHA
}

--SYSTEM MSGS
local BTN_RETURN = "Button_return"
local BTN_HELP = "Button_help"
local BTN_DRAW = "Button_draw"
local PANEL_STARDRAW = "Panel_star_draw"
local PANEL_DIAMOND1 = "Panel_diamond1_draw"
local PANEL_DIAMOND5 = "Panel_diamond5_draw"
local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_HELP,
	BTN_DRAW,
	PANEL_STARDRAW,
	PANEL_DIAMOND1,
	PANEL_DIAMOND5
}

local TEXT_FREE = "免  费"
local TEXT_GACHA = "点击扭蛋"
local TITLE_LUCKY = "本次必得皮肤"
local TITLE_VERYLUCKY = "本次必得珍稀皮肤"
local TEXT_REMARK= "Text_need_amount"
local SPRITE_TITLE = "Sprite_title"
local SPRITE_NEED = "Sprite_need"
local PANEL_GET1 = "Panel_get1"
local PANEL_GET2 = "Panel_get2"
local SPRITE_CONSUME= "Sprite_text_consume"
local GACHA_CONFIRM = GachaControl:getConfigField("tips", "GACHA_CONFIRM", "content")

local gachaType = {"STAR","DIAMOND","FIVE_DIAMOND"}

function GachaControl:ctor(model, view)
	GachaControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function GachaControl:onCreate(param)
	GachaControl.super.onCreate(self, param)
	if isNil(param) then printStack() end
	-- local csbNode = self:getChildNode(CSB_NODE)

	local name = "game.Riches"
	self:addPanel(name)

	self:init()
end

function GachaControl:init()
	local UIList = {}

	UIList[1] = {}
	UIList[1].panel = self:getChildNode(PANEL_STARDRAW)
	if isNil(UIList[1].panel) then printStack() return end
	
	UIList[2] = {}
	UIList[2].panel = self:getChildNode(PANEL_DIAMOND1)
	if isNil(UIList[2].panel) then printStack() return end

	UIList[3] = {}
	UIList[3].panel = self:getChildNode(PANEL_DIAMOND5)
	if isNil(UIList[3].panel) then printStack() return end

	local node = {"Node_star","Node_diamond1","Node_diamond5"}
	local lucky_node = {"Node_lucky","Node_lucky","Node_lucky_0"}
	for i = 1, 3, 1 do
		if UIList[i].panel then 
			if UIList[i].panel:getChildByName(BTN_DRAW) then
				UIList[i].btn = UIList[i].panel:getChildByName(BTN_DRAW)
				UIList[i].btn:addTouchEventListener(handler(self, self.touchCB))
				UIList[i].btn:setTag(i)
				UIList[i].node = UIList[i].panel:getChildByName(node[i])
				UIList[i].lnode = UIList[i].panel:getChildByName(lucky_node[i]) 
			end
			self:getModel():setUIList(UIList)

			self:addBoxAnime(i)
		end
	end

	self:refreshView()
end


function GachaControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:send(BASE_MSG.POP)
	end

	if senderName == BTN_HELP then
		self:helpEvent()
	end

	if senderName == BTN_DRAW then
		self:gachaClickEvent(sender)
	end

	if senderName == PANEL_STARDRAW then
		local param = {modelParam = {dropType = "STAR_GACHA"}}
		self:addPop("game.CultureDes",param)
	end

	if senderName == PANEL_DIAMOND1 then
		local param = {modelParam = {dropType = "DIAMOND_GACHA"}}
		self:addPop("game.CultureDes",param)
	end

	if senderName == PANEL_DIAMOND5 then
		local param = {modelParam = {dropType = "FIVE_D_GACHA"}}
		self:addPop("game.CultureDes",param)
	end
end

function GachaControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

	if name == GameMsg.MSG_DO_GACHA_AGAIN then
		self:getModel():setAgain(true)
		self:sendGacha()
		return
	end

	if name == GameMsg.MSG_DO_GACHA_DOUBLE then
		self:sendGachaDouble()
		return
	end

	if name == GameMsg.MSG_DO_GACHA then
		self:refreshView()
		self:rewardAnime(data)
		return
	end
end

function GachaControl:addBoxAnime( i )
	local UIList = self:getModel():getUIList()
	if isNil(UIList) then printStack() return end

	local j = i
	if j == 3 then
		j = 5
	end
	local anime = cc.CSLoader:createNode("res/gamecocosstudio/csb/jiangchi_"..j.."_"..j..".csb")
	UIList[i].node:addChild(anime)
	local action = cc.CSLoader:createTimeline("res/gamecocosstudio/csb/jiangchi_"..j.."_"..j..".csb")
	anime:runAction(action)
	action:gotoFrameAndPlay(0, 0, false)
	local data = GachaData[gachaType[i]]
	local anime2 = cc.CSLoader:createNode("res/gamecocosstudio/csb/jiangchi_3_3.csb")
	UIList[i].lnode:addChild(anime2)
	local action2 = cc.CSLoader:createTimeline("res/gamecocosstudio/csb/jiangchi_3_3.csb")
	anime2:runAction(action2)

	local anime3 = cc.CSLoader:createNode("res/gamecocosstudio/csb/jiangchi_4_4.csb")
	UIList[i].lnode:addChild(anime3)
	local action3 = cc.CSLoader:createTimeline("res/gamecocosstudio/csb/jiangchi_4_4.csb")
	anime3:runAction(action3)
	action3:gotoFrameAndPlay(0, 39, true)
	
	local boxAnime = self:getModel():getBoxAnime()
	if isNil(boxAnime) then printStack() return end
	if data.des == TITLE_LUCKY or data.des == TITLE_VERYLUCKY then
		boxAnime[i] = action2
	else
		boxAnime[i] = action
	end
	self:getModel():setBoxAnime(boxAnime)


	local boxAnime1 = self:getModel():getBoxAnime1()
	if isNil(boxAnime1) then printStack() return end

	boxAnime1[i] = action
	self:getModel():setBoxAnime1(boxAnime1)

	local boxAnime2 = self:getModel():getBoxAnime2()
	if isNil(boxAnime2) then printStack() return end

	boxAnime2[i] = action2
	self:getModel():setBoxAnime2(boxAnime2)
end

function GachaControl:refreshView(  )--通过接收到的数据刷新ui
	local UIList = self:getModel():getUIList()
	if isNil(UIList) then printStack() return end

	local boxAnime = self:getModel():getBoxAnime()
	if isNil(boxAnime) then printStack() return end

	local boxAnime1 = self:getModel():getBoxAnime1()
	if isNil(boxAnime1) then printStack() return end

	local boxAnime2 = self:getModel():getBoxAnime2()
	if isNil(boxAnime2) then printStack() return end

	if isNil(GachaData) then printStack() return end

	for i = 1 , 3 , 1 do
		local panel = UIList[i].panel
		local data = GachaData[gachaType[i]]

		local text_num = panel:getChildByName(TEXT_REMARK)
		if text_num then
			text_num:setString(data.cost)

			local btn = panel:getChildByName(BTN_DRAW)
			if isNil(btn) then printStack() return end

			local animeBtn = btn:getChildByTag(99)
			if animeBtn then
				btn:removeChildByTag(99)
			end
			if data.des == TITLE_LUCKY or data.des == TITLE_VERYLUCKY then
				boxAnime[i] = boxAnime2[i]
				UIList[i].node:setVisible(false)
				UIList[i].lnode:setVisible(true)
				btn:setScale(1.2)
				btn:loadTextureNormal("tongyong/btn_huang1.png", ccui.TextureResType.plistType)
				btn:loadTexturePressed("tongyong/btn_huang2.png", ccui.TextureResType.plistType)
				local action,anime = addCommonAnime(btn,"mj_choujiang_1_1")
				action:gotoFrameAndPlay(0, 19, true)
			else
				boxAnime[i] = boxAnime1[i]
				UIList[i].node:setVisible(true)
				UIList[i].lnode:setVisible(false)
				btn:setScale(1)
				btn:loadTextureNormal("tongyong/btn_lan1.png", ccui.TextureResType.plistType)
				btn:loadTexturePressed("tongyong/btn_lan2.png", ccui.TextureResType.plistType)
			end
			if getItemCountById(data.coupon) > 0 then
				btn:setTitleText(TEXT_FREE)
			else
				btn:setTitleText(TEXT_GACHA)
			end

			local sprite_need = panel:getChildByName(SPRITE_NEED)
			if isNil(sprite_need) then printStack() return end
			self:setCoinIcon(sprite_need,i,text_num)

			if i ~= 1 then
				local Panel_get1 = panel:getChildByName(PANEL_GET1)
				if isNil(Panel_get1) then printStack() return end

				local Panel_get2 = panel:getChildByName(PANEL_GET2)
				if isNil(Panel_get2) then printStack() return end

				local timeStr = GachaData[gachaType[i]].icon
				local split = string.split(timeStr,"_")
				if isNil(split[1]) then printStack() return end

				if split[1] == "normal" then
					if tonumber(split[2]) == 0 then
						Panel_get1:setVisible(false)
						Panel_get2:setVisible(true)

						local text = Panel_get2:getChildByName("text_get")
						text:setString("必得萌菌")
					else
						Panel_get1:setVisible(true)
						Panel_get2:setVisible(false)

						local textTime = Panel_get1:getChildByName("text_need_time")
						textTime:setString(split[2].."次")
					end
				elseif split[1] == "rare" then
					Panel_get1:setVisible(false)
					Panel_get2:setVisible(true)

					local text = Panel_get2:getChildByName("text_get")
					text:setString("必得珍稀萌菌")
				end
			end
		end
	end
end

function GachaControl:setCoinIcon(sprite,tag,text)
    local starID = self:getConfigField("global",1,"STAR_ITEM_ID")
    if isNil(starID) then printStack() return end

    local diamondID = self:getConfigField("global",1,"DIAMOND_ITEM_ID")
    if isNil(diamondID) then printStack() return end

	local couponID = GachaData[gachaType[tag]].coupon
	local count = getItemCountById(couponID)

	local iconID = starID
	if count >0 then
		iconID = GachaData[gachaType[tag]].coupon
		text:setString(count)
	else
		if tag ~= 1 then
			iconID = diamondID
		end
	end

	setIconById(sprite, iconID )

	local UIList = self:getModel():getUIList()
	if isNil(UIList) then printStack() return end

    local panel = UIList[tag].panel

    local sprite_text_consume = panel:getChildByName(SPRITE_CONSUME)
    if isNil(sprite_text_consume) then printStack() return end

    if count >0 then
    	sprite_text_consume:setSpriteFrame("td/td_txt8.png")
    else
    	sprite_text_consume:setSpriteFrame("td/td_txt1.png")
    end
end

function GachaControl:rewardAnime(data)
	local tag = self:getModel():getGachaTag()
	if notNumber(tag) then printStack() return end

	local param = {modelParam = {rewardData = data,type = tag,gachaType = gachaType[tag]}}
	self:addPop("game.GachaReward",param)
end

function GachaControl:gachaClickEvent(sender)
	local tag = sender:getTag()
	if notNumber(tag) then printStack() return end

	local canFlag = self:getModel():getCanFlag()
	if isNil(canFlag) then printStack() return end

	if canFlag then
		self:getModel():setGachaTag(tag)
		if tag > 1 then
			local useCointype = self:judgeUseCoin()
			if useCointype == 1 then --没有券弹出提示
				local strTable = { "星星" ,"钻石" ,"钻石" }
				local contentStr = string.format(GACHA_CONFIRM,GachaData[gachaType[tag]].cost..strTable[tag])
				local confirmCB = function()
					self:sendGacha()
				end
				local cancelCB = function() end
				self:addMsgBox(contentStr, confirmCB, cancelCB)
			else
				self:sendGacha()
			end
		else
			self:sendGacha()
		end
	end
end

function GachaControl:helpEvent()
	local helpLayer = require("FrameWork.game.GachaRuleLayer"):create()
	self:getNode():addChild(helpLayer)
end

function GachaControl:sendGachaDouble(  )
	self:getModel():setCanFlag(false)

	local action1 = cc.DelayTime:create(2.1)
	local action2 = cc.CallFunc:create(function()
		self:getModel():setCanFlag(true)
	end)
	local action3 = cc.Sequence:create(action1, action2)
	self:getNode():runAction(action3)

	--sendMsg
	local data ={}
	data.func = "gachaDouble"
	self:send(BASE_MSG.NET_FORM_WAIT, data)
end


function GachaControl:sendGacha()
	local tag = self:getModel():getGachaTag()
	if notNumber(tag) then printStack() return end

	local boxAnime = self:getModel():getBoxAnime()
	if isNil(boxAnime) then printStack() return end

	if tag < 4 and tag > 0 then
		local gachatype = self:judgeUseCoin()
		if gachatype == 1 then -- 1 ：消耗星星钻石抽取，2：消耗奖券抽取
			local type_cost = 1
			if tag == 2 or tag == 3 then--type 1 为星星， 2，3 为钻石
				type_cost = 2 
			end
			local flag = buyJudgement(type_cost , GachaData[gachaType[tag]].cost)
			if flag then
				if boxAnime[tag] then
					boxAnime[tag]:gotoFrameAndPlay(0, 39, false)
					SoundManager:playEffect("egg.mp3")
				end
				self:doGachaSend()
			end
		else
			if boxAnime[tag] then
				boxAnime[tag]:gotoFrameAndPlay(0, 39, false)
				SoundManager:playEffect("egg.mp3")
			end
			self:doGachaSend()
		end
	else
		print("test : tag error not in 1--3")
	end
end

function GachaControl:sendDoGachaMsg()
	local tag = self:getModel():getGachaTag()
	if notNumber(tag) then printStack() return end

	local data ={}
	data.func = "executeGacha"
	data.params = {gacha_type = gachaType[tag]}
	self:send(BASE_MSG.NET_FORM_WAIT, data)

	self:getModel():setAgain(false)
end

function GachaControl:doGachaSend()
	local again = self:getModel():getAgain()

	if not again then
		self:getModel():setCanFlag(false)
		local action1 = cc.DelayTime:create(0.5)
		local action2 = cc.CallFunc:create(function()
			self:sendDoGachaMsg()
		end)
		local action3 = cc.DelayTime:create(1.6)
		local action4 = cc.CallFunc:create(function()
			self:getModel():setCanFlag(true)
		end)
		local action5 = cc.Sequence:create(action1, action2,action3,action4)
		self:getNode():runAction(action5)
	else
		self:sendDoGachaMsg()
	end
end

function GachaControl:judgeUseCoin() --通过tag判断是否用券还是货币  1 ：消耗星星钻石抽取，2：消耗奖券抽取
	local tag = self:getModel():getGachaTag()
	if notNumber(tag) then printStack() return end

	if isNil(GachaData) then printStack() return end

	local couponID = GachaData[gachaType[tag]].coupon

	local count = getItemCountById(couponID)
	if count > 0 then
		return 2
	else
		return 1
	end
end

return GachaControl


