local EngineView = require "EngineView"
local PlayerInfoView = class("PlayerInfoView", EngineView)

PLAYER_CSB_NODE = 1000
PLAYER_RICH_NODE = 2000

function PlayerInfoView:ctor(csbNode)
	PlayerInfoView.super.ctor(self, csbNode)
end

function PlayerInfoView:onCreate(param)
	local csbNode = cc.CSLoader:createNode("res/Homepage.csb")
	self:getNode():addChild(csbNode)
	csbNode:setTag(PLAYER_CSB_NODE)
end

return PlayerInfoView





