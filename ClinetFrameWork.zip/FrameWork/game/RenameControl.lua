local EngineControl = require  "EngineControl"
local RenameControl = class("RenameControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
}

--SYSTEM MSGS
local BTN_RETURN = "Button_cancel"
local BTN_CONMFIRM = "Button_confirm"
local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_CONMFIRM
}


function RenameControl:ctor(model, view)
	RenameControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function RenameControl:onCreate(param)
	RenameControl.super.onCreate(self, param)
	if isNil(param) then printStack() end

	local TextField_rename = self:getChildNode("TextField_rename")
	if TextField_rename then
		TextField_rename:setVisible(false)
		local editBox_code = ccui.EditBox:create(TextField_rename:getContentSize(),"js/js_bg4.png")
		editBox_code:setPosition(TextField_rename:getPosition())
		editBox_code:setAnchorPoint(0.5,0.5)
		editBox_code.setTextColor = TextField_rename.setFontColor
		editBox_code:setFontColor(display.COLOR_BLACK)
		editBox_code:setFontSize(TextField_rename:getFontSize())
		editBox_code:setPlaceHolder(TextField_rename:getPlaceHolder())
		editBox_code:setPlaceholderFontSize(TextField_rename:getFontSize())
		editBox_code:setPlaceholderFontColor(display.COLOR_BLACK)
		editBox_code:setFontName(TextField_rename:getFontName())
        editBox_code:setContentSize(TextField_rename:getContentSize())
		self:getNode():addChild(editBox_code,0)
		editBox_code:setName("editBox_rename")
	end
end

function RenameControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:detachFromParent()
	end

	if senderName == BTN_CONMFIRM then
		local editBox_rename = self:getChildNode("editBox_rename")
		if isNil(editBox_rename) then printStack() return end

		local name = editBox_rename:getText()
		if name == "" then
			self:addTip("昵称不能为空")
		else
			name = string.urlencode(name)
			
			local params = {nickname = name}
			self:submitFormWait("setPlayerNickName", params)
			self:detachFromParent()
		end
	end
end

function RenameControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

return RenameControl


