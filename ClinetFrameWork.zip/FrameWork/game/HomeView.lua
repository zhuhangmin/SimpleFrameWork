local EngineView = require "EngineView"
local HomeView = class("HomeView", EngineView)

local csbFilePath = "res/Main.csb"

MAIN_CSB_NODE = 1000
RICH_NODE = 2000
GACHA_NODE = 3000
MENU_NODE = 4000

function HomeView:ctor(node)
	HomeView.super.ctor(self, node)
end

function HomeView:onCreate(param)
	HomeView.super.onCreate(self, param)

	local node = cc.CSLoader:createNode(csbFilePath)
	if isNil(node) then printStack() return end
	self:getNode():addChild(node)
	node:setTag(MAIN_CSB_NODE)

end

return HomeView





