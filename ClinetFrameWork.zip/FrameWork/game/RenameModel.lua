local EngineModel = require "EngineModel"
local RenameModel = class("RenameModel", EngineModel)

function RenameModel:ctor(data)
	RenameModel.super.ctor(self, data)
end

function RenameModel:onCreate(param)
	RenameModel.super.onCreate(self, param)
end

return RenameModel

