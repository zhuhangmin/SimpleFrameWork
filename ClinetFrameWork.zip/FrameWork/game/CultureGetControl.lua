local EngineControl = require  "EngineControl"
local CultureGetControl = class("CultureGetControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
}

--SYSTEM MSGS
local BTN_RETURN = "Panel_1"
local BTN_CHECK = "Button_Check_Culture"
local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_CHECK
}


function CultureGetControl:ctor(model, view)
	CultureGetControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function CultureGetControl:onCreate(param)
	CultureGetControl.super.onCreate(self, param)
	if isNil(param) then printStack() end

	local itemID = self:getModel():getItemID()
	if isNil(itemID) then printStack() return end

	local itmeInfo = self:getConfigRecord("item",itemID)
	if isNil(itmeInfo) then printStack() return end

	local text_Culture = self:getChildNode("Text_Culture")
	if isNil(text_Culture) then printStack() return end
	local itemInfo = self:getConfigRecord("item",itemID)
	if itemInfo then
		text_Culture:setString(itemInfo.name)
	end

	local aniName = "huodelingye_"..(itemID-60000)
	local armatureNode = self:getChildNode("Node_culture_animation")
	if isNil(armatureNode) then printStack() return end
	local armature = ccs.Armature:create("huodelingye")
	armature:getAnimation():play(aniName, -1, 0)
	armatureNode:addChild(armature)
end

function CultureGetControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:detachFromParent()
	end

	if senderName == BTN_CHECK then
		self:detachFromParent()
		self:send(GameMsg.MSG_GOTO_CULTUREROOM)
	end
end

function CultureGetControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

return CultureGetControl


