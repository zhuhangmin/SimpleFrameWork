local EngineControl = require  "EngineControl"
local AdControl = class("AdControl", EngineControl)
local ADManager = require("advertise.ADManager"):getInstance()
--LUA MSGS
local LUA_MSGS = {
	GameMsg.SHOW_AD_CLOSE,
	GameMsg.DO_LOTTERY,
	-- GameMsg.SHOW_AD_LOOK_BTN,
	GameMsg.SHOW_AD_LOOT_BTN,
}


local SHOW_TIME = 0.8
local ACCERELATION = 0.2


--SYSTEM MSGS
local IMG_REWARD = "Node_item"
local TEXT_NUM = "BitmapFontLabel_Count"
local TEXT_NAME = "Text_name"
local KEY_REWARD = "reward%d"
local KEY_NUM = "num%d"
local BTN_CLOSE = "Button_close"
local BTN_LOOK  = "Button_Ad"
local BTN_SLOT  = "Button_Slot"
local REWARD_NODE_LIST = {
	"Node_reward1",
	"Node_reward2",
	"Node_reward3",
	"Node_reward4",
	"Node_reward5",
	"Node_reward6",
	"Node_reward7",
	"Node_reward8",
	"Node_reward9",
	"Node_reward10",
}



local SYSTEM_MSGS = {
	BTN_CLOSE,
	BTN_LOOK,
	BTN_SLOT,
}


function AdControl:ctor(model, view)
	AdControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)
end

function AdControl:onCreate(param)
	AdControl.super.onCreate(self, param)
end

function AdControl:onEnter(param)
	AdControl.super.onEnter(self, param)
	self:initUi()
end

function AdControl:initUi()
	for index = 1, 10 do
		local gift_id = self:getConfigField("AD", index ,"gift_pack")
		if isNil(gift_id) then printStack() end
		
		local giftInfo = self:getConfigRecord("giftPack", gift_id)
		if isNil(giftInfo) then printStack() end	
		for i=1,1 do
			local keyReward = string.format(KEY_REWARD,i)
			if notNumber(giftInfo[keyReward]) then printStack() return end

			local keyNum = string.format(KEY_NUM,i)
			if notNumber(giftInfo[keyNum]) then printStack() return end

			local itemID = giftInfo[keyReward]
			local itemNum = giftInfo[keyNum]
			if itemID~=0 and itemNum~=0 then
				local panel  = self:getChildNode(REWARD_NODE_LIST[index])
				local imgReward = panel:getChildByName(IMG_REWARD)
				if isNil(imgReward) then printStack() end
				addItmeNode(imgReward,itemID)

				local name = getItemNameByID(itemID)
			 	panel:getChildByName(TEXT_NAME):setString(name)
				panel:getChildByName(TEXT_NUM):setString("x"..itemNum)
				panel:getChildByName(TEXT_NUM):setScale(0.6)
			end
		end
	end
	self:showIndex(0)
	self:updateBtn()
end

function AdControl:playAnime( tar_index )
	local now_index = self:getModel():getShowIndex()
	local step_add = self:getModel():getStep()
	local step =  tar_index - now_index + step_add
	local time_list = {}
	local time = SHOW_TIME
	time_list[1] = time
	for i = 2, step , 1 do
		time = time/(1+ACCERELATION)
		table.insert(time_list,time)
	end

	local function callFunc( node )
	    self:getModel():addShowIndex()
	    local index = self:getModel():getShowIndex()
	    self:showIndex(index)
    end
    local function endCallFunc( node )
	   self:popReward(tar_index)
    end
 	local animArr = {}
	for i = step, 1 , -1 do
		table.insert(animArr, cc.DelayTime:create(time_list[i]))
	 	table.insert(animArr, cc.CallFunc:create(callFunc))
	end
	table.insert(animArr, cc.CallFunc:create(endCallFunc))
	self:getNode():runAction(cc.Sequence:create(animArr))



end

function AdControl:popReward( index )
	local gift_id = self:getConfigField("AD", index ,"gift_pack")
	local giftInfo = self:getConfigRecord("giftPack", gift_id)
	local rewardData = {}
	for i=1,7 do
		local itemID = giftInfo["reward"..i]
		local itemNum = giftInfo["num"..i]
		if itemID~=0 and itemNum~=0 then
			table.insert(rewardData,{item_id=itemID ,item_num=itemNum})
		end
	end

	local name = "game.GetAwards"
	local param = {modelParam = {rewardData = rewardData}}
	self:addPop(name,param)
end

function AdControl:showIndex( index )
	for i = 1, 10 , 1 do
		local node = self:getChildNode(REWARD_NODE_LIST[i])
		local light = node:getChildByName("Image_light")
		if i == index then
			light:setVisible(true)
		else
			light:setVisible(false)
		end
	end
end


function AdControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_CLOSE then
		self:detachFromParent()
		return
	end

	if senderName == BTN_SLOT then
		local data ={}
		data.func = "lottery"
		data.params = {}
		self:send(BASE_MSG.NET_FORM_WAIT, data)
	end

	if senderName == BTN_LOOK then
		local data ={}
		data.func = "ADEventTracking"
		data.params = {event_name = "beg_ad"}
		self:send(BASE_MSG.NET_FORM, data)
		ADManager:showAd()
		-- self:playAnime()
	end

end

function AdControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

	if name == GameMsg.SHOW_AD_CLOSE then
		local data ={}
		data.func = "ADPlayEnd"
		data.params = {}
		self:send(BASE_MSG.NET_FORM_WAIT, data)

		local data ={}
		data.func = "ADEventTracking"
		data.params = {event_name = "end_ad"}
		self:send(BASE_MSG.NET_FORM, data)
	end

	if name == GameMsg.DO_LOTTERY then
		local netdata ={}
		netdata.func = "ADEventTracking"
		netdata.params = {event_name = "ad_reward"}
		self:send(BASE_MSG.NET_FORM, netdata)
		self:playAnime(data.index)
	end

	if name == GameMsg.SHOW_AD_LOOT_BTN then
		self:updateBtn()
	end
end

function AdControl:updateBtn( )
	if PlayerData_AD_show_loot_btn then
		self:getChildNode(BTN_SLOT):setVisible(true)
		self:getChildNode(BTN_LOOK):setVisible(false)
	else
		self:getChildNode(BTN_SLOT):setVisible(false)
		self:getChildNode(BTN_LOOK):setVisible(PlayerData_AD_show_look_btn)
	end
end

return AdControl


