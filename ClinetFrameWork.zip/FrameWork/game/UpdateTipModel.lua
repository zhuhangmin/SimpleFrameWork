local EngineModel = require "EngineModel"
local UpdateTipModel = class("UpdateTipModel", EngineModel)

function UpdateTipModel:ctor(data)
	UpdateTipModel.super.ctor(self, data)
end

function UpdateTipModel:onCreate(param)
	UpdateTipModel.super.onCreate(self, param)
end

return UpdateTipModel

