local EngineModel = require "EngineModel"
local CultureGetModel = class("CultureGetModel", EngineModel)

function CultureGetModel:ctor(data)
	CultureGetModel.super.ctor(self, data)

	self.itemID = 0
end

function CultureGetModel:onCreate(param)
	CultureGetModel.super.onCreate(self, param)

	if notNumber(param.item_id) then printStack() return end
	self:setItemID(param.item_id)
end

function CultureGetModel:setItemID(itemID)
	self.itemID = itemID
end

function CultureGetModel:getItemID()
	return self.itemID
end

return CultureGetModel

