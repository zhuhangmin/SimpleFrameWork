
local SkinNode = class("SkinNode", function()
	return cc.CSLoader:createNode("res/SkinitemList.csb")
end)

function SkinNode:ctor(type, lineIndex, index, skinInfo,ctrl)
	self.type = type
	self.lineIndex = lineIndex
	self.index = index
	self.skinInfo = skinInfo
	self.skinIndex = skinInfo.skinIndex

	self.state = nil
	self.count = -1
	self.cost = -1

	self.ctrl = ctrl

	self:init()
	self:updateInfo()
end

function SkinNode:init()
	--正在使用
	self.useImage = self:getChildByName("Sprite_tag_using")

	self.panel_star = self:getChildByName("Panel_star")
	self.panel_star:setVisible(false)
	self.panel_quality = self:getChildByName("Panel_quality")
	self.panel_quality:setVisible(false)
	self.sprite_tag_syn = self:getChildByName("Sprite_tag_syn")
	if self.type ~= 1 and self.skinInfo.issyn == 1 then
		self.sprite_tag_syn:setVisible(true)
	else
		self.sprite_tag_syn:setVisible(false)
	end
	self.image_light = self:getChildByName("Image_light")
	--使用中
	if self.type == 1 and self.skinInfo.isuse == 1 then
		self.useImage:setVisible(true)
		self.image_light:setVisible(true)
		self.ctrl:getModel():setCurClickNode(self)
	else
		self.useImage:setVisible(false)
		self.image_light:setVisible(false)
	end
	
	self.text_skin_name = self:getChildByName("Text_skin_name")
end

function SkinNode:updateInfo()
    local itemConfig = self.ctrl:getTable("item")
    if isNil(itemConfig) then printStack() return end

    local synthesisConfig = self.ctrl:getTable("synthesis")
    if isNil(synthesisConfig) then printStack() return end

	local data = self.skinInfo

	local itemInfo = itemConfig[self.skinIndex]
	if isNil(itemInfo) then printStack() return end

	--名字
	self.text_skin_name:setString(itemInfo.name)

	--头像
	local headImage = self:getChildByName("Image_skin")
	local headSize = headImage:getContentSize()
	headImage:setTouchEnabled(true)
	headImage:addTouchEventListener(handler(self, self.clickHead))
	setImgIconById(headImage, self.skinIndex )
	headImage:ignoreContentAdaptWithSize(true)
	headImage:setScale(0.7)
	headImage:setSwallowTouches(false)

	--星级
	local panel_quality = self:getChildByName("Panel_quality")
	local panel_star = self:getChildByName("Panel_star")
	if isNewRole(self.skinIndex) then
	    panel_quality:setVisible(false)
	    panel_star:setVisible(true)
	    for i = 1,4 do
	        local Sprite_level_bg = panel_star:getChildByName("Sprite_level"..i.."_bg")
	        local Sprite_level = panel_star:getChildByName("Sprite_level"..i)

	        if i <= getskinlevel(self.skinIndex) then
	            Sprite_level_bg:setVisible(false)
	            Sprite_level:setVisible(true) 
	        else
	            Sprite_level_bg:setVisible(true)
	            Sprite_level:setVisible(false)
	        end
	        setLocalSpriteFrame(Sprite_level_bg,"jsjm/pf_bg_zc_xing.png")
	    end
	else
	    panel_quality:setVisible(true)
	    panel_star:setVisible(false)
        if itemInfo.quality then
            local node = panel_quality:getChildByName("Sprite_level")
            local path = "jsjm/pf_txt"..itemInfo.quality..".png"
            setLocalSpriteFrame(node,path)
        end 
	end
end

function SkinNode:clickHead(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended then
		local lastNode = self.ctrl:getModel():getCurClickNode()
		if lastNode and lastNode.image_light then
			lastNode.image_light:setVisible(false)
		end

		self.ctrl:getModel():setCurClickNode(self)
		self.image_light:setVisible(true)

		local skinIndex = self.skinIndex
		local skindata = {id = skinIndex,count = self.skinInfo.count}
		self.ctrl:onClickItem(skindata,skinIndex)

		SoundManager:playEffect("button.mp3")
	end
end

return SkinNode
