local EngineModel = require "EngineModel"
local MatchingPeerModel = class("MatchingPeerModel", EngineModel)

function MatchingPeerModel:ctor(data)
	MatchingPeerModel.super.ctor(self, data)
	self.time = 1
	self.count = 1
	self.interval = 60
	self.player_count = 1
	self.player_total = 30
end

function MatchingPeerModel:onCreate( data )
	MatchingPeerModel.super.onCreate(self, data)
end

function MatchingPeerModel:getTime()
	return self.time
end

function MatchingPeerModel:setTime(time)
	self.time = time
end

function MatchingPeerModel:getPlayerCount()
	return self.player_count
end

function MatchingPeerModel:setPlayerCount(p)
	self.player_count = p
end

function MatchingPeerModel:getPlayerTotal()
	return self.player_total
end

function MatchingPeerModel:setPlayerTotal(t)
	self.player_total = t
end

function MatchingPeerModel:getCount()
	return self.count
end

function MatchingPeerModel:setCount(count)
	self.count = count
end

function MatchingPeerModel:getInterval()
	return self.interval
end


function MatchingPeerModel:setInterval(interval)
	self.interval = interval
end

return MatchingPeerModel; 