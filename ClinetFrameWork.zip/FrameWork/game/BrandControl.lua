local EngineControl = require  "EngineControl"
local BrandControl = class("BrandControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
}

--SYSTEM MSGS
-- local BTN_RETURN = "Button_return"
local SYSTEM_MSGS = {
	-- BTN_RETURN,
}

--NODE TAG
local IMG_BRAND = "IMG_BRAND"
local DEFAULT_BRAND_PATH = "res/logo_channel.png"
local TCY_BRAND_PATH = "res/logo_tcy.png"

function BrandControl:ctor(model, view)
	BrandControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)
end

function BrandControl:onCreate(param)
	BrandControl.super.onCreate(self, param)

	local imageName = DEFAULT_BRAND_PATH
	if Utils:isTcyChannel() then
		imageName = TCY_BRAND_PATH
	end

	local color = cc.c4b(255, 255, 255, 255)
	local layer = cc.LayerColor:create(color)
	self:getNode():addChild(layer)

	local image = cc.Sprite:create(imageName)
	image:setPosition(gScreenSize.width / 2, gScreenSize.height / 2)
	self:getNode():addChild(image)
	image:setName(IMG_BRAND)

	local action1 = cc.DelayTime:create(0.5)
	local action2 = cc.FadeOut:create(1)
	local action3 = cc.CallFunc:create(function()
		local data = {}
		data.name = "game.Loading"
		self:send(BASE_MSG.PUSH, data)
	end)

	local seq = cc.Sequence:create(action1, action2, action3)
	self:getNode():runAction(seq)
end


return BrandControl


