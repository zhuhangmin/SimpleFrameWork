local EngineView = require "EngineView"
local GetAwardsView = class("GetAwardsView", EngineView)

local csbFilePath = "res/RewardReceive.csb"
GETAWARDS_CSB_NODE = 1000

function GetAwardsView:ctor(node)
	GetAwardsView.super.ctor(self, node)
end

function GetAwardsView:onCreate(param)
	GetAwardsView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	if isNil(csbNode) then printStack() return end
	
	csbNode:setTag(GETAWARDS_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return GetAwardsView





