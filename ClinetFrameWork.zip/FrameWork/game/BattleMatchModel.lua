local EngineModel = require "EngineModel"
local MatchingModel = class("MatchingModel", EngineModel)

function MatchingModel:ctor(data)
	MatchingModel.super.ctor(self, data)
	self.time = 1
	self.count = 1
	self.interval = 60
end

function MatchingModel:onCreate( data )
	MatchingModel.super.onCreate(self, data)
end

function MatchingModel:getTime()
	return self.time
end

function MatchingModel:setTime(time)
	self.time = time
end

function MatchingModel:getCount()
	return self.count
end

function MatchingModel:setCount(count)
	self.count = count
end

function MatchingModel:getInterval()
	return self.interval
end

function MatchingModel:setInterval(interval)
	self.interval = interval
end

return MatchingModel; 