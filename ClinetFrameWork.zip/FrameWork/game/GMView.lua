local EngineView = require "EngineView"
local GMView = class("GMView", EngineView)

local csbFilePath = "res/GM_Layer.csb"
-- local csbFilePath = "res/DiamondStar.csb"

GM_CSB_NODE = 1000

function GMView:ctor(node)
	GMView.super.ctor(self, node)
end

function GMView:onCreate(param)
	GMView.super.onCreate(self, param)
	local csbNode = cc.CSLoader:createNode(csbFilePath)
	csbNode:setTag(GM_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return GMView





