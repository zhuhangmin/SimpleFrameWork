local EngineModel = require "EngineModel"
local PlayerInfoSetModel = class("PlayerInfoSetModel", EngineModel)

function PlayerInfoSetModel:ctor(data)
	PlayerInfoSetModel.super.ctor(self, data)
end

function PlayerInfoSetModel:onCreate(param)
	PlayerInfoSetModel.super.onCreate(self, param)
end

return PlayerInfoSetModel

