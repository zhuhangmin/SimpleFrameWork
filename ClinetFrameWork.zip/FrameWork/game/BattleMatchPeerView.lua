local EngineView = require "EngineView"
local MatchingPeerView = class("MatchingPeerView", EngineView)

function MatchingPeerView:ctor(node)
	MatchingPeerView.super.ctor(self, node)
end

function MatchingPeerView:onCreate(param)
	MatchingPeerView.super.onCreate(self, param)
	local csbNode = cc.CSLoader:createNode("res/GameStartTeam.csb")
	self:getNode():addChild(csbNode)

end


return MatchingPeerView;