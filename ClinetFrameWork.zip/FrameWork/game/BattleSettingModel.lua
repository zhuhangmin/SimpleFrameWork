local EngineModel = require "EngineModel"
local BattleSettingModel = class("BattleSettingModel", EngineModel)

function BattleSettingModel:onCreate( data )
	BattleSettingModel.super.onCreate(self, data)
end


function BattleSettingModel:ctor(data)
	BattleSettingModel.super.ctor(self, data)
end


return BattleSettingModel; 