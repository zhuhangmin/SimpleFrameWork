local EngineModel = require "EngineModel"
local BattleTeamOverModel = class("BattleTeamOverModel", EngineModel)

function BattleTeamOverModel:onCreate( data )
	BattleTeamOverModel.super.onCreate(self, data)
end


function BattleTeamOverModel:ctor(data)
	BattleTeamOverModel.super.ctor(self, data)
end

function BattleTeamOverModel:onEnter( data )
	self.team = nil
	self.voteData = {0,0,0,0,0}
	-- self.voteLock = {false,false,false,false,false}
	self.netData = data[1]
	dump(self.netData)
end

function BattleTeamOverModel:getTeamData( ... )
	local my_rank = self.netData.rank
	if self.team == nil then
		self.team = {}
		local count = 1
		for k , v in pairs(self.netData.alluser) do
			if v.rank == my_rank then
				if v.userid == PlayerDataBasic.id then
					self.team[1] = v
				else
					count = count + 1
					self.team[count] = v
				end
			end
		end
	end
	-- dump(self.team)
	return self.team
end

function BattleTeamOverModel:getRank( ... )
	return self.netData.rank
end

function BattleTeamOverModel:addVote( i )
	self.voteData[i] = self.voteData[i] + 1
end

function BattleTeamOverModel:getVoteNum( i )
	return self.voteData[i]
end

return BattleTeamOverModel; 