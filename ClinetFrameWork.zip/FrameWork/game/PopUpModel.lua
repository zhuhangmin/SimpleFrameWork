local EngineModel = require "EngineModel"
local PopUpModel = class("PopUpModel", EngineModel)

function PopUpModel:ctor(data)
	PopUpModel.super.ctor(self, data)
	self.contentStr = ""
	self.cancelBtnTitle = POPUP_CANCEL_TITLE
	self.confirmBtnTitle = POPUP_CONFIRM_TITLE
	self.cancelCB = nil
	self.confirmCB = nil
end

function PopUpModel:onCreate(param)
	PopUpModel.super.onCreate(self, param)
	self:setContentStr(param.contentStr)
	self:setCancelBtnTitle(param.cancelBtnTitle)
	self:setConfirmBtnTitle(param.confirmBtnTitle)
	self:setCancelCB(param.cancelCB)
	self:setConfitmCB(param.confirmCB)
end

function PopUpModel:setContentStr(contentStr)
	self.contentStr = contentStr or ""
end

function PopUpModel:setCancelBtnTitle(cancelBtnTitle)
	self.cancelBtnTitle = cancelBtnTitle or POPUP_CANCEL_TITLE
end

function PopUpModel:setConfirmBtnTitle(confirmBtnTitle)
	self.confirmBtnTitle = confirmBtnTitle or POPUP_CONFIRM_TITLE
end

function PopUpModel:setCancelCB(cancelCB)
	self.cancelCB = cancelCB or nil
end

function PopUpModel:setConfitmCB(confirmCB)
	self.confirmCB = confirmCB or nil
end

function PopUpModel:getContentStr(contentStr)
	return self.contentStr
end

function PopUpModel:getCancelBtnTitle(cancelBtnTitle)
	return self.cancelBtnTitle
end

function PopUpModel:getConfirmBtnTitle(confirmBtnTitle)
	return self.confirmBtnTitle
end

function PopUpModel:getCancelCB(cancelCB)
	return self.cancelCB
end

function PopUpModel:getConfitmCB(confirmCB)
	return self.confirmCB
end

return PopUpModel

