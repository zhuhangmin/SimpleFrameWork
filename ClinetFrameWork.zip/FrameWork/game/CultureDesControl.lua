local EngineControl = require  "EngineControl"
local CultureDesControl = class("CultureDesControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
}

--SYSTEM MSGS
local BTN_RETURN = "Button_close"
local SYSTEM_MSGS = {
	BTN_RETURN,
}

function CultureDesControl:ctor(model, view)
	CultureDesControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function CultureDesControl:onCreate(param)
	CultureDesControl.super.onCreate(self, param)
	if isNil(param) then printStack() end

	self:initAllAward()
end

function CultureDesControl:initAllAward()
	local dropType = self:getModel():getDropType()
	if isNil(dropType) then printStack() return end

	local dropPreviewConfig = self:getTable("dropPreview")
	if isNil(dropPreviewConfig) then printStack() return end

	local awards = {}
	for i,v in ipairs(dropPreviewConfig) do
		if v.drop_type == dropType then
			table.insert(awards,{item_id = v.drop_item})
		end
	end

	local list = self:getChildNode("ListView_1")
	if isNil(list) then printStack() return end
	list:removeAllChildren()

	local temp = {}
	local len = table.nums(awards)
	for i=1,len do
		temp[#temp + 1] = awards[i]

		local isCan = false

        if i % 6 == 0 then
            isCan = true
        end	

        if isCan then
            local item = require("FrameWork.game.CultureAwardItem"):create(temp)
            list:pushBackCustomItem(item)

            isCan = false
            temp = {}
        end	
	end

	if table.nums(temp)>0 then
        local item = require("FrameWork.game.CultureAwardItem"):create(temp)
        list:pushBackCustomItem(item)

        temp = {}
	end
end

function CultureDesControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:detachFromParent()
	end

end

function CultureDesControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

return CultureDesControl


