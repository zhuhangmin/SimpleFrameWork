local EngineControl = require  "EngineControl"
local CultureTipControl = class("CultureTipControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
}

--SYSTEM MSGS
local BTN_RETURN = "Button_cancel"
local BTN_CONFIRM = "Button_confirm"
local BTN_AGAIN = "Image_circle_bg"
local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_CONFIRM,
	BTN_AGAIN
}

function CultureTipControl:ctor(model, view)
	CultureTipControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function CultureTipControl:onCreate(param)
	CultureTipControl.super.onCreate(self, param)
	if isNil(param) then printStack() end

	local img_choose = self:getChildNode("Image_choose")
	if isNil(img_choose) then printStack() return end
	img_choose:setVisible(false)
end

function CultureTipControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:detachFromParent()

		SoundManager:playEffect("button.mp3")
		self:addPop("game.BattleMatch")
	end

	if senderName == BTN_AGAIN then
		local showAgain = self:getModel():getShowAgain()
		if isNil(showAgain) then printStack() return end

		showAgain = not showAgain

		local img_choose = self:getChildNode("Image_choose")
		if isNil(img_choose) then printStack() return end

		img_choose:setVisible(not showAgain)

		self:getModel():setShowAgain(showAgain)
	end

	if senderName == BTN_CONFIRM then
		self:detachFromParent()

	    local data = {}
		data.name = "game.CulturingRoom"
		self:send(BASE_MSG.PUSH, data)
	end
end

function CultureTipControl:onDestroy()
	CultureTipControl.super.onDestroy(self)
	local showAgain = self:getModel():getShowAgain()
	if not showAgain then
		local userDefault = cc.UserDefault:getInstance()
		userDefault:setIntegerForKey("SHOW_CULTURETIPS_TIME", os.time())
	end
end

function CultureTipControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

return CultureTipControl


