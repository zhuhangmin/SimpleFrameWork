local EngineControl = require  "EngineControl"
local MailControl = class("MailControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
	GameMsg.GET_MAIL_DATA,
	GameMsg.COLLECT_MAIL_REWARD,
}

--SYSTEM MSGS
local BTN_RETURN = "Button_return"
local BTN_RECEIVE= "Button_receive"
local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_RECEIVE,
}

local PANEL_MAILZERO = "Panel_mail_zero"
local LIST_VIEW = "ScrollView"
local TEXT_MAIL = "Text_mail"
local TEXT_TITLEMAIL = "Text_title_mail"
local PANEL_REWARD = "Panel_reward"
local PANEL_NO_REWARD = "Panel_no_reward"
local BTN_RECEIVED= "Button_received"
local CONFIG_MAILREWARD = "giftPack"
local CONFIG_GLOBAL = "global"
local CONFIG_ITEM = "item"
local IMG_REWARD = "Node_reward%d"
local NUM_REWARD = "reward%d_amount"
local KEY_REWARD = "reward%d"
local KEY_NUM = "num%d"
local PANEL_MAILNEW = "Panel_mail_new"

function MailControl:ctor(model, view)
	MailControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function MailControl:onCreate(param)
	MailControl.super.onCreate(self, param)
	if isNil(param) then printStack() end

	local name = "game.Riches"
	self:addPanel(name)

	self:onUpdataEvent()
end

function MailControl:onEnter(param)
	MailControl.super.onEnter(self, param)

end

function MailControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:send(BASE_MSG.POP)
	end

	if senderName == BTN_RECEIVE then
		local curIndex = self:getModel():getCurIndex()
		if notNumber(curIndex) then printStack() return end
		local mailID = MailData[curIndex].id
		self:submitFormWait("collectMailReward", {mailID = mailID})
		return
	end

	if senderName == PANEL_MAILNEW then
		local index = sender:getTag()
		self:getModel():setCurIndex(index)
		self:MailItemNodeClickEvent()
	end
end

function MailControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

	if name == GameMsg.GET_MAIL_DATA then
		self:onUpdataEvent()
		return
	end

	if name == GameMsg.COLLECT_MAIL_REWARD then
		local index = self:getModel():getCurIndex()
		if notNumber(index) then printStack() return end

		local mailInfo = MailData[index]
		if isNil(mailInfo) then printStack() return end

		local reward = self:getConfigRecord(CONFIG_MAILREWARD,mailInfo.reward)
		if isNil(reward) then printStack() return end

		local rewardData = {}
		for i=1,5 do
			local itemID = reward[string.format(KEY_REWARD,i)]
			if notNumber(itemID) then printStack() return end

			local itemNum = reward[string.format(KEY_NUM,i)]
			if notNumber(itemNum) then printStack() return end

			if itemID~=0 and itemNum~=0 then
				table.insert(rewardData,{item_id=itemID ,item_num=itemNum})
			end
		end

		local name = "game.GetAwards"
		local param = {modelParam = {rewardData = rewardData}}
		self:addPop(name,param)
		return
	end
end

function MailControl:onUpdataEvent()
	if isNil(MailData) then printStack() return end
	local model = self:getModel()
	--如果没有数据，显示无消息，无内容
	local count  = table.nums(MailData)
	if count > 0 then
		local panelMailZero = self:getChildNode(PANEL_MAILZERO)
		if isNil(panelMailZero) then printStack() return end
		panelMailZero:setVisible(false)

		local listView = self:getChildNode(LIST_VIEW)
		if isNil(listView) then printStack() return end
		listView:removeAllChildren()

		local itemNodes = {}
		for i=1,count do
			self:getMailContentByType(MailData[i])

			itemNodes[i] =  require("FrameWork.game.MailItemNode"):create(MailData[i])
			model:setItemNodes(itemNodes)

			listView:addChild(itemNodes[i])

			if count< 6 then
				itemNodes[i]:setPositionY( (itemNodes[i]._LoadMailItemNode:getContentSize().height+8) *  (5-count +i) ) 
			else
				itemNodes[i]:setPositionY( (itemNodes[i]._LoadMailItemNode:getContentSize().height+8) *  (i-1) ) 
			end
			itemNodes[i]:getPanelMail():setTag(i)
			itemNodes[i]:getPanelMail():addTouchEventListener(handler(self, self.touchCB))
			itemNodes[i]:getPanelMail():setSwallowTouches(false)
		end

		--默认显示第一条
		self:MailItemNodeClickEvent()

		local height = (itemNodes[1]._LoadMailItemNode:getContentSize().height+8) * count
		local content = listView:getContentSize()
		listView:setInnerContainerSize(cc.size(content.width, height))
	end
end

function MailControl:MailItemNodeClickEvent()
	local model = self:getModel()

	local index = model:getCurIndex()
	if notNumber(index) then printStack() return end

	local itemNodes = self:getModel():getItemNodes()
	if isNil(itemNodes) then printStack() return end
	if isNil(itemNodes[index]) then printStack() return end

	if isNil(MailData) then printStack() return end
	if isNil(MailData[index]) then printStack() return end 	

	self:setMailDetail(index)

	for i = 1,#itemNodes do
		if i == index then
			itemNodes[i]:setClickInfo()
		else
			itemNodes[i]:setInfo()
		end
	end

	if MailData[index].isread == 0 then
		self:submitFormWait("readMail", {mailID = MailData[index].id})
	end
end

function MailControl:setMailDetail(index)
	local data = MailData[index]
	if isNil(data) then printStack() return end

	local textMailTitle = self:getChildNode(TEXT_TITLEMAIL)
	if isNil(textMailTitle) then printStack() return end

	local panel_no_reward = self:getChildNode(PANEL_NO_REWARD)
	if isNil(panel_no_reward) then printStack() return end

	local textMailContent = panel_no_reward:getChildByName(TEXT_MAIL)
	if isNil(textMailContent) then printStack() return end

	local panelReward = self:getChildNode(PANEL_REWARD)
	if isNil(panelReward) then printStack() return end

	local textMailItem = panelReward:getChildByName(TEXT_MAIL)
	if isNil(textMailItem) then printStack() return end

	textMailTitle:setString(data.title)
	if haveReward(data.reward) then
		local content = data.content
		if data.type == 3 then--赛季奖励邮件
			local customJson = data.custom
			if customJson and string.len(customJson) > 0 then
				content = self:convertSeasonContent(content,customJson)
			end
		else
			content = self:convertRewardContent(content,data.reward)
		end
		textMailItem:setString(content)
		textMailItem:ignoreContentAdaptWithSize(false)
		panelReward:setVisible(true)
		textMailContent:setVisible(false)
		self:setRewards(data.reward)
	else
		local customJson = data.custom
		if customJson and string.len(customJson) > 0 then
			data.content = self:convertChargeContent(data.content,customJson)
		end
		panelReward:setVisible(false)
		textMailContent:setVisible(true)
		textMailContent:setString(data.content)
		textMailContent:ignoreContentAdaptWithSize(false)
	end

	toggleNodesVisibleByName(self:getNode(),BTN_RECEIVE,BTN_RECEIVED,data.rewardstate==0)
end

function MailControl:convertSeasonContent(content,customJson)
    local json = cc.load('json').json
    local custom_data = json.decode(customJson)

	if custom_data.num then
		content = string.gsub(content,"$NUM",custom_data.num)
	end
	if custom_data.old_score then
		local old_rank = Utils:getConfigScore(custom_data.old_score)
		content = string.gsub(content,"$RANK_OLD",old_rank.des)
	end
	if custom_data.score then
		local rank = Utils:getConfigScore(custom_data.score)
		content = string.gsub(content,"$RANK_NEW",rank.des)
	end

	return content
end

function MailControl:convertChargeContent(content,customJson)
    local json = cc.load('json').json
    local custom_data = json.decode(customJson)
    if custom_data.exchangeid then --充值邮件
	    local chargeGive = self:getTable("chargeGive")
	    if isNil(chargeGive) then printStack() return end
	    if isNil(ChargeData) then printStack() return end

	    local diamondNum = 0
	    for k,v in pairs(chargeGive) do
	        if v.exchangeid == custom_data.exchangeid then
	            if custom_data.exState==0 then
	                diamondNum = chargeGive[k].diamond+chargeGive[k].extra+chargeGive[k].first
	            else
	                diamondNum = chargeGive[k].diamond+chargeGive[k].extra
	            end
	        end
	    end
	    content = string.gsub(content,"钻石$DIAMOND，道具$TOOLS！","钻石"..diamondNum.."个,")
    end
    return content
end

function MailControl:getMailContentByType(data)
	local mailConfig = self:getTable("mail")
	if isNil(mailConfig) then printStack() return end

	data.content = mailConfig[data.type].content
	if isNil(data.content) then printStack() return end

	data.title = mailConfig[data.type].title
	if isNil(data.title) then printStack() return end
end

function MailControl:convertRewardContent(content,reward)
	local reward = self:getConfigRecord(CONFIG_MAILREWARD,reward)
	if isNil(reward) then printStack() return end

    local diamondID = self:getConfigField("global",1,"DIAMOND_ITEM_ID")
    if isNil(diamondID) then printStack() return end

    local starID = self:getConfigField("global",1,"STAR_ITEM_ID")
    if isNil(starID) then printStack() return end

    local lolipopID = self:getConfigField("global",1,"LOLLIPOP_ITEM_ID")
    if isNil(lolipopID) then printStack() return end

    local itemConfig = self:getTable("item")
    if isNil(itemConfig) then printStack() return end

    local itemStr = ""
	for i=1,5 do
		local keyReward = string.format(KEY_REWARD,i)
		if notNumber(reward[keyReward]) then printStack() return end

		local keyNum = string.format(KEY_NUM,i)
		if notNumber(reward[keyNum]) then printStack() return end

		local itemID = reward[keyReward]
		local itemNum = reward[keyNum]

		local isItem = (itemID~=0 and itemNum~=0)
		if isItem then
			if itemID == diamondID then
				itemStr = itemStr.."钻石"..itemNum.."个,"
			elseif itemID == starID then
				itemStr = itemStr.."星星"..itemNum.."个,"
			elseif itemID == lolipopID then
				itemStr = itemStr.."棒棒糖"..itemNum.."个,"
			else
				local itemInfo = itemConfig[itemID]
				if isNil(itemInfo) then printStack() return end
				itemStr = itemStr..itemInfo.name..itemNum.."个,"
			end
		end
	end	
	content = string.gsub(content,"钻石$DIAMOND，道具$TOOLS！",itemStr)
	return content
end

function MailControl:setRewards(rewardID)
	local reward = self:getConfigRecord(CONFIG_MAILREWARD,rewardID)
	if isNil(reward) then printStack() return end

	for i=1,5 do
		local keyReward = string.format(KEY_REWARD,i)
		if notNumber(reward[keyReward]) then printStack() return end

		local keyNum = string.format(KEY_NUM,i)
		if notNumber(reward[keyNum]) then printStack() return end

		local imgReward = self:getChildNode(string.format(IMG_REWARD,i))
		if isNil(imgReward) then printStack() return end

		local itemID = reward[keyReward]
		local itemNum = reward[keyNum]

		local isItem = (itemID~=0 and itemNum~=0)
		if isItem then
			addItmeNode(imgReward,itemID,itemNum)
		end
		
		setNodeVisibleByName(self:getNode(),string.format(IMG_REWARD,i),isItem)
	end
end

function MailControl:sortData()
	local topUnreadList = {}
	local topReadList = {}
	local normalUnreadList = {}
	local normalReadList = {}

	--邮件数据分类
	for i , v in pairs(MailData) do
		if v.istop and v.istop ==1 then
			if v.isread == 1 then
				topReadList[#topReadList + 1] = v
			else
				topUnreadList[#topUnreadList + 1] = v
			end
		else
			if v.isread == 1 then
				normalReadList[#normalReadList + 1] = v
			else
				normalUnreadList[#normalUnreadList + 1] = v
			end
		end
	end

	--各个类别按时间顺序排序
	table.sort(topUnreadList, function(a, b)
		return a.sendtime < b.sendtime
	end)
	table.sort(topReadList, function(a, b)
		return a.sendtime < b.sendtime
	end)
	table.sort(normalUnreadList, function(a, b)
		return a.sendtime < b.sendtime
	end)
	table.sort(normalReadList, function(a, b)
		return a.sendtime < b.sendtime
	end)

	--分类合并到itemList中
	local tmpList = {}
	tmpList[4] = topUnreadList
	tmpList[3] = topReadList
	tmpList[2] = normalUnreadList
	tmpList[1] = normalReadList

	MailData = {}
	--赋值新数据
	for i ,v in pairs(tmpList) do
		for j ,m in pairs(v) do
			table.insert(MailData,m)
		end
	end
end

return MailControl


