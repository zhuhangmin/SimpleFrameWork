local EngineModel = require "EngineModel"
local GachaRewardModel = class("GachaRewardModel", EngineModel)

function GachaRewardModel:ctor(data)
	GachaRewardModel.super.ctor(self, data)

	self.rewardData = {}
	self.type = 1
	self.gachaType = "STAR"
	self.closeFlag = false
end

function GachaRewardModel:onCreate(param)
	GachaRewardModel.super.onCreate(self, param)

	if isNil(param.rewardData) then printStack() return end
	self:setRewardData(param.rewardData)

	if isNil(param.type) then printStack() return end
	self:setType(param.type)

	if isNil(param.gachaType) then printStack() return end
	self:setGachaType(param.gachaType)
end

function GachaRewardModel:setRewardData(rewardData)
	self.rewardData = rewardData
end

function GachaRewardModel:getRewardData()
	return self.rewardData
end

function GachaRewardModel:setType(type)
	self.type = type
end

function GachaRewardModel:getType()
	return self.type
end

function GachaRewardModel:setGachaType(gachaType)
	self.gachaType = gachaType
end

function GachaRewardModel:getGachaType()
	return self.gachaType
end

function GachaRewardModel:setCloseFlag(closeFlag)
	self.closeFlag = closeFlag
end

function GachaRewardModel:getCloseFlag()
	return self.closeFlag
end


return GachaRewardModel

