local EngineControl = require  "EngineControl"
local PlayerInfoControl = class("PlayerInfoControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	GameMsg.GET_PLAYER_DATA,
}

--SYSTEM MSGS
local BTN_RETURN = "Button_return"
local BTN_ARRAGE = "Button_arrage"
local BTN_USE 	 = "Button_prop_use"
local BTN_EDIT   = "Button_player_set"
local BTN_TAG1	 = "Button_rank_message"
local BTN_TAG2	 = "Button_homepage"
local BTN_CHECK  = "Button_check"
local BTN_HELP   = "Button_help"
local BTN_LEFT 	 = "Button_left"
local BTN_RIGHT	 = "Button_right"

local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_ARRAGE,
	BTN_USE,
	BTN_EDIT,
	BTN_TAG2,
	BTN_TAG1,
	BTN_CHECK,
	BTN_HELP,
	BTN_LEFT,
	BTN_RIGHT
}

local IMG_ICON = "Sprite_player"
local LIST_PLAYER = "ListView_4"
local PANEL_1 = "Panel_homepage"
local PANEL_2 = "Panel_rank_message"

local Panel_star2 = "Panel_star2"
local Panel_star3 = "Panel_star3"
local Panel_star4 = "Panel_star4"
local Panel_star5 = "Panel_star5"
local Panel_star999 = "Panel_star999"
local STAR_TABLE = {Panel_star999,Panel_star2,Panel_star3,Panel_star4,Panel_star5}
local TEXT_RANK = "text_rank"
local PANEL_REWARD = "Panel_reward"
local MY_RANK = "Text_season_now"
local TEXT_SEASON = "Text_season"
local SEASON_STR = "第%s赛季"
local RANK_ITEM = "Sprite_rank_item"
local DISABLE_FUNCTION_STR = PlayerInfoControl:getConfigField("tips", "NOT_OPEN", "content")

function PlayerInfoControl:ctor(model, view)
	PlayerInfoControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
end

function PlayerInfoControl:onCreate()
	PlayerInfoControl.super.onCreate(self, param)

	local name = "game.Riches"
	self:addPanel(name)

	self:updateInfo()
	self:clickPanel(1)
	self:updateScore()
	
end

function PlayerInfoControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:send(BASE_MSG.POP)
	end

	if senderName == BTN_ARRAGE then
		self:addTip(DISABLE_FUNCTION_STR)
	end

	if senderName == BTN_USE then
		self:addTip(DISABLE_FUNCTION_STR)
	end

	if senderName == BTN_EDIT then
		local name = "game.PlayerInfoSet"
		self:addPanel(name) 
	end

	if senderName == BTN_CHECK then
		local name = "game.BattleScoreDetail"
		self:addPanel(name) 
	end

	if senderName == BTN_HELP then
		local name = "game.BattleScoreHelp"
		self:addPanel(name) 
	end

	if senderName == BTN_TAG1 then
		self:clickPanel(1)
	end

	if senderName == BTN_TAG2 then
		self:clickPanel(2)
	end

	if senderName == BTN_LEFT then
		self:deleteScoreAndUpdate()
	end

	if senderName == BTN_RIGHT then
		self:addScoreAndUpdate()
	end

end

function PlayerInfoControl:clickPanel( index )
	local panel = {{},{}}
	panel[1].panel = self:getChildNode(PANEL_1)
	panel[2].panel = self:getChildNode(PANEL_2)
	panel[1].btn = self:getChildNode(BTN_TAG1)
	panel[2].btn = self:getChildNode(BTN_TAG2)
	if isNil(panel[1].panel) then printStack() return end
	if isNil(panel[2].panel) then printStack() return end
	for i = 1, #panel , 1 do
		if i == index then
			panel[i].panel:setVisible(true)
			panel[i].btn:setBright(false)
			panel[i].btn:setTitleColor(display.COLOR_WHITE)
		else
			panel[i].panel:setVisible(false)
			panel[i].btn:setBright(true)
			panel[i].btn:setTitleColor(cc.c3b(197, 222, 255))
		end
	end
end

function PlayerInfoControl:addScoreAndUpdate( )
	local cfg = self:getTable("scoreChange")
	local score = self.model:getScore()
	local score2 = score
	for i = score, #cfg , 1 do
		if cfg[i].rank == cfg[score].rank + 1 then
			if cfg[i].stars == cfg[i].stars_sum  then
				score2 = i
				break
			end
		end
	end
	local score_now = math.min(#cfg,PlayerDataBasic.score)
	if cfg[score2] then
		if cfg[score2].rank == cfg[score_now].rank then
			score2 = PlayerDataBasic.score
		end
	end
	-- print("score2-==="..score2)
	-- score = math.min(#cfg,score+1)
	self.model:setScore(score2)
	self:updateScore()
end

function PlayerInfoControl:deleteScoreAndUpdate( )
	local cfg = self:getTable("scoreChange")
	local score = math.min(#cfg,self.model:getScore())
	local score2 = score
	for i = score, 1 , -1 do
		if cfg[i].rank == cfg[score].rank - 1 then
			score2 = i
			break
		end
	end
	local score_now = math.min(#cfg,PlayerDataBasic.score)
	if cfg[score2] then
		if cfg[score2].rank == cfg[score_now].rank then
			score2 = PlayerDataBasic.score
		end
	end

	-- score = math.max(1,score-1)
	self.model:setScore(score2)
	self:updateScore()
end

function PlayerInfoControl:updateScore( ... )
	self:updateRankShow()
	local panel_reward = self:getChildNode(PANEL_REWARD) 
	if isNil(panel_reward) then printStack() return end
	local score = self.model:getScore()
	local season = string.format(SEASON_STR,tostring(RankData.season))
	self:getChildNode(TEXT_SEASON):setString(season) 

	local cfg =  Utils:getConfigScore(score)
	local gift_id = cfg.end_gift
	local reward = self:getConfigRecord("giftPack", gift_id)
	for i = 1, 4, 1 do
		local imgReward = panel_reward:getChildByName("Node_reward"..i)
		if reward["reward"..i] ~= 0 then
			addItmeNode(imgReward,reward["reward"..i],reward["num"..i])
		else
			imgReward:setVisible(false)
		end
	end
end

function PlayerInfoControl:updateRankShow(  )
	local score = self.model:getScore()
	local cfg = Utils:getConfigScore(score)
	if isNil(cfg) then printStack() return end
	if isNil(cfg.stars_sum) then printStack() return end
	if isNil(cfg.stars) then printStack() return end
	-- dump(cfg)
	local stars_sum = cfg.stars_sum
	local stars = cfg.stars
	if stars_sum == 0 then stars_sum = 1 end
	for k , v in ipairs(STAR_TABLE) do
		local panel = self:getChildNode(v)
		if tostring(k) == tostring(stars_sum) then
			panel:setVisible(true)
			self:updateStar(cfg,panel)
		else
			panel:setVisible(false)
		end
	end
	self:getChildNode(TEXT_RANK):setString(cfg.des)
	local flag = (score == PlayerDataBasic.score)
	self:getChildNode(MY_RANK):setVisible(flag)
	self:getChildNode(RANK_ITEM):setSpriteFrame(cfg.icon)
end

function PlayerInfoControl:updateStar( cfg, panel )
	if isNil(panel) then printStack() return end
	if cfg.stars_sum ~= 0 then
		for i = 1, cfg.stars_sum, 1 do
			local star = panel:getChildByName("Image_star"..i.."")
			if i <= cfg.stars then
				star:setVisible(true)
			else
				star:setVisible(false)
			end
		end
	end

	if cfg.stars_sum == 0 then
		local label = panel:getChildByName("Text_star_num")
		label:setString(cfg.stars)
	end
end



function PlayerInfoControl:recv(event)
	self.super.recv(self, event)
	
	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
	end

	if name == GameMsg.GET_PLAYER_DATA then
		self:updateInfo()
	end

	
end

function PlayerInfoControl:updateInfo(  ) --右侧个人信息滚动条
	local list = self:getChildNode(LIST_PLAYER)
	if isNil(list) then printStack() return end
	list:removeAllChildren()

	local data = PlayerDataBasic
	local genderText = "男"
	if data.gender == 0 then
		genderText = "女"
	else
		genderText = "男"
	end

	local constellationText = Utils:convertTimeToConstellation(data.month,data.day)
	local areaText = self:getConfigField("city", data.area, "name")


	local data_table = {}
	data_table[1] = {name = "昵称:",det = data.nickname}
	data_table[2] = {name = "地区:",det = areaText}
	data_table[3] = {name = "性别:",det = genderText}
	data_table[4] = {name = "星座:",det = constellationText}
	data_table[5] = {name = "生日:",det = data.year.."."..data.month.."."..data.day}

	
	for i = 1 ,5 do
		local infoNode = require("FrameWork.game.PlayerInfoNode")
		local node_t = infoNode:create(data_table[i])
		list:pushBackCustomItem(node_t)
		list:jumpToTop()
	end 
	
	local imgIcon = self:getChildNode(IMG_ICON)
	if isNil(imgIcon) then printStack() return end

	setIconById(imgIcon, data.cur_skin )
	imgIcon:setScale(0.5)
end



return PlayerInfoControl


