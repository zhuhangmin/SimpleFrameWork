local ConfigManager = require "ConfigManager"
local EngineControl = require "EngineControl"

function getUserSkinInfo()
    local skinInfo = {}

    for k,v in pairs(ItemData) do
        local itemInfo = ConfigManager.getInstance():getConfigRecord("item",v.item_id)
        if isNil(itemInfo) then printStack() return end

        if itemInfo.type == "SKIN" then
            local synthesisConfig = ConfigManager.getInstance():getTable("synthesis")
            if isNil(synthesisConfig) then printStack() return end

            local info = {id = v.item_id,count =0}
            table.insert(skinInfo,info)
        end
    end

    return skinInfo
end

function getskinlevel(skinID)
    local value = tonumber(skinID)
    local index = value % 10
 return index
end 

function getSkinInfoForLevel(index,skinindex)
    local skinInfo = getUserSkinInfo()

    local skindata = {}
    local tempskinindex = 1

    local itemConfig = ConfigManager.getInstance():getTable("item")
    if isNil(itemConfig) then printStack() return end

    local level = getskinlevel(skinindex) or 1
    skinID = skinindex - level + index

    for i = 1, #skinInfo do
        if skinInfo[i].id == skinID then
            skindata = skinInfo[i]
            break
        end
    end

    return skindata,skinID
end 

function getIsRare( id )
    local itemConfig = ConfigManager.getInstance():getTable("item")
    if isNil(itemConfig) then printStack() return end

    local rare = false

    if itemConfig[id] and itemConfig[id].b_light == 1 then
        rare = true
    end

    return rare
end

--分解皮肤ID
function sepSkinID(skinID)
    local value = tonumber(skinID)

    local type = math.floor(value / 10000)
    local temp = value % 10000
    local theme = math.floor(temp / 100)
    local index = temp % 100

    return type, theme, index
end

function getHeadImageInfo(skinID, quality)
    local itemConfig = ConfigManager.getInstance():getTable("item")
    if isNil(itemConfig) then printStack() return end

    local temp = Constant.DEFAULT_SKIN_ID
    local value = tonumber(skinID)

    for i,v in pairs(itemConfig) do
        if value == i then
            temp = value
            break
        end
    end

    local _, theme, index = sepSkinID(temp)

    local fileName = string.format("ball_%02d", theme)
    local animName = string.format("%d_%02d_icon", quality, index)
    local runName = string.format("%d_%02d_run", quality, index)
    local happyName = string.format("%d_%02d_happy", quality, index)
    local fullName = string.format("%d_%02d_full", quality, index)

    return fileName, animName, runName, happyName, fullName
end

function getSkinIcon( skinID )
    if type(skinID) ~= "number" then skinID = tonumber(skinID) end 
    local img = ConfigManager.getInstance():getConfigField("item", skinID, "img")
    return img
end


function getItemCountById(id)
    if notNumber(id) then printStack() return end

    local count = 0
    for k,v in pairs(ItemData) do
        if v.item_id == id  then
            count = v.count
            break
        end
    end

    local starID = ConfigManager.getInstance():getConfigField("global",1,"STAR_ITEM_ID")
    if isNil(starID) then printStack() return end

    local diamondID = ConfigManager.getInstance():getConfigField("global",1,"DIAMOND_ITEM_ID")
    if isNil(diamondID) then printStack() return end

    local lolipopID = ConfigManager.getInstance():getConfigField("global",1,"LOLLIPOP_ITEM_ID")
    if isNil(lolipopID) then printStack() return end

    if id ==starID then
        count = PlayerDataBasic.cur_star
    elseif id == diamondID then
        count = PlayerDataBasic.cur_diamond
    elseif id == lolipopID then
        count = PlayerDataBasic.cur_lollipop
    end

    return count
end

--[[
状态不满足进行跳转（通用）
1   星星
2   钻石
]]
function gotoViewPop(type)
    local function gotoView()
        local name = "game.ChargeShop"
        local modelParam = {pageIndex = type}
        local data = buildMsgData(name, modelParam)
        EngineControl:send(BASE_MSG.PUSH, data)
    end

    local GET_STAR = ConfigManager.getInstance():getConfigField("tips", "GET_STAR", "content")
    local GET_DIAMOND = ConfigManager.getInstance():getConfigField("tips", "GET_DIAMOND", "content")
    local GET_LOLIPOP = ConfigManager.getInstance():getConfigField("tips", "GET_LOLIPOP", "content")

    if type == 1 then
        local contentStr = GET_STAR
        local confirmCB = handler(self, gotoView)
        local cancelCB = function() end
        EngineControl:addMsgBox(contentStr, confirmCB, cancelCB)
    elseif type == 2 then
        local contentStr = GET_DIAMOND
        local confirmCB = handler(self, gotoView)
        local cancelCB = function() end
        EngineControl:addMsgBox(contentStr, confirmCB, cancelCB)
    elseif type == 3 then
        local contentStr = GET_LOLIPOP
        local confirmCB = function()
            local DISABLE_FUNCTION_STR = ConfigManager.getInstance():getConfigField("tips", "NOT_OPEN", "content")
            EngineControl:addTip(DISABLE_FUNCTION_STR)
        end
        local cancelCB = function() end
        EngineControl:addMsgBox(contentStr, confirmCB, cancelCB)
    end
end
--[[
状态判定（通用）
type
1   星星
2   钻石
3   棒棒糖
num -- need
callback --回调
]]
function buyJudgement(type , num , callback )
    if isNil(type) then printStack() return end
    if isNil(num) then printStack() return end

    local flag = false 
    -- print("num=="..num..";"..type..";"..UserData.userInfo.diamond)
    if type == 1 then
        if PlayerDataBasic.cur_star >= num then
            flag = true
        else
            flag = false
            gotoViewPop(type)
        end
    elseif type == 2 then
        if PlayerDataBasic.cur_diamond >= num then
            flag = true
        else
            flag = false
            gotoViewPop(type)
        end
    elseif type == 3 then
        if PlayerDataBasic.cur_lollipop >= num then
            flag = true
        else
            flag = false
            gotoViewPop(type)
        end       
    end
    if callback then
        if flag then
            callback()
        end
    else
        return flag
    end
end

--[[
通过id将sprite设置成对应icon need sprite id
//10000 1   钻石      "1000000,10"
//20000 2   星星      "2000000,100"
//30101 3   皮肤      "30101,1"
//40101 4   皮肤碎片    "40101,10"
//50101 5   道具      "50101,2"
]]
function setIconById(sprite, id )
    if isNil(sprite) then printStack() return end

    if notNumber(id) then printStack() return end

    local starID = ConfigManager.getInstance():getConfigField("global",1,"STAR_ITEM_ID")
    if isNil(starID) then printStack() return end

    local diamondID = ConfigManager.getInstance():getConfigField("global",1,"DIAMOND_ITEM_ID")
    if isNil(diamondID) then printStack() return end

    if id == starID then
        sprite:setSpriteFrame("home/icon_star.png")
    elseif id == diamondID then
        sprite:setSpriteFrame("home/icon_zuanshi.png")
    else
        local item = ConfigManager.getInstance():getConfigRecord("item",id)
        if item and item.type == "SKIN" then
            local skinIcon = getSkinIcon( id )
            sprite:setSpriteFrame(skinIcon .. ".png")
            sprite:setScale(0.2)
        else
            sprite:setSpriteFrame("tiehua/"..id..".png")
        end
    end
end

function setImgIconById(image, id )
    if isNil(image) then printStack() return end

    if notNumber(id) then printStack() return end

    local starID = ConfigManager.getInstance():getConfigField("global",1,"STAR_ITEM_ID")
    if isNil(starID) then printStack() return end

    local diamondID = ConfigManager.getInstance():getConfigField("global",1,"DIAMOND_ITEM_ID")
    if isNil(diamondID) then printStack() return end

    local lolipopID = ConfigManager.getInstance():getConfigField("global",1,"LOLLIPOP_ITEM_ID")
    if isNil(lolipopID) then printStack() return end

    if id == starID or id == diamondID or id == lolipopID then
        image:loadTexture("tiehua/tb_"..id..".png",ccui.TextureResType.plistType)
    else
        local item = ConfigManager.getInstance():getConfigRecord("item",id)
        if item and (item.type == "SKIN" or item.type == "ROLEPIECE") then
            local skinIcon = getSkinIcon( id )
            image:loadTexture(skinIcon .. ".png",ccui.TextureResType.plistType)
        else
            image:loadTexture("tiehua/tb_"..item.img..".png",ccui.TextureResType.plistType)
        end
    end
end

--[[
通过id将sprite设置成对应icon need sprite id
//10000 1   钻石      "1000000,10"
//20000 2   星星      "2000000,100"
//30101 3   皮肤      "30101,1"
//40101 4   皮肤碎片    "40101,10"
//50101 5   道具      "50101,2"
]]
function setBigIconById(sprite, id )
    if isNil(sprite) then printStack() return end

    if notNumber(id) then printStack() return end

    local starID = ConfigManager.getInstance():getConfigField("global",1,"STAR_ITEM_ID")
    if isNil(starID) then printStack() return end

    local diamondID = ConfigManager.getInstance():getConfigField("global",1,"DIAMOND_ITEM_ID")
    if isNil(diamondID) then printStack() return end

    if id == starID then
        sprite:setSpriteFrame("tiehua/tb_1000000.png")
    elseif id == diamondID then
        sprite:setSpriteFrame("tiehua/tb_2000000.png")
    else
        local item = ConfigManager.getInstance():getConfigRecord("item",id)
        if item and item.type == "SKIN" then
            local skinIcon = getSkinIcon( id )
            sprite:setSpriteFrame(skinIcon .. ".png")
            sprite:setScale(0.5)
        else
            sprite:setSpriteFrame("tiehua/tb_"..id..".png")
        end
    end
end


--获取支付信息
function getCurrPayInfo(payID)
    print("payID = ",payID)
    local chargeConfig = ConfigManager.getInstance():getTable("chargeConfig")
    if isNil(chargeConfig) then printStack() return end

    local chargeGive = ConfigManager.getInstance():getTable("chargeGive")
    if isNil(chargeGive) then printStack() return end

    if isNil(ChargeData) then printStack() return end

    local tab = {}
    for k,v in pairs(chargeConfig) do
        if v.exchangeid == payID then
            tab.rmb = v.money
            tab.pid = v.productid
            tab.diamond = 0

            if k <= 6 then
                if ChargeData["ex"..k]==0 then
                    tab.diamond = chargeGive[k].diamond+chargeGive[k].extra+chargeGive[k].first
                else
                    tab.diamond = chargeGive[k].diamond+chargeGive[k].extra
                end
            end
        end
    end

    return tab
end

--判断是否是空的礼包
function haveReward(rewardID)
    local reward = ConfigManager.getInstance():getConfigRecord("giftPack",rewardID)
    if isNil(reward) then printStack() return end

    for i=1,5 do
        local keyReward = string.format("reward%d",i)
        if notNumber(reward[keyReward]) then printStack() return end

        local keyNum = string.format("num%d",i)
        if notNumber(reward[keyNum]) then printStack() return end

        local itemID = reward[keyReward]
        if notNumber(itemID) then printStack() return end

        local itemNum = reward[keyNum]
        if notNumber(itemNum) then printStack() return end
        if itemID~=0 and itemNum~=0 then
            return true
        end
    end
    return false
end

function showItemDesView(itemID)
    local name = "game.ItemDes"
    local param = {modelParam = {itemID = itemID}}
    EngineControl:addPop(name,param)
end

function getItemNameByID( itemID )
    if isNil(itemID) then printStack() return end
    itemID = tonumber(itemID)
    local name = ""
    local starID = ConfigManager.getInstance():getConfigField("global",1,"STAR_ITEM_ID")
    if isNil(starID) then printStack() return end

    local diamondID = ConfigManager.getInstance():getConfigField("global",1,"DIAMOND_ITEM_ID")
    if isNil(diamondID) then printStack() return end

    local lolipopID = ConfigManager.getInstance():getConfigField("global",1,"LOLLIPOP_ITEM_ID")
    if isNil(lolipopID) then printStack() return end

    if itemID == diamondID then  
        name = ConfigManager.getInstance():getConfigField("global",1,"DIAMOND_ITEM_NAME")
        return name
    end
    if itemID == starID then
        name = ConfigManager.getInstance():getConfigField("global",1,"STAR_ITEM_NAME")
        return name
    end

    if itemID == lolipopID then
        name = ConfigManager.getInstance():getConfigField("global",1,"LOLLIPOP_ITEM_NAME")
        return name
    end

    local itemInfo = ConfigManager.getInstance():getConfigRecord("item",itemID)
    if itemInfo and itemInfo.name then
        name = itemInfo.name
        return name
    end
end

function addItmeNode(node,itemID,itemNum,noClick,noReplace)
    if isNil(node) then printStack() return end
    if not noReplace then
        node:removeAllChildren()
    end

    if isNil(itemID) then printStack() return end
    itemID = tonumber(itemID)
    
    local starID = ConfigManager.getInstance():getConfigField("global",1,"STAR_ITEM_ID")
    if isNil(starID) then printStack() return end

    local diamondID = ConfigManager.getInstance():getConfigField("global",1,"DIAMOND_ITEM_ID")
    if isNil(diamondID) then printStack() return end

    local lolipopID = ConfigManager.getInstance():getConfigField("global",1,"LOLLIPOP_ITEM_ID")
    if isNil(lolipopID) then printStack() return end

    local item = cc.CSLoader:createNode("res/RewardItem.csb")
    if isNil(item) then printStack() return end

    item = changeNodeToWidget(item)

    node:addChild(item)

    local Image_role = item:getChildByName("Image_role")
    if isNil(Image_role) then printStack() return end

    local label_num = item:getChildByName("reward_count")
    if isNil(label_num) then printStack() return end

    local Image_rewarditem = item:getChildByName("Image_rewarditem")
    if isNil(Image_rewarditem) then printStack() return end

    local Image_sp = item:getChildByName("Image_sp")
    if isNil(Image_sp) then printStack() return end

    if not noClick then
        Image_rewarditem:setTouchEnabled(true)
        Image_rewarditem:setSwallowTouches(false)
        Image_rewarditem:addTouchEventListener(function(sender, eventType)
            if eventType == ccui.TouchEventType.ended then
                showItemDesView(itemID)
                SoundManager:playEffect("button.mp3")
            end
        end)
        
        Image_role:setTouchEnabled(true)
        Image_role:setSwallowTouches(false)
        Image_role:addTouchEventListener(function(sender, eventType)
            if eventType == ccui.TouchEventType.ended then
                showItemDesView(itemID)
                SoundManager:playEffect("button.mp3")
            end
        end)
    end

    if itemID == diamondID or itemID == starID or itemID == lolipopID then
        setImgIconById(Image_rewarditem,itemID)
        Image_rewarditem:setVisible(true)
        Image_role:setVisible(false)
        Image_sp:setVisible(false)
    else
        local itemInfo = ConfigManager.getInstance():getConfigRecord("item",itemID)
        if isNil(itemInfo) then printStack() return end
        if itemInfo.type == "SKIN" then--皮肤
            setImgIconById(Image_role,itemID)
            Image_rewarditem:setVisible(false)
            Image_role:setVisible(true)
            Image_sp:setVisible(false)
        elseif itemInfo.type == "ROLEPIECE" then--碎片
            setImgIconById(Image_role,itemID)
            Image_rewarditem:setVisible(true)
            Image_role:setVisible(true)
            Image_sp:setVisible(true)
            Image_role:setTouchEnabled(false)--防止弹出两个框
        else--道具
            setImgIconById(Image_rewarditem,itemID)
            Image_rewarditem:setVisible(true)
            Image_role:setVisible(false)
            Image_sp:setVisible(false)
        end
    end


    if itemNum then
        label_num:setString("×"..itemNum)
    else
        label_num:setVisible(false)
    end

    return item
end

function canUserConvert()
    local canConvert = false
    if GameSwitch:isSupportUserConvert() then
        local userConvert = require('src.app.userconvert.UserConvertCtrl'):getInstance()
        if not (userConvert._model:isTcyappLaunched() or MCAgent:getInstance():getLaunchMode() == LaunchMode["PLATFORM"]) then
        if userConvert._optionConvertStatus == userConvert.OPTIONCONVERTSTATUS_NOTCONVERT or
            userConvert._optionConvertStatus == userConvert.OPTIONCONVERTSTATUS_DOWNLOADCOMPLETED or
            userConvert._optionConvertStatus == userConvert.OPTIONCONVERTSTATUS_DOWNLOADFAILED or 
            userConvert._optionConvertStatus == userConvert.OPTIONCONVERTSTATUS_DOWNLOADING then
                canConvert = true
            end
        end
    end
    return canConvert
end


-- E:\svn\balls\test\trunk\ball2\mjdz/
function getWritablePath()
    local fileutils=cc.FileUtils:getInstance()
    return fileutils:getGameWritablePath()
end