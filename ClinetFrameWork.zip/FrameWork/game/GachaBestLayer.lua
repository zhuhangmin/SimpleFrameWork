local GachaBestLayer = class("GachaBestLayer", function()
	return cc.LayerColor:create(cc.c4b(0, 0, 0, 165))
end)

local ConfigManager = require "ConfigManager"
local cfg = ConfigManager:getInstance()

function GachaBestLayer:ctor( params )
	-- dump(params)
	
	self:init( params )
	local action = self:addCommonAnime(self,"mj_huojiang_2_2")
	action:gotoFrameAndPlay(0, 18, false)
	SoundManager:playEffect("skin_get.mp3")
end

function GachaBestLayer:init( params )
	self.rootNode = cc.CSLoader:createNode("res/DrawSkin.csb")
	self:addChild(self.rootNode)
	self.panel = self.rootNode:getChildByName("Panel_1")
	self.panel:addTouchEventListener(handler(self, self.closePanel))

	self.skinSpr = self.rootNode:getChildByName("Panel_draw_skin"):getChildByName("Image_skin")
	self.rootNode:getChildByName("Text_skin_repeat"):setVisible(false)

	local action = self:addCommonAnime(self.skinSpr,"mj_huojiang_2_1",-1)
	action:gotoFrameAndPlay(0, 65, true)
	self:addAnime( params )
end

function GachaBestLayer:addCommonAnime( node, name , zorder )
	local z = 1
	if zorder then
		z = zorder
	end
	local anime = cc.CSLoader:createNode("res/gamecocosstudio/csb/"..name..".csb")
	local size = node:getContentSize()
	anime:setPosition(cc.p(size.width/2,size.height/2))
	node:addChild(anime,z)
	local action = cc.CSLoader:createTimeline("res/gamecocosstudio/csb/"..name..".csb")
	anime:runAction(action)
	return action
end

function GachaBestLayer:closePanel(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended then
		SoundManager:playEffect("button.mp3")
		self:removeFromParent()
	end
end

function GachaBestLayer:addAnime( id )
	local a_id = cfg:getConfigField("item", id, "animation")
	local fileInfo = cfg:getConfigRecord("actionConfig",a_id)
	if isNil(fileInfo) then printStack() return end
	local fileName = fileInfo.file
	local runName = fileInfo.run_256

	if not Utils:isExistArmatureAndAnim(fileName) then
		local file = string.format("res/armature/%s/%s.ExportJson",fileName,fileName)
		gArmatureManager:addArmatureFileInfo(file)
	end
	if Utils:isExistArmatureAndAnim(fileName) then
		self.headImage = ccs.Armature:create(fileName)
		self.headImage:setScale(0.8)
		self.headImage:setAnchorPoint(cc.p(0.5, 0.5))
		self.headImage:setPosition(cc.p(24, 31))

		self.headImage:getAnimation():play(runName, -1, 0)
		self.headImage:getAnimation():setMovementEventCallFunc(function(armature, type, movementID)
			if type == ccs.MovementEventType.complete then
				self.headImage:getAnimation():play(runName, -1, 0)
			end
		end)
		self.skinSpr:addChild(self.headImage,99)
	end
end
	

return GachaBestLayer
