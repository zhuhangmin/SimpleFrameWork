local EngineView = require "EngineView"
local GachaRewardView = class("GachaRewardView", EngineView)

local csbFilePath = "res/DrawResult.csb"
GACHAREWARD_CSB_NODE = 1000

function GachaRewardView:ctor(node)
	GachaRewardView.super.ctor(self, node)
end

function GachaRewardView:onCreate(param)
	GachaRewardView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	if isNil(csbNode) then printStack() return end
	
	csbNode:setTag(GACHAREWARD_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return GachaRewardView





