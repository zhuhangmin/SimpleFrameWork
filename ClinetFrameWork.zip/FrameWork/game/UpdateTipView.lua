local EngineView = require "EngineView"
local UpdateTipView = class("UpdateTipView", EngineView)

local csbFilePath = "res/UpdateTip.csb"
UPDATETIP_CSB_NODE = 1000

function UpdateTipView:ctor(node)
	UpdateTipView.super.ctor(self, node)
end

function UpdateTipView:onCreate(param)
	UpdateTipView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	csbNode:setTag(UPDATETIP_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return UpdateTipView





