 -- mode                             string                           形容词
-- id                               int                              序号
-- comment                          string                           描述

return {
	["BEG"] = {
		id = 0,
		comment = "开始",
	},
	["MATCH_1"] = {
		id = 1,
		comment = "匹配池类型1",
	},
	["MATCH_2"] = {
		id = 2,
		comment = "匹配池类型2",
	},
	["MATCH_3"] = {
		id = 3,
		comment = "匹配池类型3",
	},
	["MATCH_4"] = {
		id = 4,
		comment = "匹配池类型4",
	},
	["MATCH_5"] = {
		id = 5,
		comment = "匹配池类型5",
	},
	["MATCH_6"] = {
		id = 6,
		comment = "匹配池类型6",
	},
	["MATCH_7"] = {
		id = 7,
		comment = "匹配池类型7",
	},
	["MATCH_8"] = {
		id = 8,
		comment = "匹配池类型8",
	},
	["MATCH_9"] = {
		id = 9,
		comment = "匹配池类型9",
	},
	["END"] = {
		id = 10,
		comment = "结束",
	},
}
