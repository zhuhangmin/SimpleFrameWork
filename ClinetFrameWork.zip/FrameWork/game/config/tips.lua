-- tips_str                         string                           tips索引
-- content                          string                           客户端提示框内容
-- comment                          string                           场景描述

return {
	["PURCHASE_SUCCESS"] = {
		content = "小店主将商品卖了出去，异常兴奋~",
		comment = "购买成功",
	},
	["STAR_INVERT"] = {
		content = "检测到您已拥有%s皮肤，将自动为您转换为%d个星星！",
		comment = "您已拥有%s皮肤，自动转换为%d个星星",
	},
	["SAVE_SUCCESS"] = {
		content = "您的信息已成功更新！",
		comment = "保存成功",
	},
	["CONNECTION_FAIL"] = {
		content = "警告！网络受到不明干扰，连接出现异常！",
		comment = "网络连接异常，请检查您的网络！",
	},
	["NOT_OPEN"] = {
		content = "耐心等待下，科技员大佬们正在爆肝输出！",
		comment = "即将开放，敬请期待",
	},
	["OVER_UPLIMIT"] = {
		content = "商品数量爆仓啦，不能再增加了！",
		comment = "超过最大拥有数量",
	},
	["GET_STAR"] = {
		content = "星星货币带的不够，需要去取一些出来吗？",
		comment = "星星不足，是否前往获取更多的星星",
	},
	["GET_DIAMOND"] = {
		content = "商品价格太高了，没有足够的钻石，需要去补充一些吗？",
		comment = "钻石不足，是否前往获取更多的钻石",
	},
	["QUIT_GAME"] = {
		content = "萌菌实验室还需要你的参与建设，真的要离开我们吗？",
		comment = "确定要离开萌菌实验室吗？",
	},
	["GACHA_CONFIRM"] = {
		content = "参加一次幸运扭蛋需要消耗%s，来试试运气吧~",
		comment = "是否消耗%s进行一次扭蛋",
	},
	["BUY_STAR"] = {
		content = "消耗%d钻石可以补充%d星星，壕气来一次吧！",
		comment = "确定要消耗%d钻石购买星星%d？",
	},
	["QUIT_BATTLE"] = {
		content = "离胜利只差一点了，真的要放弃吗？",
		comment = "确定要退出战斗吗？",
	},
	["GET_LOLIPOP"] = {
		content = "棒棒糖不足了，需要去取一些出来吗？",
		comment = "棒棒糖不足，是否前往获取更多的棒棒糖",
	},
	["TIPS_RECONNECT"] = {
		content = "您在一场战斗中意外退出，要返回继续游戏吗？",
		comment = "断线重连",
	},
	["BORN_DATE_ERROR"] = {
		content = "日期超过今天了，请重新输入",
		comment = "玩家填写生日超过今天的日期",
	},
}
