return {
    ["shop"] = {
        ["shop_item_15"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }, 
        ["shop_item_8"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }, 
        ["shop_item_9"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }, 
        ["shop_item_18"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }, 
        ["shop_item_19"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }, 
        ["shop_item_4"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }, 
        ["shop_item_5"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }, 
        ["shop_item_6"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }, 
        ["shop_item_7"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }, 
        ["shop_item_12"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }, 
        ["shop_item_1"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }, 
        ["shop_item_2"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }, 
        ["shop_item_3"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }, 
        ["shop_item_16"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }, 
        ["shop_item_20"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }, 
        ["shop_item_10"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }, 
        ["shop_item_13"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }, 
        ["shop_item_17"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }, 
        ["shop_item_11"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }, 
        ["shop_item_14"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "shopItem"
        }
    }, 
    ["itemType"] = {}, 
    ["stateConfig"] = {
        ["ownball"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "ballType"
        }, 
        ["nutrient"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "ballType"
        }, 
        ["enemyball"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "ballType"
        }, 
        ["base"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "ballType"
        }, 
        ["grass"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "ballType"
        }
    }, 
    ["giftCode"] = {
        ["gift_type"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "giftType"
        }, 
        ["gift_pack"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "giftPack"
        }
    }, 
    ["roomAi"] = {
        ["AI_type_4"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "aiConfig"
        }, 
        ["AI_type_1"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "aiConfig"
        }, 
        ["AI_type_3"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "aiConfig"
        }, 
        ["AI_type_2"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "aiConfig"
        }
    }, 
    ["entityType"] = {}, 
    ["rewardConfig"] = {
        ["item2"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }, 
        ["item1"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }
    }, 
    ["skillConfig"] = {
        ["target_state"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "stateConfig"
        }, 
        ["own_state"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "stateConfig"
        }, 
        ["target"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "targetType"
        }, 
        ["condition"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "conditionType"
        }
    }, 
    ["purchaseType"] = {}, 
    ["aiNameLast"] = {}, 
    ["battlethemeConfig"] = {}, 
    ["entityweightConfig"] = {}, 
    ["shopItem"] = {
        ["item_id"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }, 
        ["sell"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "sellType"
        }
    }, 
    ["gachagroupType"] = {}, 
    ["giftType"] = {}, 
    ["foodConfig"] = {}, 
    ["giftPack"] = {
        ["reward1"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }, 
        ["reward2"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }, 
        ["reward3"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }, 
        ["reward4"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }, 
        ["reward5"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }, 
        ["reward6"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }, 
        ["reward7"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }
    }, 
    ["initRole"] = {
        ["role"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }
    }, 
    ["objectType"] = {}, 
    ["conditionType"] = {}, 
    ["aiRoleshow"] = {
        ["ref"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }
    }, 
    ["gachagroupconfig"] = {
        ["sort"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "gachagroupType"
        }, 
        ["purchase"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "purchaseType"
        }, 
        ["buyitem"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }, 
        ["costitem"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }, 
        ["pool"] = {
            ["dstKey"] = "pool_id", 
            ["dstTbl"] = "gachapoolConfig"
        }
    }, 
    ["aiNameFirst"] = {}, 
    ["errno"] = {}, 
    ["fileType"] = {}, 
    ["chargeSystem"] = {}, 
    ["gachapoolConfig"] = {
        ["pool"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }
    }, 
    ["ballType"] = {}, 
    ["newbieSign"] = {
        ["type"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "giftPack"
        }
    }, 
    ["mail"] = {
        ["reward"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "giftPack"
        }, 
        ["type"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "mailType"
        }
    }, 
    ["tips"] = {}, 
    ["dropPreview"] = {
        ["drop_type"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "dropType"
        }, 
        ["drop_item"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }
    }, 
    ["synthesis"] = {
        ["item2"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }, 
        ["item3"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }, 
        ["item1"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }
    }, 
    ["ballsView"] = {}, 
    ["diamondStar"] = {}, 
    ["itemReward"] = {
        ["gift_id"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "giftPack"
        }, 
        ["gift_id8"] = {
            ["dstKey"] = "pool_id", 
            ["dstTbl"] = "gachapoolConfig"
        }, 
        ["gift_id9"] = {
            ["dstKey"] = "pool_id", 
            ["dstTbl"] = "gachapoolConfig"
        }, 
        ["gift_id6"] = {
            ["dstKey"] = "pool_id", 
            ["dstTbl"] = "gachapoolConfig"
        }, 
        ["gift_id7"] = {
            ["dstKey"] = "pool_id", 
            ["dstTbl"] = "gachapoolConfig"
        }, 
        ["gift_id4"] = {
            ["dstKey"] = "pool_id", 
            ["dstTbl"] = "gachapoolConfig"
        }, 
        ["gift_id5"] = {
            ["dstKey"] = "pool_id", 
            ["dstTbl"] = "gachapoolConfig"
        }, 
        ["gift_id2"] = {
            ["dstKey"] = "pool_id", 
            ["dstTbl"] = "gachapoolConfig"
        }, 
        ["gift_id3"] = {
            ["dstKey"] = "pool_id", 
            ["dstTbl"] = "gachapoolConfig"
        }, 
        ["gift_id1"] = {
            ["dstKey"] = "pool_id", 
            ["dstTbl"] = "gachapoolConfig"
        }
    }, 
    ["global"] = {}, 
    ["chargeActivty"] = {
        ["android_exchangeid"] = {
            ["dstKey"] = "exchangeid", 
            ["dstTbl"] = "chargeConfig"
        }, 
        ["gift_id"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "giftPack"
        }, 
        [" apple_exchangeid"] = {
            ["dstKey"] = "exchangeid", 
            ["dstTbl"] = "chargeConfig"
        }
    }, 
    ["accumSign"] = {
        ["type"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "giftPack"
        }
    }, 
    ["aiNameMiddle"] = {}, 
    ["entityConfig"] = {
        ["skill3"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "skillConfig"
        }, 
        ["skill2"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "skillConfig"
        }, 
        ["state"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "stateConfig"
        }, 
        ["type"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "entityType"
        }, 
        ["skill1"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "skillConfig"
        }
    }, 
    ["actionConfig"] = {}, 
    ["numMatch"] = {
        ["match_min_0"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "numMatch"
        }, 
        ["match_max_0"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "numMatch"
        }, 
        ["room_type"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "room"
        }
    }, 
    ["seasonDate"] = {}, 
    ["dropType"] = {}, 
    ["targetType"] = {}, 
    ["chargeConfig"] = {
        ["system"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "chargeSystem"
        }, 
        ["productid"] = {
            ["dstKey"] = "money", 
            ["dstTbl"] = "chargeConfig"
        }
    }, 
    ["sellType"] = {}, 
    ["room"] = {
        ["food_img"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "foodConfig"
        }, 
        ["room_ai"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "roomAi"
        }, 
        ["reward"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "rewardConfig"
        }, 
        ["born_rule"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "entityBorn"
        }, 
        ["ranking_type"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "rankingType"
        }
    }, 
    ["timeValue"] = {}, 
    ["mailType"] = {}, 
    ["aiConfig"] = {}, 
    ["item"] = {
        ["sell"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "sellType"
        }, 
        ["post_order"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }, 
        ["pre_order"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "item"
        }, 
        ["animation"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "actionConfig"
        }, 
        ["compound"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "synthesis"
        }, 
        ["type"] = {
            ["dstKey"] = "type", 
            ["dstTbl"] = "itemType"
        }
    }, 
    ["chargeGive"] = {
        ["exchangeid"] = {
            ["dstKey"] = "exchangeid", 
            ["dstTbl"] = "chargeConfig"
        }, 
        ["order"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "chargeConfig"
        }
    }, 
    ["scoreChange"] = {
        ["end_gift"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "giftPack"
        }
    }, 
    ["weightshowConfig"] = {}, 
    ["scoreMatch"] = {
        ["match_max_2"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "scoreMatch"
        }, 
        ["match_max_3"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "scoreMatch"
        }, 
        ["match_max_0"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "scoreMatch"
        }, 
        ["match_max_1"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "scoreMatch"
        }, 
        ["match_max_4"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "scoreMatch"
        }, 
        ["match_min_0"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "scoreMatch"
        }, 
        ["match_min_1"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "scoreMatch"
        }, 
        ["match_min_2"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "scoreMatch"
        }, 
        ["match_min_3"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "scoreMatch"
        }, 
        ["match_min_4"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "scoreMatch"
        }, 
        ["room_type"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "room"
        }
    }, 
    ["rankingType"] = {}, 
    ["entityBorn"] = {
        ["food_id"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "entityConfig"
        }, 
        ["entity_1"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "entityConfig"
        }, 
        ["entity_2"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "entityConfig"
        }, 
        ["entity_3"] = {
            ["dstKey"] = "id", 
            ["dstTbl"] = "entityConfig"
        }
    }
}