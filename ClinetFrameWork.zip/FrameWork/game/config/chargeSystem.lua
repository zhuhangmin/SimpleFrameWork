-- system                           string                           描述
-- type                             int                              机型

return {
	["BEG"] = {
		type = 0,
	},
	["ANDROID"] = {
		type = 1,
	},
	["IOS"] = {
		type = 2,
	},
	["END"] = {
		type = 3,
	},
}
