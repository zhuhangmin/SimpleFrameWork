-- id                               int                              序号
-- min_time                         int                              最小时间
-- max_time                         int                              最大时间
-- variable_a                       int                              变量a（万分位）
-- variable_b                       int                              变量b
-- variable_c                       int                              变量c

return {
	[1] = {
		min_time = 0,
		max_time = 240,
		variable_a = 0,
		variable_b = 0,
		variable_c = 60,
	},
	[2] = {
		min_time = 241,
		max_time = 10800,
		variable_a = 2500,
		variable_b = 0,
		variable_c = 60,
	},
	[3] = {
		min_time = 10801,
		max_time = 28800,
		variable_a = 2000,
		variable_b = 9,
		variable_c = 60,
	},
	[4] = {
		min_time = 28801,
		max_time = 57600,
		variable_a = 1460,
		variable_b = 35,
		variable_c = 60,
	},
	[5] = {
		min_time = 57601,
		max_time = 86400,
		variable_a = 1146,
		variable_b = 65,
		variable_c = 60,
	},
	[6] = {
		min_time = 86401,
		max_time = 999999,
		variable_a = 1146,
		variable_b = 65,
		variable_c = 60,
	},
}
