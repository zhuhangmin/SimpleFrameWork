-- id                               int                              序号
-- roomType                         int                              房间类型
-- CONTINUED_TIME                   int                              房间持续时间
-- OPEN_TIME                        int                              房间进入时间限制
-- ROOM_MAX_PEOPLE                  int                              房间人数上限
-- rankingType                      int                              房间结束排名方式（从大到小）
-- ROOM_REWARD                      int                              房间奖励
-- AI_NUM                           int                              每个用户携带AI的数量
-- BATTLEFIELD_WIDE                 int                              战场游戏范围宽度
-- BATTLEFIELD_HIGH                 int                              战场游戏范围高度
-- BATTLEFIELD_OUTSIDE_WIDE         int                              战场边界外范围高度
-- BATTLEFIELD_OUTSIDE_HIGH         int                              战场边界外范围宽度
-- INITIAL_SCORE                    int                              球体初始分数
-- MIN_SCORE                        int                              球体最小分数
-- MAX_SCORE                        int                              球体最大分数
-- MIN_DIVIDE_SCORE                 int                              球体最小分裂分数
-- MAX_DIVIDE_COUNT                 int                              球的最大分裂个数
-- MIN_JET_SCORE                    int                              球的最小喷射分数
-- SPRAY_NUTRIENT_SCORE             int                              喷射养份的分数
-- SYSTEM_NUTRIENT_SCORE            int                              小养份分数（系统生成）

roomConfig= {
	[1] = {
		roomType = 1,
		CONTINUED_TIME = 360,
		OPEN_TIME = 120,
		ROOM_MAX_PEOPLE = 50,
		rankingType = 1,
		ROOM_REWARD = 1,
		AI_NUM = 1,
		BATTLEFIELD_WIDE = 5000,
		BATTLEFIELD_HIGH = 5000,
		BATTLEFIELD_OUTSIDE_WIDE = 1750,
		BATTLEFIELD_OUTSIDE_HIGH = 1750,
		INITIAL_SCORE = 10,
		MIN_SCORE = 10,
		MAX_SCORE = 999999,
		MIN_DIVIDE_SCORE = 35,
		MAX_DIVIDE_COUNT = 4,
		MIN_JET_SCORE = 35,
		SPRAY_NUTRIENT_SCORE = 2,
		SYSTEM_NUTRIENT_SCORE = 1,
	},
}
