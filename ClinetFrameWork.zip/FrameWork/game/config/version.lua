-- id                               int                              服务器版本编号
-- beg_date                         int                              开始日期
-- end_date                         int                              结束日期
-- mail_type                        string                           对应更新邮件

return {
	[1] = {
		beg_date = 20180425,
		end_date = 20180528,
		mail_type = "0",
	},
	[2] = {
		beg_date = 20180528,
		end_date = 20180627,
		mail_type = "0",
	},
	[3] = {
		beg_date = 20180627,
		end_date = 20300101,
		mail_type = "UPDATE3",
	},
}
