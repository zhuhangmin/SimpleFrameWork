-- id                               int                              抽奖编号
-- prob                             int                              相对概率
-- gift_pack                        int                              奖励内容
-- des                              string                           奖品描述

return {
	[1] = {
		prob = 500,
		gift_pack = 40,
		des = "钻石100",
	},
	[2] = {
		prob = 1200,
		gift_pack = 44,
		des = "星星单抽券",
	},
	[3] = {
		prob = 1500,
		gift_pack = 41,
		des = "星星1000",
	},
	[4] = {
		prob = 1000,
		gift_pack = 46,
		des = "1级进阶道具",
	},
	[5] = {
		prob = 1500,
		gift_pack = 39,
		des = "钻石50",
	},
	[6] = {
		prob = 1000,
		gift_pack = 42,
		des = "1级营养素",
	},
	[7] = {
		prob = 800,
		gift_pack = 45,
		des = "钻石单抽券",
	},
	[8] = {
		prob = 1500,
		gift_pack = 38,
		des = "钻石10",
	},
	[9] = {
		prob = 500,
		gift_pack = 47,
		des = "2级进阶道具",
	},
	[10] = {
		prob = 500,
		gift_pack = 43,
		des = "2级营养素",
	},
}
