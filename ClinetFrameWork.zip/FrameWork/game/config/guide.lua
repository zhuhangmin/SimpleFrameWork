-- id                               int                              引导编号
-- step1                            int                              引导步骤1
-- step2                            int                              引导步骤2
-- step3                            int                              引导步骤4
-- step4                            int                              引导步骤4
-- step5                            int                              引导步骤5
-- next_guide                       int                              下一引导ID
-- pre_guide                        int                              上一引导ID
-- condition_count                  int                              登录次数条件

return {
	[1] = {
		step1 = 1,
		step2 = 0,
		step3 = 0,
		step4 = 0,
		step5 = 0,
		next_guide = -1,
		pre_guide = 0,
		condition_count = 1,
	},
}
