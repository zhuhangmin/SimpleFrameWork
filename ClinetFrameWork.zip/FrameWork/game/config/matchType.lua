-- mode                             string                           形容词
-- type                             int                              序号
-- comment                          string                           描述

return {
	["BEG"] = {
		type = 0,
		comment = "开始",
	},
	["MATCH_1"] = {
		type = 1,
		comment = "haha",
	},
	["MATCH_2"] = {
		type = 2,
		comment = "hei",
	},
	["MATCH_3"] = {
		type = 3,
		comment = "aga",
	},
	["MATCH_4"] = {
		type = 4,
		comment = "dd",
	},
	["MATCH_5"] = {
		type = 5,
		comment = "dd",
	},
	["MATCH_6"] = {
		type = 6,
		comment = "ddd",
	},
	["END"] = {
		type = 9,
		comment = "结束",
	},
}
