-- id                               int                              商品编号
-- item_id                          int                              物品编号
-- sell                             string                           购买消耗货币类型
-- price                            int                              购买价格

return {
	[1] = {
		item_id = 40001,
		sell = "STAR",
		price = 500,
	},
	[2] = {
		item_id = 40002,
		sell = "DIAMOND",
		price = 30,
	},
	[3] = {
		item_id = 40003,
		sell = "DIAMOND",
		price = 60,
	},
	[4] = {
		item_id = 40004,
		sell = "DIAMOND",
		price = 120,
	},
	[5] = {
		item_id = 55001,
		sell = "DIAMOND",
		price = 200,
	},
	[6] = {
		item_id = 55002,
		sell = "DIAMOND",
		price = 300,
	},
	[7] = {
		item_id = 55003,
		sell = "DIAMOND",
		price = 400,
	},
	[8] = {
		item_id = 55004,
		sell = "DIAMOND",
		price = 500,
	},
	[9] = {
		item_id = 30101,
		sell = "DIAMOND",
		price = 100,
	},
	[10] = {
		item_id = 30104,
		sell = "DIAMOND",
		price = 100,
	},
	[11] = {
		item_id = 30107,
		sell = "DIAMOND",
		price = 100,
	},
	[12] = {
		item_id = 30108,
		sell = "DIAMOND",
		price = 100,
	},
	[13] = {
		item_id = 30201,
		sell = "DIAMOND",
		price = 100,
	},
	[14] = {
		item_id = 30202,
		sell = "DIAMOND",
		price = 100,
	},
	[15] = {
		item_id = 30401,
		sell = "DIAMOND",
		price = 400,
	},
	[16] = {
		item_id = 30402,
		sell = "DIAMOND",
		price = 400,
	},
	[17] = {
		item_id = 30403,
		sell = "DIAMOND",
		price = 400,
	},
	[18] = {
		item_id = 30404,
		sell = "DIAMOND",
		price = 400,
	},
	[19] = {
		item_id = 30405,
		sell = "DIAMOND",
		price = 400,
	},
	[20] = {
		item_id = 30406,
		sell = "DIAMOND",
		price = 400,
	},
	[21] = {
		item_id = 30407,
		sell = "DIAMOND",
		price = 400,
	},
	[22] = {
		item_id = 30408,
		sell = "DIAMOND",
		price = 400,
	},
	[23] = {
		item_id = 30409,
		sell = "DIAMOND",
		price = 400,
	},
	[24] = {
		item_id = 30410,
		sell = "DIAMOND",
		price = 400,
	},
	[25] = {
		item_id = 30501,
		sell = "DIAMOND",
		price = 400,
	},
	[26] = {
		item_id = 30502,
		sell = "DIAMOND",
		price = 400,
	},
	[27] = {
		item_id = 30503,
		sell = "DIAMOND",
		price = 400,
	},
	[28] = {
		item_id = 30504,
		sell = "DIAMOND",
		price = 400,
	},
	[29] = {
		item_id = 30505,
		sell = "DIAMOND",
		price = 400,
	},
	[30] = {
		item_id = 30506,
		sell = "DIAMOND",
		price = 400,
	},
	[31] = {
		item_id = 30512,
		sell = "DIAMOND",
		price = 400,
	},
	[32] = {
		item_id = 30513,
		sell = "DIAMOND",
		price = 400,
	},
	[33] = {
		item_id = 30507,
		sell = "DIAMOND",
		price = 1200,
	},
	[34] = {
		item_id = 30508,
		sell = "DIAMOND",
		price = 1200,
	},
	[35] = {
		item_id = 30509,
		sell = "DIAMOND",
		price = 1200,
	},
	[36] = {
		item_id = 30510,
		sell = "DIAMOND",
		price = 1200,
	},
	[37] = {
		item_id = 30511,
		sell = "DIAMOND",
		price = 1200,
	},
	[38] = {
		item_id = 30514,
		sell = "DIAMOND",
		price = 1200,
	},
	[39] = {
		item_id = 30515,
		sell = "DIAMOND",
		price = 1200,
	},
	[40] = {
		item_id = 30601,
		sell = "DIAMOND",
		price = 1200,
	},
	[41] = {
		item_id = 30602,
		sell = "DIAMOND",
		price = 1200,
	},
	[42] = {
		item_id = 30603,
		sell = "DIAMOND",
		price = 1200,
	},
	[43] = {
		item_id = 30604,
		sell = "DIAMOND",
		price = 1200,
	},
	[44] = {
		item_id = 30605,
		sell = "DIAMOND",
		price = 1200,
	},
	[45] = {
		item_id = 30606,
		sell = "DIAMOND",
		price = 1200,
	},
	[46] = {
		item_id = 30607,
		sell = "DIAMOND",
		price = 1200,
	},
	[47] = {
		item_id = 30608,
		sell = "DIAMOND",
		price = 1200,
	},
	[48] = {
		item_id = 30609,
		sell = "DIAMOND",
		price = 1200,
	},
	[49] = {
		item_id = 30610,
		sell = "DIAMOND",
		price = 3000,
	},
	[50] = {
		item_id = 30611,
		sell = "DIAMOND",
		price = 3000,
	},
	[51] = {
		item_id = 30612,
		sell = "DIAMOND",
		price = 3000,
	},
	[52] = {
		item_id = 30613,
		sell = "DIAMOND",
		price = 3000,
	},
	[53] = {
		item_id = 30614,
		sell = "DIAMOND",
		price = 3000,
	},
	[54] = {
		item_id = 30701,
		sell = "DIAMOND",
		price = 3000,
	},
	[55] = {
		item_id = 30702,
		sell = "DIAMOND",
		price = 3000,
	},
	[56] = {
		item_id = 30703,
		sell = "DIAMOND",
		price = 3000,
	},
	[57] = {
		item_id = 30704,
		sell = "DIAMOND",
		price = 3000,
	},
}
