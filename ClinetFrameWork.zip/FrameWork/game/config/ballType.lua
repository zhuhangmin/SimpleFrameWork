-- type                             string                           说明
-- id                               int                              道具类型
-- comment                          string                           描述

return {
	["BEG"] = {
		id = 0,
		comment = "开始",
	},
	["EAT"] = {
		id = 1,
		comment = "不能吃",
	},
	["NOEAT"] = {
		id = 2,
		comment = "可以吃",
	},
	["RULEEAT"] = {
		id = 3,
		comment = "按规则大吃小",
	},
	["END"] = {
		id = 4,
		comment = "结束",
	},
}
