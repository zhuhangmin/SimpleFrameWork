-- id                               int                              邮件礼包编号
-- reward1                          int                              奖励物品1
-- num1                             int                              物品数量1
-- reward2                          int                              奖励物品2
-- num2                             int                              物品数量2
-- reward3                          int                              奖励物品3
-- num3                             int                              物品数量3
-- reward4                          int                              奖励物品4
-- num4                             int                              物品数量4
-- reward5                          int                              奖励物品5
-- num5                             int                              物品数量5

return {
	[1] = {
		reward1 = 1000000,
		num1 = 1000,
		reward2 = 40001,
		num2 = 1,
		reward3 = 30101,
		num3 = 1,
		reward4 = 0,
		num4 = 0,
		reward5 = 0,
		num5 = 0,
	},
	[2] = {
		reward1 = 0,
		num1 = 0,
		reward2 = 0,
		num2 = 0,
		reward3 = 0,
		num3 = 0,
		reward4 = 0,
		num4 = 0,
		reward5 = 0,
		num5 = 0,
	},
}
