-- type                             string                           说明
-- id                               int                              道具类型
-- comment                          string                           描述

return {
	["BEG"] = {
		id = 0,
		comment = "开始",
	},
	["SELF"] = {
		id = 1,
		comment = "自己",
	},
	["ENEMY"] = {
		id = 2,
		comment = "产生碰撞的目标",
	},
	["END"] = {
		id = 3,
		comment = "结束",
	},
}
