-- id                               int                              充值序号
-- system                           int                              机型
-- money                            int                              充值金额
-- exchangeid                       int                              充值ID
-- productid                        int                              产品ID（苹果专用）

return {
	[1] = {
		system = 1,
		money = 10,
		exchangeid = 2242,
		productid = 10,
	},
	[2] = {
		system = 1,
		money = 25,
		exchangeid = 2243,
		productid = 25,
	},
	[3] = {
		system = 1,
		money = 68,
		exchangeid = 2244,
		productid = 68,
	},
	[4] = {
		system = 1,
		money = 108,
		exchangeid = 2245,
		productid = 108,
	},
	[5] = {
		system = 1,
		money = 288,
		exchangeid = 2246,
		productid = 288,
	},
	[6] = {
		system = 1,
		money = 648,
		exchangeid = 2247,
		productid = 648,
	},
	[7] = {
		system = 1,
		money = 1,
		exchangeid = 2303,
		productid = 1,
	},
	[8] = {
		system = 1,
		money = 2,
		exchangeid = 2304,
		productid = 2,
	},
	[9] = {
		system = 1,
		money = 5,
		exchangeid = 2305,
		productid = 5,
	},
	[10] = {
		system = 1,
		money = 6,
		exchangeid = 2306,
		productid = 6,
	},
}
