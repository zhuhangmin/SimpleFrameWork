-- id                               int                              序号
-- comment                          string                           屏蔽字

return {
	[1] = {
		comment = " ",
	},
	[2] = {
		comment = "毛泽东",
	},
	[3] = {
		comment = "周恩来",
	},
	[4] = {
		comment = "刘少奇",
	},
	[5] = {
		comment = "朱德",
	},
	[6] = {
		comment = "彭德怀",
	},
	[7] = {
		comment = "林彪",
	},
	[8] = {
		comment = "刘伯承",
	},
	[9] = {
		comment = "陈毅",
	},
	[10] = {
		comment = "贺龙",
	},
	[11] = {
		comment = "聂荣臻",
	},
	[12] = {
		comment = "徐向前",
	},
	[13] = {
		comment = "罗荣桓",
	},
	[14] = {
		comment = "叶剑英",
	},
	[15] = {
		comment = "李大钊",
	},
	[16] = {
		comment = "陈独秀",
	},
	[17] = {
		comment = "孙中山",
	},
	[18] = {
		comment = "孙文",
	},
	[19] = {
		comment = "孙逸仙",
	},
	[20] = {
		comment = "邓小平",
	},
	[21] = {
		comment = "陈云",
	},
	[22] = {
		comment = "江泽民",
	},
	[23] = {
		comment = "李鹏",
	},
	[24] = {
		comment = "朱镕基",
	},
	[25] = {
		comment = "李瑞环",
	},
	[26] = {
		comment = "尉健行",
	},
	[27] = {
		comment = "李岚清",
	},
	[28] = {
		comment = "胡锦涛",
	},
	[29] = {
		comment = "罗干",
	},
	[30] = {
		comment = "温家宝",
	},
	[31] = {
		comment = "吴邦国",
	},
	[32] = {
		comment = "曾庆红",
	},
	[33] = {
		comment = "贾庆林",
	},
	[34] = {
		comment = "黄菊",
	},
	[35] = {
		comment = "吴官正",
	},
	[36] = {
		comment = "李长春",
	},
	[37] = {
		comment = "吴仪",
	},
	[38] = {
		comment = "回良玉",
	},
	[39] = {
		comment = "曾培炎",
	},
	[40] = {
		comment = "周永康",
	},
	[41] = {
		comment = "曹刚川",
	},
	[42] = {
		comment = "唐家璇",
	},
	[43] = {
		comment = "华建敏",
	},
	[44] = {
		comment = "陈至立",
	},
	[45] = {
		comment = "陈良宇",
	},
	[46] = {
		comment = "张德江",
	},
	[47] = {
		comment = "张立昌",
	},
	[48] = {
		comment = "张德江",
	},
	[49] = {
		comment = "俞正声",
	},
	[50] = {
		comment = "刘云山",
	},
	[51] = {
		comment = "王岐山",
	},
	[52] = {
		comment = "张高丽",
	},
	[53] = {
		comment = "王乐泉",
	},
	[54] = {
		comment = "刘云山",
	},
	[55] = {
		comment = "王刚",
	},
	[56] = {
		comment = "王兆国",
	},
	[57] = {
		comment = "刘淇",
	},
	[58] = {
		comment = "贺国强",
	},
	[59] = {
		comment = "郭伯雄",
	},
	[60] = {
		comment = "胡耀邦",
	},
	[61] = {
		comment = "王乐泉",
	},
	[62] = {
		comment = "王兆国",
	},
	[63] = {
		comment = "周永康",
	},
	[64] = {
		comment = "李登辉",
	},
	[65] = {
		comment = "连战",
	},
	[66] = {
		comment = "陈水扁",
	},
	[67] = {
		comment = "宋楚瑜",
	},
	[68] = {
		comment = "吕秀莲",
	},
	[69] = {
		comment = "郁慕明",
	},
	[70] = {
		comment = "蒋介石",
	},
	[71] = {
		comment = "蒋中正",
	},
	[72] = {
		comment = "蒋经国",
	},
	[73] = {
		comment = "马英九",
	},
	[74] = {
		comment = "习近平",
	},
	[75] = {
		comment = "李克强",
	},
	[76] = {
		comment = "吴帮国",
	},
	[77] = {
		comment = "无帮国",
	},
	[78] = {
		comment = "无邦国",
	},
	[79] = {
		comment = "无帮过",
	},
	[80] = {
		comment = "瘟家宝",
	},
	[81] = {
		comment = "假庆林",
	},
	[82] = {
		comment = "甲庆林",
	},
	[83] = {
		comment = "假青林",
	},
	[84] = {
		comment = "离长春",
	},
	[85] = {
		comment = "习远平",
	},
	[86] = {
		comment = "袭近平",
	},
	[87] = {
		comment = "李磕墙",
	},
	[88] = {
		comment = "贺过墙",
	},
	[89] = {
		comment = "和锅枪",
	},
	[90] = {
		comment = "粥永康",
	},
	[91] = {
		comment = "轴永康",
	},
	[92] = {
		comment = "肘永康",
	},
	[93] = {
		comment = "周健康",
	},
	[94] = {
		comment = "粥健康",
	},
	[95] = {
		comment = "周小康",
	},
	[96] = {
		comment = "李肇星务",
	},
	[97] = {
		comment = "国务委员",
	},
	[98] = {
		comment = "国务院",
	},
	[99] = {
		comment = "中央委员",
	},
	[100] = {
		comment = "发改委",
	},
	[101] = {
		comment = "国家发展和改革委员会",
	},
	[102] = {
		comment = "发展和改革委员会",
	},
	[103] = {
		comment = "国家发展与改革委员会",
	},
	[104] = {
		comment = "发展与改革委员会",
	},
	[105] = {
		comment = "薄熙来",
	},
	[106] = {
		comment = "温家饱",
	},
	[107] = {
		comment = "温假饱",
	},
	[108] = {
		comment = "胡惊涛",
	},
	[109] = {
		comment = "习仲勋",
	},
	[110] = {
		comment = "华国锋",
	},
	[111] = {
		comment = "彭丽媛",
	},
	[112] = {
		comment = "新闻出版总署",
	},
	[113] = {
		comment = "新闻出版署",
	},
	[114] = {
		comment = "布什",
	},
	[115] = {
		comment = "布莱尔",
	},
	[116] = {
		comment = "小泉",
	},
	[117] = {
		comment = "纯一郎",
	},
	[118] = {
		comment = "萨马兰奇",
	},
	[119] = {
		comment = "安南",
	},
	[120] = {
		comment = "阿拉法特",
	},
	[121] = {
		comment = "普京",
	},
	[122] = {
		comment = "默克尔",
	},
	[123] = {
		comment = "克林顿",
	},
	[124] = {
		comment = "里根",
	},
	[125] = {
		comment = "尼克松",
	},
	[126] = {
		comment = "林肯",
	},
	[127] = {
		comment = "杜鲁门",
	},
	[128] = {
		comment = "赫鲁晓夫",
	},
	[129] = {
		comment = "列宁",
	},
	[130] = {
		comment = "斯大林",
	},
	[131] = {
		comment = "马克思",
	},
	[132] = {
		comment = "恩格斯",
	},
	[133] = {
		comment = "金正日",
	},
	[134] = {
		comment = "金日成",
	},
	[135] = {
		comment = "萨达姆",
	},
	[136] = {
		comment = "胡志明",
	},
	[137] = {
		comment = "西哈努克",
	},
	[138] = {
		comment = "希拉克",
	},
	[139] = {
		comment = "撒切尔",
	},
	[140] = {
		comment = "阿罗约",
	},
	[141] = {
		comment = "曼德拉",
	},
	[142] = {
		comment = "卡斯特罗",
	},
	[143] = {
		comment = "富兰克林",
	},
	[144] = {
		comment = "华盛顿",
	},
	[145] = {
		comment = "艾森豪威尔",
	},
	[146] = {
		comment = "拿破仑",
	},
	[147] = {
		comment = "亚历山大",
	},
	[148] = {
		comment = "路易",
	},
	[149] = {
		comment = "拉姆斯菲尔德",
	},
	[150] = {
		comment = "劳拉",
	},
	[151] = {
		comment = "鲍威尔",
	},
	[152] = {
		comment = "奥巴马",
	},
	[153] = {
		comment = "本拉登",
	},
	[154] = {
		comment = "奥马尔",
	},
	[155] = {
		comment = "柴玲",
	},
	[156] = {
		comment = "达赖喇嘛",
	},
	[157] = {
		comment = "江青",
	},
	[158] = {
		comment = "张春桥",
	},
	[159] = {
		comment = "姚文元",
	},
	[160] = {
		comment = "王洪文",
	},
	[161] = {
		comment = "东条英机",
	},
	[162] = {
		comment = "希特勒",
	},
	[163] = {
		comment = "墨索里尼",
	},
	[164] = {
		comment = "冈村秀树",
	},
	[165] = {
		comment = "冈村宁次",
	},
	[166] = {
		comment = "高丽朴",
	},
	[167] = {
		comment = "赵紫阳",
	},
	[168] = {
		comment = "王丹",
	},
	[169] = {
		comment = "沃尔开西",
	},
	[170] = {
		comment = "李洪志",
	},
	[171] = {
		comment = "李大师",
	},
	[172] = {
		comment = "赖昌星",
	},
	[173] = {
		comment = "马加爵",
	},
	[174] = {
		comment = "班禅",
	},
	[175] = {
		comment = "额尔德尼",
	},
	[176] = {
		comment = "山本五十六",
	},
	[177] = {
		comment = "阿扁",
	},
	[178] = {
		comment = "阿扁万岁",
	},
	[179] = {
		comment = "热那亚",
	},
	[180] = {
		comment = "热比娅",
	},
	[181] = {
		comment = "尖阁列岛",
	},
	[182] = {
		comment = "实际神",
	},
	[183] = {
		comment = "东方闪电",
	},
	[184] = {
		comment = "全能神",
	},
	[185] = {
		comment = "安倍晋三",
	},
	[186] = {
		comment = "金正恩",
	},
	[187] = {
		comment = "恐怖组织",
	},
	[188] = {
		comment = "买毒品",
	},
	[189] = {
		comment = "卖毒品",
	},
	[190] = {
		comment = "茉莉花",
	},
	[191] = {
		comment = "钓鱼岛",
	},
	[192] = {
		comment = "钓鱼岛不属于中国",
	},
	[193] = {
		comment = "突尼斯",
	},
	[194] = {
		comment = "gongchandang",
	},
	[195] = {
		comment = "西藏314事件",
	},
	[196] = {
		comment = "新疆7.5事件",
	},
	[197] = {
		comment = "新疆国",
	},
	[198] = {
		comment = "党中央",
	},
	[199] = {
		comment = "新闻管制",
	},
	[200] = {
		comment = "一边一国",
	},
	[201] = {
		comment = "两国论",
	},
	[202] = {
		comment = "分裂中国",
	},
	[203] = {
		comment = "革命",
	},
	[204] = {
		comment = "茉莉花",
	},
	[205] = {
		comment = "突尼斯",
	},
	[206] = {
		comment = "国内动态详情",
	},
	[207] = {
		comment = "回回",
	},
	[208] = {
		comment = "六四",
	},
	[209] = {
		comment = "六四运动",
	},
	[210] = {
		comment = "美国之音",
	},
	[211] = {
		comment = "密宗",
	},
	[212] = {
		comment = "民国",
	},
	[213] = {
		comment = "民进党",
	},
	[214] = {
		comment = "民运",
	},
	[215] = {
		comment = "民主",
	},
	[216] = {
		comment = "民主潮",
	},
	[217] = {
		comment = "摩门教",
	},
	[218] = {
		comment = "纳粹",
	},
	[219] = {
		comment = "南华早报",
	},
	[220] = {
		comment = "南蛮",
	},
	[221] = {
		comment = "明慧网",
	},
	[222] = {
		comment = "起义",
	},
	[223] = {
		comment = "亲民党",
	},
	[224] = {
		comment = "瘸腿帮",
	},
	[225] = {
		comment = "人民报",
	},
	[226] = {
		comment = "法轮功",
	},
	[227] = {
		comment = "法轮大法",
	},
	[228] = {
		comment = "打倒共产党",
	},
	[229] = {
		comment = "台独万岁",
	},
	[230] = {
		comment = "圣战",
	},
	[231] = {
		comment = "示威",
	},
	[232] = {
		comment = "台独",
	},
	[233] = {
		comment = "台独分子",
	},
	[234] = {
		comment = "台联",
	},
	[235] = {
		comment = "台湾民国",
	},
	[236] = {
		comment = "台湾岛国",
	},
	[237] = {
		comment = "台湾国",
	},
	[238] = {
		comment = "台湾独立",
	},
	[239] = {
		comment = "太子党",
	},
	[240] = {
		comment = "天安门事件",
	},
	[241] = {
		comment = "屠杀",
	},
	[242] = {
		comment = "小泉",
	},
	[243] = {
		comment = "新党",
	},
	[244] = {
		comment = "新疆独立",
	},
	[245] = {
		comment = "新疆分裂",
	},
	[246] = {
		comment = "新疆国",
	},
	[247] = {
		comment = "疆独",
	},
	[248] = {
		comment = "西藏独立",
	},
	[249] = {
		comment = "西藏分裂",
	},
	[250] = {
		comment = "西藏国",
	},
	[251] = {
		comment = "藏独",
	},
	[252] = {
		comment = "藏青会",
	},
	[253] = {
		comment = "藏妇会",
	},
	[254] = {
		comment = "学潮",
	},
	[255] = {
		comment = "学运",
	},
	[256] = {
		comment = "一党专政",
	},
	[257] = {
		comment = "一中一台",
	},
	[258] = {
		comment = "两个中国",
	},
	[259] = {
		comment = "一贯道",
	},
	[260] = {
		comment = "游行",
	},
	[261] = {
		comment = "造反",
	},
	[262] = {
		comment = "真善忍",
	},
	[263] = {
		comment = "镇压",
	},
	[264] = {
		comment = "政变",
	},
	[265] = {
		comment = "政治",
	},
	[266] = {
		comment = "政治反对派",
	},
	[267] = {
		comment = "政治犯",
	},
	[268] = {
		comment = "中共",
	},
	[269] = {
		comment = "共产党",
	},
	[270] = {
		comment = "反党",
	},
	[271] = {
		comment = "反共",
	},
	[272] = {
		comment = "政府",
	},
	[273] = {
		comment = "民主党",
	},
	[274] = {
		comment = "中国之春",
	},
	[275] = {
		comment = "转法轮",
	},
	[276] = {
		comment = "自焚",
	},
	[277] = {
		comment = "共党",
	},
	[278] = {
		comment = "共匪",
	},
	[279] = {
		comment = "苏家屯",
	},
	[280] = {
		comment = "基地组织",
	},
	[281] = {
		comment = "塔利班",
	},
	[282] = {
		comment = "东亚病夫",
	},
	[283] = {
		comment = "支那",
	},
	[284] = {
		comment = "高治联",
	},
	[285] = {
		comment = "高自联",
	},
	[286] = {
		comment = "专政",
	},
	[287] = {
		comment = "专制",
	},
	[288] = {
		comment = "世界维吾尔大会",
	},
	[289] = {
		comment = "核工业基地",
	},
	[290] = {
		comment = "核武器",
	},
	[291] = {
		comment = "铀",
	},
	[292] = {
		comment = "原子弹",
	},
	[293] = {
		comment = "氢弹",
	},
	[294] = {
		comment = "导弹",
	},
	[295] = {
		comment = "核潜艇",
	},
	[296] = {
		comment = "大参考",
	},
	[297] = {
		comment = "小参考",
	},
	[298] = {
		comment = "国内动态清样",
	},
	[299] = {
		comment = "释迦牟尼",
	},
	[300] = {
		comment = "阿弥陀佛",
	},
	[301] = {
		comment = "多维",
	},
	[302] = {
		comment = "河殇",
	},
	[303] = {
		comment = "摩门教",
	},
	[304] = {
		comment = "穆罕默德",
	},
	[305] = {
		comment = "圣战",
	},
	[306] = {
		comment = "耶和华",
	},
	[307] = {
		comment = "耶稣",
	},
	[308] = {
		comment = "伊斯兰",
	},
	[309] = {
		comment = "真主安拉",
	},
	[310] = {
		comment = "白莲教",
	},
	[311] = {
		comment = "天主教",
	},
	[312] = {
		comment = "基督教",
	},
	[313] = {
		comment = "东正教",
	},
	[314] = {
		comment = "大法",
	},
	[315] = {
		comment = "法轮",
	},
	[316] = {
		comment = "法轮功",
	},
	[317] = {
		comment = "瘸腿帮",
	},
	[318] = {
		comment = "真理教",
	},
	[319] = {
		comment = "真善忍",
	},
	[320] = {
		comment = "转法轮",
	},
	[321] = {
		comment = "自焚",
	},
	[322] = {
		comment = "走向圆满",
	},
	[323] = {
		comment = "黄大仙",
	},
	[324] = {
		comment = "跳大神",
	},
	[325] = {
		comment = "神汉",
	},
	[326] = {
		comment = "神婆",
	},
	[327] = {
		comment = "真理教",
	},
	[328] = {
		comment = "大卫教",
	},
	[329] = {
		comment = "阎王",
	},
	[330] = {
		comment = "黑白无常",
	},
	[331] = {
		comment = "牛头马面",
	},
	[332] = {
		comment = "藏独",
	},
	[333] = {
		comment = "高丽棒子",
	},
	[334] = {
		comment = "疆独",
	},
	[335] = {
		comment = "蒙古鞑子",
	},
	[336] = {
		comment = "台独",
	},
	[337] = {
		comment = "台独分子",
	},
	[338] = {
		comment = "台联",
	},
	[339] = {
		comment = "台湾民国",
	},
	[340] = {
		comment = "西藏独立",
	},
	[341] = {
		comment = "新疆独立",
	},
	[342] = {
		comment = "南蛮",
	},
	[343] = {
		comment = "老毛子",
	},
	[344] = {
		comment = "回民吃猪肉",
	},
	[345] = {
		comment = "k粉",
	},
	[346] = {
		comment = "古柯碱",
	},
	[347] = {
		comment = "谋杀",
	},
	[348] = {
		comment = "杀人",
	},
	[349] = {
		comment = "吸毒",
	},
	[350] = {
		comment = "贩毒",
	},
	[351] = {
		comment = "赌博",
	},
	[352] = {
		comment = "拐卖",
	},
	[353] = {
		comment = "走私",
	},
	[354] = {
		comment = "卖淫",
	},
	[355] = {
		comment = "造反",
	},
	[356] = {
		comment = "强奸",
	},
	[357] = {
		comment = "轮奸",
	},
	[358] = {
		comment = "抢劫",
	},
	[359] = {
		comment = "先奸后杀",
	},
	[360] = {
		comment = "押大",
	},
	[361] = {
		comment = "押小",
	},
	[362] = {
		comment = "押注",
	},
	[363] = {
		comment = "下注",
	},
	[364] = {
		comment = "抽头",
	},
	[365] = {
		comment = "坐庄",
	},
	[366] = {
		comment = "赌马",
	},
	[367] = {
		comment = "赌球",
	},
	[368] = {
		comment = "筹码",
	},
	[369] = {
		comment = "老虎机",
	},
	[370] = {
		comment = "轮盘赌",
	},
	[371] = {
		comment = "安非他命",
	},
	[372] = {
		comment = "大麻",
	},
	[373] = {
		comment = "可卡因",
	},
	[374] = {
		comment = "海洛因",
	},
	[375] = {
		comment = "冰毒",
	},
	[376] = {
		comment = "摇头丸",
	},
	[377] = {
		comment = "杜冷丁",
	},
	[378] = {
		comment = "鸦片",
	},
	[379] = {
		comment = "罂粟",
	},
	[380] = {
		comment = "迷幻药",
	},
	[381] = {
		comment = "白粉",
	},
	[382] = {
		comment = "嗑药",
	},
	[383] = {
		comment = "吸毒",
	},
	[384] = {
		comment = "冰毒",
	},
	[385] = {
		comment = "冰粉",
	},
	[386] = {
		comment = "二奶",
	},
	[387] = {
		comment = "偷窥图片",
	},
	[388] = {
		comment = "成人影片",
	},
	[389] = {
		comment = "AV电影下载",
	},
	[390] = {
		comment = "夫妻床上激情自拍",
	},
	[391] = {
		comment = "处女",
	},
	[392] = {
		comment = "房事",
	},
	[393] = {
		comment = "押大",
	},
	[394] = {
		comment = "押小",
	},
	[395] = {
		comment = "坐台",
	},
	[396] = {
		comment = "猥亵",
	},
	[397] = {
		comment = "猥琐",
	},
	[398] = {
		comment = "肉欲",
	},
	[399] = {
		comment = "肉体",
	},
	[400] = {
		comment = "排泄",
	},
	[401] = {
		comment = "卵子",
	},
	[402] = {
		comment = "搞基",
	},
	[403] = {
		comment = "约炮",
	},
	[404] = {
		comment = "撸管子",
	},
	[405] = {
		comment = "处男",
	},
	[406] = {
		comment = "黄盘",
	},
	[407] = {
		comment = "毛盘",
	},
	[408] = {
		comment = "艾滋病",
	},
	[409] = {
		comment = "性病",
	},
	[410] = {
		comment = "叫春",
	},
	[411] = {
		comment = "牛B",
	},
	[412] = {
		comment = "牛比",
	},
	[413] = {
		comment = "J8",
	},
	[414] = {
		comment = "小姐兼职",
	},
	[415] = {
		comment = "交媾",
	},
	[416] = {
		comment = "毛片",
	},
	[417] = {
		comment = "黄片",
	},
	[418] = {
		comment = "交配",
	},
	[419] = {
		comment = "房事",
	},
	[420] = {
		comment = "性事",
	},
	[421] = {
		comment = "偷窥",
	},
	[422] = {
		comment = "马拉戈壁",
	},
	[423] = {
		comment = "AIDS",
	},
	[424] = {
		comment = "aids",
	},
	[425] = {
		comment = "Aids",
	},
	[426] = {
		comment = "DICK",
	},
	[427] = {
		comment = "dick",
	},
	[428] = {
		comment = "Dick",
	},
	[429] = {
		comment = "penis",
	},
	[430] = {
		comment = "sex",
	},
	[431] = {
		comment = "SM",
	},
	[432] = {
		comment = "屙",
	},
	[433] = {
		comment = "爱滋",
	},
	[434] = {
		comment = "淋病",
	},
	[435] = {
		comment = "梅毒",
	},
	[436] = {
		comment = "爱液",
	},
	[437] = {
		comment = "屄",
	},
	[438] = {
		comment = "逼",
	},
	[439] = {
		comment = "臭机八",
	},
	[440] = {
		comment = "臭鸡巴",
	},
	[441] = {
		comment = "吹喇叭",
	},
	[442] = {
		comment = "吹箫",
	},
	[443] = {
		comment = "催情药",
	},
	[444] = {
		comment = "屌",
	},
	[445] = {
		comment = "肛交",
	},
	[446] = {
		comment = "肛门",
	},
	[447] = {
		comment = "龟头",
	},
	[448] = {
		comment = "黄色",
	},
	[449] = {
		comment = "机八",
	},
	[450] = {
		comment = "机巴",
	},
	[451] = {
		comment = "鸡八",
	},
	[452] = {
		comment = "鸡巴",
	},
	[453] = {
		comment = "机掰",
	},
	[454] = {
		comment = "机巴",
	},
	[455] = {
		comment = "鸡叭",
	},
	[456] = {
		comment = "鸡鸡",
	},
	[457] = {
		comment = "鸡掰",
	},
	[458] = {
		comment = "鸡奸",
	},
	[459] = {
		comment = "妓女",
	},
	[460] = {
		comment = "奸",
	},
	[461] = {
		comment = "茎",
	},
	[462] = {
		comment = "精液",
	},
	[463] = {
		comment = "精子",
	},
	[464] = {
		comment = "尻",
	},
	[465] = {
		comment = "口交",
	},
	[466] = {
		comment = "滥交",
	},
	[467] = {
		comment = "乱交",
	},
	[468] = {
		comment = "轮奸",
	},
	[469] = {
		comment = "卖淫",
	},
	[470] = {
		comment = "屁眼",
	},
	[471] = {
		comment = "嫖娼",
	},
	[472] = {
		comment = "强奸",
	},
	[473] = {
		comment = "强奸犯",
	},
	[474] = {
		comment = "情色",
	},
	[475] = {
		comment = "肉棒",
	},
	[476] = {
		comment = "乳房",
	},
	[477] = {
		comment = "乳峰",
	},
	[478] = {
		comment = "乳交",
	},
	[479] = {
		comment = "乳头",
	},
	[480] = {
		comment = "乳晕",
	},
	[481] = {
		comment = "三陪",
	},
	[482] = {
		comment = "色情",
	},
	[483] = {
		comment = "射精",
	},
	[484] = {
		comment = "手淫",
	},
	[485] = {
		comment = "威而钢",
	},
	[486] = {
		comment = "威而柔",
	},
	[487] = {
		comment = "伟哥",
	},
	[488] = {
		comment = "性高潮",
	},
	[489] = {
		comment = "性交",
	},
	[490] = {
		comment = "性虐",
	},
	[491] = {
		comment = "性欲",
	},
	[492] = {
		comment = "穴",
	},
	[493] = {
		comment = "颜射",
	},
	[494] = {
		comment = "阳物",
	},
	[495] = {
		comment = "一夜情",
	},
	[496] = {
		comment = "阴部",
	},
	[497] = {
		comment = "阴唇",
	},
	[498] = {
		comment = "阴道",
	},
	[499] = {
		comment = "阴蒂",
	},
	[500] = {
		comment = "阴核",
	},
	[501] = {
		comment = "阴户",
	},
	[502] = {
		comment = "阴茎",
	},
	[503] = {
		comment = "阴门",
	},
	[504] = {
		comment = "淫",
	},
	[505] = {
		comment = "淫秽",
	},
	[506] = {
		comment = "淫乱",
	},
	[507] = {
		comment = "淫水",
	},
	[508] = {
		comment = "淫娃",
	},
	[509] = {
		comment = "淫液",
	},
	[510] = {
		comment = "淫汁",
	},
	[511] = {
		comment = "淫穴",
	},
	[512] = {
		comment = "淫洞",
	},
	[513] = {
		comment = "援交妹",
	},
	[514] = {
		comment = "做爱",
	},
	[515] = {
		comment = "梦遗",
	},
	[516] = {
		comment = "阳痿",
	},
	[517] = {
		comment = "早泄",
	},
	[518] = {
		comment = "奸淫",
	},
	[519] = {
		comment = "性欲",
	},
	[520] = {
		comment = "性交",
	},
	[521] = {
		comment = "Bitch",
	},
	[522] = {
		comment = "bt",
	},
	[523] = {
		comment = "cao",
	},
	[524] = {
		comment = "FUCK",
	},
	[525] = {
		comment = "Fuck",
	},
	[526] = {
		comment = "fuck",
	},
	[527] = {
		comment = "kao",
	},
	[528] = {
		comment = "NMD",
	},
	[529] = {
		comment = "NND",
	},
	[530] = {
		comment = "sb",
	},
	[531] = {
		comment = "shit",
	},
	[532] = {
		comment = "SHIT",
	},
	[533] = {
		comment = "SUCK",
	},
	[534] = {
		comment = "Suck",
	},
	[535] = {
		comment = "tmd",
	},
	[536] = {
		comment = "TMD",
	},
	[537] = {
		comment = "tnnd",
	},
	[538] = {
		comment = "K他命",
	},
	[539] = {
		comment = "白痴",
	},
	[540] = {
		comment = "笨蛋",
	},
	[541] = {
		comment = "屄",
	},
	[542] = {
		comment = "变态",
	},
	[543] = {
		comment = "婊子",
	},
	[544] = {
		comment = "操她妈",
	},
	[545] = {
		comment = "操妳妈",
	},
	[546] = {
		comment = "操你",
	},
	[547] = {
		comment = "操你妈",
	},
	[548] = {
		comment = "操他妈",
	},
	[549] = {
		comment = "草你",
	},
	[550] = {
		comment = "肏",
	},
	[551] = {
		comment = "册那",
	},
	[552] = {
		comment = "侧那",
	},
	[553] = {
		comment = "测拿",
	},
	[554] = {
		comment = "插",
	},
	[555] = {
		comment = "蠢猪",
	},
	[556] = {
		comment = "荡妇",
	},
	[557] = {
		comment = "发骚",
	},
	[558] = {
		comment = "废物",
	},
	[559] = {
		comment = "干她妈",
	},
	[560] = {
		comment = "干妳",
	},
	[561] = {
		comment = "干妳娘",
	},
	[562] = {
		comment = "干你",
	},
	[563] = {
		comment = "干你妈",
	},
	[564] = {
		comment = "干你妈B",
	},
	[565] = {
		comment = "干你妈b",
	},
	[566] = {
		comment = "干你妈逼",
	},
	[567] = {
		comment = "干你娘",
	},
	[568] = {
		comment = "干他妈",
	},
	[569] = {
		comment = "狗娘养的",
	},
	[570] = {
		comment = "滚",
	},
	[571] = {
		comment = "鸡奸",
	},
	[572] = {
		comment = "贱货",
	},
	[573] = {
		comment = "贱人",
	},
	[574] = {
		comment = "烂人",
	},
	[575] = {
		comment = "老母",
	},
	[576] = {
		comment = "老土",
	},
	[577] = {
		comment = "妈比",
	},
	[578] = {
		comment = "妈的",
	},
	[579] = {
		comment = "马的",
	},
	[580] = {
		comment = "妳老母的",
	},
	[581] = {
		comment = "妳娘的",
	},
	[582] = {
		comment = "你妈逼",
	},
	[583] = {
		comment = "破鞋",
	},
	[584] = {
		comment = "仆街",
	},
	[585] = {
		comment = "去她妈",
	},
	[586] = {
		comment = "去妳的",
	},
	[587] = {
		comment = "去妳妈",
	},
	[588] = {
		comment = "去你的",
	},
	[589] = {
		comment = "去你妈",
	},
	[590] = {
		comment = "去死",
	},
	[591] = {
		comment = "去他妈",
	},
	[592] = {
		comment = "日",
	},
	[593] = {
		comment = "日你",
	},
	[594] = {
		comment = "赛她娘",
	},
	[595] = {
		comment = "赛妳娘",
	},
	[596] = {
		comment = "赛你娘",
	},
	[597] = {
		comment = "赛他娘",
	},
	[598] = {
		comment = "骚货",
	},
	[599] = {
		comment = "傻B",
	},
	[600] = {
		comment = "傻比",
	},
	[601] = {
		comment = "傻子",
	},
	[602] = {
		comment = "上妳",
	},
	[603] = {
		comment = "上你",
	},
	[604] = {
		comment = "神经病",
	},
	[605] = {
		comment = "屎",
	},
	[606] = {
		comment = "屎妳娘",
	},
	[607] = {
		comment = "屎你娘",
	},
	[608] = {
		comment = "他妈的",
	},
	[609] = {
		comment = "王八蛋",
	},
	[610] = {
		comment = "我操",
	},
	[611] = {
		comment = "我日",
	},
	[612] = {
		comment = "乡巴佬",
	},
	[613] = {
		comment = "猪猡",
	},
	[614] = {
		comment = "屙",
	},
	[615] = {
		comment = "干",
	},
	[616] = {
		comment = "尿",
	},
	[617] = {
		comment = "掯",
	},
	[618] = {
		comment = "屌",
	},
	[619] = {
		comment = "操",
	},
	[620] = {
		comment = "骑你",
	},
	[621] = {
		comment = "湿了",
	},
	[622] = {
		comment = "操你",
	},
	[623] = {
		comment = "操他",
	},
	[624] = {
		comment = "操她",
	},
	[625] = {
		comment = "骑你",
	},
	[626] = {
		comment = "骑他",
	},
	[627] = {
		comment = "骑她",
	},
	[628] = {
		comment = "欠骑",
	},
	[629] = {
		comment = "欠人骑",
	},
	[630] = {
		comment = "来爽我",
	},
	[631] = {
		comment = "来插我",
	},
	[632] = {
		comment = "干你",
	},
	[633] = {
		comment = "干他",
	},
	[634] = {
		comment = "干她",
	},
	[635] = {
		comment = "干死",
	},
	[636] = {
		comment = "干爆",
	},
	[637] = {
		comment = "干机",
	},
	[638] = {
		comment = "FUCK",
	},
	[639] = {
		comment = "机叭",
	},
	[640] = {
		comment = "臭鸡",
	},
	[641] = {
		comment = "臭机",
	},
	[642] = {
		comment = "烂鸟",
	},
	[643] = {
		comment = "览叫",
	},
	[644] = {
		comment = "阳具",
	},
	[645] = {
		comment = "肉棒",
	},
	[646] = {
		comment = "肉壶",
	},
	[647] = {
		comment = "奶子",
	},
	[648] = {
		comment = "摸咪咪",
	},
	[649] = {
		comment = "干鸡",
	},
	[650] = {
		comment = "干入",
	},
	[651] = {
		comment = "小穴",
	},
	[652] = {
		comment = "强奸",
	},
	[653] = {
		comment = "插你",
	},
	[654] = {
		comment = "插你",
	},
	[655] = {
		comment = "爽你",
	},
	[656] = {
		comment = "爽你",
	},
	[657] = {
		comment = "干干",
	},
	[658] = {
		comment = "干X",
	},
	[659] = {
		comment = "我操",
	},
	[660] = {
		comment = "他干",
	},
	[661] = {
		comment = "干它",
	},
	[662] = {
		comment = "干牠",
	},
	[663] = {
		comment = "干您",
	},
	[664] = {
		comment = "干汝",
	},
	[665] = {
		comment = "干林",
	},
	[666] = {
		comment = "操林",
	},
	[667] = {
		comment = "干尼",
	},
	[668] = {
		comment = "操尼",
	},
	[669] = {
		comment = "我咧干",
	},
	[670] = {
		comment = "干勒",
	},
	[671] = {
		comment = "干我",
	},
	[672] = {
		comment = "干到",
	},
	[673] = {
		comment = "干啦",
	},
	[674] = {
		comment = "干爽",
	},
	[675] = {
		comment = "欠干",
	},
	[676] = {
		comment = "狗干",
	},
	[677] = {
		comment = "我干",
	},
	[678] = {
		comment = "来干",
	},
	[679] = {
		comment = "轮干",
	},
	[680] = {
		comment = "轮流干",
	},
	[681] = {
		comment = "干一干",
	},
	[682] = {
		comment = "援交",
	},
	[683] = {
		comment = "骑你",
	},
	[684] = {
		comment = "我操",
	},
	[685] = {
		comment = "轮奸",
	},
	[686] = {
		comment = "鸡奸",
	},
	[687] = {
		comment = "奸暴",
	},
	[688] = {
		comment = "再奸",
	},
	[689] = {
		comment = "我奸",
	},
	[690] = {
		comment = "奸你",
	},
	[691] = {
		comment = "奸你",
	},
	[692] = {
		comment = "奸他",
	},
	[693] = {
		comment = "奸她",
	},
	[694] = {
		comment = "奸一奸",
	},
	[695] = {
		comment = "淫水",
	},
	[696] = {
		comment = "淫湿",
	},
	[697] = {
		comment = "鸡歪",
	},
	[698] = {
		comment = "仆街",
	},
	[699] = {
		comment = "臭西",
	},
	[700] = {
		comment = "尻",
	},
	[701] = {
		comment = "遗精",
	},
	[702] = {
		comment = "烂逼",
	},
	[703] = {
		comment = "大血比",
	},
	[704] = {
		comment = "叼你妈",
	},
	[705] = {
		comment = "靠你妈",
	},
	[706] = {
		comment = "草你",
	},
	[707] = {
		comment = "干你",
	},
	[708] = {
		comment = "日你",
	},
	[709] = {
		comment = "插你",
	},
	[710] = {
		comment = "奸你",
	},
	[711] = {
		comment = "戳你",
	},
	[712] = {
		comment = "逼你老母",
	},
	[713] = {
		comment = "挨球",
	},
	[714] = {
		comment = "我日你",
	},
	[715] = {
		comment = "草拟妈",
	},
	[716] = {
		comment = "卖逼",
	},
	[717] = {
		comment = "狗操卖逼",
	},
	[718] = {
		comment = "奸淫",
	},
	[719] = {
		comment = "日死",
	},
	[720] = {
		comment = "奶子",
	},
	[721] = {
		comment = "阴茎",
	},
	[722] = {
		comment = "奶娘",
	},
	[723] = {
		comment = "他娘",
	},
	[724] = {
		comment = "她娘",
	},
	[725] = {
		comment = "骚B",
	},
	[726] = {
		comment = "你妈了妹",
	},
	[727] = {
		comment = "逼毛",
	},
	[728] = {
		comment = "插你妈",
	},
	[729] = {
		comment = "叼你",
	},
	[730] = {
		comment = "渣波波",
	},
	[731] = {
		comment = "嫩b",
	},
	[732] = {
		comment = "weelaa",
	},
	[733] = {
		comment = "缔顺",
	},
	[734] = {
		comment = "帝顺",
	},
	[735] = {
		comment = "蒂顺",
	},
	[736] = {
		comment = "系统消息",
	},
	[737] = {
		comment = "午夜",
	},
	[738] = {
		comment = "看下",
	},
	[739] = {
		comment = "草泥马",
	},
	[740] = {
		comment = "法克鱿",
	},
	[741] = {
		comment = "雅蠛蝶",
	},
	[742] = {
		comment = "潜烈蟹",
	},
	[743] = {
		comment = "菊花蚕",
	},
	[744] = {
		comment = "尾申鲸",
	},
	[745] = {
		comment = "吉跋猫",
	},
	[746] = {
		comment = "搞栗棒",
	},
	[747] = {
		comment = "吟稻雁",
	},
	[748] = {
		comment = "达菲鸡",
	},
	[749] = {
		comment = "SM",
	},
	[750] = {
		comment = "ML",
	},
	[751] = {
		comment = "3P",
	},
	[752] = {
		comment = "群P",
	},
	[753] = {
		comment = "马勒戈壁",
	},
	[754] = {
		comment = "双飞",
	},
	[755] = {
		comment = "周恩來",
	},
	[756] = {
		comment = "碡",
	},
	[757] = {
		comment = "籀",
	},
	[758] = {
		comment = "朱駿",
	},
	[759] = {
		comment = "朱狨基",
	},
	[760] = {
		comment = "朱容基",
	},
	[761] = {
		comment = "朱溶剂",
	},
	[762] = {
		comment = "朱熔基",
	},
	[763] = {
		comment = "朱镕基",
	},
	[764] = {
		comment = "邾",
	},
	[765] = {
		comment = "猪操",
	},
	[766] = {
		comment = "猪聋畸",
	},
	[767] = {
		comment = "猪毛",
	},
	[768] = {
		comment = "猪毛1",
	},
	[769] = {
		comment = "舳",
	},
	[770] = {
		comment = "瘃",
	},
	[771] = {
		comment = "躅",
	},
	[772] = {
		comment = "翥",
	},
	[773] = {
		comment = "專政",
	},
	[774] = {
		comment = "颛",
	},
	[775] = {
		comment = "丬",
	},
	[776] = {
		comment = "隹",
	},
	[777] = {
		comment = "窀",
	},
	[778] = {
		comment = "卓伯源",
	},
	[779] = {
		comment = "倬",
	},
	[780] = {
		comment = "斫",
	},
	[781] = {
		comment = "诼",
	},
	[782] = {
		comment = "髭",
	},
	[783] = {
		comment = "鲻",
	},
	[784] = {
		comment = "子宫",
	},
	[785] = {
		comment = "秭",
	},
	[786] = {
		comment = "訾",
	},
	[787] = {
		comment = "自焚",
	},
	[788] = {
		comment = "自民党",
	},
	[789] = {
		comment = "自慰",
	},
	[790] = {
		comment = "自已的故事",
	},
	[791] = {
		comment = "自由民主论坛",
	},
	[792] = {
		comment = "总理",
	},
	[793] = {
		comment = "偬",
	},
	[794] = {
		comment = "诹",
	},
	[795] = {
		comment = "陬",
	},
	[796] = {
		comment = "鄹",
	},
	[797] = {
		comment = "鲰",
	},
	[798] = {
		comment = "躜",
	},
	[799] = {
		comment = "缵",
	},
	[800] = {
		comment = "作爱",
	},
	[801] = {
		comment = "作秀",
	},
	[802] = {
		comment = "阼",
	},
	[803] = {
		comment = "祚",
	},
	[804] = {
		comment = "做爱",
	},
	[805] = {
		comment = "阿扁萬歲",
	},
	[806] = {
		comment = "阿萊娜",
	},
	[807] = {
		comment = "啊無卵",
	},
	[808] = {
		comment = "埃裏克蘇特勤",
	},
	[809] = {
		comment = "埃斯萬",
	},
	[810] = {
		comment = "艾麗絲",
	},
	[811] = {
		comment = "愛滋",
	},
	[812] = {
		comment = "愛滋病",
	},
	[813] = {
		comment = "垵",
	},
	[814] = {
		comment = "暗黑法師",
	},
	[815] = {
		comment = "嶴",
	},
	[816] = {
		comment = "奧克拉",
	},
	[817] = {
		comment = "奧拉德",
	},
	[818] = {
		comment = "奧利弗",
	},
	[819] = {
		comment = "奧魯奇",
	},
	[820] = {
		comment = "奧倫",
	},
	[821] = {
		comment = "奧特蘭",
	},
	[822] = {
		comment = "㈧",
	},
	[823] = {
		comment = "巴倫侍從",
	},
	[824] = {
		comment = "巴倫坦",
	},
	[825] = {
		comment = "白立樸",
	},
	[826] = {
		comment = "白夢",
	},
	[827] = {
		comment = "白皮書",
	},
	[828] = {
		comment = "班禪",
	},
	[829] = {
		comment = "寶石商人",
	},
	[830] = {
		comment = "保釣",
	},
	[831] = {
		comment = "鮑戈",
	},
	[832] = {
		comment = "鮑彤",
	},
	[833] = {
		comment = "鮑伊",
	},
	[834] = {
		comment = "暴風亡靈",
	},
	[835] = {
		comment = "暴亂",
	},
	[836] = {
		comment = "暴熱的戰士",
	},
	[837] = {
		comment = "暴躁的城塔野獸",
	},
	[838] = {
		comment = "暴躁的警衛兵靈魂",
	},
	[839] = {
		comment = "暴躁的馬杜克",
	},
	[840] = {
		comment = "北大三角地論壇",
	},
	[841] = {
		comment = "北韓",
	},
	[842] = {
		comment = "北京當局",
	},
	[843] = {
		comment = "北美自由論壇",
	},
	[844] = {
		comment = "貝尤爾",
	},
	[845] = {
		comment = "韝",
	},
	[846] = {
		comment = "逼樣",
	},
	[847] = {
		comment = "比樣",
	},
	[848] = {
		comment = "蹕",
	},
	[849] = {
		comment = "颮",
	},
	[850] = {
		comment = "鑣",
	},
	[851] = {
		comment = "婊子養的",
	},
	[852] = {
		comment = "賓周",
	},
	[853] = {
		comment = "冰後",
	},
	[854] = {
		comment = "博訊",
	},
	[855] = {
		comment = "不滅帝王",
	},
	[856] = {
		comment = "不爽不要錢",
	},
	[857] = {
		comment = "布萊爾",
	},
	[858] = {
		comment = "布雷爾",
	},
	[859] = {
		comment = "蔡崇國",
	},
	[860] = {
		comment = "蔡啓芳",
	},
	[861] = {
		comment = "黲",
	},
	[862] = {
		comment = "操鶏",
	},
	[863] = {
		comment = "操那嗎B",
	},
	[864] = {
		comment = "操那嗎逼",
	},
	[865] = {
		comment = "操那嗎比",
	},
	[866] = {
		comment = "操你媽",
	},
	[867] = {
		comment = "操你爺爺",
	},
	[868] = {
		comment = "曹長青",
	},
	[869] = {
		comment = "曹剛川",
	},
	[870] = {
		comment = "草",
	},
	[871] = {
		comment = "草你媽",
	},
	[872] = {
		comment = "草擬媽",
	},
	[873] = {
		comment = "册那娘餓比",
	},
	[874] = {
		comment = "插那嗎B",
	},
	[875] = {
		comment = "插那嗎逼",
	},
	[876] = {
		comment = "插那嗎比",
	},
	[877] = {
		comment = "插你媽",
	},
	[878] = {
		comment = "插你爺爺",
	},
	[879] = {
		comment = "覘",
	},
	[880] = {
		comment = "蕆",
	},
	[881] = {
		comment = "囅",
	},
	[882] = {
		comment = "閶",
	},
	[883] = {
		comment = "長官沙塔特",
	},
	[884] = {
		comment = "常勁",
	},
	[885] = {
		comment = "朝鮮",
	},
	[886] = {
		comment = "車侖",
	},
	[887] = {
		comment = "車侖女幹",
	},
	[888] = {
		comment = "沉睡圖騰",
	},
	[889] = {
		comment = "陳炳基",
	},
	[890] = {
		comment = "陳博志",
	},
	[891] = {
		comment = "陳定南",
	},
	[892] = {
		comment = "陳建銘",
	},
	[893] = {
		comment = "陳景俊",
	},
	[894] = {
		comment = "陳菊",
	},
	[895] = {
		comment = "陳軍",
	},
	[896] = {
		comment = "陳良宇",
	},
	[897] = {
		comment = "陳蒙",
	},
	[898] = {
		comment = "陳破空",
	},
	[899] = {
		comment = "陳水扁",
	},
	[900] = {
		comment = "陳唐山",
	},
	[901] = {
		comment = "陳希同",
	},
	[902] = {
		comment = "陳小同",
	},
	[903] = {
		comment = "陳宣良",
	},
	[904] = {
		comment = "陳學聖",
	},
	[905] = {
		comment = "陳一諮",
	},
	[906] = {
		comment = "陳總統",
	},
	[907] = {
		comment = "諶",
	},
	[908] = {
		comment = "齔",
	},
	[909] = {
		comment = "櫬",
	},
	[910] = {
		comment = "讖",
	},
	[911] = {
		comment = "程凱",
	},
	[912] = {
		comment = "程鐵軍",
	},
	[913] = {
		comment = "鴟",
	},
	[914] = {
		comment = "痴鳩",
	},
	[915] = {
		comment = "痴拈",
	},
	[916] = {
		comment = "遲鈍的圖騰",
	},
	[917] = {
		comment = "持不同政見",
	},
	[918] = {
		comment = "赤色騎士",
	},
	[919] = {
		comment = "赤色戰士",
	},
	[920] = {
		comment = "處女膜",
	},
	[921] = {
		comment = "傳染性病",
	},
	[922] = {
		comment = "吹簫",
	},
	[923] = {
		comment = "春夏自由論壇",
	},
	[924] = {
		comment = "戳那嗎B",
	},
	[925] = {
		comment = "戳那嗎逼",
	},
	[926] = {
		comment = "戳那嗎比",
	},
	[927] = {
		comment = "輳",
	},
	[928] = {
		comment = "鹺",
	},
	[929] = {
		comment = "錯B",
	},
	[930] = {
		comment = "錯逼",
	},
	[931] = {
		comment = "錯比",
	},
	[932] = {
		comment = "錯那嗎B",
	},
	[933] = {
		comment = "錯那嗎逼",
	},
	[934] = {
		comment = "錯那嗎比",
	},
	[935] = {
		comment = "達夫警衛兵",
	},
	[936] = {
		comment = "達夫侍從",
	},
	[937] = {
		comment = "達癩",
	},
	[938] = {
		comment = "打飛機",
	},
	[939] = {
		comment = "大參考",
	},
	[940] = {
		comment = "大東亞",
	},
	[941] = {
		comment = "大東亞共榮",
	},
	[942] = {
		comment = "大鶏巴",
	},
	[943] = {
		comment = "大紀元",
	},
	[944] = {
		comment = "大紀元新聞網",
	},
	[945] = {
		comment = "大紀園",
	},
	[946] = {
		comment = "大家論壇",
	},
	[947] = {
		comment = "大奶媽",
	},
	[948] = {
		comment = "大史記",
	},
	[949] = {
		comment = "大史紀",
	},
	[950] = {
		comment = "大衛教",
	},
	[951] = {
		comment = "大中國論壇",
	},
	[952] = {
		comment = "大中華論壇",
	},
	[953] = {
		comment = "大衆真人真事",
	},
	[954] = {
		comment = "紿",
	},
	[955] = {
		comment = "戴維教",
	},
	[956] = {
		comment = "戴相龍",
	},
	[957] = {
		comment = "彈劾",
	},
	[958] = {
		comment = "氹",
	},
	[959] = {
		comment = "蕩婦",
	},
	[960] = {
		comment = "導師",
	},
	[961] = {
		comment = "盜竊犯",
	},
	[962] = {
		comment = "德維爾",
	},
	[963] = {
		comment = "登輝",
	},
	[964] = {
		comment = "鄧笑貧",
	},
	[965] = {
		comment = "糴",
	},
	[966] = {
		comment = "迪裏夏提",
	},
	[967] = {
		comment = "覿",
	},
	[968] = {
		comment = "地下教會",
	},
	[969] = {
		comment = "帝國主義",
	},
	[970] = {
		comment = "電視流氓",
	},
	[971] = {
		comment = "叼你媽",
	},
	[972] = {
		comment = "釣魚島",
	},
	[973] = {
		comment = "丁關根",
	},
	[974] = {
		comment = "東北獨立",
	},
	[975] = {
		comment = "東部地下水路",
	},
	[976] = {
		comment = "東方紅時空",
	},
	[977] = {
		comment = "東方時空",
	},
	[978] = {
		comment = "東南西北論談",
	},
	[979] = {
		comment = "東社",
	},
	[980] = {
		comment = "東升",
	},
	[981] = {
		comment = "東條",
	},
	[982] = {
		comment = "東條英機",
	},
	[983] = {
		comment = "東突暴動",
	},
	[984] = {
		comment = "東突獨立",
	},
	[985] = {
		comment = "東土耳其斯坦",
	},
	[986] = {
		comment = "東西南北論壇",
	},
	[987] = {
		comment = "東亞",
	},
	[988] = {
		comment = "東院看守",
	},
	[989] = {
		comment = "動亂",
	},
	[990] = {
		comment = "鬥士哈夫拉蘇",
	},
	[991] = {
		comment = "鬥士霍克",
	},
	[992] = {
		comment = "獨裁",
	},
	[993] = {
		comment = "獨裁政治",
	},
	[994] = {
		comment = "獨夫",
	},
	[995] = {
		comment = "獨立臺灣會",
	},
	[996] = {
		comment = "俄國",
	},
	[997] = {
		comment = "鮞",
	},
	[998] = {
		comment = "㈡",
	},
	[999] = {
		comment = "發楞",
	},
	[1000] = {
		comment = "發掄",
	},
	[1001] = {
		comment = "發掄功",
	},
	[1002] = {
		comment = "發倫",
	},
	[1003] = {
		comment = "發倫功",
	},
	[1004] = {
		comment = "發輪",
	},
	[1005] = {
		comment = "發論",
	},
	[1006] = {
		comment = "發論公",
	},
	[1007] = {
		comment = "發論功",
	},
	[1008] = {
		comment = "發騷",
	},
	[1009] = {
		comment = "發正念",
	},
	[1010] = {
		comment = "法~倫",
	},
	[1011] = {
		comment = "法~淪",
	},
	[1012] = {
		comment = "法~綸",
	},
	[1013] = {
		comment = "法~輪",
	},
	[1014] = {
		comment = "法~論",
	},
	[1015] = {
		comment = "法爾卡",
	},
	[1016] = {
		comment = "法掄",
	},
	[1017] = {
		comment = "法掄功",
	},
	[1018] = {
		comment = "法侖",
	},
	[1019] = {
		comment = "法淪",
	},
	[1020] = {
		comment = "法綸",
	},
	[1021] = {
		comment = "法輪大法",
	},
	[1022] = {
		comment = "法輪功",
	},
	[1023] = {
		comment = "法十輪十功",
	},
	[1024] = {
		comment = "法謫",
	},
	[1025] = {
		comment = "法謫功",
	},
	[1026] = {
		comment = "反封鎖",
	},
	[1027] = {
		comment = "反封鎖技術",
	},
	[1028] = {
		comment = "反腐敗論壇",
	},
	[1029] = {
		comment = "反人類",
	},
	[1030] = {
		comment = "反社會",
	},
	[1031] = {
		comment = "方勵之",
	},
	[1032] = {
		comment = "防衛指揮官",
	},
	[1033] = {
		comment = "放蕩",
	},
	[1034] = {
		comment = "飛揚論壇",
	},
	[1035] = {
		comment = "廢墟守護者",
	},
	[1036] = {
		comment = "費鴻泰",
	},
	[1037] = {
		comment = "費良勇",
	},
	[1038] = {
		comment = "分隊長施蒂文",
	},
	[1039] = {
		comment = "粉飾太平",
	},
	[1040] = {
		comment = "糞便",
	},
	[1041] = {
		comment = "鱝",
	},
	[1042] = {
		comment = "豐饒的果實",
	},
	[1043] = {
		comment = "風雨神州",
	},
	[1044] = {
		comment = "風雨神州論壇",
	},
	[1045] = {
		comment = "封從德",
	},
	[1046] = {
		comment = "封殺",
	},
	[1047] = {
		comment = "封印的靈魂騎士",
	},
	[1048] = {
		comment = "馮東海",
	},
	[1049] = {
		comment = "馮素英",
	},
	[1050] = {
		comment = "紱",
	},
	[1051] = {
		comment = "襆",
	},
	[1052] = {
		comment = "嘸",
	},
	[1053] = {
		comment = "傅作義",
	},
	[1054] = {
		comment = "幹bi",
	},
	[1055] = {
		comment = "幹逼",
	},
	[1056] = {
		comment = "幹比",
	},
	[1057] = {
		comment = "幹的你",
	},
	[1058] = {
		comment = "幹幹幹",
	},
	[1059] = {
		comment = "幹她",
	},
	[1060] = {
		comment = "幹你",
	},
	[1061] = {
		comment = "幹你老比",
	},
	[1062] = {
		comment = "幹你老母",
	},
	[1063] = {
		comment = "幹你娘",
	},
	[1064] = {
		comment = "幹全家",
	},
	[1065] = {
		comment = "幹死",
	},
	[1066] = {
		comment = "幹死你",
	},
	[1067] = {
		comment = "幹他",
	},
	[1068] = {
		comment = "幹一家",
	},
	[1069] = {
		comment = "趕你娘",
	},
	[1070] = {
		comment = "岡巒",
	},
	[1071] = {
		comment = "剛比",
	},
	[1072] = {
		comment = "剛比樣子",
	},
	[1073] = {
		comment = "崗哨士兵",
	},
	[1074] = {
		comment = "肛門",
	},
	[1075] = {
		comment = "高麗棒子",
	},
	[1076] = {
		comment = "高文謙",
	},
	[1077] = {
		comment = "高薪養廉",
	},
	[1078] = {
		comment = "高自聯",
	},
	[1079] = {
		comment = "膏藥旗",
	},
	[1080] = {
		comment = "戈瑞爾德",
	},
	[1081] = {
		comment = "戈揚",
	},
	[1082] = {
		comment = "鴿派",
	},
	[1083] = {
		comment = "歌功頌德",
	},
	[1084] = {
		comment = "格雷(關卡排名管理者)",
	},
	[1085] = {
		comment = "格魯",
	},
	[1086] = {
		comment = "格魯(城鎮移動)",
	},
	[1087] = {
		comment = "鯁",
	},
	[1088] = {
		comment = "工自聯",
	},
	[1089] = {
		comment = "弓雖",
	},
	[1090] = {
		comment = "共産",
	},
	[1091] = {
		comment = "共産黨",
	},
	[1092] = {
		comment = "共産主義",
	},
	[1093] = {
		comment = "共黨",
	},
	[1094] = {
		comment = "共軍",
	},
	[1095] = {
		comment = "共榮圈",
	},
	[1096] = {
		comment = "緱",
	},
	[1097] = {
		comment = "狗誠",
	},
	[1098] = {
		comment = "狗狼養的",
	},
	[1099] = {
		comment = "狗娘養的",
	},
	[1100] = {
		comment = "狗養",
	},
	[1101] = {
		comment = "狗雜種",
	},
	[1102] = {
		comment = "覯",
	},
	[1103] = {
		comment = "轂",
	},
	[1104] = {
		comment = "古龍祭壇",
	},
	[1105] = {
		comment = "骨獅",
	},
	[1106] = {
		comment = "鯝",
	},
	[1107] = {
		comment = "鴰",
	},
	[1108] = {
		comment = "詿",
	},
	[1109] = {
		comment = "關卓中",
	},
	[1110] = {
		comment = "貫通兩極法",
	},
	[1111] = {
		comment = "廣聞",
	},
	[1112] = {
		comment = "嬀",
	},
	[1113] = {
		comment = "龜兒子",
	},
	[1114] = {
		comment = "龜公",
	},
	[1115] = {
		comment = "龜孫子",
	},
	[1116] = {
		comment = "龜頭",
	},
	[1117] = {
		comment = "龜投",
	},
	[1118] = {
		comment = "劌",
	},
	[1119] = {
		comment = "緄",
	},
	[1120] = {
		comment = "滾那嗎",
	},
	[1121] = {
		comment = "滾那嗎B",
	},
	[1122] = {
		comment = "滾那嗎錯比",
	},
	[1123] = {
		comment = "滾那嗎老比",
	},
	[1124] = {
		comment = "滾那嗎瘟比",
	},
	[1125] = {
		comment = "鯀",
	},
	[1126] = {
		comment = "咼",
	},
	[1127] = {
		comment = "郭俊銘",
	},
	[1128] = {
		comment = "郭羅基",
	},
	[1129] = {
		comment = "郭岩華",
	},
	[1130] = {
		comment = "國家安全",
	},
	[1131] = {
		comment = "國家機密",
	},
	[1132] = {
		comment = "國軍",
	},
	[1133] = {
		comment = "國賊",
	},
	[1134] = {
		comment = "哈爾羅尼",
	},
	[1135] = {
		comment = "頇",
	},
	[1136] = {
		comment = "韓東方",
	},
	[1137] = {
		comment = "韓聯潮",
	},
	[1138] = {
		comment = "韓正",
	},
	[1139] = {
		comment = "漢奸",
	},
	[1140] = {
		comment = "顥",
	},
	[1141] = {
		comment = "灝",
	},
	[1142] = {
		comment = "河殤",
	},
	[1143] = {
		comment = "賀國强",
	},
	[1144] = {
		comment = "賀龍",
	},
	[1145] = {
		comment = "黑社會",
	},
	[1146] = {
		comment = "黑手黨",
	},
	[1147] = {
		comment = "紅燈區",
	},
	[1148] = {
		comment = "紅色恐怖",
	},
	[1149] = {
		comment = "紅炎猛獸",
	},
	[1150] = {
		comment = "洪傳",
	},
	[1151] = {
		comment = "洪興",
	},
	[1152] = {
		comment = "洪哲勝",
	},
	[1153] = {
		comment = "黌",
	},
	[1154] = {
		comment = "鱟",
	},
	[1155] = {
		comment = "胡緊掏",
	},
	[1156] = {
		comment = "胡錦滔",
	},
	[1157] = {
		comment = "胡錦淘",
	},
	[1158] = {
		comment = "胡景濤",
	},
	[1159] = {
		comment = "胡喬木",
	},
	[1160] = {
		comment = "胡總書記",
	},
	[1161] = {
		comment = "湖岸護衛兵",
	},
	[1162] = {
		comment = "湖岸警衛兵",
	},
	[1163] = {
		comment = "湖岸哨兵隊長",
	},
	[1164] = {
		comment = "護法",
	},
	[1165] = {
		comment = "鸌",
	},
	[1166] = {
		comment = "華建敏",
	},
	[1167] = {
		comment = "華通時事論壇",
	},
	[1168] = {
		comment = "華夏文摘",
	},
	[1169] = {
		comment = "華語世界論壇",
	},
	[1170] = {
		comment = "華岳時事論壇",
	},
	[1171] = {
		comment = "懷特",
	},
	[1172] = {
		comment = "鍰",
	},
	[1173] = {
		comment = "皇軍",
	},
	[1174] = {
		comment = "黃伯源",
	},
	[1175] = {
		comment = "黃慈萍",
	},
	[1176] = {
		comment = "黃禍",
	},
	[1177] = {
		comment = "黃劍輝",
	},
	[1178] = {
		comment = "黃金幼龍",
	},
	[1179] = {
		comment = "黃菊",
	},
	[1180] = {
		comment = "黃片",
	},
	[1181] = {
		comment = "黃翔",
	},
	[1182] = {
		comment = "黃義交",
	},
	[1183] = {
		comment = "黃仲生",
	},
	[1184] = {
		comment = "回民暴動",
	},
	[1185] = {
		comment = "噦",
	},
	[1186] = {
		comment = "繢",
	},
	[1187] = {
		comment = "毀滅步兵",
	},
	[1188] = {
		comment = "毀滅騎士",
	},
	[1189] = {
		comment = "毀滅射手",
	},
	[1190] = {
		comment = "昏迷圖騰",
	},
	[1191] = {
		comment = "混亂的圖騰",
	},
	[1192] = {
		comment = "鍃",
	},
	[1193] = {
		comment = "活動",
	},
	[1194] = {
		comment = "擊倒圖騰",
	},
	[1195] = {
		comment = "擊傷的圖騰",
	},
	[1196] = {
		comment = "鶏8",
	},
	[1197] = {
		comment = "鶏八",
	},
	[1198] = {
		comment = "鶏巴",
	},
	[1199] = {
		comment = "鶏吧",
	},
	[1200] = {
		comment = "鶏鶏",
	},
	[1201] = {
		comment = "鶏奸",
	},
	[1202] = {
		comment = "鶏毛信文匯",
	},
	[1203] = {
		comment = "鶏女",
	},
	[1204] = {
		comment = "鶏院",
	},
	[1205] = {
		comment = "姬勝德",
	},
	[1206] = {
		comment = "積克館",
	},
	[1207] = {
		comment = "賫",
	},
	[1208] = {
		comment = "鱭",
	},
	[1209] = {
		comment = "賈廷安",
	},
	[1210] = {
		comment = "賈育台",
	},
	[1211] = {
		comment = "戔",
	},
	[1212] = {
		comment = "監視塔",
	},
	[1213] = {
		comment = "監視塔哨兵",
	},
	[1214] = {
		comment = "監視塔哨兵隊長",
	},
	[1215] = {
		comment = "鰹",
	},
	[1216] = {
		comment = "韉",
	},
	[1217] = {
		comment = "簡肇棟",
	},
	[1218] = {
		comment = "建國黨",
	},
	[1219] = {
		comment = "賤B",
	},
	[1220] = {
		comment = "賤bi",
	},
	[1221] = {
		comment = "賤逼",
	},
	[1222] = {
		comment = "賤比",
	},
	[1223] = {
		comment = "賤貨",
	},
	[1224] = {
		comment = "賤人",
	},
	[1225] = {
		comment = "賤種",
	},
	[1226] = {
		comment = "江八點",
	},
	[1227] = {
		comment = "江羅",
	},
	[1228] = {
		comment = "江綿恒",
	},
	[1229] = {
		comment = "江戲子",
	},
	[1230] = {
		comment = "江則民",
	},
	[1231] = {
		comment = "江澤慧",
	},
	[1232] = {
		comment = "江賊",
	},
	[1233] = {
		comment = "江賊民",
	},
	[1234] = {
		comment = "薑春雲",
	},
	[1235] = {
		comment = "將則民",
	},
	[1236] = {
		comment = "僵賊",
	},
	[1237] = {
		comment = "僵賊民",
	},
	[1238] = {
		comment = "講法",
	},
	[1239] = {
		comment = "蔣介石",
	},
	[1240] = {
		comment = "蔣中正",
	},
	[1241] = {
		comment = "降低命中的圖騰",
	},
	[1242] = {
		comment = "醬猪媳",
	},
	[1243] = {
		comment = "撟",
	},
	[1244] = {
		comment = "狡猾的達夫",
	},
	[1245] = {
		comment = "矯健的馬努爾",
	},
	[1246] = {
		comment = "嶠",
	},
	[1247] = {
		comment = "教養院",
	},
	[1248] = {
		comment = "癤",
	},
	[1249] = {
		comment = "揭批書",
	},
	[1250] = {
		comment = "訐",
	},
	[1251] = {
		comment = "她媽",
	},
	[1252] = {
		comment = "届中央政治局委員",
	},
	[1253] = {
		comment = "金槍不倒",
	},
	[1254] = {
		comment = "金堯如",
	},
	[1255] = {
		comment = "金澤辰",
	},
	[1256] = {
		comment = "巹",
	},
	[1257] = {
		comment = "錦濤",
	},
	[1258] = {
		comment = "經文",
	},
	[1259] = {
		comment = "經血",
	},
	[1260] = {
		comment = "莖候佳陰",
	},
	[1261] = {
		comment = "荊棘護衛兵",
	},
	[1262] = {
		comment = "靖國神社",
	},
	[1263] = {
		comment = "㈨",
	},
	[1264] = {
		comment = "舊斗篷哨兵",
	},
	[1265] = {
		comment = "齟",
	},
	[1266] = {
		comment = "巨槌騎兵",
	},
	[1267] = {
		comment = "巨鐵角哈克",
	},
	[1268] = {
		comment = "鋸齒通道被遺弃的骷髏",
	},
	[1269] = {
		comment = "鋸齒通道骷髏",
	},
	[1270] = {
		comment = "屨",
	},
	[1271] = {
		comment = "棬",
	},
	[1272] = {
		comment = "絕望之地",
	},
	[1273] = {
		comment = "譎",
	},
	[1274] = {
		comment = "軍妓",
	},
	[1275] = {
		comment = "開苞",
	},
	[1276] = {
		comment = "開放雜志",
	},
	[1277] = {
		comment = "凱奧勒尼什",
	},
	[1278] = {
		comment = "凱爾本",
	},
	[1279] = {
		comment = "凱爾雷斯",
	},
	[1280] = {
		comment = "凱特切爾",
	},
	[1281] = {
		comment = "砍翻一條街",
	},
	[1282] = {
		comment = "看中國",
	},
	[1283] = {
		comment = "闞",
	},
	[1284] = {
		comment = "靠你媽",
	},
	[1285] = {
		comment = "柯賜海",
	},
	[1286] = {
		comment = "柯建銘",
	},
	[1287] = {
		comment = "科萊爾",
	},
	[1288] = {
		comment = "克萊恩",
	},
	[1289] = {
		comment = "克萊特",
	},
	[1290] = {
		comment = "克勞森",
	},
	[1291] = {
		comment = "客戶服務",
	},
	[1292] = {
		comment = "緙",
	},
	[1293] = {
		comment = "空氣精靈",
	},
	[1294] = {
		comment = "空虛的伊坤",
	},
	[1295] = {
		comment = "空虛之地",
	},
	[1296] = {
		comment = "恐怖主義",
	},
	[1297] = {
		comment = "瞘",
	},
	[1298] = {
		comment = "嚳",
	},
	[1299] = {
		comment = "鄺錦文",
	},
	[1300] = {
		comment = "貺",
	},
	[1301] = {
		comment = "昆圖",
	},
	[1302] = {
		comment = "拉姆斯菲爾德",
	},
	[1303] = {
		comment = "拉皮條",
	},
	[1304] = {
		comment = "萊特",
	},
	[1305] = {
		comment = "賴士葆",
	},
	[1306] = {
		comment = "蘭迪",
	},
	[1307] = {
		comment = "爛B",
	},
	[1308] = {
		comment = "爛逼",
	},
	[1309] = {
		comment = "爛比",
	},
	[1310] = {
		comment = "爛袋",
	},
	[1311] = {
		comment = "爛貨",
	},
	[1312] = {
		comment = "濫B",
	},
	[1313] = {
		comment = "濫逼",
	},
	[1314] = {
		comment = "濫比",
	},
	[1315] = {
		comment = "濫貨",
	},
	[1316] = {
		comment = "濫交",
	},
	[1317] = {
		comment = "勞動教養所",
	},
	[1318] = {
		comment = "勞改",
	},
	[1319] = {
		comment = "勞教",
	},
	[1320] = {
		comment = "鰳",
	},
	[1321] = {
		comment = "雷尼亞",
	},
	[1322] = {
		comment = "誄",
	},
	[1323] = {
		comment = "李紅痔",
	},
	[1324] = {
		comment = "李洪寬",
	},
	[1325] = {
		comment = "李繼耐",
	},
	[1326] = {
		comment = "李蘭菊",
	},
	[1327] = {
		comment = "李老師",
	},
	[1328] = {
		comment = "李錄",
	},
	[1329] = {
		comment = "李祿",
	},
	[1330] = {
		comment = "李慶安",
	},
	[1331] = {
		comment = "李慶華",
	},
	[1332] = {
		comment = "李淑嫻",
	},
	[1333] = {
		comment = "李鐵映",
	},
	[1334] = {
		comment = "李旺陽",
	},
	[1335] = {
		comment = "李小鵬",
	},
	[1336] = {
		comment = "李月月鳥",
	},
	[1337] = {
		comment = "李志綏",
	},
	[1338] = {
		comment = "李總理",
	},
	[1339] = {
		comment = "李總統",
	},
	[1340] = {
		comment = "裏菲斯",
	},
	[1341] = {
		comment = "鱧",
	},
	[1342] = {
		comment = "轢",
	},
	[1343] = {
		comment = "躒",
	},
	[1344] = {
		comment = "奩",
	},
	[1345] = {
		comment = "連方瑀",
	},
	[1346] = {
		comment = "連惠心",
	},
	[1347] = {
		comment = "連勝德",
	},
	[1348] = {
		comment = "連勝文",
	},
	[1349] = {
		comment = "連戰",
	},
	[1350] = {
		comment = "聯總",
	},
	[1351] = {
		comment = "廉政大論壇",
	},
	[1352] = {
		comment = "煉功",
	},
	[1353] = {
		comment = "兩岸關係",
	},
	[1354] = {
		comment = "兩岸三地論壇",
	},
	[1355] = {
		comment = "兩個中國",
	},
	[1356] = {
		comment = "兩會",
	},
	[1357] = {
		comment = "兩會報道",
	},
	[1358] = {
		comment = "兩會新聞",
	},
	[1359] = {
		comment = "廖錫龍",
	},
	[1360] = {
		comment = "林保華",
	},
	[1361] = {
		comment = "林長盛",
	},
	[1362] = {
		comment = "林佳龍",
	},
	[1363] = {
		comment = "林信義",
	},
	[1364] = {
		comment = "林正勝",
	},
	[1365] = {
		comment = "林重謨",
	},
	[1366] = {
		comment = "躪",
	},
	[1367] = {
		comment = "淩鋒",
	},
	[1368] = {
		comment = "劉賓深",
	},
	[1369] = {
		comment = "劉賓雁",
	},
	[1370] = {
		comment = "劉剛",
	},
	[1371] = {
		comment = "劉國凱",
	},
	[1372] = {
		comment = "劉華清",
	},
	[1373] = {
		comment = "劉俊國",
	},
	[1374] = {
		comment = "劉凱中",
	},
	[1375] = {
		comment = "劉千石",
	},
	[1376] = {
		comment = "劉青",
	},
	[1377] = {
		comment = "劉山青",
	},
	[1378] = {
		comment = "劉士賢",
	},
	[1379] = {
		comment = "劉文勝",
	},
	[1380] = {
		comment = "劉文雄",
	},
	[1381] = {
		comment = "劉曉波",
	},
	[1382] = {
		comment = "劉曉竹",
	},
	[1383] = {
		comment = "劉永川",
	},
	[1384] = {
		comment = "㈥",
	},
	[1385] = {
		comment = "鷚",
	},
	[1386] = {
		comment = "龍虎豹",
	},
	[1387] = {
		comment = "龍火之心",
	},
	[1388] = {
		comment = "盧卡",
	},
	[1389] = {
		comment = "盧西德",
	},
	[1390] = {
		comment = "陸委會",
	},
	[1391] = {
		comment = "輅",
	},
	[1392] = {
		comment = "呂京花",
	},
	[1393] = {
		comment = "呂秀蓮",
	},
	[1394] = {
		comment = "亂交",
	},
	[1395] = {
		comment = "亂倫",
	},
	[1396] = {
		comment = "亂輪",
	},
	[1397] = {
		comment = "鋝",
	},
	[1398] = {
		comment = "掄功",
	},
	[1399] = {
		comment = "倫功",
	},
	[1400] = {
		comment = "輪大",
	},
	[1401] = {
		comment = "輪功",
	},
	[1402] = {
		comment = "輪奸",
	},
	[1403] = {
		comment = "論壇管理員",
	},
	[1404] = {
		comment = "羅福助",
	},
	[1405] = {
		comment = "羅幹",
	},
	[1406] = {
		comment = "羅禮詩",
	},
	[1407] = {
		comment = "羅文嘉",
	},
	[1408] = {
		comment = "羅志明",
	},
	[1409] = {
		comment = "腡",
	},
	[1410] = {
		comment = "濼",
	},
	[1411] = {
		comment = "洛克菲爾特",
	},
	[1412] = {
		comment = "媽B",
	},
	[1413] = {
		comment = "媽比",
	},
	[1414] = {
		comment = "媽的",
	},
	[1415] = {
		comment = "媽批",
	},
	[1416] = {
		comment = "馬大維",
	},
	[1417] = {
		comment = "馬克思",
	},
	[1418] = {
		comment = "馬良駿",
	},
	[1419] = {
		comment = "馬三家",
	},
	[1420] = {
		comment = "馬時敏",
	},
	[1421] = {
		comment = "馬特斯",
	},
	[1422] = {
		comment = "馬英九",
	},
	[1423] = {
		comment = "馬永成",
	},
	[1424] = {
		comment = "瑪麗亞",
	},
	[1425] = {
		comment = "瑪雅",
	},
	[1426] = {
		comment = "嗎的",
	},
	[1427] = {
		comment = "嗎啡",
	},
	[1428] = {
		comment = "勱",
	},
	[1429] = {
		comment = "麥克斯",
	},
	[1430] = {
		comment = "賣逼",
	},
	[1431] = {
		comment = "賣比",
	},
	[1432] = {
		comment = "賣國",
	},
	[1433] = {
		comment = "賣騷",
	},
	[1434] = {
		comment = "賣淫",
	},
	[1435] = {
		comment = "瞞報",
	},
	[1436] = {
		comment = "毛厠洞",
	},
	[1437] = {
		comment = "毛賊",
	},
	[1438] = {
		comment = "毛賊東",
	},
	[1439] = {
		comment = "美國",
	},
	[1440] = {
		comment = "美國參考",
	},
	[1441] = {
		comment = "美國佬",
	},
	[1442] = {
		comment = "美國之音",
	},
	[1443] = {
		comment = "蒙獨",
	},
	[1444] = {
		comment = "蒙古達子",
	},
	[1445] = {
		comment = "蒙古獨",
	},
	[1446] = {
		comment = "蒙古獨立",
	},
	[1447] = {
		comment = "禰",
	},
	[1448] = {
		comment = "羋",
	},
	[1449] = {
		comment = "綿恒",
	},
	[1450] = {
		comment = "黽",
	},
	[1451] = {
		comment = "民國",
	},
	[1452] = {
		comment = "民進黨",
	},
	[1453] = {
		comment = "民聯",
	},
	[1454] = {
		comment = "民意論壇",
	},
	[1455] = {
		comment = "民陣",
	},
	[1456] = {
		comment = "民主墻",
	},
	[1457] = {
		comment = "緡",
	},
	[1458] = {
		comment = "湣",
	},
	[1459] = {
		comment = "鰵",
	},
	[1460] = {
		comment = "摸你鶏巴",
	},
	[1461] = {
		comment = "莫偉强",
	},
	[1462] = {
		comment = "木子論壇",
	},
	[1463] = {
		comment = "內褲",
	},
	[1464] = {
		comment = "內衣",
	},
	[1465] = {
		comment = "那嗎B",
	},
	[1466] = {
		comment = "那嗎逼",
	},
	[1467] = {
		comment = "那嗎錯比",
	},
	[1468] = {
		comment = "那嗎老比",
	},
	[1469] = {
		comment = "那嗎瘟比",
	},
	[1470] = {
		comment = "那娘錯比",
	},
	[1471] = {
		comment = "納粹",
	},
	[1472] = {
		comment = "奶頭",
	},
	[1473] = {
		comment = "南大自由論壇",
	},
	[1474] = {
		comment = "南蠻子",
	},
	[1475] = {
		comment = "鬧事",
	},
	[1476] = {
		comment = "能樣",
	},
	[1477] = {
		comment = "尼奧夫",
	},
	[1478] = {
		comment = "倪育賢",
	},
	[1479] = {
		comment = "鯢",
	},
	[1480] = {
		comment = "你媽",
	},
	[1481] = {
		comment = "你媽逼",
	},
	[1482] = {
		comment = "你媽比",
	},
	[1483] = {
		comment = "你媽的",
	},
	[1484] = {
		comment = "你媽了妹",
	},
	[1485] = {
		comment = "你說我說論壇",
	},
	[1486] = {
		comment = "你爺",
	},
	[1487] = {
		comment = "娘餓比",
	},
	[1488] = {
		comment = "捏你鶏巴",
	},
	[1489] = {
		comment = "儂著岡巒",
	},
	[1490] = {
		comment = "儂著卵拋",
	},
	[1491] = {
		comment = "奴隸魔族士兵",
	},
	[1492] = {
		comment = "女幹",
	},
	[1493] = {
		comment = "女主人羅姬馬莉",
	},
	[1494] = {
		comment = "儺",
	},
	[1495] = {
		comment = "諾姆",
	},
	[1496] = {
		comment = "潘國平",
	},
	[1497] = {
		comment = "蹣",
	},
	[1498] = {
		comment = "龐建國",
	},
	[1499] = {
		comment = "泡沫經濟",
	},
	[1500] = {
		comment = "轡",
	},
	[1501] = {
		comment = "噴你",
	},
	[1502] = {
		comment = "皮條客",
	},
	[1503] = {
		comment = "羆",
	},
	[1504] = {
		comment = "諞",
	},
	[1505] = {
		comment = "潑婦",
	},
	[1506] = {
		comment = "齊墨",
	},
	[1507] = {
		comment = "齊諾",
	},
	[1508] = {
		comment = "騎你",
	},
	[1509] = {
		comment = "磧",
	},
	[1510] = {
		comment = "僉",
	},
	[1511] = {
		comment = "鈐",
	},
	[1512] = {
		comment = "錢達",
	},
	[1513] = {
		comment = "錢國梁",
	},
	[1514] = {
		comment = "錢其琛",
	},
	[1515] = {
		comment = "膁",
	},
	[1516] = {
		comment = "槧",
	},
	[1517] = {
		comment = "錆",
	},
	[1518] = {
		comment = "繰",
	},
	[1519] = {
		comment = "喬石",
	},
	[1520] = {
		comment = "喬伊",
	},
	[1521] = {
		comment = "橋侵襲兵",
	},
	[1522] = {
		comment = "譙",
	},
	[1523] = {
		comment = "鞽",
	},
	[1524] = {
		comment = "篋",
	},
	[1525] = {
		comment = "親美",
	},
	[1526] = {
		comment = "親民黨",
	},
	[1527] = {
		comment = "親日",
	},
	[1528] = {
		comment = "欽本立",
	},
	[1529] = {
		comment = "禽獸",
	},
	[1530] = {
		comment = "唚",
	},
	[1531] = {
		comment = "輕舟快訊",
	},
	[1532] = {
		comment = "情婦",
	},
	[1533] = {
		comment = "情獸",
	},
	[1534] = {
		comment = "檾",
	},
	[1535] = {
		comment = "慶紅",
	},
	[1536] = {
		comment = "丘垂貞",
	},
	[1537] = {
		comment = "詘",
	},
	[1538] = {
		comment = "去你媽的",
	},
	[1539] = {
		comment = "闃",
	},
	[1540] = {
		comment = "全國兩會",
	},
	[1541] = {
		comment = "全國人大",
	},
	[1542] = {
		comment = "犬",
	},
	[1543] = {
		comment = "綣",
	},
	[1544] = {
		comment = "瘸腿幫",
	},
	[1545] = {
		comment = "愨",
	},
	[1546] = {
		comment = "讓你操",
	},
	[1547] = {
		comment = "熱比婭",
	},
	[1548] = {
		comment = "熱站政論網",
	},
	[1549] = {
		comment = "人民報",
	},
	[1550] = {
		comment = "人民大會堂",
	},
	[1551] = {
		comment = "人民內情真相",
	},
	[1552] = {
		comment = "人民真實",
	},
	[1553] = {
		comment = "人民之聲論壇",
	},
	[1554] = {
		comment = "人權",
	},
	[1555] = {
		comment = "日本帝國",
	},
	[1556] = {
		comment = "日軍",
	},
	[1557] = {
		comment = "日內瓦金融",
	},
	[1558] = {
		comment = "日你媽",
	},
	[1559] = {
		comment = "日你爺爺",
	},
	[1560] = {
		comment = "日朱駿",
	},
	[1561] = {
		comment = "顬",
	},
	[1562] = {
		comment = "乳頭",
	},
	[1563] = {
		comment = "乳暈",
	},
	[1564] = {
		comment = "瑞士金融大學",
	},
	[1565] = {
		comment = "薩達姆",
	},
	[1566] = {
		comment = "三K黨",
	},
	[1567] = {
		comment = "三個代表",
	},
	[1568] = {
		comment = "三級片",
	},
	[1569] = {
		comment = "三去車侖工力",
	},
	[1570] = {
		comment = "㈢",
	},
	[1571] = {
		comment = "毿",
	},
	[1572] = {
		comment = "糝",
	},
	[1573] = {
		comment = "騷B",
	},
	[1574] = {
		comment = "騷棒",
	},
	[1575] = {
		comment = "騷包",
	},
	[1576] = {
		comment = "騷逼",
	},
	[1577] = {
		comment = "騷棍",
	},
	[1578] = {
		comment = "騷貨",
	},
	[1579] = {
		comment = "騷鶏",
	},
	[1580] = {
		comment = "騷卵",
	},
	[1581] = {
		comment = "殺你全家",
	},
	[1582] = {
		comment = "殺你一家",
	},
	[1583] = {
		comment = "殺人犯",
	},
	[1584] = {
		comment = "傻鳥",
	},
	[1585] = {
		comment = "煞筆",
	},
	[1586] = {
		comment = "山口組",
	},
	[1587] = {
		comment = "善惡有報",
	},
	[1588] = {
		comment = "上訪",
	},
	[1589] = {
		comment = "上海幫",
	},
	[1590] = {
		comment = "上海孤兒院",
	},
	[1591] = {
		comment = "厙",
	},
	[1592] = {
		comment = "社會主義",
	},
	[1593] = {
		comment = "射了還說要",
	},
	[1594] = {
		comment = "灄",
	},
	[1595] = {
		comment = "詵",
	},
	[1596] = {
		comment = "神經病",
	},
	[1597] = {
		comment = "諗",
	},
	[1598] = {
		comment = "生孩子沒屁眼",
	},
	[1599] = {
		comment = "生命分流的圖騰",
	},
	[1600] = {
		comment = "澠",
	},
	[1601] = {
		comment = "聖射手",
	},
	[1602] = {
		comment = "聖戰",
	},
	[1603] = {
		comment = "盛華仁",
	},
	[1604] = {
		comment = "濕了還說不要",
	},
	[1605] = {
		comment = "濕了還說要",
	},
	[1606] = {
		comment = "釃",
	},
	[1607] = {
		comment = "鯴",
	},
	[1608] = {
		comment = "㈩",
	},
	[1609] = {
		comment = "石化圖騰",
	},
	[1610] = {
		comment = "石拳戰鬥兵",
	},
	[1611] = {
		comment = "時代論壇",
	},
	[1612] = {
		comment = "時事論壇",
	},
	[1613] = {
		comment = "鰣",
	},
	[1614] = {
		comment = "史萊姆",
	},
	[1615] = {
		comment = "史萊姆王",
	},
	[1616] = {
		comment = "士兵管理員瓦爾臣",
	},
	[1617] = {
		comment = "世界經濟導報",
	},
	[1618] = {
		comment = "事實獨立",
	},
	[1619] = {
		comment = "侍從貝赫爾特",
	},
	[1620] = {
		comment = "侍從倫斯韋",
	},
	[1621] = {
		comment = "貰",
	},
	[1622] = {
		comment = "攄",
	},
	[1623] = {
		comment = "數據中國",
	},
	[1624] = {
		comment = "雙十節",
	},
	[1625] = {
		comment = "氵去車侖工力",
	},
	[1626] = {
		comment = "氵去車侖工力?",
	},
	[1627] = {
		comment = "稅力",
	},
	[1628] = {
		comment = "司馬晋",
	},
	[1629] = {
		comment = "司馬璐",
	},
	[1630] = {
		comment = "司徒華",
	},
	[1631] = {
		comment = "私?服",
	},
	[1632] = {
		comment = "私處",
	},
	[1633] = {
		comment = "思科羅",
	},
	[1634] = {
		comment = "斯諾",
	},
	[1635] = {
		comment = "斯皮爾德",
	},
	[1636] = {
		comment = "四川獨",
	},
	[1637] = {
		comment = "四川獨立",
	},
	[1638] = {
		comment = "四人幫",
	},
	[1639] = {
		comment = "㈣",
	},
	[1640] = {
		comment = "宋書元",
	},
	[1641] = {
		comment = "藪",
	},
	[1642] = {
		comment = "蘇菲爾",
	},
	[1643] = {
		comment = "蘇拉",
	},
	[1644] = {
		comment = "蘇南成",
	},
	[1645] = {
		comment = "蘇紹智",
	},
	[1646] = {
		comment = "蘇特勒守護兵",
	},
	[1647] = {
		comment = "蘇特勤",
	},
	[1648] = {
		comment = "蘇特勤護衛兵",
	},
	[1649] = {
		comment = "蘇特勤魔法師",
	},
	[1650] = {
		comment = "蘇曉康",
	},
	[1651] = {
		comment = "蘇盈貴",
	},
	[1652] = {
		comment = "蘇貞昌",
	},
	[1653] = {
		comment = "誶",
	},
	[1654] = {
		comment = "碎片製造商人馬克",
	},
	[1655] = {
		comment = "碎片製造商人蘇克",
	},
	[1656] = {
		comment = "孫大千",
	},
	[1657] = {
		comment = "孫中山",
	},
	[1658] = {
		comment = "他媽",
	},
	[1659] = {
		comment = "他媽的",
	},
	[1660] = {
		comment = "他嗎的",
	},
	[1661] = {
		comment = "他母親",
	},
	[1662] = {
		comment = "塔內",
	},
	[1663] = {
		comment = "塔烏",
	},
	[1664] = {
		comment = "鰨",
	},
	[1665] = {
		comment = "闥",
	},
	[1666] = {
		comment = "臺盟",
	},
	[1667] = {
		comment = "臺灣帝國",
	},
	[1668] = {
		comment = "臺灣獨立",
	},
	[1669] = {
		comment = "臺灣獨",
	},
	[1670] = {
		comment = "臺灣共産黨",
	},
	[1671] = {
		comment = "臺灣狗",
	},
	[1672] = {
		comment = "臺灣建國運動組織",
	},
	[1673] = {
		comment = "臺灣民國",
	},
	[1674] = {
		comment = "臺灣青年獨立聯盟",
	},
	[1675] = {
		comment = "臺灣政論區",
	},
	[1676] = {
		comment = "臺灣自由聯盟",
	},
	[1677] = {
		comment = "鮐",
	},
	[1678] = {
		comment = "太監",
	},
	[1679] = {
		comment = "泰奴橋警衛兵",
	},
	[1680] = {
		comment = "泰奴橋掠奪者",
	},
	[1681] = {
		comment = "湯光中",
	},
	[1682] = {
		comment = "唐柏橋",
	},
	[1683] = {
		comment = "鞀",
	},
	[1684] = {
		comment = "謄",
	},
	[1685] = {
		comment = "天安門",
	},
	[1686] = {
		comment = "天安門錄影帶",
	},
	[1687] = {
		comment = "天安門事件",
	},
	[1688] = {
		comment = "天安門屠殺",
	},
	[1689] = {
		comment = "天安門一代",
	},
	[1690] = {
		comment = "天閹",
	},
	[1691] = {
		comment = "田紀雲",
	},
	[1692] = {
		comment = "齠",
	},
	[1693] = {
		comment = "鰷",
	},
	[1694] = {
		comment = "銚",
	},
	[1695] = {
		comment = "庭院警衛兵",
	},
	[1696] = {
		comment = "統獨",
	},
	[1697] = {
		comment = "統獨論壇",
	},
	[1698] = {
		comment = "統戰",
	},
	[1699] = {
		comment = "頭領奧馬",
	},
	[1700] = {
		comment = "頭領墳墓管理員",
	},
	[1701] = {
		comment = "圖書管理員卡特",
	},
	[1702] = {
		comment = "屠殺",
	},
	[1703] = {
		comment = "團長戈登",
	},
	[1704] = {
		comment = "團員馬爾汀",
	},
	[1705] = {
		comment = "摶",
	},
	[1706] = {
		comment = "鼉",
	},
	[1707] = {
		comment = "籜",
	},
	[1708] = {
		comment = "膃",
	},
	[1709] = {
		comment = "外交論壇",
	},
	[1710] = {
		comment = "外交與方略",
	},
	[1711] = {
		comment = "晚年周恩來",
	},
	[1712] = {
		comment = "綰",
	},
	[1713] = {
		comment = "萬里",
	},
	[1714] = {
		comment = "萬潤南",
	},
	[1715] = {
		comment = "萬維讀者論壇",
	},
	[1716] = {
		comment = "萬曉東",
	},
	[1717] = {
		comment = "王寶森",
	},
	[1718] = {
		comment = "王超華",
	},
	[1719] = {
		comment = "王輔臣",
	},
	[1720] = {
		comment = "王剛",
	},
	[1721] = {
		comment = "王涵萬",
	},
	[1722] = {
		comment = "王滬寧",
	},
	[1723] = {
		comment = "王軍濤",
	},
	[1724] = {
		comment = "王樂泉",
	},
	[1725] = {
		comment = "王潤生",
	},
	[1726] = {
		comment = "王世堅",
	},
	[1727] = {
		comment = "王世勛",
	},
	[1728] = {
		comment = "王秀麗",
	},
	[1729] = {
		comment = "王兆國",
	},
	[1730] = {
		comment = "網禪",
	},
	[1731] = {
		comment = "網特",
	},
	[1732] = {
		comment = "猥褻",
	},
	[1733] = {
		comment = "鮪",
	},
	[1734] = {
		comment = "溫B",
	},
	[1735] = {
		comment = "溫逼",
	},
	[1736] = {
		comment = "溫比",
	},
	[1737] = {
		comment = "溫家寶",
	},
	[1738] = {
		comment = "溫元凱",
	},
	[1739] = {
		comment = "閿",
	},
	[1740] = {
		comment = "無界瀏覽器",
	},
	[1741] = {
		comment = "吳百益",
	},
	[1742] = {
		comment = "吳敦義",
	},
	[1743] = {
		comment = "吳方城",
	},
	[1744] = {
		comment = "吳弘達",
	},
	[1745] = {
		comment = "吳宏達",
	},
	[1746] = {
		comment = "吳仁華",
	},
	[1747] = {
		comment = "吳淑珍",
	},
	[1748] = {
		comment = "吳學燦",
	},
	[1749] = {
		comment = "吳學璨",
	},
	[1750] = {
		comment = "吳育升",
	},
	[1751] = {
		comment = "吳志芳",
	},
	[1752] = {
		comment = "西藏獨",
	},
	[1753] = {
		comment = "吸收的圖騰",
	},
	[1754] = {
		comment = "吸血獸",
	},
	[1755] = {
		comment = "覡",
	},
	[1756] = {
		comment = "洗腦",
	},
	[1757] = {
		comment = "系統",
	},
	[1758] = {
		comment = "系統公告",
	},
	[1759] = {
		comment = "餼",
	},
	[1760] = {
		comment = "郤",
	},
	[1761] = {
		comment = "下賤",
	},
	[1762] = {
		comment = "下體",
	},
	[1763] = {
		comment = "薟",
	},
	[1764] = {
		comment = "躚",
	},
	[1765] = {
		comment = "鮮族",
	},
	[1766] = {
		comment = "獫",
	},
	[1767] = {
		comment = "蜆",
	},
	[1768] = {
		comment = "峴",
	},
	[1769] = {
		comment = "現金",
	},
	[1770] = {
		comment = "現金交易",
	},
	[1771] = {
		comment = "獻祭的圖騰",
	},
	[1772] = {
		comment = "鯗",
	},
	[1773] = {
		comment = "項懷誠",
	},
	[1774] = {
		comment = "項小吉",
	},
	[1775] = {
		comment = "嘵",
	},
	[1776] = {
		comment = "小B樣",
	},
	[1777] = {
		comment = "小比樣",
	},
	[1778] = {
		comment = "小參考",
	},
	[1779] = {
		comment = "小鶏鶏",
	},
	[1780] = {
		comment = "小靈通",
	},
	[1781] = {
		comment = "小泉純一郎",
	},
	[1782] = {
		comment = "謝長廷",
	},
	[1783] = {
		comment = "謝深山",
	},
	[1784] = {
		comment = "謝選駿",
	},
	[1785] = {
		comment = "謝中之",
	},
	[1786] = {
		comment = "辛灝年",
	},
	[1787] = {
		comment = "新觀察論壇",
	},
	[1788] = {
		comment = "新華舉報",
	},
	[1789] = {
		comment = "新華內情",
	},
	[1790] = {
		comment = "新華通論壇",
	},
	[1791] = {
		comment = "新疆獨",
	},
	[1792] = {
		comment = "新生網",
	},
	[1793] = {
		comment = "新手訓練營",
	},
	[1794] = {
		comment = "新聞出版總署",
	},
	[1795] = {
		comment = "新聞封鎖",
	},
	[1796] = {
		comment = "新義安",
	},
	[1797] = {
		comment = "新語絲",
	},
	[1798] = {
		comment = "信用危機",
	},
	[1799] = {
		comment = "邢錚",
	},
	[1800] = {
		comment = "性愛",
	},
	[1801] = {
		comment = "性無能",
	},
	[1802] = {
		comment = "修煉",
	},
	[1803] = {
		comment = "頊",
	},
	[1804] = {
		comment = "虛弱圖騰",
	},
	[1805] = {
		comment = "虛無的飽食者",
	},
	[1806] = {
		comment = "徐國舅",
	},
	[1807] = {
		comment = "許財利",
	},
	[1808] = {
		comment = "許家屯",
	},
	[1809] = {
		comment = "許信良",
	},
	[1810] = {
		comment = "諼",
	},
	[1811] = {
		comment = "薛偉",
	},
	[1812] = {
		comment = "學潮",
	},
	[1813] = {
		comment = "學聯",
	},
	[1814] = {
		comment = "學運",
	},
	[1815] = {
		comment = "學自聯",
	},
	[1816] = {
		comment = "澩",
	},
	[1817] = {
		comment = "閹狗",
	},
	[1818] = {
		comment = "訁",
	},
	[1819] = {
		comment = "嚴家其",
	},
	[1820] = {
		comment = "嚴家祺",
	},
	[1821] = {
		comment = "閻明複",
	},
	[1822] = {
		comment = "顔清標",
	},
	[1823] = {
		comment = "顔慶章",
	},
	[1824] = {
		comment = "顔射",
	},
	[1825] = {
		comment = "讞",
	},
	[1826] = {
		comment = "央視內部晚會",
	},
	[1827] = {
		comment = "陽具",
	},
	[1828] = {
		comment = "陽痿",
	},
	[1829] = {
		comment = "陽物",
	},
	[1830] = {
		comment = "楊懷安",
	},
	[1831] = {
		comment = "楊建利",
	},
	[1832] = {
		comment = "楊巍",
	},
	[1833] = {
		comment = "楊月清",
	},
	[1834] = {
		comment = "楊周",
	},
	[1835] = {
		comment = "姚羅",
	},
	[1836] = {
		comment = "姚月謙",
	},
	[1837] = {
		comment = "軺",
	},
	[1838] = {
		comment = "搖頭丸",
	},
	[1839] = {
		comment = "藥材商人蘇耐得",
	},
	[1840] = {
		comment = "藥水",
	},
	[1841] = {
		comment = "耶穌",
	},
	[1842] = {
		comment = "野鶏",
	},
	[1843] = {
		comment = "葉菊蘭",
	},
	[1844] = {
		comment = "夜話紫禁城",
	},
	[1845] = {
		comment = "一陀糞",
	},
	[1846] = {
		comment = "㈠",
	},
	[1847] = {
		comment = "伊莎貝爾",
	},
	[1848] = {
		comment = "伊斯蘭",
	},
	[1849] = {
		comment = "伊斯蘭亞格林尼斯",
	},
	[1850] = {
		comment = "遺精",
	},
	[1851] = {
		comment = "議長阿茵斯塔",
	},
	[1852] = {
		comment = "議員斯格文德",
	},
	[1853] = {
		comment = "异見人士",
	},
	[1854] = {
		comment = "异型叛軍",
	},
	[1855] = {
		comment = "异議人士",
	},
	[1856] = {
		comment = "易丹軒",
	},
	[1857] = {
		comment = "意志不堅的圖騰",
	},
	[1858] = {
		comment = "瘞",
	},
	[1859] = {
		comment = "陰部",
	},
	[1860] = {
		comment = "陰唇",
	},
	[1861] = {
		comment = "陰道",
	},
	[1862] = {
		comment = "陰蒂",
	},
	[1863] = {
		comment = "陰戶",
	},
	[1864] = {
		comment = "陰莖",
	},
	[1865] = {
		comment = "陰精",
	},
	[1866] = {
		comment = "陰毛",
	},
	[1867] = {
		comment = "陰門",
	},
	[1868] = {
		comment = "陰囊",
	},
	[1869] = {
		comment = "陰水",
	},
	[1870] = {
		comment = "淫蕩",
	},
	[1871] = {
		comment = "淫穢",
	},
	[1872] = {
		comment = "淫貨",
	},
	[1873] = {
		comment = "淫賤",
	},
	[1874] = {
		comment = "尹慶民",
	},
	[1875] = {
		comment = "引導",
	},
	[1876] = {
		comment = "隱者之路",
	},
	[1877] = {
		comment = "鷹眼派氏族",
	},
	[1878] = {
		comment = "硬直圖騰",
	},
	[1879] = {
		comment = "憂鬱的艾拉",
	},
	[1880] = {
		comment = "尤比亞",
	},
	[1881] = {
		comment = "由喜貴",
	},
	[1882] = {
		comment = "游蕩的僵尸",
	},
	[1883] = {
		comment = "游蕩的士兵",
	},
	[1884] = {
		comment = "游蕩爪牙",
	},
	[1885] = {
		comment = "游錫坤",
	},
	[1886] = {
		comment = "游戲管理員",
	},
	[1887] = {
		comment = "友好的魯德",
	},
	[1888] = {
		comment = "幼齒",
	},
	[1889] = {
		comment = "幼龍",
	},
	[1890] = {
		comment = "于幼軍",
	},
	[1891] = {
		comment = "余英時",
	},
	[1892] = {
		comment = "漁夫菲斯曼",
	},
	[1893] = {
		comment = "輿論",
	},
	[1894] = {
		comment = "輿論反制",
	},
	[1895] = {
		comment = "傴",
	},
	[1896] = {
		comment = "宇明網",
	},
	[1897] = {
		comment = "齬",
	},
	[1898] = {
		comment = "飫",
	},
	[1899] = {
		comment = "鵒",
	},
	[1900] = {
		comment = "元老蘭提(沃德）",
	},
	[1901] = {
		comment = "圓滿",
	},
	[1902] = {
		comment = "緣圈圈",
	},
	[1903] = {
		comment = "遠志明",
	},
	[1904] = {
		comment = "月經",
	},
	[1905] = {
		comment = "韞",
	},
	[1906] = {
		comment = "雜種",
	},
	[1907] = {
		comment = "鏨",
	},
	[1908] = {
		comment = "造愛",
	},
	[1909] = {
		comment = "則民",
	},
	[1910] = {
		comment = "擇民",
	},
	[1911] = {
		comment = "澤夫",
	},
	[1912] = {
		comment = "澤民",
	},
	[1913] = {
		comment = "賾",
	},
	[1914] = {
		comment = "賊民",
	},
	[1915] = {
		comment = "譖",
	},
	[1916] = {
		comment = "扎卡維是英雄",
	},
	[1917] = {
		comment = "驏",
	},
	[1918] = {
		comment = "張伯笠",
	},
	[1919] = {
		comment = "張博雅",
	},
	[1920] = {
		comment = "張鋼",
	},
	[1921] = {
		comment = "張健",
	},
	[1922] = {
		comment = "張林",
	},
	[1923] = {
		comment = "張清芳",
	},
	[1924] = {
		comment = "張偉國",
	},
	[1925] = {
		comment = "張溫鷹",
	},
	[1926] = {
		comment = "張昭富",
	},
	[1927] = {
		comment = "張志清",
	},
	[1928] = {
		comment = "章孝嚴",
	},
	[1929] = {
		comment = "帳號",
	},
	[1930] = {
		comment = "賬號",
	},
	[1931] = {
		comment = "招鶏",
	},
	[1932] = {
		comment = "趙海青",
	},
	[1933] = {
		comment = "趙建銘",
	},
	[1934] = {
		comment = "趙南",
	},
	[1935] = {
		comment = "趙品潞",
	},
	[1936] = {
		comment = "趙曉微",
	},
	[1937] = {
		comment = "趙紫陽",
	},
	[1938] = {
		comment = "貞操",
	},
	[1939] = {
		comment = "鎮壓",
	},
	[1940] = {
		comment = "爭鳴論壇",
	},
	[1941] = {
		comment = "正見網",
	},
	[1942] = {
		comment = "正義黨論壇",
	},
	[1943] = {
		comment = "㊣",
	},
	[1944] = {
		comment = "鄭寶清",
	},
	[1945] = {
		comment = "鄭麗文",
	},
	[1946] = {
		comment = "鄭義",
	},
	[1947] = {
		comment = "鄭餘鎮",
	},
	[1948] = {
		comment = "鄭源",
	},
	[1949] = {
		comment = "鄭運鵬",
	},
	[1950] = {
		comment = "政權",
	},
	[1951] = {
		comment = "政治反對派",
	},
	[1952] = {
		comment = "縶",
	},
	[1953] = {
		comment = "躑",
	},
	[1954] = {
		comment = "指點江山論壇",
	},
	[1955] = {
		comment = "騭",
	},
	[1956] = {
		comment = "觶",
	},
	[1957] = {
		comment = "躓",
	},
	[1958] = {
		comment = "中毒的圖騰",
	},
	[1959] = {
		comment = "中毒圖騰",
	},
	[1960] = {
		comment = "中俄邊界",
	},
	[1961] = {
		comment = "中國復興論壇",
	},
	[1962] = {
		comment = "中國共産黨",
	},
	[1963] = {
		comment = "中國孤兒院",
	},
	[1964] = {
		comment = "中國和平",
	},
	[1965] = {
		comment = "中國論壇",
	},
	[1966] = {
		comment = "中國社會進步黨",
	},
	[1967] = {
		comment = "中國社會論壇",
	},
	[1968] = {
		comment = "中國威脅論",
	},
	[1969] = {
		comment = "中國問題論壇",
	},
	[1970] = {
		comment = "中國移動通信",
	},
	[1971] = {
		comment = "中國真實內容",
	},
	[1972] = {
		comment = "中國之春",
	},
	[1973] = {
		comment = "中國猪",
	},
	[1974] = {
		comment = "中華大地",
	},
	[1975] = {
		comment = "中華大衆",
	},
	[1976] = {
		comment = "中華講清",
	},
	[1977] = {
		comment = "中華民國",
	},
	[1978] = {
		comment = "中華人民實話實說",
	},
	[1979] = {
		comment = "中華人民正邪",
	},
	[1980] = {
		comment = "中華時事",
	},
	[1981] = {
		comment = "中華養生益智功",
	},
	[1982] = {
		comment = "中華真實報道",
	},
	[1983] = {
		comment = "中央電視臺",
	},
	[1984] = {
		comment = "鐘山風雨論壇",
	},
	[1985] = {
		comment = "周鋒鎖",
	},
	[1986] = {
		comment = "周守訓",
	},
	[1987] = {
		comment = "朱鳳芝",
	},
	[1988] = {
		comment = "朱立倫",
	},
	[1989] = {
		comment = "朱溶劑",
	},
	[1990] = {
		comment = "㈱",
	},
	[1991] = {
		comment = "猪聾畸",
	},
	[1992] = {
		comment = "主攻指揮官",
	},
	[1993] = {
		comment = "主義",
	},
	[1994] = {
		comment = "助手威爾特",
	},
	[1995] = {
		comment = "專制",
	},
	[1996] = {
		comment = "顓",
	},
	[1997] = {
		comment = "轉化",
	},
	[1998] = {
		comment = "諑",
	},
	[1999] = {
		comment = "資本主義",
	},
	[2000] = {
		comment = "鯔",
	},
	[2001] = {
		comment = "子宮",
	},
	[2002] = {
		comment = "自民黨",
	},
	[2003] = {
		comment = "自由民主論壇",
	},
	[2004] = {
		comment = "總理",
	},
	[2005] = {
		comment = "諏",
	},
	[2006] = {
		comment = "鯫",
	},
	[2007] = {
		comment = "躦",
	},
	[2008] = {
		comment = "纘",
	},
	[2009] = {
		comment = "作愛",
	},
	[2010] = {
		comment = "做愛",
	},
	[2011] = {
		comment = "胡总书记，胡景涛",
	},
	[2012] = {
		comment = "大纪元",
	},
	[2013] = {
		comment = "大纪元新闻网",
	},
	[2014] = {
		comment = "燕玲论坛",
	},
	[2015] = {
		comment = "fuck",
	},
	[2016] = {
		comment = "共产党",
	},
	[2017] = {
		comment = "urban",
	},
	[2018] = {
		comment = "我操",
	},
	[2019] = {
		comment = "cao",
	},
	[2020] = {
		comment = "他妈的",
	},
	[2021] = {
		comment = "TMD",
	},
	[2022] = {
		comment = "鸡巴",
	},
	[2023] = {
		comment = "煞笔",
	},
	[2024] = {
		comment = "傻B",
	},
	[2025] = {
		comment = "法轮功",
	},
	[2026] = {
		comment = "江泽民",
	},
	[2027] = {
		comment = "胡锦涛",
	},
	[2028] = {
		comment = "温家宝",
	},
	[2029] = {
		comment = "urban-rivals",
	},
	[2030] = {
		comment = "rivals",
	},
	[2031] = {
		comment = "我日",
	},
	[2032] = {
		comment = "UR",
	},
	[2033] = {
		comment = "ur",
	},
	[2034] = {
		comment = "性交",
	},
	[2035] = {
		comment = "口交",
	},
	[2036] = {
		comment = "婊子",
	},
	[2037] = {
		comment = "妓女",
	},
	[2038] = {
		comment = "她妈",
	},
	[2039] = {
		comment = "牛逼",
	},
	[2040] = {
		comment = "牛B，牛比",
	},
	[2041] = {
		comment = "煞笔",
	},
	[2042] = {
		comment = "傻逼",
	},
	[2043] = {
		comment = "傻B",
	},
	[2044] = {
		comment = "操你妈",
	},
	[2045] = {
		comment = "装逼",
	},
	[2046] = {
		comment = "装B",
	},
	[2047] = {
		comment = "日你妈",
	},
	[2048] = {
		comment = "不玩了",
	},
	[2049] = {
		comment = "删号",
	},
	[2050] = {
		comment = "卖号",
	},
	[2051] = {
		comment = "删号",
	},
	[2052] = {
		comment = "妈的",
	},
	[2053] = {
		comment = "妈逼",
	},
	[2054] = {
		comment = "草你妈",
	},
	[2055] = {
		comment = "T.M.D",
	},
	[2056] = {
		comment = "JB",
	},
	[2057] = {
		comment = "jb",
	},
	[2058] = {
		comment = "出售账号",
	},
	[2059] = {
		comment = "出售此号",
	},
	[2060] = {
		comment = "卖号",
	},
	[2061] = {
		comment = "U/R",
	},
	[2062] = {
		comment = "U-R",
	},
	[2063] = {
		comment = "j8",
	},
	[2064] = {
		comment = "吗的",
	},
	[2065] = {
		comment = "8仙",
	},
	[2066] = {
		comment = "狗日",
	},
	[2067] = {
		comment = "出售神符",
	},
	[2068] = {
		comment = "色情",
	},
	[2069] = {
		comment = "黄色",
	},
	[2070] = {
		comment = "藏独",
	},
	[2071] = {
		comment = "台独",
	},
	[2072] = {
		comment = "法轮大法",
	},
	[2073] = {
		comment = "鸡巴",
	},
	[2074] = {
		comment = "毛泽东",
	},
	[2075] = {
		comment = "NPC",
	},
	[2076] = {
		comment = "*法*轮*功*",
	},
	[2077] = {
		comment = "*李*洪*志*阿扁",
	},
	[2078] = {
		comment = "阿扁万岁",
	},
	[2079] = {
		comment = "阿拉",
	},
	[2080] = {
		comment = "阿拉法特",
	},
	[2081] = {
		comment = "挨球",
	},
	[2082] = {
		comment = "安南",
	},
	[2083] = {
		comment = "安全局",
	},
	[2084] = {
		comment = "澳洲光明网",
	},
	[2085] = {
		comment = "八九",
	},
	[2086] = {
		comment = "八九风波",
	},
	[2087] = {
		comment = "办理文凭",
	},
	[2088] = {
		comment = "办理证件",
	},
	[2089] = {
		comment = "包皮",
	},
	[2090] = {
		comment = "保钓",
	},
	[2091] = {
		comment = "保监会",
	},
	[2092] = {
		comment = "保密局",
	},
	[2093] = {
		comment = "鸨",
	},
	[2094] = {
		comment = "鲍岳桥",
	},
	[2095] = {
		comment = "暴动",
	},
	[2096] = {
		comment = "暴乱",
	},
	[2097] = {
		comment = "暴徒",
	},
	[2098] = {
		comment = "北京之春",
	},
	[2099] = {
		comment = "贝肉",
	},
	[2100] = {
		comment = "本?拉登",
	},
	[2101] = {
		comment = "本?拉登",
	},
	[2102] = {
		comment = "苯比",
	},
	[2103] = {
		comment = "笨屄",
	},
	[2104] = {
		comment = "笨逼",
	},
	[2105] = {
		comment = "屄",
	},
	[2106] = {
		comment = "屄毛",
	},
	[2107] = {
		comment = "逼毛",
	},
	[2108] = {
		comment = "逼你老母",
	},
	[2109] = {
		comment = "逼样",
	},
	[2110] = {
		comment = "比毛",
	},
	[2111] = {
		comment = "婊",
	},
	[2112] = {
		comment = "婊子",
	},
	[2113] = {
		comment = "宾周",
	},
	[2114] = {
		comment = "冰毒",
	},
	[2115] = {
		comment = "波霸",
	},
	[2116] = {
		comment = "博讯",
	},
	[2117] = {
		comment = "薄一波",
	},
	[2118] = {
		comment = "布莱尔",
	},
	[2119] = {
		comment = "布雷尔",
	},
	[2120] = {
		comment = "布什",
	},
	[2121] = {
		comment = "布什",
	},
	[2122] = {
		comment = "财政部",
	},
	[2123] = {
		comment = "参事室",
	},
	[2124] = {
		comment = "藏独",
	},
	[2125] = {
		comment = "藏独",
	},
	[2126] = {
		comment = "藏独",
	},
	[2127] = {
		comment = "操",
	},
	[2128] = {
		comment = "操GM",
	},
	[2129] = {
		comment = "操Gm",
	},
	[2130] = {
		comment = "操gM",
	},
	[2131] = {
		comment = "操gm",
	},
	[2132] = {
		comment = "操XX",
	},
	[2133] = {
		comment = "操逼",
	},
	[2134] = {
		comment = "操比",
	},
	[2135] = {
		comment = "操蛋",
	},
	[2136] = {
		comment = "操你",
	},
	[2137] = {
		comment = "交媾",
	},
	[2138] = {
		comment = "CAO",
	},
	[2139] = {
		comment = "K粉",
	},
	[2140] = {
		comment = "J8",
	},
	[2141] = {
		comment = "小姐兼职",
	},
	[2142] = {
		comment = "交媾",
	},
	[2143] = {
		comment = "西藏314事件",
	},
	[2144] = {
		comment = "新疆7.5事件",
	},
	[2145] = {
		comment = "乱伦",
	},
	[2146] = {
		comment = "毛片",
	},
	[2147] = {
		comment = "黄片",
	},
	[2148] = {
		comment = "交配",
	},
	[2149] = {
		comment = "群交",
	},
	[2150] = {
		comment = "小姐兼职",
	},
	[2151] = {
		comment = "茉莉花革命",
	},
	[2152] = {
		comment = "操你八辈祖宗",
	},
	[2153] = {
		comment = "操你妈",
	},
	[2154] = {
		comment = "操你妈屄",
	},
	[2155] = {
		comment = "操他",
	},
	[2156] = {
		comment = "曹刚川",
	},
	[2157] = {
		comment = "草的你妈",
	},
	[2158] = {
		comment = "草妈",
	},
	[2159] = {
		comment = "草你妈",
	},
	[2160] = {
		comment = "草拟妈",
	},
	[2161] = {
		comment = "肏",
	},
	[2162] = {
		comment = "测绘局",
	},
	[2163] = {
		comment = "插GM",
	},
	[2164] = {
		comment = "插Gm",
	},
	[2165] = {
		comment = "插gM",
	},
	[2166] = {
		comment = "插gm",
	},
	[2167] = {
		comment = "插妳",
	},
	[2168] = {
		comment = "插你",
	},
	[2169] = {
		comment = "插你妈",
	},
	[2170] = {
		comment = "插深些",
	},
	[2171] = {
		comment = "产权局",
	},
	[2172] = {
		comment = "朝鲜",
	},
	[2173] = {
		comment = "车臣",
	},
	[2174] = {
		comment = "车仑",
	},
	[2175] = {
		comment = "陈功",
	},
	[2176] = {
		comment = "陈良宇",
	},
	[2177] = {
		comment = "陈水扁",
	},
	[2178] = {
		comment = "陈希同",
	},
	[2179] = {
		comment = "陈晓宁",
	},
	[2180] = {
		comment = "陈毅",
	},
	[2181] = {
		comment = "陈至立",
	},
	[2182] = {
		comment = "成人电影",
	},
	[2183] = {
		comment = "成人片",
	},
	[2184] = {
		comment = "吃大便",
	},
	[2185] = {
		comment = "吃屎",
	},
	[2186] = {
		comment = "迟浩田",
	},
	[2187] = {
		comment = "赤匪",
	},
	[2188] = {
		comment = "抽插",
	},
	[2189] = {
		comment = "抽你丫的",
	},
	[2190] = {
		comment = "臭化西",
	},
	[2191] = {
		comment = "出售假币",
	},
	[2192] = {
		comment = "出售枪支",
	},
	[2193] = {
		comment = "出售手枪",
	},
	[2194] = {
		comment = "吹喇叭",
	},
	[2195] = {
		comment = "吹箫",
	},
	[2196] = {
		comment = "春药",
	},
	[2197] = {
		comment = "蠢猪",
	},
	[2198] = {
		comment = "戳你",
	},
	[2199] = {
		comment = "粗制吗啡",
	},
	[2200] = {
		comment = "催情药",
	},
	[2201] = {
		comment = "达赖",
	},
	[2202] = {
		comment = "达赖喇嘛",
	},
	[2203] = {
		comment = "打炮",
	},
	[2204] = {
		comment = "大B",
	},
	[2205] = {
		comment = "大逼",
	},
	[2206] = {
		comment = "大便",
	},
	[2207] = {
		comment = "大波波",
	},
	[2208] = {
		comment = "大麻",
	},
	[2209] = {
		comment = "大麻树脂",
	},
	[2210] = {
		comment = "大麻油",
	},
	[2211] = {
		comment = "大师",
	},
	[2212] = {
		comment = "戴维教",
	},
	[2213] = {
		comment = "大学骚乱",
	},
	[2214] = {
		comment = "大血B",
	},
	[2215] = {
		comment = "大血比",
	},
	[2216] = {
		comment = "呆卵",
	},
	[2217] = {
		comment = "戴海静",
	},
	[2218] = {
		comment = "戴红",
	},
	[2219] = {
		comment = "戴晶",
	},
	[2220] = {
		comment = "戴维教",
	},
	[2221] = {
		comment = "党主席",
	},
	[2222] = {
		comment = "荡妇",
	},
	[2223] = {
		comment = "档案局",
	},
	[2224] = {
		comment = "盗窃犯",
	},
	[2225] = {
		comment = "盗窃犯",
	},
	[2226] = {
		comment = "道教",
	},
	[2227] = {
		comment = "邓小平",
	},
	[2228] = {
		comment = "帝国主义",
	},
	[2229] = {
		comment = "电监会",
	},
	[2230] = {
		comment = "叼你",
	},
	[2231] = {
		comment = "叼你妈",
	},
	[2232] = {
		comment = "屌",
	},
	[2233] = {
		comment = "屌7",
	},
	[2234] = {
		comment = "屌鸠",
	},
	[2235] = {
		comment = "屌毛",
	},
	[2236] = {
		comment = "屌妳",
	},
	[2237] = {
		comment = "屌七",
	},
	[2238] = {
		comment = "屌西",
	},
	[2239] = {
		comment = "钓鱼台",
	},
	[2240] = {
		comment = "丁关根",
	},
	[2241] = {
		comment = "丁子霖",
	},
	[2242] = {
		comment = "东北独立",
	},
	[2243] = {
		comment = "东升",
	},
	[2244] = {
		comment = "东条英机",
	},
	[2245] = {
		comment = "东突",
	},
	[2246] = {
		comment = "东突暴动和独立",
	},
	[2247] = {
		comment = "东突组织",
	},
	[2248] = {
		comment = "东亚病夫",
	},
	[2249] = {
		comment = "董建华",
	},
	[2250] = {
		comment = "董贱华",
	},
	[2251] = {
		comment = "董文华",
	},
	[2252] = {
		comment = "懂文华",
	},
	[2253] = {
		comment = "独立",
	},
	[2254] = {
		comment = "独立台湾会",
	},
	[2255] = {
		comment = "恩格斯",
	},
	[2256] = {
		comment = "二B",
	},
	[2257] = {
		comment = "二屄",
	},
	[2258] = {
		comment = "二逼",
	},
	[2259] = {
		comment = "二乙基酰胺发抡",
	},
	[2260] = {
		comment = "发抡功",
	},
	[2261] = {
		comment = "发伦",
	},
	[2262] = {
		comment = "发伦功",
	},
	[2263] = {
		comment = "发轮",
	},
	[2264] = {
		comment = "发论",
	},
	[2265] = {
		comment = "发论公",
	},
	[2266] = {
		comment = "发论功",
	},
	[2267] = {
		comment = "发骚",
	},
	[2268] = {
		comment = "法(轮)功",
	},
	[2269] = {
		comment = "法*轮*功",
	},
	[2270] = {
		comment = "法功",
	},
	[2271] = {
		comment = "法愣",
	},
	[2272] = {
		comment = "法仑",
	},
	[2273] = {
		comment = "法轮",
	},
	[2274] = {
		comment = "法轮大法",
	},
	[2275] = {
		comment = "法轮功",
	},
	[2276] = {
		comment = "法西斯",
	},
	[2277] = {
		comment = "法制办",
	},
	[2278] = {
		comment = "反动",
	},
	[2279] = {
		comment = "反革命",
	},
	[2280] = {
		comment = "发票",
	},
	[2281] = {
		comment = "冰粉",
	},
	[2282] = {
		comment = "性奴",
	},
	[2283] = {
		comment = "反共",
	},
	[2284] = {
		comment = "反华",
	},
	[2285] = {
		comment = "反恐委员会",
	},
	[2286] = {
		comment = "反日",
	},
	[2287] = {
		comment = "反政府",
	},
	[2288] = {
		comment = "分裂祖国",
	},
	[2289] = {
		comment = "佛教",
	},
	[2290] = {
		comment = "佛展千手法",
	},
	[2291] = {
		comment = "佛祖",
	},
	[2292] = {
		comment = "斧头镰刀",
	},
	[2293] = {
		comment = "阝月",
	},
	[2294] = {
		comment = "傅鹏",
	},
	[2295] = {
		comment = "傅作义",
	},
	[2296] = {
		comment = "干GM",
	},
	[2297] = {
		comment = "干Gm",
	},
	[2298] = {
		comment = "干gM",
	},
	[2299] = {
		comment = "干gm",
	},
	[2300] = {
		comment = "干拎娘",
	},
	[2301] = {
		comment = "干妳",
	},
	[2302] = {
		comment = "干妳老母",
	},
	[2303] = {
		comment = "干妳妈",
	},
	[2304] = {
		comment = "干妳娘",
	},
	[2305] = {
		comment = "干你",
	},
	[2306] = {
		comment = "干你妈",
	},
	[2307] = {
		comment = "干你妈b",
	},
	[2308] = {
		comment = "干你妈逼",
	},
	[2309] = {
		comment = "干你娘",
	},
	[2310] = {
		comment = "干七八",
	},
	[2311] = {
		comment = "干死你",
	},
	[2312] = {
		comment = "肛",
	},
	[2313] = {
		comment = "肛交",
	},
	[2314] = {
		comment = "肛门",
	},
	[2315] = {
		comment = "港澳办",
	},
	[2316] = {
		comment = "高俊",
	},
	[2317] = {
		comment = "高丽棒子",
	},
	[2318] = {
		comment = "高校暴乱",
	},
	[2319] = {
		comment = "高校群体事件",
	},
	[2320] = {
		comment = "高校骚乱",
	},
	[2321] = {
		comment = "睾",
	},
	[2322] = {
		comment = "睾丸",
	},
	[2323] = {
		comment = "膏药旗",
	},
	[2324] = {
		comment = "弓虽女干",
	},
	[2325] = {
		comment = "公安",
	},
	[2326] = {
		comment = "公安部",
	},
	[2327] = {
		comment = "公安局",
	},
	[2328] = {
		comment = "共产党",
	},
	[2329] = {
		comment = "共产主义",
	},
	[2330] = {
		comment = "共匪",
	},
	[2331] = {
		comment = "共狗",
	},
	[2332] = {
		comment = "狗b",
	},
	[2333] = {
		comment = "狗操",
	},
	[2334] = {
		comment = "狗卵",
	},
	[2335] = {
		comment = "狗娘",
	},
	[2336] = {
		comment = "狗屁",
	},
	[2337] = {
		comment = "狗日",
	},
	[2338] = {
		comment = "狗日的",
	},
	[2339] = {
		comment = "狗屎",
	},
	[2340] = {
		comment = "观世音",
	},
	[2341] = {
		comment = "官逼民反",
	},
	[2342] = {
		comment = "官商勾结",
	},
	[2343] = {
		comment = "龟儿子",
	},
	[2344] = {
		comment = "龟公",
	},
	[2345] = {
		comment = "龟孙子",
	},
	[2346] = {
		comment = "龟头",
	},
	[2347] = {
		comment = "鬼村",
	},
	[2348] = {
		comment = "滚",
	},
	[2349] = {
		comment = "郭伯雄",
	},
	[2350] = {
		comment = "国安局",
	},
	[2351] = {
		comment = "国防部",
	},
	[2352] = {
		comment = "国防科工委",
	},
	[2353] = {
		comment = "国管局",
	},
	[2354] = {
		comment = "国际法院",
	},
	[2355] = {
		comment = "国家民委",
	},
	[2356] = {
		comment = "国家主席",
	},
	[2357] = {
		comment = "国家主要部委",
	},
	[2358] = {
		comment = "国民党",
	},
	[2359] = {
		comment = "国民党万岁",
	},
	[2360] = {
		comment = "海洛因",
	},
	[2361] = {
		comment = "海洋局",
	},
	[2362] = {
		comment = "何候华",
	},
	[2363] = {
		comment = "贺国强",
	},
	[2364] = {
		comment = "贺龙",
	},
	[2365] = {
		comment = "黑社会",
	},
	[2366] = {
		comment = "黑手党",
	},
	[2367] = {
		comment = "黑手党",
	},
	[2368] = {
		comment = "黑手党",
	},
	[2369] = {
		comment = "红卫兵",
	},
	[2370] = {
		comment = "洪兴",
	},
	[2371] = {
		comment = "洪志",
	},
	[2372] = {
		comment = "后庭",
	},
	[2373] = {
		comment = "胡XX",
	},
	[2374] = {
		comment = "胡紧涛",
	},
	[2375] = {
		comment = "胡紧掏",
	},
	[2376] = {
		comment = "胡紧套",
	},
	[2377] = {
		comment = "胡锦涛",
	},
	[2378] = {
		comment = "胡锦淘",
	},
	[2379] = {
		comment = "胡乔木",
	},
	[2380] = {
		comment = "胡耀邦",
	},
	[2381] = {
		comment = "胡主席",
	},
	[2382] = {
		comment = "花柳",
	},
	[2383] = {
		comment = "华国锋",
	},
	[2384] = {
		comment = "华建敏",
	},
	[2385] = {
		comment = "换妻",
	},
	[2386] = {
		comment = "黄　菊",
	},
	[2387] = {
		comment = "黄菊",
	},
	[2388] = {
		comment = "黄色电影",
	},
	[2389] = {
		comment = "黄色小电影",
	},
	[2390] = {
		comment = "回教",
	},
	[2391] = {
		comment = "回良玉",
	},
	[2392] = {
		comment = "回民暴动",
	},
	[2393] = {
		comment = "回族人吃猪肉",
	},
	[2394] = {
		comment = "昏药",
	},
	[2395] = {
		comment = "火棒",
	},
	[2396] = {
		comment = "机八",
	},
	[2397] = {
		comment = "机巴",
	},
	[2398] = {
		comment = "鸡八",
	},
	[2399] = {
		comment = "鸡巴",
	},
	[2400] = {
		comment = "鸡叭",
	},
	[2401] = {
		comment = "鸡芭",
	},
	[2402] = {
		comment = "鸡掰",
	},
	[2403] = {
		comment = "鸡奸",
	},
	[2404] = {
		comment = "基地组织",
	},
	[2405] = {
		comment = "基督",
	},
	[2406] = {
		comment = "基督教",
	},
	[2407] = {
		comment = "激情电影",
	},
	[2408] = {
		comment = "激情小电影",
	},
	[2409] = {
		comment = "鸡",
	},
	[2410] = {
		comment = "计牌软件",
	},
	[2411] = {
		comment = "计生委",
	},
	[2412] = {
		comment = "妓",
	},
	[2413] = {
		comment = "妓女",
	},
	[2414] = {
		comment = "妓院",
	},
	[2415] = {
		comment = "贾庆林",
	},
	[2416] = {
		comment = "奸",
	},
	[2417] = {
		comment = "奸夫淫妇",
	},
	[2418] = {
		comment = "奸你",
	},
	[2419] = {
		comment = "奸淫",
	},
	[2420] = {
		comment = "贱",
	},
	[2421] = {
		comment = "贱逼",
	},
	[2422] = {
		comment = "贱货",
	},
	[2423] = {
		comment = "贱人",
	},
	[2424] = {
		comment = "江Core",
	},
	[2425] = {
		comment = "江八",
	},
	[2426] = {
		comment = "江八点",
	},
	[2427] = {
		comment = "江独裁",
	},
	[2428] = {
		comment = "江核心",
	},
	[2429] = {
		comment = "江青",
	},
	[2430] = {
		comment = "江戏子",
	},
	[2431] = {
		comment = "江择民",
	},
	[2432] = {
		comment = "江泽民",
	},
	[2433] = {
		comment = "江贼民",
	},
	[2434] = {
		comment = "江折民",
	},
	[2435] = {
		comment = "江猪",
	},
	[2436] = {
		comment = "江猪媳",
	},
	[2437] = {
		comment = "江主席",
	},
	[2438] = {
		comment = "僵贼民",
	},
	[2439] = {
		comment = "疆独",
	},
	[2440] = {
		comment = "蒋介石",
	},
	[2441] = {
		comment = "蒋经国",
	},
	[2442] = {
		comment = "蒋中正",
	},
	[2443] = {
		comment = "酱猪媳",
	},
	[2444] = {
		comment = "交通部",
	},
	[2445] = {
		comment = "姣西",
	},
	[2446] = {
		comment = "叫床",
	},
	[2447] = {
		comment = "叫鸡",
	},
	[2448] = {
		comment = "叫小姐",
	},
	[2449] = {
		comment = "教育部",
	},
	[2450] = {
		comment = "她妈的金日成",
	},
	[2451] = {
		comment = "金正日",
	},
	[2452] = {
		comment = "禁书",
	},
	[2453] = {
		comment = "经济社会理事会",
	},
	[2454] = {
		comment = "经社理事会",
	},
	[2455] = {
		comment = "精液",
	},
	[2456] = {
		comment = "精子",
	},
	[2457] = {
		comment = "警匪一家",
	},
	[2458] = {
		comment = "敬国神社",
	},
	[2459] = {
		comment = "靖国神社",
	},
	[2460] = {
		comment = "静坐",
	},
	[2461] = {
		comment = "纠察员",
	},
	[2462] = {
		comment = "鸠",
	},
	[2463] = {
		comment = "鸠屎",
	},
	[2464] = {
		comment = "军长发威",
	},
	[2465] = {
		comment = "军国主义",
	},
	[2466] = {
		comment = "军妓",
	},
	[2467] = {
		comment = "尻",
	},
	[2468] = {
		comment = "靠",
	},
	[2469] = {
		comment = "靠你妈",
	},
	[2470] = {
		comment = "靠腰",
	},
	[2471] = {
		comment = "可待因",
	},
	[2472] = {
		comment = "可卡叶",
	},
	[2473] = {
		comment = "可卡因",
	},
	[2474] = {
		comment = "克林顿",
	},
	[2475] = {
		comment = "恐怖份子",
	},
	[2476] = {
		comment = "恐怖主义",
	},
	[2477] = {
		comment = "口交",
	},
	[2478] = {
		comment = "寇晓伟",
	},
	[2479] = {
		comment = "狂操",
	},
	[2480] = {
		comment = "狂操你全家",
	},
	[2481] = {
		comment = "拉登",
	},
	[2482] = {
		comment = "拉姆斯菲尔德",
	},
	[2483] = {
		comment = "懒教",
	},
	[2484] = {
		comment = "烂B",
	},
	[2485] = {
		comment = "烂屄",
	},
	[2486] = {
		comment = "烂逼",
	},
	[2487] = {
		comment = "烂比",
	},
	[2488] = {
		comment = "烂屌",
	},
	[2489] = {
		comment = "烂货",
	},
	[2490] = {
		comment = "劳+教+所",
	},
	[2491] = {
		comment = "劳动保障部",
	},
	[2492] = {
		comment = "老逼",
	},
	[2493] = {
		comment = "老毛子",
	},
	[2494] = {
		comment = "老母",
	},
	[2495] = {
		comment = "黎阳评",
	},
	[2496] = {
		comment = "李长春",
	},
	[2497] = {
		comment = "李登辉",
	},
	[2498] = {
		comment = "李弘旨",
	},
	[2499] = {
		comment = "李红志",
	},
	[2500] = {
		comment = "李宏旨",
	},
	[2501] = {
		comment = "李宏志",
	},
	[2502] = {
		comment = "李洪志",
	},
	[2503] = {
		comment = "李岚清",
	},
	[2504] = {
		comment = "李鹏",
	},
	[2505] = {
		comment = "李鹏*",
	},
	[2506] = {
		comment = "李瑞环",
	},
	[2507] = {
		comment = "李山",
	},
	[2508] = {
		comment = "李铁映",
	},
	[2509] = {
		comment = "李先念",
	},
	[2510] = {
		comment = "连战",
	},
	[2511] = {
		comment = "联大",
	},
	[2512] = {
		comment = "联合国",
	},
	[2513] = {
		comment = "联合国大会",
	},
	[2514] = {
		comment = "联易",
	},
	[2515] = {
		comment = "联易互动",
	},
	[2516] = {
		comment = "粮食局",
	},
	[2517] = {
		comment = "两腿之间",
	},
	[2518] = {
		comment = "列宁",
	},
	[2519] = {
		comment = "林彪",
	},
	[2520] = {
		comment = "林业局",
	},
	[2521] = {
		comment = "刘　淇",
	},
	[2522] = {
		comment = "刘军",
	},
	[2523] = {
		comment = "刘淇",
	},
	[2524] = {
		comment = "刘少奇",
	},
	[2525] = {
		comment = "刘云山",
	},
	[2526] = {
		comment = "流氓",
	},
	[2527] = {
		comment = "六.四",
	},
	[2528] = {
		comment = "六。四",
	},
	[2529] = {
		comment = "六?四",
	},
	[2530] = {
		comment = "六合彩",
	},
	[2531] = {
		comment = "六四",
	},
	[2532] = {
		comment = "六-四",
	},
	[2533] = {
		comment = "六四事件",
	},
	[2534] = {
		comment = "六四真相",
	},
	[2535] = {
		comment = "龙新民",
	},
	[2536] = {
		comment = "吕秀莲",
	},
	[2537] = {
		comment = "旅游局",
	},
	[2538] = {
		comment = "卵",
	},
	[2539] = {
		comment = "轮功",
	},
	[2540] = {
		comment = "轮奸",
	},
	[2541] = {
		comment = "罗　干",
	},
	[2542] = {
		comment = "罗干",
	},
	[2543] = {
		comment = "骡干",
	},
	[2544] = {
		comment = "妈逼",
	},
	[2545] = {
		comment = "妈比",
	},
	[2546] = {
		comment = "妈卖妈屁",
	},
	[2547] = {
		comment = "妈批",
	},
	[2548] = {
		comment = "妈祖",
	},
	[2549] = {
		comment = "妈B",
	},
	[2550] = {
		comment = "妈的",
	},
	[2551] = {
		comment = "麻醉钢枪",
	},
	[2552] = {
		comment = "麻醉枪",
	},
	[2553] = {
		comment = "麻醉药",
	},
	[2554] = {
		comment = "麻醉乙醚",
	},
	[2555] = {
		comment = "马克思",
	},
	[2556] = {
		comment = "马卖马屁",
	},
	[2557] = {
		comment = "马英九",
	},
	[2558] = {
		comment = "吗啡",
	},
	[2559] = {
		comment = "吗啡碱",
	},
	[2560] = {
		comment = "吗啡片",
	},
	[2561] = {
		comment = "买财富",
	},
	[2562] = {
		comment = "买卖枪支",
	},
	[2563] = {
		comment = "麦角酸",
	},
	[2564] = {
		comment = "卖.国",
	},
	[2565] = {
		comment = "卖B",
	},
	[2566] = {
		comment = "卖ID",
	},
	[2567] = {
		comment = "卖QQ",
	},
	[2568] = {
		comment = "卖逼",
	},
	[2569] = {
		comment = "卖比",
	},
	[2570] = {
		comment = "卖财富",
	},
	[2571] = {
		comment = "卖党求荣",
	},
	[2572] = {
		comment = "卖国",
	},
	[2573] = {
		comment = "卖国求荣",
	},
	[2574] = {
		comment = "卖号",
	},
	[2575] = {
		comment = "卖卡",
	},
	[2576] = {
		comment = "卖软件",
	},
	[2577] = {
		comment = "卖淫",
	},
	[2578] = {
		comment = "毛XX",
	},
	[2579] = {
		comment = "毛厕洞",
	},
	[2580] = {
		comment = "毛一鲜",
	},
	[2581] = {
		comment = "毛泽东",
	},
	[2582] = {
		comment = "毛贼东",
	},
	[2583] = {
		comment = "毛主席",
	},
	[2584] = {
		comment = "梅花网",
	},
	[2585] = {
		comment = "美国",
	},
	[2586] = {
		comment = "美国佬",
	},
	[2587] = {
		comment = "美国之音",
	},
	[2588] = {
		comment = "美利坚",
	},
	[2589] = {
		comment = "蒙尘药",
	},
	[2590] = {
		comment = "蒙独",
	},
	[2591] = {
		comment = "蒙古达子",
	},
	[2592] = {
		comment = "蒙古独立",
	},
	[2593] = {
		comment = "迷魂药",
	},
	[2594] = {
		comment = "迷奸药",
	},
	[2595] = {
		comment = "迷歼药",
	},
	[2596] = {
		comment = "迷药",
	},
	[2597] = {
		comment = "密洞",
	},
	[2598] = {
		comment = "密宗",
	},
	[2599] = {
		comment = "民航局",
	},
	[2600] = {
		comment = "民进党",
	},
	[2601] = {
		comment = "民运",
	},
	[2602] = {
		comment = "民政部",
	},
	[2603] = {
		comment = "明慧网",
	},
	[2604] = {
		comment = "摩门教",
	},
	[2605] = {
		comment = "莫索里尼",
	},
	[2606] = {
		comment = "穆罕默德",
	},
	[2607] = {
		comment = "穆斯林",
	},
	[2608] = {
		comment = "乳头",
	},
	[2609] = {
		comment = "奶子",
	},
	[2610] = {
		comment = "妳老母的",
	},
	[2611] = {
		comment = "妳妈的",
	},
	[2612] = {
		comment = "妳马的",
	},
	[2613] = {
		comment = "妳娘的",
	},
	[2614] = {
		comment = "南联盟",
	},
	[2615] = {
		comment = "南蛮子",
	},
	[2616] = {
		comment = "南蛮子",
	},
	[2617] = {
		comment = "嫩B",
	},
	[2618] = {
		comment = "嫩b",
	},
	[2619] = {
		comment = "伱妈",
	},
	[2620] = {
		comment = "你爸",
	},
	[2621] = {
		comment = "你大爷",
	},
	[2622] = {
		comment = "你二大爷",
	},
	[2623] = {
		comment = "你老母",
	},
	[2624] = {
		comment = "你老味",
	},
	[2625] = {
		comment = "你姥",
	},
	[2626] = {
		comment = "你姥姥的",
	},
	[2627] = {
		comment = "你妈",
	},
	[2628] = {
		comment = "你妈逼",
	},
	[2629] = {
		comment = "你妈的",
	},
	[2630] = {
		comment = "你娘",
	},
	[2631] = {
		comment = "你爷爷的",
	},
	[2632] = {
		comment = "鸟GM",
	},
	[2633] = {
		comment = "鸟Gm",
	},
	[2634] = {
		comment = "鸟gM",
	},
	[2635] = {
		comment = "鸟gm",
	},
	[2636] = {
		comment = "鸟你",
	},
	[2637] = {
		comment = "牛逼",
	},
	[2638] = {
		comment = "牛比",
	},
	[2639] = {
		comment = "农业部",
	},
	[2640] = {
		comment = "虐待",
	},
	[2641] = {
		comment = "拍肩神药",
	},
	[2642] = {
		comment = "喷你",
	},
	[2643] = {
		comment = "彭真",
	},
	[2644] = {
		comment = "皮条",
	},
	[2645] = {
		comment = "屁眼",
	},
	[2646] = {
		comment = "嫖客",
	},
	[2647] = {
		comment = "苹果日报",
	},
	[2648] = {
		comment = "破坏",
	},
	[2649] = {
		comment = "破鞋",
	},
	[2650] = {
		comment = "仆街",
	},
	[2651] = {
		comment = "普京",
	},
	[2652] = {
		comment = "气象局",
	},
	[2653] = {
		comment = "钱其琛",
	},
	[2654] = {
		comment = "枪决女犯",
	},
	[2655] = {
		comment = "枪决现场",
	},
	[2656] = {
		comment = "枪支弹药",
	},
	[2657] = {
		comment = "强奸",
	},
	[2658] = {
		comment = "强奸犯",
	},
	[2659] = {
		comment = "强卫",
	},
	[2660] = {
		comment = "强效失意药",
	},
	[2661] = {
		comment = "强硬发言",
	},
	[2662] = {
		comment = "抢劫",
	},
	[2663] = {
		comment = "乔石",
	},
	[2664] = {
		comment = "侨办",
	},
	[2665] = {
		comment = "切七",
	},
	[2666] = {
		comment = "窃听器",
	},
	[2667] = {
		comment = "窃听器材",
	},
	[2668] = {
		comment = "亲民党",
	},
	[2669] = {
		comment = "青天白日",
	},
	[2670] = {
		comment = "情色",
	},
	[2671] = {
		comment = "去你妈的",
	},
	[2672] = {
		comment = "去死",
	},
	[2673] = {
		comment = "全国人大",
	},
	[2674] = {
		comment = "瘸腿帮",
	},
	[2675] = {
		comment = "人大",
	},
	[2676] = {
		comment = "人大代表",
	},
	[2677] = {
		comment = "人代会",
	},
	[2678] = {
		comment = "人弹",
	},
	[2679] = {
		comment = "人民",
	},
	[2680] = {
		comment = "人民大会堂",
	},
	[2681] = {
		comment = "人民广场",
	},
	[2682] = {
		comment = "人民日报",
	},
	[2683] = {
		comment = "人民银行",
	},
	[2684] = {
		comment = "人体炸弹",
	},
	[2685] = {
		comment = "日GM",
	},
	[2686] = {
		comment = "日Gm",
	},
	[2687] = {
		comment = "日gM",
	},
	[2688] = {
		comment = "日gm",
	},
	[2689] = {
		comment = "日X妈",
	},
	[2690] = {
		comment = "日本RING",
	},
	[2691] = {
		comment = "日本鬼子",
	},
	[2692] = {
		comment = "日你",
	},
	[2693] = {
		comment = "日你妈",
	},
	[2694] = {
		comment = "日你娘",
	},
	[2695] = {
		comment = "日他娘",
	},
	[2696] = {
		comment = "肉棒",
	},
	[2697] = {
		comment = "肉壁",
	},
	[2698] = {
		comment = "肉洞",
	},
	[2699] = {
		comment = "肉缝",
	},
	[2700] = {
		comment = "肉棍",
	},
	[2701] = {
		comment = "肉棍子",
	},
	[2702] = {
		comment = "肉穴",
	},
	[2703] = {
		comment = "乳",
	},
	[2704] = {
		comment = "乳波臀浪",
	},
	[2705] = {
		comment = "乳房",
	},
	[2706] = {
		comment = "乳交",
	},
	[2707] = {
		comment = "乳头",
	},
	[2708] = {
		comment = "撒尿",
	},
	[2709] = {
		comment = "萨达姆",
	},
	[2710] = {
		comment = "塞白",
	},
	[2711] = {
		comment = "塞你爸",
	},
	[2712] = {
		comment = "塞你公",
	},
	[2713] = {
		comment = "塞你老母",
	},
	[2714] = {
		comment = "塞你老师",
	},
	[2715] = {
		comment = "塞你母",
	},
	[2716] = {
		comment = "塞你娘",
	},
	[2717] = {
		comment = "三个呆婊",
	},
	[2718] = {
		comment = "三个代婊",
	},
	[2719] = {
		comment = "三级片",
	},
	[2720] = {
		comment = "三民主义",
	},
	[2721] = {
		comment = "三陪",
	},
	[2722] = {
		comment = "三陪女",
	},
	[2723] = {
		comment = "三去车仑",
	},
	[2724] = {
		comment = "三唑仑",
	},
	[2725] = {
		comment = "骚",
	},
	[2726] = {
		comment = "骚B",
	},
	[2727] = {
		comment = "骚逼",
	},
	[2728] = {
		comment = "骚货",
	},
	[2729] = {
		comment = "骚",
	},
	[2730] = {
		comment = "色情",
	},
	[2731] = {
		comment = "色情电影",
	},
	[2732] = {
		comment = "色情服务",
	},
	[2733] = {
		comment = "色情小电影",
	},
	[2734] = {
		comment = "杀人犯",
	},
	[2735] = {
		comment = "傻B",
	},
	[2736] = {
		comment = "傻屄",
	},
	[2737] = {
		comment = "傻逼",
	},
	[2738] = {
		comment = "傻比",
	},
	[2739] = {
		comment = "傻吊",
	},
	[2740] = {
		comment = "傻卵",
	},
	[2741] = {
		comment = "傻子",
	},
	[2742] = {
		comment = "煞逼",
	},
	[2743] = {
		comment = "商务部",
	},
	[2744] = {
		comment = "上妳",
	},
	[2745] = {
		comment = "上你",
	},
	[2746] = {
		comment = "社科院",
	},
	[2747] = {
		comment = "射精",
	},
	[2748] = {
		comment = "身份生成器",
	},
	[2749] = {
		comment = "神经病",
	},
	[2750] = {
		comment = "神通加持法",
	},
	[2751] = {
		comment = "生鸦片",
	},
	[2752] = {
		comment = "圣女峰",
	},
	[2753] = {
		comment = "十八摸",
	},
	[2754] = {
		comment = "十年动乱石进",
	},
	[2755] = {
		comment = "食捻屎",
	},
	[2756] = {
		comment = "食屎",
	},
	[2757] = {
		comment = "驶你爸",
	},
	[2758] = {
		comment = "驶你公",
	},
	[2759] = {
		comment = "驶你老母",
	},
	[2760] = {
		comment = "驶你老师",
	},
	[2761] = {
		comment = "驶你母",
	},
	[2762] = {
		comment = "驶你娘",
	},
	[2763] = {
		comment = "是鸡",
	},
	[2764] = {
		comment = "手淫",
	},
	[2765] = {
		comment = "受虐狂",
	},
	[2766] = {
		comment = "售ID",
	},
	[2767] = {
		comment = "售号",
	},
	[2768] = {
		comment = "售软件",
	},
	[2769] = {
		comment = "双峰微颤",
	},
	[2770] = {
		comment = "氵去",
	},
	[2771] = {
		comment = "水利部",
	},
	[2772] = {
		comment = "水去车仑",
	},
	[2773] = {
		comment = "税务总局",
	},
	[2774] = {
		comment = "司法部",
	},
	[2775] = {
		comment = "私服",
	},
	[2776] = {
		comment = "私/服",
	},
	[2777] = {
		comment = "私\\服",
	},
	[2778] = {
		comment = "私服",
	},
	[2779] = {
		comment = "私-服",
	},
	[2780] = {
		comment = "私—服",
	},
	[2781] = {
		comment = "斯大林",
	},
	[2782] = {
		comment = "死gd",
	},
	[2783] = {
		comment = "死GD",
	},
	[2784] = {
		comment = "死gm",
	},
	[2785] = {
		comment = "死GM",
	},
	[2786] = {
		comment = "死全家",
	},
	[2787] = {
		comment = "四川独立",
	},
	[2788] = {
		comment = "四人帮",
	},
	[2789] = {
		comment = "宋楚瑜",
	},
	[2790] = {
		comment = "宋祖英",
	},
	[2791] = {
		comment = "孙文",
	},
	[2792] = {
		comment = "孙逸仙",
	},
	[2793] = {
		comment = "孙中山",
	},
	[2794] = {
		comment = "他爹",
	},
	[2795] = {
		comment = "他妈",
	},
	[2796] = {
		comment = "他妈的",
	},
	[2797] = {
		comment = "他马的",
	},
	[2798] = {
		comment = "他母亲",
	},
	[2799] = {
		comment = "他祖宗",
	},
	[2800] = {
		comment = "台办",
	},
	[2801] = {
		comment = "台独",
	},
	[2802] = {
		comment = "台联",
	},
	[2803] = {
		comment = "台湾党",
	},
	[2804] = {
		comment = "台湾帝国",
	},
	[2805] = {
		comment = "台湾独立",
	},
	[2806] = {
		comment = "台湾共产党",
	},
	[2807] = {
		comment = "台湾共和国",
	},
	[2808] = {
		comment = "台湾狗",
	},
	[2809] = {
		comment = "台湾国",
	},
	[2810] = {
		comment = "台湾民国",
	},
	[2811] = {
		comment = "太监",
	},
	[2812] = {
		comment = "太子党",
	},
	[2813] = {
		comment = "唐家璇",
	},
	[2814] = {
		comment = "天皇陛下",
	},
	[2815] = {
		comment = "田纪云",
	},
	[2816] = {
		comment = "舔西",
	},
	[2817] = {
		comment = "投毒杀人",
	},
	[2818] = {
		comment = "透视软件",
	},
	[2819] = {
		comment = "推油",
	},
	[2820] = {
		comment = "外　挂",
	},
	[2821] = {
		comment = "外挂",
	},
	[2822] = {
		comment = "外/挂",
	},
	[2823] = {
		comment = "外\\挂",
	},
	[2824] = {
		comment = "外_挂",
	},
	[2825] = {
		comment = "外挂",
	},
	[2826] = {
		comment = "外-挂",
	},
	[2827] = {
		comment = "外—挂",
	},
	[2828] = {
		comment = "外汇局",
	},
	[2829] = {
		comment = "外交部",
	},
	[2830] = {
		comment = "外专局",
	},
	[2831] = {
		comment = "晚年周恩来",
	},
	[2832] = {
		comment = "万税",
	},
	[2833] = {
		comment = "王八蛋",
	},
	[2834] = {
		comment = "王宝森",
	},
	[2835] = {
		comment = "王刚",
	},
	[2836] = {
		comment = "王昊",
	},
	[2837] = {
		comment = "王乐泉",
	},
	[2838] = {
		comment = "王岐山",
	},
	[2839] = {
		comment = "王太华",
	},
	[2840] = {
		comment = "王兆国",
	},
	[2841] = {
		comment = "王震",
	},
	[2842] = {
		comment = "网管",
	},
	[2843] = {
		comment = "威而钢",
	},
	[2844] = {
		comment = "威而柔",
	},
	[2845] = {
		comment = "卫生部",
	},
	[2846] = {
		comment = "尉健行",
	},
	[2847] = {
		comment = "温加宝",
	},
	[2848] = {
		comment = "温家宝",
	},
	[2849] = {
		comment = "温家保",
	},
	[2850] = {
		comment = "温馨",
	},
	[2851] = {
		comment = "温总理",
	},
	[2852] = {
		comment = "文化部",
	},
	[2853] = {
		comment = "文物局",
	},
	[2854] = {
		comment = "倭国",
	},
	[2855] = {
		comment = "倭寇",
	},
	[2856] = {
		comment = "我操",
	},
	[2857] = {
		comment = "我操你",
	},
	[2858] = {
		comment = "我干",
	},
	[2859] = {
		comment = "我妳老爸",
	},
	[2860] = {
		comment = "我日",
	},
	[2861] = {
		comment = "我日你",
	},
	[2862] = {
		comment = "无界浏览器",
	},
	[2863] = {
		comment = "吴　仪",
	},
	[2864] = {
		comment = "吴邦国",
	},
	[2865] = {
		comment = "吴官正",
	},
	[2866] = {
		comment = "吴仪",
	},
	[2867] = {
		comment = "五星红旗",
	},
	[2868] = {
		comment = "西藏独立",
	},
	[2869] = {
		comment = "西藏天葬",
	},
	[2870] = {
		comment = "希拉克",
	},
	[2871] = {
		comment = "希特勒",
	},
	[2872] = {
		comment = "希望之声",
	},
	[2873] = {
		comment = "洗脑班",
	},
	[2874] = {
		comment = "系统",
	},
	[2875] = {
		comment = "系统公告",
	},
	[2876] = {
		comment = "系统讯息",
	},
	[2877] = {
		comment = "鲜族",
	},
	[2878] = {
		comment = "乡巴佬",
	},
	[2879] = {
		comment = "想上你",
	},
	[2880] = {
		comment = "小鸡鸡",
	},
	[2881] = {
		comment = "小泉",
	},
	[2882] = {
		comment = "小泉纯一郎",
	},
	[2883] = {
		comment = "小日本",
	},
	[2884] = {
		comment = "小肉粒",
	},
	[2885] = {
		comment = "小乳头",
	},
	[2886] = {
		comment = "小穴",
	},
	[2887] = {
		comment = "邪教",
	},
	[2888] = {
		comment = "新疆独立",
	},
	[2889] = {
		comment = "兴奋剂",
	},
	[2890] = {
		comment = "性爱",
	},
	[2891] = {
		comment = "性交",
	},
	[2892] = {
		comment = "性虐待",
	},
	[2893] = {
		comment = "性无能",
	},
	[2894] = {
		comment = "性欲",
	},
	[2895] = {
		comment = "徐光春",
	},
	[2896] = {
		comment = "学潮",
	},
	[2897] = {
		comment = "血逼",
	},
	[2898] = {
		comment = "血腥图片",
	},
	[2899] = {
		comment = "鸦片",
	},
	[2900] = {
		comment = "鸦片液",
	},
	[2901] = {
		comment = "鸦片渣",
	},
	[2902] = {
		comment = "烟草局",
	},
	[2903] = {
		comment = "严方军",
	},
	[2904] = {
		comment = "阳精",
	},
	[2905] = {
		comment = "阳具",
	},
	[2906] = {
		comment = "摇头丸",
	},
	[2907] = {
		comment = "摇头玩",
	},
	[2908] = {
		comment = "耶和华",
	},
	[2909] = {
		comment = "耶苏",
	},
	[2910] = {
		comment = "耶稣",
	},
	[2911] = {
		comment = "叶剑英",
	},
	[2912] = {
		comment = "夜情",
	},
	[2913] = {
		comment = "一党专制",
	},
	[2914] = {
		comment = "一贯道",
	},
	[2915] = {
		comment = "一国两制",
	},
	[2916] = {
		comment = "一夜情",
	},
	[2917] = {
		comment = "一中一台",
	},
	[2918] = {
		comment = "伊拉克",
	},
	[2919] = {
		comment = "伊朗",
	},
	[2920] = {
		comment = "伊斯兰",
	},
	[2921] = {
		comment = "以茎至洞",
	},
	[2922] = {
		comment = "抑制剂",
	},
	[2923] = {
		comment = "阴部",
	},
	[2924] = {
		comment = "阴唇",
	},
	[2925] = {
		comment = "阴道",
	},
	[2926] = {
		comment = "阴蒂",
	},
	[2927] = {
		comment = "阴核",
	},
	[2928] = {
		comment = "阴户",
	},
	[2929] = {
		comment = "阴茎",
	},
	[2930] = {
		comment = "阴毛",
	},
	[2931] = {
		comment = "阴水",
	},
	[2932] = {
		comment = "阴小撕大",
	},
	[2933] = {
		comment = "淫",
	},
	[2934] = {
		comment = "淫荡",
	},
	[2935] = {
		comment = "淫秽",
	},
	[2936] = {
		comment = "淫货",
	},
	[2937] = {
		comment = "淫贱",
	},
	[2938] = {
		comment = "淫叫",
	},
	[2939] = {
		comment = "淫毛",
	},
	[2940] = {
		comment = "淫靡",
	},
	[2941] = {
		comment = "淫水",
	},
	[2942] = {
		comment = "淫娃",
	},
	[2943] = {
		comment = "淫语连连",
	},
	[2944] = {
		comment = "淫欲",
	},
	[2945] = {
		comment = "英雄纪念碑",
	},
	[2946] = {
		comment = "硬挺",
	},
	[2947] = {
		comment = "邮政局",
	},
	[2948] = {
		comment = "游戏发奖员",
	},
	[2949] = {
		comment = "游戏宫理员",
	},
	[2950] = {
		comment = "游戏管理员",
	},
	[2951] = {
		comment = "游行",
	},
	[2952] = {
		comment = "俞正声",
	},
	[2953] = {
		comment = "舆论钳制",
	},
	[2954] = {
		comment = "玉杵",
	},
	[2955] = {
		comment = "欲火焚身",
	},
	[2956] = {
		comment = "原子能机构",
	},
	[2957] = {
		comment = "援交",
	},
	[2958] = {
		comment = "远程偷拍",
	},
	[2959] = {
		comment = "曰GM",
	},
	[2960] = {
		comment = "曰Gm",
	},
	[2961] = {
		comment = "曰gM",
	},
	[2962] = {
		comment = "曰gm",
	},
	[2963] = {
		comment = "曰你",
	},
	[2964] = {
		comment = "月经",
	},
	[2965] = {
		comment = "月经不调",
	},
	[2966] = {
		comment = "月经",
	},
	[2967] = {
		comment = "扎卡维是英雄",
	},
	[2968] = {
		comment = "杂种",
	},
	[2969] = {
		comment = "造反",
	},
	[2970] = {
		comment = "曾培炎",
	},
	[2971] = {
		comment = "曾庆红",
	},
	[2972] = {
		comment = "扎卡维",
	},
	[2973] = {
		comment = "张朝阳",
	},
	[2974] = {
		comment = "张潮阳",
	},
	[2975] = {
		comment = "张德江",
	},
	[2976] = {
		comment = "张磊",
	},
	[2977] = {
		comment = "张立昌",
	},
	[2978] = {
		comment = "张小平",
	},
	[2979] = {
		comment = "赵紫阳",
	},
	[2980] = {
		comment = "侦探设备",
	},
	[2981] = {
		comment = "真理教",
	},
	[2982] = {
		comment = "中国恐怖组织",
	},
	[2983] = {
		comment = "中华民国",
	},
	[2984] = {
		comment = "中南海",
	},
	[2985] = {
		comment = "中宣部",
	},
	[2986] = {
		comment = "周恩来",
	},
	[2987] = {
		comment = "周永康",
	},
	[2988] = {
		comment = "周总理",
	},
	[2989] = {
		comment = "朱德",
	},
	[2990] = {
		comment = "朱容鸡",
	},
	[2991] = {
		comment = "朱容基",
	},
	[2992] = {
		comment = "朱熔基",
	},
	[2993] = {
		comment = "朱镕基",
	},
	[2994] = {
		comment = "朱总理",
	},
	[2995] = {
		comment = "猪操",
	},
	[2996] = {
		comment = "猪容基",
	},
	[2997] = {
		comment = "主席",
	},
	[2998] = {
		comment = "转法轮",
	},
	[2999] = {
		comment = "转法轮",
	},
	[3000] = {
		comment = "装屄",
	},
	[3001] = {
		comment = "装逼",
	},
	[3002] = {
		comment = "追查国际",
	},
	[3003] = {
		comment = "子女任职名单",
	},
	[3004] = {
		comment = "自焚",
	},
	[3005] = {
		comment = "自杀手册",
	},
	[3006] = {
		comment = "自杀指南",
	},
	[3007] = {
		comment = "自制手枪",
	},
	[3008] = {
		comment = "自治机关",
	},
	[3009] = {
		comment = "宗教",
	},
	[3010] = {
		comment = "总局",
	},
	[3011] = {
		comment = "总理",
	},
	[3012] = {
		comment = "作爱",
	},
	[3013] = {
		comment = "坐台的",
	},
	[3014] = {
		comment = "做爱",
	},
	[3015] = {
		comment = "共产党",
	},
	[3016] = {
		comment = "江泽民",
	},
	[3017] = {
		comment = "胡锦涛",
	},
	[3018] = {
		comment = "温家宝",
	},
	[3019] = {
		comment = "严方军",
	},
	[3020] = {
		comment = "屄毛",
	},
	[3021] = {
		comment = "操逼毛",
	},
	[3022] = {
		comment = "东突",
	},
	[3023] = {
		comment = "骚货",
	},
	[3024] = {
		comment = "法轮功",
	},
	[3025] = {
		comment = "江泽民",
	},
	[3026] = {
		comment = "胡锦涛",
	},
	[3027] = {
		comment = "温家宝",
	},
	[3028] = {
		comment = "urban-rivals",
	},
	[3029] = {
		comment = "rivals",
	},
	[3030] = {
		comment = "ur",
	},
	[3031] = {
		comment = "ur",
	},
	[3032] = {
		comment = "我日",
	},
	[3033] = {
		comment = "UR",
	},
	[3034] = {
		comment = "ur",
	},
	[3035] = {
		comment = "性交",
	},
	[3036] = {
		comment = "口交",
	},
	[3037] = {
		comment = "UR",
	},
	[3038] = {
		comment = "taobao",
	},
	[3039] = {
		comment = "webgame.com.cn",
	},
	[3040] = {
		comment = "婊子",
	},
	[3041] = {
		comment = "妓女",
	},
	[3042] = {
		comment = "他妈",
	},
	[3043] = {
		comment = "她妈",
	},
	[3044] = {
		comment = "牛逼",
	},
	[3045] = {
		comment = "牛比",
	},
	[3046] = {
		comment = "牛B",
	},
	[3047] = {
		comment = "煞笔",
	},
	[3048] = {
		comment = "傻逼",
	},
	[3049] = {
		comment = "傻B",
	},
	[3050] = {
		comment = "你妈",
	},
	[3051] = {
		comment = "操你妈",
	},
	[3052] = {
		comment = "装逼",
	},
	[3053] = {
		comment = "装B",
	},
	[3054] = {
		comment = "日你妈",
	},
	[3055] = {
		comment = "不玩了",
	},
	[3056] = {
		comment = "删号",
	},
	[3057] = {
		comment = "卖号",
	},
	[3058] = {
		comment = "垃圾游戏",
	},
	[3059] = {
		comment = "烂游戏",
	},
	[3060] = {
		comment = "删号",
	},
	[3061] = {
		comment = "妈的",
	},
	[3062] = {
		comment = "妈逼",
	},
	[3063] = {
		comment = "草你妈",
	},
	[3064] = {
		comment = "T.M.D",
	},
	[3065] = {
		comment = "JB",
	},
	[3066] = {
		comment = "jb",
	},
	[3067] = {
		comment = "淘宝",
	},
	[3068] = {
		comment = "出售账号",
	},
	[3069] = {
		comment = "出售此号",
	},
	[3070] = {
		comment = "卖号",
	},
	[3071] = {
		comment = "U/R",
	},
	[3072] = {
		comment = "U-R",
	},
	[3073] = {
		comment = "cao",
	},
	[3074] = {
		comment = "j8",
	},
	[3075] = {
		comment = "吗的",
	},
	[3076] = {
		comment = "8仙",
	},
	[3077] = {
		comment = "狗日",
	},
	[3078] = {
		comment = "出售神符",
	},
	[3079] = {
		comment = "色情",
	},
	[3080] = {
		comment = "黄色",
	},
	[3081] = {
		comment = "h站",
	},
	[3082] = {
		comment = "龙虎",
	},
	[3083] = {
		comment = "虎门",
	},
	[3084] = {
		comment = "龙虎门",
	},
	[3085] = {
		comment = "WEB牌戰",
	},
	[3086] = {
		comment = "WEB战牌",
	},
	[3087] = {
		comment = "战牌",
	},
	[3088] = {
		comment = "8仙",
	},
	[3089] = {
		comment = "ＵＲ",
	},
	[3090] = {
		comment = "ur",
	},
	[3091] = {
		comment = "UR",
	},
	[3092] = {
		comment = "街头对抗",
	},
	[3093] = {
		comment = "藏独",
	},
	[3094] = {
		comment = "台独",
	},
	[3095] = {
		comment = "法轮大法",
	},
	[3096] = {
		comment = "混沌决",
	},
	[3097] = {
		comment = "ur",
	},
	[3098] = {
		comment = "UR",
	},
	[3099] = {
		comment = "urban",
	},
	[3100] = {
		comment = "鸡巴",
	},
	[3101] = {
		comment = "坐台的",
	},
	[3102] = {
		comment = "作爱",
	},
	[3103] = {
		comment = "总理",
	},
	[3104] = {
		comment = "宗教",
	},
	[3105] = {
		comment = "自治机关",
	},
	[3106] = {
		comment = "自制手枪",
	},
	[3107] = {
		comment = "藏独",
	},
	[3108] = {
		comment = "台独",
	},
	[3109] = {
		comment = "习近平",
	},
	[3110] = {
		comment = "江泽民",
	},
	[3111] = {
		comment = "张高丽",
	},
	[3112] = {
		comment = "sex",
	},
	[3113] = {
		comment = "李克强",
	},
	[3114] = {
		comment = "偷窥视频",
	},
	[3115] = {
		comment = "k粉",
	},
	[3116] = {
		comment = "强暴幼女",
	},
	[3117] = {
		comment = "西藏自由",
	},
	[3118] = {
		comment = "东突",
	},
	[3119] = {
		comment = "Freetibet",
	},
	[3120] = {
		comment = "全能神",
	},
	[3121] = {
		comment = "呼喊派",
	},
	[3122] = {
		comment = "徒弟会",
	},
	[3123] = {
		comment = "全范围教会",
	},
	[3124] = {
		comment = "灵灵教",
	},
	[3125] = {
		comment = "新约教会",
	},
	[3126] = {
		comment = "观音法门",
	},
	[3127] = {
		comment = "主神教",
	},
	[3128] = {
		comment = "被立王",
	},
	[3129] = {
		comment = "同一教",
	},
	[3130] = {
		comment = "三班仆人派",
	},
	[3131] = {
		comment = "灵仙真佛宗",
	},
	[3132] = {
		comment = "天父的儿女",
	},
	[3133] = {
		comment = "达米宣教会",
	},
	[3134] = {
		comment = "世界以利亚福音宣教会",
	},
	[3135] = {
		comment = "常受教",
	},
	[3136] = {
		comment = "中华大陆行政执事站",
	},
	[3137] = {
		comment = "主神教",
	},
	[3138] = {
		comment = "实际神",
	},
	[3139] = {
		comment = "东方闪电",
	},
	[3140] = {
		comment = "isis",
	},
	[3141] = {
		comment = "伊斯兰国",
	},
	[3142] = {
		comment = "isil",
	},
	[3143] = {
		comment = "乌克兰分离",
	},
	[3144] = {
		comment = "占中",
	},
	[3145] = {
		comment = "ISIS",
	},
	[3146] = {
		comment = "ISIL藏独",
	},
	[3147] = {
		comment = "台独",
	},
	[3148] = {
		comment = "习近平江泽民张高丽",
	},
	[3149] = {
		comment = "sex李克强偷窥视频",
	},
	[3150] = {
		comment = "k粉强暴幼女西藏自由",
	},
	[3151] = {
		comment = "东突",
	},
	[3152] = {
		comment = "Freetibet全能神",
	},
	[3153] = {
		comment = "呼喊派",
	},
	[3154] = {
		comment = "徒弟会",
	},
	[3155] = {
		comment = "全范围教会",
	},
	[3156] = {
		comment = "灵灵教",
	},
	[3157] = {
		comment = "新约教会",
	},
	[3158] = {
		comment = "观音法门",
	},
	[3159] = {
		comment = "主神教",
	},
	[3160] = {
		comment = "被立王",
	},
	[3161] = {
		comment = "同一教",
	},
	[3162] = {
		comment = "三班仆人派",
	},
	[3163] = {
		comment = "灵仙真佛宗",
	},
	[3164] = {
		comment = "天父的儿女",
	},
	[3165] = {
		comment = "达米宣教会",
	},
	[3166] = {
		comment = "世界以利亚福音宣教会",
	},
	[3167] = {
		comment = "常受教",
	},
	[3168] = {
		comment = "中华大陆行政执事站",
	},
	[3169] = {
		comment = "主神教",
	},
	[3170] = {
		comment = "实际神",
	},
	[3171] = {
		comment = "东方闪电ISIS",
	},
	[3172] = {
		comment = "ISIL",
	},
	[3173] = {
		comment = "伊斯兰国",
	},
	[3174] = {
		comment = "占中",
	},
	[3175] = {
		comment = "占领中环",
	},
	[3176] = {
		comment = "默罕默德",
	},
}
