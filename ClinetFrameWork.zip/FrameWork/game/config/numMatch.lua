-- id                               int                              场数序号
-- match_times                      int                              匹配条件（场次）
-- wait_players_0                   int                              等待0s时可开始的人数
-- wait_players_1                   int                              等待1s时可开始的人数
-- wait_players_2                   int                              等待2s时可开始的人数
-- wait_players_3                   int                              等待3s时可开始的人数
-- wait_players_4                   int                              房间等待4s时可开始的人数
-- match_min_0                      int                              玩家向上搜索匹配池id
-- match_max_0                      int                              玩家向下搜索匹配池id
-- room_type                        int                              新手模式房间类型

return {
	[1] = {
		match_times = 0,
		wait_players_0 = 1,
		wait_players_1 = 1,
		wait_players_2 = 1,
		wait_players_3 = 1,
		wait_players_4 = 1,
		match_min_0 = 1,
		match_max_0 = 1,
		room_type = 1,
	},
}
