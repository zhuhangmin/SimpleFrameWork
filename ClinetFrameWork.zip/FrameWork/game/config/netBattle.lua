-- id                               int                              序号
-- CAPTURE_TOUCH_FRAME              int                              采集触摸方向的帧率
-- QUALITY_MID_SCORE                int                              球体品质区分（区分高和低品质）
-- SELF_INCRE_FRAME_COUNT           int                              自己补帧帧数
-- OTHER_INCRE_FRAME_COUNT          int                              别的玩家补帧帧数
-- TURN_FRAME_COUNT                 int                              转向帧数
-- SCENE_GRID_WIDTH                 int                              判断格子的宽
-- SCENE_GRID_HEIGHT                int                              判断格子的长
-- DRAG_ACC                         int                              阻力加速度
-- BALL_ACC                         int                              小球的加速度
-- BALL_DEC                         int                              小球的减速度

return {
	[1] = {
		CAPTURE_TOUCH_FRAME = 15,
		QUALITY_MID_SCORE = 53,
		SELF_INCRE_FRAME_COUNT = 20,
		OTHER_INCRE_FRAME_COUNT = 20,
		TURN_FRAME_COUNT = 15,
		SCENE_GRID_WIDTH = 30,
		SCENE_GRID_HEIGHT = 30,
		DRAG_ACC = -300,
		BALL_ACC = 6000,
		BALL_DEC = 1000,
	},
}
