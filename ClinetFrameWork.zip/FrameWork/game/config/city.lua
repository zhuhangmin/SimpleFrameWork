-- id                               int                              序号
-- full_name                        string                           省份全称(最长8个字)
-- name                             string                           省份简称(最长3个字)

return {
	[1] = {
		full_name = "北京市",
		name = "北京",
	},
	[2] = {
		full_name = "浙江省",
		name = "浙江",
	},
	[3] = {
		full_name = "天津市",
		name = "天津",
	},
	[4] = {
		full_name = "安徽省",
		name = "安徽",
	},
	[5] = {
		full_name = "上海市",
		name = "上海",
	},
	[6] = {
		full_name = "福建省",
		name = "福建",
	},
	[7] = {
		full_name = "重庆市",
		name = "重庆",
	},
	[8] = {
		full_name = "江西省",
		name = "江西",
	},
	[9] = {
		full_name = "山东省",
		name = "山东",
	},
	[10] = {
		full_name = "河南省",
		name = "河南",
	},
	[11] = {
		full_name = "湖北省",
		name = "湖北",
	},
	[12] = {
		full_name = "湖南省",
		name = "湖南",
	},
	[13] = {
		full_name = "广东省",
		name = "广东",
	},
	[14] = {
		full_name = "海南省",
		name = "海南",
	},
	[15] = {
		full_name = "山西省",
		name = "山西",
	},
	[16] = {
		full_name = "青海省",
		name = "青海",
	},
	[17] = {
		full_name = "江苏省",
		name = "江苏",
	},
	[18] = {
		full_name = "辽宁省",
		name = "辽宁",
	},
	[19] = {
		full_name = "吉林省",
		name = "吉林",
	},
	[20] = {
		full_name = "台湾省",
		name = "台湾",
	},
	[21] = {
		full_name = "河北省",
		name = "河北",
	},
	[22] = {
		full_name = "贵州省",
		name = "贵州",
	},
	[23] = {
		full_name = "四川省",
		name = "四川",
	},
	[24] = {
		full_name = "云南省",
		name = "云南",
	},
	[25] = {
		full_name = "陕西省",
		name = "陕西",
	},
	[26] = {
		full_name = "甘肃省",
		name = "甘肃",
	},
	[27] = {
		full_name = "黑龙江省",
		name = "黑龙江",
	},
	[28] = {
		full_name = "香港特别行政区",
		name = "香港",
	},
	[29] = {
		full_name = "澳门特别行政区",
		name = "澳门",
	},
	[30] = {
		full_name = "广西壮族自治区",
		name = "广西",
	},
	[31] = {
		full_name = "宁夏回族自治区",
		name = "宁夏",
	},
	[32] = {
		full_name = "新疆维吾尔自治区",
		name = "新疆",
	},
	[33] = {
		full_name = "内蒙古自治区",
		name = "内蒙古",
	},
	[34] = {
		full_name = "西藏自治区",
		name = "西藏",
	},
}
