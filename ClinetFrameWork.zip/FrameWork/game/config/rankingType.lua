-- type                             string                           类型
-- id                               int                              序号
-- comment                          string                           描述

return {
	["BEG"] = {
		id = 0,
		comment = "开始",
	},
	["WEIGHT"] = {
		id = 1,
		comment = "重量",
	},
	["DEVOUR"] = {
		id = 2,
		comment = "吞噬数",
	},
	["LIFE_TIME"] = {
		id = 3,
		comment = "存活时间",
	},
	["END"] = {
		id = 4,
		comment = "结束",
	},
}
