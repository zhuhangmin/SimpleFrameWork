-- id                               int                              序号
-- FPS                              int                              游戏帧数
-- MAX_LINE_PHOTO_COUNT             int                              每行显示照片数
-- DOWNLOAD_PHOTO_SIZE              int                              上传下载照片的尺寸（要修改需先去平台修改上传照片的尺寸配置)
-- MAX_NAME_LENGTH                  int                              名字最大长度（平台目前要求名字使用平台名称，游戏不得自行修改）
-- MAX_BARRAGE_LENGTH               int                              留言的最大长度
-- MAX_DECLARATION_LENGTH           int                              宣言的最大长度
-- INIT_RANK_SCORE                  int                              初始匹配积分
-- RANK_SCORE_MIN                   int                              匹配积分下限
-- RANK_SCORE_MAX                   int                              匹配积分上限
-- MATCH_CANCLE_TIME                int                              取消匹配时间(毫秒)
-- INIT_VIEW_WIDTH                  int                              默认视野宽度
-- INIT_VIEW_HEIGHT                 int                              默认视野高度
-- STAR_ITEM_ID                     int                              星星道具ID
-- DIAMOND_ITEM_ID                  int                              钻石道具ID
-- LOLLIPOP_ITEM_ID                 int                              棒棒糖道具ID
-- CULTURE_LIMIT                    int                              培养液上限
-- STAR_ITEM_NAME                   string                           星星道具名称
-- DIAMOND_ITEM_NAME                string                           钻石道具名称
-- LOLLIPOP_ITEM_NAME               string                           棒棒糖道具名称
-- STAR_ITEM_DES                    string                           星星道具描述
-- DIAMOND_ITEM_DES                 string                           钻石道具描述
-- LOLLIPOP_ITEM_DES                string                           棒棒糖道具描述
-- STAR_ITEM_GET                    string                           星星道具获取途径
-- DIAMOND_ITEM_GET                 string                           钻石道具获取途径
-- LOLLIPOP_ITEM_GET                string                           棒棒糖道具获取途径
-- TEAM_ADD_TIME_MIN                int                              团队匹配增加人数最小时间(帧)
-- TEAM_ADD_TIME_MAX                int                              团队匹配增加人数最大时间(帧)
-- AD_TO_LOTTERY_NUM                int                              几次广告得到一次抽奖
-- MAX_LOTTERY_NUM                  int                              积累最大广告抽奖次数

return {
	[1] = {
		FPS = 60,
		MAX_LINE_PHOTO_COUNT = 5,
		DOWNLOAD_PHOTO_SIZE = 400,
		MAX_NAME_LENGTH = 8,
		MAX_BARRAGE_LENGTH = 7,
		MAX_DECLARATION_LENGTH = 20,
		INIT_RANK_SCORE = 1,
		RANK_SCORE_MIN = 1,
		RANK_SCORE_MAX = 9999,
		MATCH_CANCLE_TIME = 5000,
		INIT_VIEW_WIDTH = 1136,
		INIT_VIEW_HEIGHT = 640,
		STAR_ITEM_ID = 1000000,
		DIAMOND_ITEM_ID = 2000000,
		LOLLIPOP_ITEM_ID = 3000000,
		CULTURE_LIMIT = 4,
		STAR_ITEM_NAME = "星星",
		DIAMOND_ITEM_NAME = "钻石",
		LOLLIPOP_ITEM_NAME = "棒棒糖",
		STAR_ITEM_DES = "最基础的货币，可以用于商城购买、星星扭蛋、萌菌的合成和进化",
		DIAMOND_ITEM_DES = "最稀有的货币，可以用于商城购买和钻石扭蛋",
		LOLLIPOP_ITEM_DES = "高级的货币，目前作用未知",
		STAR_ITEM_GET = "培养液、扭蛋、钻石兑换",
		DIAMOND_ITEM_GET = "充值",
		LOLLIPOP_ITEM_GET = "赛季结算、活动礼包",
		TEAM_ADD_TIME_MIN = 12,
		TEAM_ADD_TIME_MAX = 108,
		AD_TO_LOTTERY_NUM = 1,
		MAX_LOTTERY_NUM = 10,
	},
}
