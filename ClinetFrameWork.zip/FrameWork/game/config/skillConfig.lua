-- id                               int                              序号
-- des                              string                           描述
-- target                           string                           技能目标
-- condition                        string                           技能的施放条件
-- consume_score                    int                              消耗积分
-- cd                               int                              技能冷却时间(毫秒)
-- target_state                     int                              目标增加状态编号
-- target_state_time                int                              目标状态持续时间(毫秒)
-- own_state                        int                              自身增加状态编号
-- own_state_time                   int                              自身状态持续时间(毫秒)
-- target_script                    string                           对象相关使用的脚本
-- own_script                       string                           自身增加的脚本

return {
	[1] = {
		des = "主动分裂",
		target = "SELF",
		condition = "CON1",
		consume_score = 0,
		cd = 0,
		target_state = 0,
		target_state_time = 0,
		own_state = 0,
		own_state_time = 0,
		target_script = "divide_target",
		own_script = "divide_self",
	},
	[2] = {
		des = "吐出养分",
		target = "SELF",
		condition = "CON2",
		consume_score = 17,
		cd = 50,
		target_state = 0,
		target_state_time = 0,
		own_state = 0,
		own_state_time = 0,
		target_script = "spit_target",
		own_script = "spit_self",
	},
	[3] = {
		des = "草球分裂",
		target = "ENEMY",
		condition = "CON3",
		consume_score = 0,
		cd = 0,
		target_state = 0,
		target_state_time = 0,
		own_state = 0,
		own_state_time = 0,
		target_script = "grass_target",
		own_script = "grass_self",
	},
}
