-- type                             string                           说明
-- id                               int                              引导类型
-- comment                          string                           描述

return {
	["BEG"] = {
		id = 0,
		comment = "开始",
	},
	["STRONG"] = {
		id = 1,
		comment = "强引导",
	},
	["WEAK"] = {
		id = 2,
		comment = "弱引导",
	},
	["END"] = {
		id = 3,
		comment = "结束",
	},
}
