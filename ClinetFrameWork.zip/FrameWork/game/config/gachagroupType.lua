-- type                             string                           类型
-- id                               int                              序号
-- comment                          string                           奖励池内容

return {
	["BEG"] = {
		id = 0,
		comment = "开始",
	},
	["STAR"] = {
		id = 1,
		comment = "星星单抽",
	},
	["DIAMOND"] = {
		id = 2,
		comment = "钻石单抽",
	},
	["FIVE_DIAMOND"] = {
		id = 3,
		comment = "钻石五连抽",
	},
	["END"] = {
		id = 4,
		comment = "结束",
	},
}
