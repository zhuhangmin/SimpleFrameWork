-- id                               int                              道具
-- gift_id                          int                              固定奖励礼包
-- gift_id1                         int                              随机奖励1
-- gift_id2                         int                              随机奖励2
-- gift_id3                         int                              随机奖励3
-- gift_id4                         int                              随机奖励4
-- gift_id5                         int                              随机奖励5
-- gift_id6                         int                              随机奖励6
-- gift_id7                         int                              随机奖励7
-- gift_id8                         int                              随机奖励8
-- gift_id9                         int                              随机奖励9

return {
	[60001] = {
		gift_id = 0,
		gift_id1 = 6101,
		gift_id2 = 6102,
		gift_id3 = 6103,
		gift_id4 = 6104,
		gift_id5 = 0,
		gift_id6 = 0,
		gift_id7 = 0,
		gift_id8 = 0,
		gift_id9 = 0,
	},
	[60002] = {
		gift_id = 0,
		gift_id1 = 6201,
		gift_id2 = 6202,
		gift_id3 = 6203,
		gift_id4 = 6204,
		gift_id5 = 6205,
		gift_id6 = 0,
		gift_id7 = 0,
		gift_id8 = 0,
		gift_id9 = 0,
	},
	[60003] = {
		gift_id = 0,
		gift_id1 = 6301,
		gift_id2 = 6302,
		gift_id3 = 6303,
		gift_id4 = 6304,
		gift_id5 = 6305,
		gift_id6 = 6306,
		gift_id7 = 0,
		gift_id8 = 0,
		gift_id9 = 0,
	},
	[60004] = {
		gift_id = 0,
		gift_id1 = 6401,
		gift_id2 = 6402,
		gift_id3 = 6403,
		gift_id4 = 6404,
		gift_id5 = 6405,
		gift_id6 = 6406,
		gift_id7 = 6407,
		gift_id8 = 0,
		gift_id9 = 0,
	},
}
