-- id                               int                              商店编号
-- comment                          string                           描述
-- shop_item_1                      int                              商品1
-- shop_item_2                      int                              商品2
-- shop_item_3                      int                              商品3
-- shop_item_4                      int                              商品4
-- shop_item_5                      int                              商品5
-- shop_item_6                      int                              商品6
-- shop_item_7                      int                              商品7
-- shop_item_8                      int                              商品8
-- shop_item_9                      int                              商品9
-- shop_item_10                     int                              商品10
-- shop_item_11                     int                              商品11
-- shop_item_12                     int                              商品12
-- shop_item_13                     int                              商品13
-- shop_item_14                     int                              商品14
-- shop_item_15                     int                              商品15
-- shop_item_16                     int                              商品16
-- shop_item_17                     int                              商品17
-- shop_item_18                     int                              商品18
-- shop_item_19                     int                              商品19
-- shop_item_20                     int                              商品20

return {
	[1] = {
		comment = "主界面商店",
		shop_item_1 = 12,
		shop_item_2 = 22,
		shop_item_3 = 19,
		shop_item_4 = 31,
		shop_item_5 = 34,
		shop_item_6 = 37,
		shop_item_7 = 43,
		shop_item_8 = 52,
		shop_item_9 = 54,
		shop_item_10 = 1,
		shop_item_11 = 2,
		shop_item_12 = 5,
		shop_item_13 = 0,
		shop_item_14 = 0,
		shop_item_15 = 0,
		shop_item_16 = 0,
		shop_item_17 = 0,
		shop_item_18 = 0,
		shop_item_19 = 0,
		shop_item_20 = 0,
	},
}
