-- id                               int                              ID
-- diamond                          int                              消耗钻石
-- star                             int                              获得星星

return {
	[1] = {
		diamond = 50,
		star = 1800,
	},
	[2] = {
		diamond = 80,
		star = 3200,
	},
	[3] = {
		diamond = 160,
		star = 7500,
	},
	[4] = {
		diamond = 250,
		star = 12800,
	},
	[5] = {
		diamond = 500,
		star = 27500,
	},
	[6] = {
		diamond = 800,
		star = 48000,
	},
}
