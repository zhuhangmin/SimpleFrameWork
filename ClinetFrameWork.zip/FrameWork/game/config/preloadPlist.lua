return {
"res/Plist_1.plist",
"res/Plist_2.plist",
"res/Plist_3.plist",
"res/Plist_4.plist",
"res/Plist_5.plist",
"res/Plist_6.plist",
"res/share.plist",
"res/ball_icon0.plist",
"res/ball_icon1.plist",
"res/ball_icon2.plist",
}
