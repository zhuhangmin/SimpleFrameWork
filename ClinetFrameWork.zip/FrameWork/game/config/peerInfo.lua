-- id                               int                              序号
-- date                             string                           名称
-- skinid                           int                              皮肤

return {
	[1] = {
		date = "青蒙草",
		skinid = 30101,
	},
	[2] = {
		date = "海洋球",
		skinid = 30104,
	},
	[3] = {
		date = "粉玫瑰",
		skinid = 30107,
	},
	[4] = {
		date = "金桔桔",
		skinid = 30108,
	},
	[5] = {
		date = "石榴红",
		skinid = 30201,
	},
	[6] = {
		date = "熏衣紫",
		skinid = 30202,
	},
	[7] = {
		date = "独眼黄",
		skinid = 30401,
	},
	[8] = {
		date = "独眼红",
		skinid = 30402,
	},
}
