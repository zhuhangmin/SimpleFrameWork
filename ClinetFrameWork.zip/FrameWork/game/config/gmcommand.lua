-- paraNum 为参数个数
return {
	["@diamond"] = {
		paraNum = 2, --加钻石 @diamond,num
	},
	["@star"] = {
		paraNum = 2, --加星星 @star,num
	},
	["@lollipop"] = {
		paraNum = 2, --加棒棒糖 @lollipop,num
	},	
	["@item"] = {
		paraNum = 3, --加道具 @item,id,num
	},
	["@mail"] = {
		paraNum = 2, --发邮件 @mail,type
	},
	["@signnew"] = {
		paraNum = 2, --新人签到 @signnew,20180420
	},
	["@signacc"] = {
		paraNum = 2, --累计签到 @signacc,20180420
	},
	["@seasonmail"] = {
		paraNum = 2, --赛季 @seasonmail,1
	},
	["@score"] = {
		paraNum = 2, --积分 @score,100
	},	
}