-- type                             string                           购买类型
-- id                               int                              序号
-- comment                          string                           描述

return {
	["BEG"] = {
		id = 0,
		comment = "开始",
	},
	["UNABLE"] = {
		id = 1,
		comment = "不能购买",
	},
	["DIAMOND"] = {
		id = 2,
		comment = "钻石购买",
	},
	["STAR"] = {
		id = 3,
		comment = "星星购买",
	},
	["END"] = {
		id = 4,
		comment = "结束",
	},
}
