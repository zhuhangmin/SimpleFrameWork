-- id                               int                              ID
-- order                            int                              充值序号
-- diamond                          int                              发放钻石
-- extra                            int                              额外奖励
-- first                            int                              首充奖励
-- exchangeid                       int                              充值ID

return {
	[1] = {
		order = 1,
		diamond = 100,
		extra = 15,
		first = 85,
		exchangeid = 2242,
	},
	[2] = {
		order = 2,
		diamond = 250,
		extra = 45,
		first = 205,
		exchangeid = 2243,
	},
	[3] = {
		order = 3,
		diamond = 680,
		extra = 136,
		first = 544,
		exchangeid = 2244,
	},
	[4] = {
		order = 4,
		diamond = 1080,
		extra = 270,
		first = 810,
		exchangeid = 2245,
	},
	[5] = {
		order = 5,
		diamond = 2880,
		extra = 720,
		first = 2160,
		exchangeid = 2246,
	},
	[6] = {
		order = 6,
		diamond = 6480,
		extra = 1620,
		first = 4860,
		exchangeid = 2247,
	},
}
