-- id                               int                              新手签到天数
-- type                             int                              礼包ID

return {
	[1] = {
		type = 4,
	},
	[2] = {
		type = 5,
	},
	[3] = {
		type = 6,
	},
	[4] = {
		type = 7,
	},
	[5] = {
		type = 8,
	},
	[6] = {
		type = 9,
	},
	[7] = {
		type = 10,
	},
}
