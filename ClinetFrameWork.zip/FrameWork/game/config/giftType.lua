-- type                             string                           说明
-- id                               int                              礼包类型
-- player_use_limit                 int                              同一玩家使用次数
-- comment                          string                           描述

return {
	["BEG"] = {
		id = 0,
		player_use_limit = 0,
		comment = "开始",
	},
	["QQ"] = {
		id = 1,
		player_use_limit = 1,
		comment = "QQ群礼包",
	},
	["APPOINTMENT1"] = {
		id = 2,
		player_use_limit = 1,
		comment = "渠道预约1",
	},
	["FEEDBACK"] = {
		id = 3,
		player_use_limit = 9999,
		comment = "反馈礼包",
	},
	["END"] = {
		id = 4,
		player_use_limit = 0,
		comment = "结束",
	},
}
