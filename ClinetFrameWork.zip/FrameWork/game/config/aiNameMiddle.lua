-- id                               int                              中名序号
-- middle_name                      string                           中名

return {
	[1] = {
		middle_name = "的",
	},
	[2] = {
		middle_name = "の",
	},
	[3] = {
		middle_name = "之",
	},
	[4] = {
		middle_name = "滴",
	},
	[5] = {
		middle_name = "丶",
	},
	[6] = {
		middle_name = "哒",
	},
	[7] = {
		middle_name = "丨",
	},
	[8] = {
		middle_name = "丿",
	},
	[9] = {
		middle_name = "灬",
	},
	[10] = {
		middle_name = "阝",
	},
	[11] = {
		middle_name = "乀",
	},
	[12] = {
		middle_name = "de",
	},
	[13] = {
		middle_name = "く",
	},
	[14] = {
		middle_name = "つ",
	},
	[15] = {
		middle_name = "へ",
	},
	[16] = {
		middle_name = "し",
	},
	[17] = {
		middle_name = "ぃ",
	},
}
