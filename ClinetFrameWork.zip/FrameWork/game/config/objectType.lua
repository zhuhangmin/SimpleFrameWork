-- mode                             string                           形容词
-- type                             int                              序号
-- comment                          string                           描述

return {
	["BEG"] = {
		type = 0,
		comment = "开始",
	},
	["OWN_ALL"] = {
		type = 1,
		comment = "自己所有的球",
	},
	["OWN_WEIGHT_BEST"] = {
		type = 2,
		comment = "自己质量最大的一个球",
	},
	["OWN_RANDOM_ONE"] = {
		type = 3,
		comment = "自己随机的一个球",
	},
	["ENEMY_RANGE_1000"] = {
		type = 4,
		comment = "以自身屏幕中心点范围1000内的敌人",
	},
	["ENEMY_NEAR_DISTANCE_ONE"] = {
		type = 5,
		comment = "距离自身屏幕中心点最近的敌人单球",
	},
	["ENEMY_NEAR_DISTANCE_ALL"] = {
		type = 6,
		comment = "距离自身屏幕中心点最近的敌人全部球",
	},
	["BULLET"] = {
		type = 7,
		comment = "子弹",
	},
	["LASER"] = {
		type = 8,
		comment = "激光",
	},
	["END"] = {
		type = 9,
		comment = "结束",
	},
}
