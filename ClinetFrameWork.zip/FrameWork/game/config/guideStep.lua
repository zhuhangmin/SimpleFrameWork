-- id                               int                              引导步骤编号
-- guideType                        string                           引导类型
-- layerName                        string                           引导触发层
-- widgetName                       string                           引导按钮名
-- message                          string                           引导对话
-- pencent_posx                     float                            横坐标位置百分比
-- pencent_posy                     float                            纵坐标位置百分比

return {
	[1] = {
		guideType = "STRONG",
		layerName = "game.Home",
		widgetName = "Button_start",
		message = "点击快速开始，开始战斗吧！",
		pencent_posx = 0.3,
		pencent_posy = 0.3,
	},
}
