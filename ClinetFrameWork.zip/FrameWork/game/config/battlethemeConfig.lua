-- type                             int                              类型
-- comment                          string                           描述
-- topTitleBg                       string                           顶部背景
-- rankBg                           string                           排行榜背景
-- fieldBg                          string                           区域背景
-- vjoyBg                           string                           vjoyBg
-- vjoy                             string                           vjoy
-- jetNormalBg                      string                           jetNormalBg
-- jetPressBg                       string                           jetPressBg
-- divideNormalBg                   string                           divideNormalBg
-- dividePressBg                    string                           dividePressBg
-- shadow                           string                           阴影
-- setNormalBg                      string                           设置
-- setPressBg                       string                           设置
-- returnNormalBg                   string                           返回
-- returnPressBg                    string                           返回
-- ExpressionOpen                   string                           表情
-- ExpressionClose                  string                           表情
-- grass                            string                           草丛
-- Spore                            string                           孢子

return {
	[1] = {
		comment = "紫色背景",
		topTitleBg = "zd_new/zd_bg_tz_zi.png",
		rankBg = "zd_new/zd_bg_ph_zi.png",
		fieldBg = "zd_new/zd_bg_zi.png",
		vjoyBg = "zd_new/zd_bg_vjoy.png",
		vjoy = "zd_new/zd_up_vjoy_zi.png",
		jetNormalBg = "zd_new/zd_jet_zi1.png",
		jetPressBg = "zd_new/zd_jet_zi2.png",
		divideNormalBg = "zd_new/zd_divide_zi1.png",
		dividePressBg = "zd_new/zd_divide_zi2.png",
		shadow = "zd_new/bg_zhezhao_zi.png",
		setNormalBg = "zd_new/zd_sz_zi1.png",
		setPressBg = "zd_new/zd_sz_zi2.png",
		returnNormalBg = "zd_new/zd_back_zi_btn1.png",
		returnPressBg = "zd_new/zd_back_zi_btn2.png",
		ExpressionOpen = "zd_new/zd_bq_btn_zi.png",
		ExpressionClose = "zd_new/zd_bq_btn_zi2.png",
		grass = "zd_new/zd_grass2.png",
		Spore = "zd_new/zd_jet_food2.png",
	},
}
