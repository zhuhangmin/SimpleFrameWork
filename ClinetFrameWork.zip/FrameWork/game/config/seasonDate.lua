-- id                               int                              序号
-- date                             string                           日期
-- season                           int                              赛季

return {
	[1] = {
		date = "20180531",
		season = 1,
	},
	[2] = {
		date = "20180630",
		season = 2,
	},
	[3] = {
		date = "20180731",
		season = 3,
	},
	[4] = {
		date = "20180831",
		season = 4,
	},
	[5] = {
		date = "20180930",
		season = 5,
	},
	[6] = {
		date = "20181031",
		season = 6,
	},
	[7] = {
		date = "20181130",
		season = 7,
	},
	[8] = {
		date = "20181231",
		season = 8,
	},
	[9] = {
		date = "20190131",
		season = 9,
	},
	[10] = {
		date = "20190228",
		season = 10,
	},
	[11] = {
		date = "20190331",
		season = 11,
	},
	[12] = {
		date = "20190430",
		season = 12,
	},
}
