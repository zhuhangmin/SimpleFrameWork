-- id                               int                              id
-- comment                          string                           描述
-- type                             string                           类型
-- weight                           int                              初始重量
-- speed                            int                              初始速度
-- absorb                           int                              吸收的范围
-- state                            int                              初始状态
-- skill1                           int                              拥有技能
-- skill2                           int                              拥有技能
-- skill3                           int                              拥有技能
-- live_rule                        string                           生成/销毁规则

return {
	[1] = {
		comment = "初始球体状态",
		type = "BALL",
		weight = 10,
		speed = 0,
		absorb = 500,
		state = 1,
		skill1 = 1,
		skill2 = 2,
		skill3 = 0,
		live_rule = "ball",
	},
	[2] = {
		comment = "基础营养",
		type = "FOOD",
		weight = 1,
		speed = 0,
		absorb = 0,
		state = 2,
		skill1 = 0,
		skill2 = 0,
		skill3 = 0,
		live_rule = "food",
	},
	[3] = {
		comment = "吐出养份",
		type = "JETFOOD",
		weight = 17,
		speed = 3000,
		absorb = 0,
		state = 3,
		skill1 = 0,
		skill2 = 0,
		skill3 = 0,
		live_rule = "jet",
	},
	[4] = {
		comment = "草球1",
		type = "GRASS",
		weight = 60,
		speed = 0,
		absorb = 0,
		state = 2,
		skill1 = 3,
		skill2 = 0,
		skill3 = 0,
		live_rule = "grass",
	},
	[5] = {
		comment = "草球2",
		type = "GRASS",
		weight = 100,
		speed = 0,
		absorb = 0,
		state = 2,
		skill1 = 3,
		skill2 = 0,
		skill3 = 0,
		live_rule = "grass",
	},
	[6] = {
		comment = "草球3",
		type = "GRASS",
		weight = 140,
		speed = 0,
		absorb = 0,
		state = 2,
		skill1 = 3,
		skill2 = 0,
		skill3 = 0,
		live_rule = "grass",
	},
}
