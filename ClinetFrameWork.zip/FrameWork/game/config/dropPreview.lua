-- id                               int                              编号
-- drop_type                        string                           掉落类型
-- drop_item                        int                              掉落物品
-- des                              string                           物品名称

return {
	[1] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 41001,
		des = "中级精华",
	},
	[2] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 1000000,
		des = "金币",
	},
	[3] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 55001,
		des = "营养液",
	},
	[4] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 40003,
		des = "3阶碎片",
	},
	[5] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 40002,
		des = "2阶碎片",
	},
	[6] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 40001,
		des = "1阶碎片",
	},
	[7] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70514,
		des = "舞动福运碎片",
	},
	[8] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70509,
		des = "中华庆典碎片",
	},
	[9] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70515,
		des = "鸡年大吉碎片",
	},
	[10] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70601,
		des = "鸭子侦探碎片",
	},
	[11] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70602,
		des = "棕熊保镖碎片",
	},
	[12] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70605,
		des = "水象喷泉碎片",
	},
	[13] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70606,
		des = "哈士奇碎片",
	},
	[14] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70607,
		des = "黑猫警卫碎片",
	},
	[15] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70402,
		des = "独眼红碎片",
	},
	[16] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70404,
		des = "鲜花饼碎片",
	},
	[17] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70406,
		des = "红衫木碎片",
	},
	[18] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70407,
		des = "黄豆馍碎片",
	},
	[19] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70410,
		des = "保湿雾碎片",
	},
	[20] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70501,
		des = "酷帅墨镜碎片",
	},
	[21] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70503,
		des = "女装大佬碎片",
	},
	[22] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70504,
		des = "运动小子碎片",
	},
	[23] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70505,
		des = "封神星牙碎片",
	},
	[24] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70104,
		des = "海洋球碎片",
	},
	[25] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70107,
		des = "粉玫瑰碎片",
	},
	[26] = {
		drop_type = "JUNIOR_CULTURE",
		drop_item = 70202,
		des = "熏衣紫碎片",
	},
	[27] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 41002,
		des = "高级精华",
	},
	[28] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 1000000,
		des = "金币",
	},
	[29] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 55002,
		des = "陨石",
	},
	[30] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 40003,
		des = "3阶碎片",
	},
	[31] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 40002,
		des = "2阶碎片",
	},
	[32] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 40001,
		des = "1阶碎片",
	},
	[33] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70514,
		des = "舞动福运碎片",
	},
	[34] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70509,
		des = "中华庆典碎片",
	},
	[35] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70515,
		des = "鸡年大吉碎片",
	},
	[36] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70601,
		des = "鸭子侦探碎片",
	},
	[37] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70602,
		des = "棕熊保镖碎片",
	},
	[38] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70605,
		des = "水象喷泉碎片",
	},
	[39] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70606,
		des = "哈士奇碎片",
	},
	[40] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70607,
		des = "黑猫警卫碎片",
	},
	[41] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70402,
		des = "独眼红碎片",
	},
	[42] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70404,
		des = "鲜花饼碎片",
	},
	[43] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70406,
		des = "红衫木碎片",
	},
	[44] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70407,
		des = "黄豆馍碎片",
	},
	[45] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70410,
		des = "保湿雾碎片",
	},
	[46] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70501,
		des = "酷帅墨镜碎片",
	},
	[47] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70503,
		des = "女装大佬碎片",
	},
	[48] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70504,
		des = "运动小子碎片",
	},
	[49] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70505,
		des = "封神星牙碎片",
	},
	[50] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70104,
		des = "海洋球碎片",
	},
	[51] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70107,
		des = "粉玫瑰碎片",
	},
	[52] = {
		drop_type = "MEDIUM_CULTURE",
		drop_item = 70202,
		des = "熏衣紫碎片",
	},
	[53] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 41003,
		des = "特级精华",
	},
	[54] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 1000000,
		des = "金币",
	},
	[55] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 55003,
		des = "晶石",
	},
	[56] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 55002,
		des = "陨石",
	},
	[57] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 40004,
		des = "4阶碎片",
	},
	[58] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 40003,
		des = "3阶碎片",
	},
	[59] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 40002,
		des = "2阶碎片",
	},
	[60] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 30402,
		des = "独眼红",
	},
	[61] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 30404,
		des = "鲜花饼",
	},
	[62] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 30406,
		des = "红衫木",
	},
	[63] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 30407,
		des = "黄豆馍",
	},
	[64] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 30410,
		des = "保湿雾",
	},
	[65] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 30501,
		des = "酷帅墨镜",
	},
	[66] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 30503,
		des = "女装大佬",
	},
	[67] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 30504,
		des = "运动小子",
	},
	[68] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 30505,
		des = "封神星牙",
	},
	[69] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 30104,
		des = "海洋球",
	},
	[70] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 30107,
		des = "粉玫瑰",
	},
	[71] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 30202,
		des = "熏衣紫",
	},
	[72] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70611,
		des = "火鸡碎片",
	},
	[73] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70612,
		des = "雪人碎片",
	},
	[74] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70703,
		des = "靓饺包碎片",
	},
	[75] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70514,
		des = "舞动福运碎片",
	},
	[76] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70509,
		des = "中华庆典碎片",
	},
	[77] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70515,
		des = "鸡年大吉碎片",
	},
	[78] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70601,
		des = "鸭子侦探碎片",
	},
	[79] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70602,
		des = "棕熊保镖碎片",
	},
	[80] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70605,
		des = "水象喷泉碎片",
	},
	[81] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70606,
		des = "哈士奇碎片",
	},
	[82] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70607,
		des = "黑猫警卫碎片",
	},
	[83] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70402,
		des = "独眼红碎片",
	},
	[84] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70404,
		des = "鲜花饼碎片",
	},
	[85] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70406,
		des = "红衫木碎片",
	},
	[86] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70407,
		des = "黄豆馍碎片",
	},
	[87] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70410,
		des = "保湿雾碎片",
	},
	[88] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70501,
		des = "酷帅墨镜碎片",
	},
	[89] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70503,
		des = "女装大佬碎片",
	},
	[90] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70504,
		des = "运动小子碎片",
	},
	[91] = {
		drop_type = "SENIOR_CULTURE",
		drop_item = 70505,
		des = "封神星牙碎片",
	},
	[92] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 1000000,
		des = "金币",
	},
	[93] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 55004,
		des = "琥珀",
	},
	[94] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 55003,
		des = "晶石",
	},
	[95] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 40004,
		des = "4阶碎片",
	},
	[96] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 40003,
		des = "3阶碎片",
	},
	[97] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30514,
		des = "舞动福运",
	},
	[98] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30509,
		des = "中华庆典",
	},
	[99] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30515,
		des = "鸡年大吉",
	},
	[100] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30601,
		des = "鸭子侦探",
	},
	[101] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30602,
		des = "棕熊保镖",
	},
	[102] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30605,
		des = "水象喷泉",
	},
	[103] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30606,
		des = "哈士奇",
	},
	[104] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30607,
		des = "黑猫警卫",
	},
	[105] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30402,
		des = "独眼红",
	},
	[106] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30404,
		des = "鲜花饼",
	},
	[107] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30406,
		des = "红衫木",
	},
	[108] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30407,
		des = "黄豆馍",
	},
	[109] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30410,
		des = "保湿雾",
	},
	[110] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30501,
		des = "酷帅墨镜",
	},
	[111] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30503,
		des = "女装大佬",
	},
	[112] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30504,
		des = "运动小子",
	},
	[113] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30505,
		des = "封神星牙",
	},
	[114] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30104,
		des = "海洋球",
	},
	[115] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30107,
		des = "粉玫瑰",
	},
	[116] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 30202,
		des = "熏衣紫",
	},
	[117] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 70611,
		des = "火鸡碎片",
	},
	[118] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 70612,
		des = "雪人碎片",
	},
	[119] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 70703,
		des = "靓饺包碎片",
	},
	[120] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 70514,
		des = "舞动福运碎片",
	},
	[121] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 70509,
		des = "中华庆典碎片",
	},
	[122] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 70515,
		des = "鸡年大吉碎片",
	},
	[123] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 70601,
		des = "鸭子侦探碎片",
	},
	[124] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 70602,
		des = "棕熊保镖碎片",
	},
	[125] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 70605,
		des = "水象喷泉碎片",
	},
	[126] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 70606,
		des = "哈士奇碎片",
	},
	[127] = {
		drop_type = "SUPER_CULTURE",
		drop_item = 70607,
		des = "黑猫警卫碎片",
	},
	[128] = {
		drop_type = "STAR_GACHA",
		drop_item = 30101,
		des = "青蒙草",
	},
	[129] = {
		drop_type = "STAR_GACHA",
		drop_item = 30104,
		des = "海洋球",
	},
	[130] = {
		drop_type = "STAR_GACHA",
		drop_item = 30107,
		des = "粉玫瑰",
	},
	[131] = {
		drop_type = "STAR_GACHA",
		drop_item = 30201,
		des = "石榴红",
	},
	[132] = {
		drop_type = "STAR_GACHA",
		drop_item = 30202,
		des = "熏衣紫",
	},
	[133] = {
		drop_type = "STAR_GACHA",
		drop_item = 70402,
		des = "独眼红碎片",
	},
	[134] = {
		drop_type = "STAR_GACHA",
		drop_item = 70404,
		des = "鲜花饼碎片",
	},
	[135] = {
		drop_type = "STAR_GACHA",
		drop_item = 70406,
		des = "红衫木碎片",
	},
	[136] = {
		drop_type = "STAR_GACHA",
		drop_item = 70407,
		des = "黄豆馍碎片",
	},
	[137] = {
		drop_type = "STAR_GACHA",
		drop_item = 70410,
		des = "保湿雾碎片",
	},
	[138] = {
		drop_type = "STAR_GACHA",
		drop_item = 70501,
		des = "酷帅墨镜碎片",
	},
	[139] = {
		drop_type = "STAR_GACHA",
		drop_item = 70503,
		des = "女装大佬碎片",
	},
	[140] = {
		drop_type = "STAR_GACHA",
		drop_item = 70504,
		des = "运动小子碎片",
	},
	[141] = {
		drop_type = "STAR_GACHA",
		drop_item = 70505,
		des = "封神星牙碎片",
	},
	[142] = {
		drop_type = "STAR_GACHA",
		drop_item = 70104,
		des = "海洋球碎片",
	},
	[143] = {
		drop_type = "STAR_GACHA",
		drop_item = 70107,
		des = "粉玫瑰碎片",
	},
	[144] = {
		drop_type = "STAR_GACHA",
		drop_item = 70202,
		des = "熏衣紫碎片",
	},
	[145] = {
		drop_type = "STAR_GACHA",
		drop_item = 40001,
		des = "1阶碎片",
	},
	[146] = {
		drop_type = "STAR_GACHA",
		drop_item = 40002,
		des = "2阶碎片",
	},
	[147] = {
		drop_type = "STAR_GACHA",
		drop_item = 55001,
		des = "营养液",
	},
	[148] = {
		drop_type = "STAR_GACHA",
		drop_item = 55002,
		des = "陨石",
	},
	[149] = {
		drop_type = "STAR_GACHA",
		drop_item = 1000000,
		des = "金币",
	},
	[150] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30507,
		des = "中华龙",
	},
	[151] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30509,
		des = "中华庆典",
	},
	[152] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30510,
		des = "中秋月兔",
	},
	[153] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30514,
		des = "舞动福运",
	},
	[154] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30515,
		des = "鸡年大吉",
	},
	[155] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30601,
		des = "鸭子侦探",
	},
	[156] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30602,
		des = "棕熊保镖",
	},
	[157] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30603,
		des = "吉祥牛牛",
	},
	[158] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30605,
		des = "水象喷泉",
	},
	[159] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30606,
		des = "哈士奇",
	},
	[160] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30607,
		des = "黑猫警卫",
	},
	[161] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30608,
		des = "羊驼",
	},
	[162] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30609,
		des = "仓鼠",
	},
	[163] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30401,
		des = "独眼黄",
	},
	[164] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30402,
		des = "独眼红",
	},
	[165] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30403,
		des = "青花瓷",
	},
	[166] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30404,
		des = "鲜花饼",
	},
	[167] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30406,
		des = "红衫木",
	},
	[168] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30407,
		des = "黄豆馍",
	},
	[169] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30409,
		des = "苏打水",
	},
	[170] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30410,
		des = "保湿雾",
	},
	[171] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30501,
		des = "酷帅墨镜",
	},
	[172] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30502,
		des = "时空裂缝",
	},
	[173] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30503,
		des = "女装大佬",
	},
	[174] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30504,
		des = "运动小子",
	},
	[175] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30505,
		des = "封神星牙",
	},
	[176] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30506,
		des = "封神风将",
	},
	[177] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 30513,
		des = "恭喜发财",
	},
	[178] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70514,
		des = "舞动福运碎片",
	},
	[179] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70509,
		des = "中华庆典碎片",
	},
	[180] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70515,
		des = "鸡年大吉碎片",
	},
	[181] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70601,
		des = "鸭子侦探碎片",
	},
	[182] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70602,
		des = "棕熊保镖碎片",
	},
	[183] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70605,
		des = "水象喷泉碎片",
	},
	[184] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70606,
		des = "哈士奇碎片",
	},
	[185] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70607,
		des = "黑猫警卫碎片",
	},
	[186] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70402,
		des = "独眼红碎片",
	},
	[187] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70404,
		des = "鲜花饼碎片",
	},
	[188] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70406,
		des = "红衫木碎片",
	},
	[189] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70407,
		des = "黄豆馍碎片",
	},
	[190] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70410,
		des = "保湿雾碎片",
	},
	[191] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70501,
		des = "酷帅墨镜碎片",
	},
	[192] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70503,
		des = "女装大佬碎片",
	},
	[193] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70504,
		des = "运动小子碎片",
	},
	[194] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70505,
		des = "封神星牙碎片",
	},
	[195] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70104,
		des = "海洋球碎片",
	},
	[196] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70107,
		des = "粉玫瑰碎片",
	},
	[197] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 70202,
		des = "熏衣紫碎片",
	},
	[198] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 40001,
		des = "1阶碎片",
	},
	[199] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 40002,
		des = "2阶碎片",
	},
	[200] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 40003,
		des = "3阶碎片",
	},
	[201] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 55001,
		des = "营养液",
	},
	[202] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 55002,
		des = "陨石",
	},
	[203] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 55003,
		des = "晶石",
	},
	[204] = {
		drop_type = "DIAMOND_GACHA",
		drop_item = 1000000,
		des = "金币",
	},
	[205] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30610,
		des = "圣诞老人",
	},
	[206] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30611,
		des = "火鸡",
	},
	[207] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30612,
		des = "雪人",
	},
	[208] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30613,
		des = "驯鹿",
	},
	[209] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30702,
		des = "君饺包",
	},
	[210] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30703,
		des = "靓饺包",
	},
	[211] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30704,
		des = "天狗炎日",
	},
	[212] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30507,
		des = "中华龙",
	},
	[213] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30509,
		des = "中华庆典",
	},
	[214] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30510,
		des = "中秋月兔",
	},
	[215] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30514,
		des = "舞动福运",
	},
	[216] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30515,
		des = "鸡年大吉",
	},
	[217] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30601,
		des = "鸭子侦探",
	},
	[218] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30602,
		des = "棕熊保镖",
	},
	[219] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30603,
		des = "吉祥牛牛",
	},
	[220] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30605,
		des = "水象喷泉",
	},
	[221] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30606,
		des = "哈士奇",
	},
	[222] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30607,
		des = "黑猫警卫",
	},
	[223] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30608,
		des = "羊驼",
	},
	[224] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30609,
		des = "仓鼠",
	},
	[225] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30401,
		des = "独眼黄",
	},
	[226] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30402,
		des = "独眼红",
	},
	[227] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30403,
		des = "青花瓷",
	},
	[228] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30404,
		des = "鲜花饼",
	},
	[229] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30406,
		des = "红衫木",
	},
	[230] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30407,
		des = "黄豆馍",
	},
	[231] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30409,
		des = "苏打水",
	},
	[232] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30410,
		des = "保湿雾",
	},
	[233] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30501,
		des = "酷帅墨镜",
	},
	[234] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30502,
		des = "时空裂缝",
	},
	[235] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30503,
		des = "女装大佬",
	},
	[236] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30504,
		des = "运动小子",
	},
	[237] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30505,
		des = "封神星牙",
	},
	[238] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30506,
		des = "封神风将",
	},
	[239] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 30513,
		des = "恭喜发财",
	},
	[240] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70611,
		des = "火鸡碎片",
	},
	[241] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70612,
		des = "雪人碎片",
	},
	[242] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70703,
		des = "靓饺包碎片",
	},
	[243] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70514,
		des = "舞动福运碎片",
	},
	[244] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70509,
		des = "中华庆典碎片",
	},
	[245] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70515,
		des = "鸡年大吉碎片",
	},
	[246] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70601,
		des = "鸭子侦探碎片",
	},
	[247] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70602,
		des = "棕熊保镖碎片",
	},
	[248] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70605,
		des = "水象喷泉碎片",
	},
	[249] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70606,
		des = "哈士奇碎片",
	},
	[250] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70607,
		des = "黑猫警卫碎片",
	},
	[251] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70402,
		des = "独眼红碎片",
	},
	[252] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70404,
		des = "鲜花饼碎片",
	},
	[253] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70406,
		des = "红衫木碎片",
	},
	[254] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70407,
		des = "黄豆馍碎片",
	},
	[255] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70410,
		des = "保湿雾碎片",
	},
	[256] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70501,
		des = "酷帅墨镜碎片",
	},
	[257] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70503,
		des = "女装大佬碎片",
	},
	[258] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70504,
		des = "运动小子碎片",
	},
	[259] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 70505,
		des = "封神星牙碎片",
	},
	[260] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 40002,
		des = "2阶碎片",
	},
	[261] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 40003,
		des = "3阶碎片",
	},
	[262] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 40004,
		des = "4阶碎片",
	},
	[263] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 55002,
		des = "陨石",
	},
	[264] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 55003,
		des = "晶石",
	},
	[265] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 55004,
		des = "琥珀",
	},
	[266] = {
		drop_type = "FIVE_D_GACHA",
		drop_item = 1000000,
		des = "金币",
	},
}
