-- type                             string                           形容词
-- id                               int                              序号
-- is_control                       int                              是否玩家控制
-- comment                          string                           描述

return {
	["BEG"] = {
		id = 0,
		is_control = 0,
		comment = "开始",
	},
	["BALL"] = {
		id = 1,
		is_control = 1,
		comment = "玩家球体",
	},
	["FOOD"] = {
		id = 2,
		is_control = 0,
		comment = "基础营养",
	},
	["JETFOOD"] = {
		id = 3,
		is_control = 0,
		comment = "吐出养分",
	},
	["GRASS"] = {
		id = 4,
		is_control = 0,
		comment = "草球",
	},
	["END"] = {
		id = 5,
		is_control = 0,
		comment = "结束",
	},
}
