-- id                               int                              索引id
-- peer_num                         int                              组队人数
-- open_time                        int                              开始后进入时间限制(s)
-- comment                          string                           描述

return {
	[1] = {
		peer_num = 0,
		open_time = 30,
		comment = "普通模式",
	},
	[2] = {
		peer_num = 5,
		open_time = 30,
		comment = "团战模式",
	},
}
