-- type                             string                           邮件类型
-- id                               int                              枚举
-- comment                          string                           描述

return {
	["BEG"] = {
		id = 0,
		comment = "开始",
	},
	["NEW"] = {
		id = 1,
		comment = "新手玩家邮件",
	},
	["RECHARGE"] = {
		id = 2,
		comment = "充值邮件",
	},
	["SEASON"] = {
		id = 3,
		comment = "赛季结算",
	},
	["UPDATE3"] = {
		id = 4,
		comment = "三号版本更新",
	},
	["UPDATE4"] = {
		id = 5,
		comment = "四号版本更新",
	},
	["END"] = {
		id = 6,
		comment = "结束",
	},
}
