-- type                             int                              类型
-- comment                          string                           描述
-- priority                         int                              优先级
-- b_run                            int                              能否移动
-- b_turn                           int                              能否转向
-- b_use_skill                      int                              能否使用技能
-- b_immune                         int                              能否免疫别人技能
-- b_absorb_nutrient                int                              能否大范围吸收养份
-- absorb                           int                              吸收的范围
-- base                             string                           能否吃基础营养
-- nutrient                         string                           能否吃养份
-- grass                            string                           能否吃草球
-- ownball                          string                           能否吃自己球(融合)
-- enemyball                        string                           能否吃敌方球

return {
	[0] = {
		comment = "标准球状态",
		priority = 1,
		b_run = 1,
		b_turn = 1,
		b_use_skill = 1,
		b_immune = 1,
		b_absorb_nutrient = 0,
		absorb = 0,
		base = "NOEAT",
		nutrient = "RULEEAT",
		grass = "NOEAT",
		ownball = "NOEAT",
		enemyball = "NOEAT",
	},
	[1] = {
		comment = "初始球体状态",
		priority = 20,
		b_run = 1,
		b_turn = 1,
		b_use_skill = 1,
		b_immune = 1,
		b_absorb_nutrient = 1,
		absorb = 500,
		base = "NOEAT",
		nutrient = "RULEEAT",
		grass = "NOEAT",
		ownball = "NOEAT",
		enemyball = "NOEAT",
	},
	[2] = {
		comment = "草球",
		priority = 19,
		b_run = 1,
		b_turn = 1,
		b_use_skill = 1,
		b_immune = 1,
		b_absorb_nutrient = 0,
		absorb = 500,
		base = "EAT",
		nutrient = "NOEAT",
		grass = "EAT",
		ownball = "EAT",
		enemyball = "EAT",
	},
	[3] = {
		comment = "养份",
		priority = 18,
		b_run = 1,
		b_turn = 1,
		b_use_skill = 1,
		b_immune = 1,
		b_absorb_nutrient = 0,
		absorb = 500,
		base = "EAT",
		nutrient = "EAT",
		grass = "EAT",
		ownball = "EAT",
		enemyball = "EAT",
	},
	[4] = {
		comment = "基础营养",
		priority = 17,
		b_run = 1,
		b_turn = 1,
		b_use_skill = 1,
		b_immune = 1,
		b_absorb_nutrient = 0,
		absorb = 500,
		base = "EAT",
		nutrient = "EAT",
		grass = "EAT",
		ownball = "EAT",
		enemyball = "EAT",
	},
}
