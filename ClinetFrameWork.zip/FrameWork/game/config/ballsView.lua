-- id                               int                              序号
-- width                            int                              宽度
-- height                           int                              高度
-- scale                            int                              放大倍数（百分位）

return {
	[1] = {
		width = 1136,
		height = 640,
		scale = 100,
	},
	[2] = {
		width = 1249,
		height = 704,
		scale = 110,
	},
	[3] = {
		width = 1363,
		height = 768,
		scale = 120,
	},
	[4] = {
		width = 1476,
		height = 832,
		scale = 130,
	},
	[5] = {
		width = 1590,
		height = 896,
		scale = 140,
	},
	[6] = {
		width = 1704,
		height = 960,
		scale = 150,
	},
	[7] = {
		width = 1817,
		height = 1024,
		scale = 160,
	},
	[8] = {
		width = 1931,
		height = 1088,
		scale = 170,
	},
	[9] = {
		width = 2044,
		height = 1152,
		scale = 180,
	},
	[10] = {
		width = 2158,
		height = 1216,
		scale = 190,
	},
	[11] = {
		width = 2272,
		height = 1280,
		scale = 200,
	},
	[12] = {
		width = 2385,
		height = 1344,
		scale = 210,
	},
	[13] = {
		width = 2499,
		height = 1408,
		scale = 220,
	},
	[14] = {
		width = 2612,
		height = 1472,
		scale = 230,
	},
	[15] = {
		width = 2726,
		height = 1536,
		scale = 240,
	},
	[16] = {
		width = 2840,
		height = 1600,
		scale = 250,
	},
	[17] = {
		width = 2953,
		height = 1664,
		scale = 260,
	},
	[18] = {
		width = 3067,
		height = 1728,
		scale = 270,
	},
	[19] = {
		width = 3180,
		height = 1792,
		scale = 280,
	},
	[20] = {
		width = 3294,
		height = 1856,
		scale = 290,
	},
	[21] = {
		width = 3408,
		height = 1920,
		scale = 300,
	},
	[22] = {
		width = 3521,
		height = 1984,
		scale = 310,
	},
	[23] = {
		width = 3635,
		height = 2048,
		scale = 320,
	},
	[24] = {
		width = 3748,
		height = 2112,
		scale = 330,
	},
	[25] = {
		width = 3862,
		height = 2176,
		scale = 340,
	},
	[26] = {
		width = 3976,
		height = 2240,
		scale = 350,
	},
	[27] = {
		width = 4089,
		height = 2304,
		scale = 360,
	},
	[28] = {
		width = 4203,
		height = 2368,
		scale = 370,
	},
	[29] = {
		width = 4316,
		height = 2432,
		scale = 380,
	},
	[30] = {
		width = 4430,
		height = 2496,
		scale = 390,
	},
	[31] = {
		width = 4544,
		height = 2560,
		scale = 400,
	},
	[32] = {
		width = 4657,
		height = 2624,
		scale = 410,
	},
	[33] = {
		width = 4771,
		height = 2688,
		scale = 420,
	},
	[34] = {
		width = 4884,
		height = 2752,
		scale = 430,
	},
	[35] = {
		width = 4998,
		height = 2816,
		scale = 440,
	},
}
