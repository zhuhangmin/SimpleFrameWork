-- type                             string                           支付类型
-- id                               int                              序号
-- comment                          string                           描述

return {
	["BEG"] = {
		id = 0,
		comment = "开始",
	},
	["UNABLE"] = {
		id = 1,
		comment = "不能出售",
	},
	["DIAMOND"] = {
		id = 2,
		comment = "钻石出售",
	},
	["STAR"] = {
		id = 3,
		comment = "星星出售",
	},
	["END"] = {
		id = 4,
		comment = "结束",
	},
}
