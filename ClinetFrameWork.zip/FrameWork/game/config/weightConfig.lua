-- id                               int                              序号
-- str                              string                           类型
-- imgName                          string                           图片名称
-- carry                            string                           进位
-- display_carry                    string                           显示进位

return {
	[1] = {
		str = "克",
		imgName = "tongyong/ke.png",
		carry = "1000",
		display_carry = "10000",
	},
	[2] = {
		str = "千克",
		imgName = "tongyong/qianke.png",
		carry = "1000000",
		display_carry = "10000000",
	},
	[3] = {
		str = "吨",
		imgName = "tongyong/dunwei.png",
		carry = "1e+012",
		display_carry = "1e+012",
	},
}
