-- id                               int                              房间ai组合类型
-- AI_type_1                        int                              AI类型1
-- AI_rate_1                        int                              AI概率1
-- AI_type_2                        int                              AI类型2
-- AI_rate_2                        int                              AI概率2
-- AI_type_3                        int                              AI类型3
-- AI_rate_3                        int                              AI概率3
-- AI_type_4                        int                              AI类型4
-- AI_rate_4                        int                              AI概率4

return {
	[1] = {
		AI_type_1 = 1,
		AI_rate_1 = 60,
		AI_type_2 = 18,
		AI_rate_2 = 40,
		AI_type_3 = 0,
		AI_rate_3 = 0,
		AI_type_4 = 0,
		AI_rate_4 = 0,
	},
	[2] = {
		AI_type_1 = 1,
		AI_rate_1 = 50,
		AI_type_2 = 2,
		AI_rate_2 = 20,
		AI_type_3 = 18,
		AI_rate_3 = 30,
		AI_type_4 = 0,
		AI_rate_4 = 0,
	},
	[3] = {
		AI_type_1 = 1,
		AI_rate_1 = 10,
		AI_type_2 = 2,
		AI_rate_2 = 50,
		AI_type_3 = 3,
		AI_rate_3 = 20,
		AI_type_4 = 18,
		AI_rate_4 = 20,
	},
	[4] = {
		AI_type_1 = 2,
		AI_rate_1 = 20,
		AI_type_2 = 3,
		AI_rate_2 = 50,
		AI_type_3 = 4,
		AI_rate_3 = 20,
		AI_type_4 = 18,
		AI_rate_4 = 10,
	},
	[5] = {
		AI_type_1 = 4,
		AI_rate_1 = 20,
		AI_type_2 = 5,
		AI_rate_2 = 50,
		AI_type_3 = 6,
		AI_rate_3 = 30,
		AI_type_4 = 0,
		AI_rate_4 = 0,
	},
	[6] = {
		AI_type_1 = 6,
		AI_rate_1 = 20,
		AI_type_2 = 7,
		AI_rate_2 = 50,
		AI_type_3 = 8,
		AI_rate_3 = 30,
		AI_type_4 = 0,
		AI_rate_4 = 0,
	},
	[7] = {
		AI_type_1 = 8,
		AI_rate_1 = 20,
		AI_type_2 = 9,
		AI_rate_2 = 50,
		AI_type_3 = 10,
		AI_rate_3 = 30,
		AI_type_4 = 0,
		AI_rate_4 = 0,
	},
	[8] = {
		AI_type_1 = 10,
		AI_rate_1 = 20,
		AI_type_2 = 11,
		AI_rate_2 = 50,
		AI_type_3 = 12,
		AI_rate_3 = 30,
		AI_type_4 = 0,
		AI_rate_4 = 0,
	},
	[9] = {
		AI_type_1 = 10,
		AI_rate_1 = 20,
		AI_type_2 = 11,
		AI_rate_2 = 50,
		AI_type_3 = 12,
		AI_rate_3 = 30,
		AI_type_4 = 0,
		AI_rate_4 = 0,
	},
}
