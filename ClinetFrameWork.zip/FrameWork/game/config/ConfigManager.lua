local BaseConfigManager = require "BaseConfigManager"
local ConfigManager = class("ConfigManager", BaseConfigManager)
ConfigManager.instance = nil

function ConfigManager.getInstance()
    if not ConfigManager.instance then
        ConfigManager.instance = ConfigManager.new()
    end
    return ConfigManager.instance
end

function ConfigManager:ctor()
	ConfigManager.super.ctor(self)
end

function ConfigManager:init(configuration)
    local configTable = {}
    for k, tblName in pairs(configuration) do
        configTable[tblName] = require(tblName)
    end
    
    self:setConfigTbl(configTable)
    local referenceTbl = self:getConfigTbl()["ConfigTableReference"]
    self:setReferenceTbl(referenceTbl)
end

return ConfigManager
