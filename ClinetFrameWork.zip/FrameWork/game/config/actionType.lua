-- type                             int                              序号
-- file                             string                           文件名称
-- name                             string                           动作名称
-- comment                          string                           描述

return {
	[0] = {
		file = "BEG",
		name = "BEG",
		comment = "开始",
	},
	[1] = {
		file = "ball_001",
		name = "RUN",
		comment = "001移动",
	},
	[2] = {
		file = "ball_001",
		name = "HAPPY",
		comment = "001开心",
	},
	[3] = {
		file = "ball_001",
		name = "FULL",
		comment = "001饱",
	},
	[4] = {
		file = "ball_002",
		name = "RUN",
		comment = "002移动",
	},
	[5] = {
		file = "ball_002",
		name = "HAPPY",
		comment = "002开心",
	},
	[6] = {
		file = "ball_002",
		name = "FULL",
		comment = "002饱",
	},
	[7] = {
		file = "ball_003",
		name = "RUN",
		comment = "003移动",
	},
	[8] = {
		file = "ball_003",
		name = "HAPPY",
		comment = "003开心",
	},
	[9] = {
		file = "ball_003",
		name = "FULL",
		comment = "003饱",
	},
	[10] = {
		file = "ball_004",
		name = "RUN",
		comment = "004移动",
	},
	[11] = {
		file = "ball_004",
		name = "HAPPY",
		comment = "004开心",
	},
	[12] = {
		file = "ball_004",
		name = "FULL",
		comment = "004饱",
	},
	[13] = {
		file = "ball_005",
		name = "RUN",
		comment = "005移动",
	},
	[14] = {
		file = "ball_005",
		name = "HAPPY",
		comment = "005开心",
	},
	[15] = {
		file = "ball_005",
		name = "FULL",
		comment = "005饱",
	},
	[16] = {
		file = "END",
		name = "END",
		comment = "结束",
	},
}
