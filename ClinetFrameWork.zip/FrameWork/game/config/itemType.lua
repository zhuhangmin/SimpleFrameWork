-- type                             string                           说明
-- id                               int                              道具类型
-- comment                          string                           描述

return {
	["BEG"] = {
		id = 0,
		comment = "开始",
	},
	["SKIN"] = {
		id = 1,
		comment = "皮肤",
	},
	["FRAGMENT"] = {
		id = 2,
		comment = "碎片",
	},
	["DECORATE"] = {
		id = 3,
		comment = "装饰",
	},
	["LOTTERY"] = {
		id = 4,
		comment = "奖券",
	},
	["EVOLUTION"] = {
		id = 5,
		comment = "进化道具",
	},
	["PACK"] = {
		id = 6,
		comment = "礼包",
	},
	["FUNCTION"] = {
		id = 7,
		comment = "功能道具",
	},
	["CULTURE"] = {
		id = 8,
		comment = "培养液",
	},
	["ROLEPIECE"] = {
		id = 9,
		comment = "萌菌碎片",
	},
	["END"] = {
		id = 10,
		comment = "结束",
	},
}
