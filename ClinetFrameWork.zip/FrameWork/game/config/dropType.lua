-- type                             string                           说明
-- id                               int                              掉落类型
-- comment                          string                           描述

return {
	["BEG"] = {
		id = 0,
		comment = "开始",
	},
	["JUNIOR_CULTURE"] = {
		id = 1,
		comment = "初级培养液",
	},
	["MEDIUM_CULTURE"] = {
		id = 2,
		comment = "中级培养液",
	},
	["SENIOR_CULTURE"] = {
		id = 3,
		comment = "高级培养液",
	},
	["SUPER_CULTURE"] = {
		id = 4,
		comment = "特级培养液",
	},
	["STAR_GACHA"] = {
		id = 5,
		comment = "星星扭蛋",
	},
	["DIAMOND_GACHA"] = {
		id = 6,
		comment = "钻石扭蛋",
	},
	["FIVE_D_GACHA"] = {
		id = 7,
		comment = "钻石五连扭",
	},
	["END"] = {
		id = 8,
		comment = "结束",
	},
}
