-- id                               int                              序号
-- type                             int                              类型
-- imgName                          string                           图片名称
-- minScale                         int                              最小缩放比例（百分之一）
-- maxScale                         int                              最大缩放比例（百分之一）

return {
	[1] = {
		type = 1,
		imgName = "food1",
		minScale = 75,
		maxScale = 120,
	},
	[2] = {
		type = 1,
		imgName = "food2",
		minScale = 75,
		maxScale = 120,
	},
	[3] = {
		type = 1,
		imgName = "food3",
		minScale = 75,
		maxScale = 120,
	},
	[4] = {
		type = 1,
		imgName = "food4",
		minScale = 75,
		maxScale = 120,
	},
}
