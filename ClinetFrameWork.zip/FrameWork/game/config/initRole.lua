-- id                               int                              序号
-- role                             int                              初始皮肤id

return {
	[1] = {
		role = 30101,
	},
	[2] = {
		role = 30104,
	},
	[3] = {
		role = 30107,
	},
	[4] = {
		role = 30108,
	},
	[5] = {
		role = 30201,
	},
	[6] = {
		role = 30202,
	},
}
