-- id                               int                              累积签到天数
-- type                             int                              礼包ID

return {
	[1] = {
		type = 11,
	},
	[2] = {
		type = 12,
	},
	[3] = {
		type = 13,
	},
	[4] = {
		type = 14,
	},
	[5] = {
		type = 15,
	},
	[6] = {
		type = 16,
	},
	[7] = {
		type = 17,
	},
}
