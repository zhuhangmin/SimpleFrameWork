-- id                               int                              充值活动编号
-- gift_id                          int                              礼包编号
-- rate                             int                              触发概率
-- b_diamond                        int                              是否触发钻石充值
-- android_exchangeid               int                              安卓充值ID
-- apple_exchangeid                 int                              苹果充值ID
-- accum                            int                              累计次数
-- active_time                      int                              有效时间(s)
-- comment                          string                           充值活动描述
-- old_price                        int                              原价
-- new_price                        int                              折扣价
-- title                            string                           标题
-- trigger                          int                              触发其他充值活动完成（解决首冲问题，0代表不触发）

return {
	[1] = {
		gift_id = 2,
		rate = 10000,
		b_diamond = 1,
		android_exchangeid = 0,
		apple_exchangeid = 0,
		accum = 1,
		active_time = 9999999,
		comment = "首充礼包",
		old_price = 0,
		new_price = 0,
		title = "null",
		trigger = 0,
	},
	[2] = {
		gift_id = 3,
		rate = 10000,
		b_diamond = 0,
		android_exchangeid = 2243,
		apple_exchangeid = 2243,
		accum = 1,
		active_time = 9999999,
		comment = "25元超值礼包",
		old_price = 0,
		new_price = 0,
		title = "null",
		trigger = 1,
	},
	[3] = {
		gift_id = 20,
		rate = 6000,
		b_diamond = 0,
		android_exchangeid = 2303,
		apple_exchangeid = 2303,
		accum = 99999,
		active_time = 86400,
		comment = "登陆礼包-每次登录后",
		old_price = 10,
		new_price = 1,
		title = "lbxs/img_sign",
		trigger = 1,
	},
	[4] = {
		gift_id = 21,
		rate = 5000,
		b_diamond = 0,
		android_exchangeid = 2305,
		apple_exchangeid = 2305,
		accum = 99999,
		active_time = 86400,
		comment = "周末礼包-周末登录后",
		old_price = 60,
		new_price = 5,
		title = "lbxs/img_Sunday",
		trigger = 1,
	},
}
