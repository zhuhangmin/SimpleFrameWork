--任务配置
--[[
id=任务ID，必须唯一
prevtid=前置任务ID,没有填0
nexttid=后置任务ID, 完成任务后将触发的下一个任务ID,没有填0
conditions={diamond=0, star=0, kill=0, mvp=0, weight=0},任务条件，分别为钻石，星星，捕获，荣誉，质量，没有的可以去掉该字段
awards={diamond=0, star=0, tools=""},奖励,钻石，星星，道具。没有的可以去掉该字段。道具格式为:物品id,数量;物品id,数量;物品id,数量
]]--
--日常任务

taskconfig = {}
--所有任务开启时间
taskconfig.opentime = {year=2016, month=10, day=28, hour=0, min=0, sec=0}

daytasks={
	{
		--开始时间,全部0表示立即开始，时间格式为：{year=2016, month=12, day=22, hour=0, min=0, sec=0}
		begintime = {year=0, month=0, day=0, hour=0, min=0, sec=0},
		--结束时间,全部0表示永远
		endtime = {year=0, month=0, day=0, hour=0, min=0, sec=0},
		tasks = {
			{id=8001, prevtid=0, nexttid={}, conditions={gates=5}, awards="3006,1;104,20"},
			{id=8002, prevtid=0, nexttid={}, conditions={gates=3}, awards="3006,1;104,20"},
			{id=8011, prevtid=0, nexttid={}, conditions={planelevelup=2}, awards="1002,5;104,10"},
			{id=8012, prevtid=0, nexttid={}, conditions={planelevelup=1}, awards="1002,5;104,10"},
		}
	} 
}

--永久任务
maintasks={
	--{id = 10001,type = 1,version = 1,prevtid=0,nexttid={10002,20002,20018,20020,20021,20022,40003},conditions={gate10101=1},awards="100,2000"},
	{id = 10001,type = 1,version = 1,prevtid=0,nexttid={10002,20002},conditions={gate10101=1},awards="100,2000"},
	{id = 10002,type = 1,version = 1,prevtid=10001,nexttid={10003},conditions={gate10102=1},awards="100,500"},
	{id = 10003,type = 1,version = 1,prevtid=10002,nexttid={10004},conditions={gate10103=1},awards="100,1000"},
	{id = 10004,type = 1,version = 1,prevtid=10003,nexttid={10005},conditions={gate10105=1},awards="100,1500"},
	{id = 10005,type = 1,version = 1,prevtid = 10004,nexttid={10006},conditions={gate10202=1},awards="100,2500"},
	{id = 10006,type = 1,version = 1,prevtid = 10005,nexttid={10007},conditions={gate10206=1},awards="100,3000"},
	{id = 10007,type = 1,version = 1,prevtid = 10006,nexttid={10008},conditions={gate10304=1},awards="100,4000"},
	{id = 10008,type = 1,version = 1,prevtid = 10007,nexttid={10009},conditions={gate10309=1},awards="100,5000"},
	{id = 10009,type = 1,version = 1,prevtid = 10008,nexttid={10010},conditions={gate10402=1},awards="100,6000"},
	{id = 10010,type = 1,version = 1,prevtid = 10009,nexttid={10011},conditions={gate10410=1},awards="100,8000"},
	{id = 10011,type = 1,version = 1,prevtid = 10010,nexttid={10012},conditions={gate10506=1},awards="100,10000"},
	{id = 10012,type = 1,version = 1,prevtid = 10011,nexttid={10013},conditions={gate10511=1},awards="100,12000"},
	{id = 10013,type = 1,version = 1,prevtid = 10012,nexttid={10014},conditions={gate10602=1},awards="100,15000"},
	{id = 10014,type = 1,version = 1,prevtid = 10013,nexttid={10015},conditions={gate10611=1},awards="100,18000"},
	{id = 10015,type = 1,version = 1,prevtid = 10014,nexttid={10016},conditions={gate10705=1},awards="100,21000"},
	{id = 10016,type = 1,version = 1,prevtid = 10015,nexttid={10017},conditions={gate10709=1},awards="100,24000"},
	{id = 10017,type = 1,version = 1,prevtid = 10016,nexttid={10018},conditions={gate10803=1},awards="100,27000"},
	{id = 10018,type = 1,version = 1,prevtid = 10017,nexttid={10019},conditions={gate10809=1},awards="100,30000"},
	{id = 10019,type = 1,version = 1,prevtid = 10018,nexttid={10020},conditions={gate10811=1},awards="100,33000"},
	{id = 10020,type = 1,version = 1,prevtid = 10019,nexttid={10021},conditions={gate10905=1},awards="100,36000"},
	{id = 10021,type = 1,version = 1,prevtid = 10020,nexttid={10022},conditions={gate10908=1},awards="100,39000"},
	{id = 10022,type = 1,version = 1,prevtid = 10021,nexttid={},conditions={gate10910=1},awards="100,42000"},
	{id = 20001,type = 2,version = 1,prevtid = 0,nexttid={},conditions={perfect=1},awards="3001,1"},
	{id = 20002,type = 2,version = 1,prevtid =10001,nexttid={},conditions={boss10106=1,boss20106=1,boss30106=1},awards="1002,1"},
	{id = 20003,type = 2,version = 1,prevtid = 0,nexttid={},conditions={diamond=1},awards="100,2000"},
}