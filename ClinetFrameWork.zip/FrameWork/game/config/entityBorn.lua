-- id                               int                              生成规则ID
-- food_id                          int                              基础营养id
-- food_percent                     int                              基础营养占比（万分位）
-- entity_1                         int                              生成实体1
-- num_1                            int                              生成数量1
-- entity_2                         int                              生成实体2
-- num_2                            int                              生成数量2
-- entity_3                         int                              生成实体3
-- num_3                            int                              生成数量3

return {
	[1] = {
		food_id = 2,
		food_percent = 600,
		entity_1 = 4,
		num_1 = 5,
		entity_2 = 5,
		num_2 = 5,
		entity_3 = 6,
		num_3 = 5,
	},
	[2] = {
		food_id = 2,
		food_percent = 600,
		entity_1 = 4,
		num_1 = 2,
		entity_2 = 5,
		num_2 = 2,
		entity_3 = 6,
		num_3 = 2,
	},
	[3] = {
		food_id = 2,
		food_percent = 600,
		entity_1 = 4,
		num_1 = 4,
		entity_2 = 5,
		num_2 = 4,
		entity_3 = 6,
		num_3 = 4,
	},
}
