-- type                             string                           说明
-- id                               int                              道具类型
-- comment                          string                           描述

return {
	["BEG"] = {
		id = 0,
		comment = "开始",
	},
	["CON1"] = {
		id = 1,
		comment = "所有分身数量小于16",
	},
	["CON2"] = {
		id = 2,
		comment = "自身分数大于40",
	},
	["CON3"] = {
		id = 3,
		comment = "目标满足吞噬自身的要求",
	},
	["END"] = {
		id = 4,
		comment = "结束",
	},
}
