-- file_type                        string                           文件类型
-- type                             int                              购买类型
-- comment                          string                           描述

return {
	["BEG"] = {
		type = 0,
		comment = "开始",
	},
	["EXPORTJSON"] = {
		type = 1,
		comment = "ExportJson文件",
	},
	["PNG"] = {
		type = 2,
		comment = "png文件",
	},
	["END"] = {
		type = 3,
		comment = "结束",
	},
}
