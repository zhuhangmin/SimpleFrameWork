-- mode                             string                           形容词
-- type                             int                              序号
-- comment                          string                           描述

return {
	["BEG"] = {
		type = 0,
		comment = "开始",
	},
	["ROOM_1"] = {
		type = 1,
		comment = "新手房",
	},
	["ROOM_2"] = {
		type = 2,
		comment = "青铜房",
	},
	["ROOM_3"] = {
		type = 3,
		comment = "白银房",
	},
	["ROOM_4"] = {
		type = 4,
		comment = "黄金房",
	},
	["ROOM_5"] = {
		type = 5,
		comment = "白金房",
	},
	["ROOM_6"] = {
		type = 6,
		comment = "钻石房",
	},
	["ROOM_7"] = {
		type = 7,
		comment = "大师房",
	},
	["ROOM_8"] = {
		type = 8,
		comment = "王者房",
	},
	["ROOM_9"] = {
		type = 9,
		comment = "超神房",
	},
	["END"] = {
		type = 10,
		comment = "结束",
	},
}
