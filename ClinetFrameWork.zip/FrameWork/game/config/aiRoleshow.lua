-- id                               int                              序号
-- ref                              int                              皮肤id
-- name                             string                           皮肤名称
-- weight                           int                              随机概率（万分比）

return {
	[1] = {
		ref = 30101,
		name = "青蒙草",
		weight = 484,
	},
	[2] = {
		ref = 30104,
		name = "海洋球",
		weight = 484,
	},
	[3] = {
		ref = 30107,
		name = "粉玫瑰",
		weight = 484,
	},
	[4] = {
		ref = 30108,
		name = "金桔桔",
		weight = 484,
	},
	[5] = {
		ref = 30201,
		name = "石榴红",
		weight = 484,
	},
	[6] = {
		ref = 30202,
		name = "熏衣紫",
		weight = 484,
	},
	[7] = {
		ref = 30401,
		name = "独眼黄",
		weight = 160,
	},
	[8] = {
		ref = 30402,
		name = "独眼红",
		weight = 160,
	},
	[9] = {
		ref = 30403,
		name = "青花瓷",
		weight = 160,
	},
	[10] = {
		ref = 30404,
		name = "鲜花饼",
		weight = 160,
	},
	[11] = {
		ref = 30405,
		name = "绿豆糕",
		weight = 160,
	},
	[12] = {
		ref = 30406,
		name = "红衫木",
		weight = 160,
	},
	[13] = {
		ref = 30407,
		name = "黄豆馍",
		weight = 160,
	},
	[14] = {
		ref = 30408,
		name = "大奶牛",
		weight = 160,
	},
	[15] = {
		ref = 30409,
		name = "苏打水",
		weight = 160,
	},
	[16] = {
		ref = 30410,
		name = "保湿雾",
		weight = 160,
	},
	[17] = {
		ref = 30501,
		name = "酷帅墨镜",
		weight = 160,
	},
	[18] = {
		ref = 30502,
		name = "时空裂缝",
		weight = 160,
	},
	[19] = {
		ref = 30503,
		name = "女装大佬",
		weight = 160,
	},
	[20] = {
		ref = 30504,
		name = "运动小子",
		weight = 160,
	},
	[21] = {
		ref = 30505,
		name = "封神星牙",
		weight = 160,
	},
	[22] = {
		ref = 30506,
		name = "封神风将",
		weight = 160,
	},
	[23] = {
		ref = 30512,
		name = "憨萌国宝",
		weight = 160,
	},
	[24] = {
		ref = 30513,
		name = "恭喜发财",
		weight = 160,
	},
	[25] = {
		ref = 30507,
		name = "中华龙",
		weight = 80,
	},
	[26] = {
		ref = 30508,
		name = "嫦娥倩影",
		weight = 80,
	},
	[27] = {
		ref = 30509,
		name = "中华庆典",
		weight = 80,
	},
	[28] = {
		ref = 30510,
		name = "中秋月兔",
		weight = 80,
	},
	[29] = {
		ref = 30511,
		name = "月满星空",
		weight = 80,
	},
	[30] = {
		ref = 30514,
		name = "舞动福运",
		weight = 80,
	},
	[31] = {
		ref = 30515,
		name = "鸡年大吉",
		weight = 80,
	},
	[32] = {
		ref = 30601,
		name = "鸭子侦探",
		weight = 80,
	},
	[33] = {
		ref = 30602,
		name = "棕熊保镖",
		weight = 80,
	},
	[34] = {
		ref = 30603,
		name = "吉祥牛牛",
		weight = 80,
	},
	[35] = {
		ref = 30604,
		name = "森林之主",
		weight = 80,
	},
	[36] = {
		ref = 30605,
		name = "水象喷泉",
		weight = 80,
	},
	[37] = {
		ref = 30606,
		name = "哈士奇",
		weight = 80,
	},
	[38] = {
		ref = 30607,
		name = "黑猫警卫",
		weight = 80,
	},
	[39] = {
		ref = 30608,
		name = "羊驼",
		weight = 80,
	},
	[40] = {
		ref = 30609,
		name = "仓鼠",
		weight = 80,
	},
	[41] = {
		ref = 30610,
		name = "圣诞老人",
		weight = 31,
	},
	[42] = {
		ref = 30611,
		name = "火鸡",
		weight = 31,
	},
	[43] = {
		ref = 30612,
		name = "雪人",
		weight = 31,
	},
	[44] = {
		ref = 30613,
		name = "驯鹿",
		weight = 31,
	},
	[45] = {
		ref = 30614,
		name = "凤凰",
		weight = 31,
	},
	[46] = {
		ref = 30701,
		name = "红包拿来",
		weight = 31,
	},
	[47] = {
		ref = 30702,
		name = "君饺包",
		weight = 31,
	},
	[48] = {
		ref = 30703,
		name = "靓饺包",
		weight = 31,
	},
	[49] = {
		ref = 30704,
		name = "天狗炎日",
		weight = 31,
	},
	[50] = {
		ref = 31101,
		name = "跳跳菌",
		weight = 242,
	},
	[51] = {
		ref = 31102,
		name = "抱抱兽",
		weight = 80,
	},
	[52] = {
		ref = 31103,
		name = "滑行者",
		weight = 39,
	},
	[53] = {
		ref = 31104,
		name = "闪电战士",
		weight = 19,
	},
	[54] = {
		ref = 31201,
		name = "人工智能",
		weight = 242,
	},
	[55] = {
		ref = 31202,
		name = "初代改造",
		weight = 80,
	},
	[56] = {
		ref = 31203,
		name = "二代改造",
		weight = 39,
	},
	[57] = {
		ref = 31204,
		name = "最终拟人",
		weight = 19,
	},
	[58] = {
		ref = 31301,
		name = "咕噜菌",
		weight = 242,
	},
	[59] = {
		ref = 31302,
		name = "胖次",
		weight = 80,
	},
	[60] = {
		ref = 31303,
		name = "魔法师",
		weight = 39,
	},
	[61] = {
		ref = 31304,
		name = "精灵之声",
		weight = 19,
	},
	[62] = {
		ref = 31401,
		name = "豆豆",
		weight = 242,
	},
	[63] = {
		ref = 31402,
		name = "叶芽",
		weight = 80,
	},
	[64] = {
		ref = 31403,
		name = "花仙",
		weight = 39,
	},
	[65] = {
		ref = 31404,
		name = "妖精森林",
		weight = 19,
	},
	[66] = {
		ref = 31501,
		name = "小恶魔",
		weight = 242,
	},
	[67] = {
		ref = 31502,
		name = "独角兽",
		weight = 80,
	},
	[68] = {
		ref = 31503,
		name = "魅魔",
		weight = 39,
	},
	[69] = {
		ref = 31504,
		name = "天使之翼",
		weight = 18,
	},
	[70] = {
		ref = 31601,
		name = "希望",
		weight = 242,
	},
	[71] = {
		ref = 31602,
		name = "凝聚",
		weight = 80,
	},
	[72] = {
		ref = 31603,
		name = "守护",
		weight = 39,
	},
	[73] = {
		ref = 31604,
		name = "大地骑士",
		weight = 18,
	},
	[74] = {
		ref = 31701,
		name = "喵喵",
		weight = 242,
	},
	[75] = {
		ref = 31702,
		name = "喵司仪",
		weight = 80,
	},
	[76] = {
		ref = 31703,
		name = "见习爱神",
		weight = 39,
	},
	[77] = {
		ref = 31704,
		name = "幸福天女",
		weight = 18,
	},
}
