local EngineView = require "EngineView"
local GachaView = class("GachaView", EngineView)

local csbFilePath = "res/Draw.csb"
GACHA_CSB_NODE = 1000

function GachaView:ctor(node)
	GachaView.super.ctor(self, node)
end

function GachaView:onCreate(param)
	GachaView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	if isNil(csbNode) then printStack() return end
	
	csbNode:setTag(GACHA_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return GachaView





