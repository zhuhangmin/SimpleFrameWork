--------
local crypt  = require "crypt.c"

local print   = print
local string = string
local tonumber = tonumber
local socket_tcp = socket_tcp
local socket_data = ""
local step = 0

module "socket_verify"
-----------------------------------------------------------------------------------------------------------------------

local challenge
local clientkey
local secret

verified = false

local function writeline(text)
	socket_tcp.send(text .. "\n")
end

local function unpack_line(text)
	local from = text:find("\n", 1, true)
	
	if from then
		return text:sub(1, from-1), text:sub(from+1)
	end
	
	return nil, text
end

function reset()
	socket_data = ""
	step = 0
	verified = false
end

function onSocketData(rawdata)
	socket_data = socket_data .. rawdata
	
	local data,remain = unpack_line(socket_data)
	
	if data == nil then
		return
	end
	
	socket_data = remain

	if step == 0 then
		challenge = crypt.base64decode(data)
		clientkey = crypt.randomkey()
		writeline(crypt.base64encode(crypt.dhexchange(clientkey)))
		step = 1
	elseif step == 1 then
		secret = crypt.dhsecret(crypt.base64decode(data), clientkey)
		local hmac = crypt.hmac64(challenge, secret)
		writeline(crypt.base64encode(hmac))
		step = 2
	elseif step == 2 then
		local code = tonumber(string.sub(data, 1, 3))
		if code == 200 then
			verified = true
		end
	end
end