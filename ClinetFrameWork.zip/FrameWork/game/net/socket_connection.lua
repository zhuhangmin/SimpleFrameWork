
local socket_tcp =import ".socket_tcp"
import ".socket_msg"
import ".socket_verify"

local connected = false
local connectcount = 0
local socket_data   = ""
local lastcallback
local loginaddrs = {}
local login_tcp = socket_tcp.new(true)------都需要通过验证
local fight_tcp = socket_tcp.new(true)---------不需要传false  但是服务器端 要相应改动验证过程


function addconnectaddr(host, port)
    table.insert(loginaddrs,{host,port})
end

function makeConnect(callback,host,port,flag,tcp_object)----可传入tcp对象 同login_tcp对象相同的 创建
    connectcount = connectcount + 1

    if tcp_object then
        if tcp_object:connected() then
            tcp_object:disconnect()
        end

        tcp_object:connect(callback,host,port, true)
    else
        if not flag then
            if login_tcp:connected() then
                login_tcp:disconnect()
            end

            lastcallback = callback
            lasthost = host or lasthost
            lastport = port or port
            login_tcp:connect(callback,host,port, true) ----true 表示要重连
        else
            if fight_tcp:connected() then
                fight_tcp:disconnect()
            end

            fight_tcp:connect(callback,host,port, false) -----false 表示不在尝试重连 默认重连
        end
    end
 --    local addr = loginaddrs[math.random(1,#loginaddrs)]
	-- local host = addr[1]
	-- local port = addr[2]
	--bind use event:
	-- socket_tcp.setCallback(onSocketData,onSocketConnect,onSocketConnectError,onSocketDisconnect)
	-- socket_tcp.connect(host,port,true)
end

function reConnectLogin()
--    login_tcp:close()
--    login_tcp.isConnected =false
--    login_tcp:_reconnect()
    --login_tcp:disconnect()
    --makeConnect(handler(NetFunc, NetFunc.connectNetCB), "192.168.6.170", 10301)
    local scene = require("src.app.LoadGame.Load.LoadScene"):create()
        gDirector:replaceScene(scene)
end 

function send_info(msg,data,flag,tcp_object)
    if tcp_object then
        tcp_object:send(msg,data,flag)
    else
        if not flag then
            login_tcp:send(msg,data,flag)
        else
            fight_tcp:send(msg,data,flag)
        end
    end
	  -- login_tcp:send(msg,data,flag)
end

function myDisconnect(tcp_object)
    if tcp_object then
        if tcp_object:connected() then
            tcp_object:disconnect()
        end
    else
        if login_tcp:connected() then
            login_tcp:disconnect()
        end
    end
end

function fightDisconnect()
    if fight_tcp:connected() then
        fight_tcp:disconnect()
    end
end

local connectionlosttime = 0
local connecting = false

local function checkconnection()
    if login_tcp:connected() then
        connectionlosttime = 0
        connecting = false
        return
    end
    
    if connectcount == 0 then
        return
    end
    
    if not cmsg.hasqueuemessage() then
        connectionlosttime = connectionlosttime + 1
        
        if connectionlosttime > 300 then
            makeConnect(lastcallback)
            connectionlosttime = 0
        end
    else
        if login_tcp:connecttimeout() then
            makeConnect(lastcallback)
        end
        
        connectionlosttime = connectionlosttime + 1

        if connectionlosttime > 60 then
            cmsg.clearqueue()
            connectionlosttime = 0
        end
    end
end

cc.Director:getInstance():getScheduler():scheduleScriptFunc(checkconnection,1,false)
