
local eventclass = require("cocos.framework.components.event")
require("cocos.framework.package_support")
import(".protobuf")
require("pack")

local print   = print
local string = string
local tostring = tostring
local socket_tcp = socket_tcp
local protobuf = protobuf
local aiOnSend = aiOnSend
local DEBUG = DEBUG
local table = table

local debugsocket = false

local protos = 
{
	"login.pb",
	"room.pb",
	"rank.pb",
	"tool.pb",
	"mail.pb",
	"task.pb",
	"fight.pb",
	"OM.pb",

	"social.pb",
	"playerinfo.pb",
	"newactivity.pb",
	"gacha.pb",
    "role.pb",
    "shop.pb",
    "form.pb",
    "match.pb",
    "battle.pb",
}

proto_id_map = 
{
	["login.auth"] = 100,
	["login.auth_ack"] = 101,
    ["login.heartbeat"] = 102,--心跳包发送
    ["login.heartbeat_ack"] = 103,--心跳包接收
    ["login.rollingbannernotify"] = 105,--跑马灯
	["login.enterserver"] = 106,
	["login.enterserver_resp"] = 2006,
	["login.timesync"] = 121,
	["login.timesync_resp"] = 2021,
	["login.timesyncresp_ack"] = 124,
	["login.usertoolnotify"] = 5007,
	["login.signconfig"] = 5012,
	["login.fightServer"] = 5013,
	["login.payconfig"] = 163,
	["login.sign"] = 136,
	["login.sign_resp"] = 2036,
	["login.privateround"] = 139,
	["login.privateround_resp"] = 2039,
	["login.updatenickname"] = 142,
	["login.updatenickname_resp"] = 2042,
	["login.updatecity"] = 145,
	["login.updatecity_resp"] = 2045,
	["login.updatesex"] = 148,
	["login.updatesex_resp"] = 2048,
	["login.addpayserial"] = 157,
	["login.addpayserial_resp"] = 2057,
	["login.paysuccess"] = 160,
	["login.paysuccess_resp"] = 2060,
	["login.repeatlogin"] = 104,
	["login.userconvert_award"] = 98,
	-- ["login.userisGM"] = 104,
	

	-- ["room.notifystate"] = 5000,
	-- ["room.propertynotify"] = 5001,
	-- ["room.foodnotify"] = 5002,
	-- ["room.centernotify"] = 5003,
	-- ["room.ranknotify"] = 5004,
	-- ["room.gameover"] = 5005,
	["room.changedirect"] = 109,
	["room.changedirect_resp"] = 2009,
	["room.division"] = 112,
	["room.division_resp"] = 2012,
	["room.jet"] = 115,
	["room.jet_resp"] = 2015,
	["room.checkpos"] = 127,
	["room.checkpos_resp"] = 2027,
	["room.deadusernotify"] = 5006,
	["room.relive"] = 130,
	["room.relive_resp"] = 2030,
	["room.exitroom"] = 133,
	["room.exitroom_resp"] = 2033,
	["room.userchangenotify"] = 5008,
	["room.bindainotify"] = 5010,
	["room.removeainotify"] = 5011,
	["room.sendface"] = 151,
	["room.facenotify"] = 154,
	["room.hiddenSkill"] = 162,
	["room.hiddenSkill_resp"] = 2062,

	["rank.getrank"] = 118,
	["rank.getrank_resp"] = 2018,

	["tool.merge"] = 500,
	["tool.merge_resp"] = 2500,
	["tool.changeskin"] = 503,
	["tool.changeskin_resp"] = 2503,
	["tool.newtools"] = 5009,

	["mail.getmail"] = 900,
	["mail.getmail_resp"] = 2900,
	["mail.newmail"] = 903,
	["mail.readmail"] = 906,

	["task.tasks_notify"] = 1100,
	["task.tasksprogress_notify"] = 1103,
	["task.task_getaward"] = 1106,
	["task.task_getaward_resp"] = 1109,

	["fight.entergame"] = 601,

	["OM.OM_PCtype"] = 201,
	["OM.OM_jetDivison"] = 202,

	["playerinfo.basicinfo"] = 801,
	["playerinfo.othersBasicinfo"] = 802,
	["playerinfo.basicinfo_resp"] = 2801,
	["playerinfo.otherbasicinfo_resp"] = 2802,
	["playerinfo.photos_home_page"] = 806,
	["playerinfo.photos_home_page_rsp"] = 807,
	["playerinfo.photos_add"] = 803,
	["playerinfo.photos_add_rsp"] = 2803,
	["playerinfo.photos_remove"] = 804,
	["playerinfo.photos_remove_rsp"] = 2804,
	["playerinfo.changeuserinfo"] = 819,
	["playerinfo.changeuserinfo_resp"] = 2819,
	["playerinfo.phoneintro_notify"] = 2099,

	["social.social_attention"] = 901,
	["social.social_attention_rsp"] = 2901,
	["social.social_flower_add"] = 902,
	["social.social_flower_add_rsp"] = 2902,
	["social.social_slogan_add"] = 913,
	["social.social_slogan_add_rsp"] = 2913,
	["social.social_sendflower"] = 905,
	["social.social_sendflower_resp"] = 2905,
	["social.social_gift"] = 904,
	["social.social_gift_rsp"] = 2904,
	["social.social_buydecoration"] = 908,
	["social.social_buydecoration_resp"] = 2908,
	["social.social_deleteslogan"] = 907,
	["social.social_deleteslogan_resp"] = 2907,
	["social.social_followlist"] = 918,
	["social.social_followlist_resp"] = 2918,
	["social.social_flower_delete"] = 910,
	["social.social_flower_delete_resp"] = 2910,
	["social.GM_TipOffs"] = 911,
	["social.GM_TipOffs_resp"] = 2911,
	["social.social_newfollowlist"] = 919,
	["social.social_newfollowlist_resp"] = 2919,

	--活动begin
	["newactivity.accum_sign_config_notify"] = 2089,
	["newactivity.week_sign_config_notify"] = 2088,
	["newactivity.newbie_sign_config_notify"] = 2087,
	["newactivity.sign_accum"] = 180,
	["newactivity.sign_accum_resp"] = 2080,
	["newactivity.sign_week"] = 181,
	["newactivity.sign_week_resp"] = 2081,
	["newactivity.sign_newbie"] = 182,
    ["newactivity.sign_newbie_resp"] = 2082,
	["newactivity.gift_config_notify"] = 2090,
    ["newactivity.photo_config_notify"] = 2091,
    ["newactivity.thumb_config_notify"] = 2092,
    ["newactivity.gift_award"] = 183,
    ["newactivity.gift_award_resp"] = 2083,
    ["newactivity.photo_award"] = 184,
    ["newactivity.photo_award_resp"] = 2084,
    ["newactivity.thumb_award"] = 185,
    ["newactivity.thumb_award_resp"] = 2085,
    ["newactivity.newbie_enable_notify"] = 2086,
    ["newactivity.activity_user_data"] = 193,
    ["newactivity.activity_user_data_resp"] = 2093,
	--活动end
    --钻石换星星begin
    --["login.diamondToStar"] = 105,
    ["login.diamondToStar_resp"] = 2105,
    --钻石换星星end

    --新皮肤界面的消息begin
    ["role.advancedSkin"] = 1101,
    ["role.advancedSkin_resp"] = 22101,
    --end

    --新商城界面的消息begin
    ["shop.shoplistNotify"] = 1201,--登录成功后接收的商城内买那些道具
    ["shop.buyShopTool"] = 1202,--请求买道具
    ["shop.buyShopTool_resp"] = 21202,--买道具返回
    --end

    --vip变化通知 
    ["login.vip_notify"] = 820,

    --gacha 扭蛋相关
    ["gacha.gacha_showpool"] = 400,
    ["gacha.show_gacha_notify"] = 2400,
    ["gacha.gacha_trigger"] = 401,
    ["gacha.gacha_notify"] = 2401,
    ["gacha.gacha_double"] = 402,

    --表单提交
    ["form.submit_form"] = 30000,
    ["form.submit_form_resp"] = 30001,
    ["form.form_notify"] = 30002,

    ["match.enter_match"] = 5000,
    ["match.enter_match_resp"] = 5001,
    ["match.exit_match"] = 5002,
    ["match.exit_match_resp"] = 5003,
    ["match.enter_match_peer"] = 5004,
    ["match.user_count_notify"] = 5005,



    ["battle.entity_notify"] = 5601,
    ["battle.buff_notify"] = 1,
    ["battle.move_notify"] = 5603,
    ["battle.leave_notify"] = 5604,
    ["battle.dead_notify"] = 5605,
    -- ["battle.time_notify"] = 5605,
    -- ["battle.weight_element"] = 5606,
	["battle.property_notify"] = 5606,
	["battle.food_notify"] = 5600,
	["battle.exit"] = 5750,
	["battle.exit_resp"] = 5751,
	["battle.center_notify"] = 5607,
	["battle.getranks"] = 5725,
	["battle.getranks_resp"] = 5726,
	["battle.eat_me_user_notify"] = 1,
	["battle.set_direct"] = 1,
	["battle.set_direct_ack"] = 1,
	["battle.use_skill"] = 1,
	["battle.use_skill_ack"] = 1,
	["battle.use_skill_notify"] = 1,
	["battle.check_pos"] = 5550,
	["battle.check_pos_ack"] = 5551,
	["battle.dead_user_notify"] = 1,
	["battle.set_relive"] = 5720,
	["battle.set_relive_ack"] = 5721,
	["battle.bind_ai_notify"] = 5735,
	["battle.remove_ai_notify"] = 5736,
	["battle.timesync"] = 5500,
	["battle.timesync_resp"] = 5501,
	["battle.timesync_resp_ack"] = 5502,
	["battle.change_direct"] = 5701,
	["battle.change_direct_resp"] = 5702,

	["battle.division" ] = 5703,
	["battle.division_resp" ] = 5704,
	["battle.jet" ] = 5705,
	["battle.jet_resp" ] = 5706,
	["battle.rank_notify" ] = 5725,
	["battle.dead_user_notify"] = 5726,
	["room.leave_room"] = 5208,
	["room.leave_room_ack"] = 5209,
	["room.leave_room2"] = 5210,
	["room.enter_room"] = 5211,
	["battle.balance_notify"] = 5800,
	["battle.play_timesync_notify"] = 5740,
	["room.status_notify"] = 5212,
	["battle.peer_user_notify"] = 5608,
	["battle.upload_voice_info"] = 5760,
	["battle.upload_voice_info_notify"] = 5761,
}

local id_proto_map = {}

for proto,id in pairs(proto_id_map) do
	id_proto_map[id] = proto
end

for _,file in ipairs(protos) do
	local fullPath = cc.FileUtils:getInstance():fullPathForFilename("protocol/"..file)
	print(fullPath)
	protobuf.register_file(fullPath)
end

local recv = setmetatable({},eventclass)
eventclass.bind(recv,recv)

local msgqueue = {}
local authpackage

module "cmsg"
-----------------------------------------------------------------------------------------------------------------------

function recvevent()
	return recv
end

function msgtoproto(msgid)
	return id_proto_map[msgid]
end

function getauthpackage()
	return authpackage
end

function cleanAuthpackage()
	authpackage = nil
end

local function encode(msgid,msgname,data)
	local msgdata = protobuf.encode(msgname, data)
	local size = #msgdata + 2
	local package = string.pack(">h", size) .. string.pack(">h", msgid)  .. msgdata
	return package
end

local function send_request(package)
	if socket_tcp.connected() then
		socket_tcp.send(package)
	else
		table.insert(msgqueue,package)
	end
end

function addqueuemessage()
	table.insert(msgqueue,package)
end

function hasqueuemessage()
	if #msgqueue > 0 then
		return true
	else
		return false
	end
end

function clearqueue()
	msgqueue = {}
end

function flushqueue()
	if socket_tcp.connected() then
		for _,package in ipairs(msgqueue) do
			socket_tcp.send(package)
		end
	end

	msgqueue = {}
end

function send(msg,data)
	if DEBUG == 2 then
		print("send message:",msg)
	end

	if debugsocket then
		aiOnSend(msg,data)
	else
		local msgid = proto_id_map[msg]

		if msgid == nil then
			print("unknown msg: not registered",msg)
			return
		end

		if msg == "login.auth" then
			authpackage = data
		end

		send_request(encode(msgid,msg,data))
	end
end

local tag = 1
local listenertag = {}

function on(eventName, listener)
	local function _listener(event)
		listener(event.data)
	end

	tag = tag + 1
	listenertag[listener] = tag
	recv:addEventListener(eventName,_listener,tag)
end

function off(eventName, listener)
	local tag = listenertag[listener]
	if not tag then
		return
	end

	recv:removeEventListenersByTag(tag)
	listenertag[listener] = nil
end

function handlemsg(msg,proto,data)
	local handler = recv.listeners_[string.upper(proto)]
	if handler then
		recv:dispatchEvent({name = proto,data = data})
	else
		print("unhandle proto message",proto)
	end
end

