
local socket = require("socket.core")
local socket_tcp = class("socket_tcp")
local crypt = require "crypt.c"
-- local cc       = cc
-- local print    = print
-- local string  = string
-- local assert = assert
-- local tonumber = tonumber
local SOCKET_READ_TICK = 0.01
local SOCKET_CONNECT_TICK = 0.001
local SOCKET_RECONNECT_TIME = 1
local SOCKET_CONNECT_FAIL_TIMEOUT = 0.5
local STATUS_CLOSED = "closed"
local STATUS_NOT_CONNECTED = "Socket is not connected"
local STATUS_ALREADY_CONNECTED = "already connected"
local name = 'socket tcp client'


local function unpack_line(text)
	local from = text:find("\n", 1, true)

	if from then
		return text:sub(1, from - 1), text:sub(from + 1)
	end

	return nil, text
end

function socket_tcp:ctor(needverify)
	--gate data
	-- self._onData=nil
	-- self._onClose=nil
	-- self._onConnect=nil
	-- self._onConnectError =nil		--最后设备ID

	self.host = ""
	self.port = 0
	self.tcp = nil
	self.isRetryConnect = false -- initiative to disconnect, no reconnect.
	self.retrytimes = 0
	self.isConnected  = false
	self.isConnecting = false
	self.tickScheduler = nil						-- timer for data
	self.reconnectScheduler = nil				-- timer for reconnect
	self.connectTimeTickScheduler = nil	-- timer for connect timeout
	self.verified = nil
	self.waitConnect = nil
	self.scheduler = cc.Director:getInstance():getScheduler()
	self.socket_data = ""
	self.challenge = nil
    self.clientkey = nil
    self.secret = nil
    self.step=0
    self.callback =nil
    self.needverify = needverify
end

function socket_tcp:writeline(text)
	self.tcp:send(text .. "\n")
end

function socket_tcp:encode(msgid,msgname,data)
	local msgdata = protobuf.encode(msgname, data)
	local size = #msgdata + 2
	local package = string.pack(">h", size) .. string.pack(">h", msgid)  .. msgdata
	return package
end
function socket_tcp:unpack_package(text)
	local size = #text

	if size < 2 then
		return nil, text
	end
	
	local s = text:byte(1) * 256 + text:byte(2)

	if size < s + 2 then
		return nil, text
	end

	return text:sub(3,2+s), text:sub(3+s)
end
function socket_tcp:onSocketData(rawdata)
	-- print("rawdata",rawdata)
	if not self.verified  then
		 self.socket_data = self.socket_data .. rawdata

		local data,remain = unpack_line(self.socket_data)
		if data == nil then
			return
		end
		self.socket_data = remain

		if self.step == 0 then
			self.challenge = crypt.base64decode(data)
			self.clientkey = crypt.randomkey()
			self:writeline(crypt.base64encode(crypt.dhexchange(self.clientkey)))
			self.step = 1
		elseif self.step == 1 then
			self.secret = crypt.dhsecret(crypt.base64decode(data), self.clientkey)
			local hmac = crypt.hmac64(self.challenge,self.secret)
			self:writeline(crypt.base64encode(hmac))
			self.step = 2
		elseif self.step == 2 then
			local code = tonumber(string.sub(data, 1, 3))
			if code == 200 then
				self.verified = true
				self.socket_data=""
				if self.callback then
					self.callback()
				end
			end
		end
	else
		self.socket_data = self.socket_data .. rawdata
		
		while true do
			local package,remain = self:unpack_package(self.socket_data)

			if package == nil then
				break
			end

			self.socket_data = remain
			local msg  = package:byte(1) * 256 + package:byte(2)
			local proto = cmsg.msgtoproto(msg)
			if  proto then
				local msgdata = string.sub(package,3,-1)
				local result,error = protobuf.decode(proto, msgdata)
				if not error then
					cmsg.handlemsg(msg,proto,result)
					
					if proto == "login.auth" then
						cmsg.flushqueue()
					end
				else
					print("failed to decode msg",proto)
				end
			else
				print("unknow msg",msg)
			end
		end
	end
end

-- function socket_tcp:setCallback(onData,onConnect,onConnectError,onClose)	
-- 	self._onData 				 = self:onSocketData
-- 	self._onClose 			 = onClose
-- 	self._onConnect 		 = onConnect
-- 	self._onConnectError = onConnectError
	
-- 	self.retrytimes = 0
-- end

function socket_tcp:connected()
	return self.isConnected or self.isConnecting
end

-- if connection is initiative, do not reconnect
function socket_tcp:_reconnect()
	if self.connectTimeTickScheduler then
		self.scheduler:unscheduleScriptEntry(self.connectTimeTickScheduler) 
		self.connectTimeTickScheduler = nil
	end

	if not self.isRetryConnect then 
		return 
	end

    	self.retrytimes = self.retrytimes + 1
	if self.retrytimes>3 then
        local scene = require("src.app.LoadGame.Load.LoadScene"):create()
        gDirector:replaceScene(scene)
		return
	end
	

	if self.reconnectScheduler then 
		self.scheduler:unscheduleScriptEntry(self.reconnectScheduler) 
	end

	local __doReConnect = function ()
		self.scheduler:unscheduleScriptEntry(self.reconnectScheduler) 
		self.reconnectScheduler = nil

		self:connect()
	end

	self.reconnectScheduler = self.scheduler:scheduleScriptFunc(__doReConnect, SOCKET_RECONNECT_TIME,false)
end

function socket_tcp:connect(callback,__host, __port, __retryConnectWhenFailure)
	if __host then self.host = __host end
	if __port then self.port = __port end
	if __retryConnectWhenFailure ~= nil then self.isRetryConnect = __retryConnectWhenFailure end
	self.isConnecting = true
	print("connect to ",self.host,":",self.port,callback)
	if not self.callback then
		self.callback = callback
	end

	--根据self.host判断是否是ipv6
	local isIPV6 = false
	local addrInfo = socket.dns.getaddrinfo(self.host)

	if addrInfo then
		for k, v in pairs(addrInfo) do
			if v.family == "inet6" then
				isIPV6 = true
				break
			end
		end
	end

	if isIPV6 then
		print("-----special------ipv6")
		self.tcp = socket.tcp6()
	else
		print("-----normal------ipv4")
		self.tcp = socket.tcp()
	end

	-- self.tcp = socket.tcp()
	self.tcp:settimeout(0)
	local function __checkConnect()
		local __succ, __status = self.tcp:connect(self.host, self.port)

		if __succ == 1 or __status == STATUS_ALREADY_CONNECTED then
			self:_onConnected()
		end
		
		return __succ
	end

	--start connect timer
	if not __checkConnect() then
		local __connectTimeTick = function ()
			if self.isConnected then return end
			
			self.waitConnect = self.waitConnect or 0
			self.waitConnect = self.waitConnect + SOCKET_CONNECT_TICK
			
			if self.waitConnect >= SOCKET_CONNECT_FAIL_TIMEOUT then
				self.waitConnect = nil
				self:close()	
				self:_reconnect()
			else
				__checkConnect()
			end
		end
		
		self.connectTimeTickScheduler = self.scheduler:scheduleScriptFunc(__connectTimeTick, SOCKET_CONNECT_TICK,false)
	end
end

-- connecte success, cancel the connection timerout timer
function socket_tcp:_onConnected()

	self.isConnected = true
	self.retrytimes = 0

	if self.connectTimeTickScheduler then 
		self.scheduler:unscheduleScriptEntry(self.connectTimeTickScheduler) 
		self.connectTimeTickScheduler = nil
	end
	if not self.needverify then
		self.verified=true
		self.isConnected = true
		self.socket_data=""
		-- self.tcp:settimeout(0)
	end
	local __tick = function()
		while true and self.tcp do
			local __body, __status, __partial = self.tcp:receive("*a")	
			
    	    if __status == STATUS_CLOSED or __status == STATUS_NOT_CONNECTED then
		    	self:close()
		    	if self.isConnected then
		    		self.isConnected =false
					self:_reconnect()
		    	end
				
		   		return
	    	end
			
		    if 	(__body and string.len(__body) == 0) or (__partial and string.len(__partial) == 0) then return end
			
			if __body and __partial then 
				__body = __body .. __partial 
			end			
			-- if self._onData  ~= nil then
			-- 	self._onData (__partial or __body)
			-- end
			self:onSocketData(__partial or __body)
		end
	end

	-- start to read TCP data
	self.tickScheduler = self.scheduler:scheduleScriptFunc(__tick, SOCKET_READ_TICK,false)
	if not self.needverify then
		self.callback()
	end
end

function socket_tcp:close()
	if self.tcp then
		self.tcp:close()
	end
	if self.connectTimeTickScheduler then
		self.scheduler:unscheduleScriptEntry(self.connectTimeTickScheduler) 
		self.connectTimeTickScheduler = nil
	end

	if self.tickScheduler then 
		self.scheduler:unscheduleScriptEntry(self.tickScheduler) 
		self.tickScheduler = nil
	end
	self.verified = nil
	self.step = 0
	self.challenge = nil
    self.clientkey = nil
    self.secret = nil
    self.socket_data=""
	self.tcp = nil
end
-- disconnect on user's own initiative.
function socket_tcp:disconnect()
	-- self:setCallback(nil,nil,nil,nil)

	self:close()
	self.isConnected = false
	self.isRetryConnect = false -- initiative to disconnect, no reconnect.
	self.host = ""
	self.port = 0
	self.callback=nil
	self.isConnecting = false
	-- self.tcp:shutdown()
end

function socket_tcp:send(msg,data,flag)
    if DEBUG == 2 then
        -- print("send message:",msg)
    end

    if debugsocket then
        aiOnSend(msg,data)
    else
        local msgid = proto_id_map[msg]

        if msgid == nil then
            print("unknown msg: not registered",msg)
            return
        end
        
        if msg == "login.auth" then
            authpackage = data
        end
        if self.isConnected and self.tcp then
            local package = self:encode(msgid,msg,data)
      	    self.tcp:send(package)
      	    if not flag then
      	    	cmsg.addqueuemessage(package)
      	    end
      	end
    end
end

return socket_tcp