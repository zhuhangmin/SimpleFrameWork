--网络协议模块
require("FrameWork.game.netmsg.CMD")
local Login = require("FrameWork.game.netmsg.Login")
local Form  = require("FrameWork.game.netmsg.CMDBase")
local Match = require("FrameWork.game.netmsg.Match")
local netBattle = require("FrameWork.game.netmsg.netBattle")
local NetFunc = class("NetFunc")

function NetFunc:ctor()
	self.linkCB = nil
	self.isLink = false

	self:init()
end

function NetFunc:init()
	self.login = Login:create()
    self.form = Form:create()
    self.match = Match:create()
    self.netBattle = netBattle:create()
end

---------------------------------连接服务器-----------------------------------
--建立网络连接
function NetFunc:connectNet(callback)
	if self.isLink then
		self:disconnectNet()
	end

	self.linkCB = callback
	makeConnect(handler(self, self.connectNetCB), LoginManager.sHost, LoginManager.sPort)
    -- makeConnect(handler(self, self.connectNetCB), "192.168.6.208",10401)
     -- makeConnect(handler(self, self.connectNetCB), "120.26.10.87",10601)
     -- makeConnect(handler(self, self.connectNetCB), "192.168.6.123",10601)
end

function NetFunc:connectNetCB()
	if not self.isLink then
		self.isLink = true
		self.login:loginServer(handler(self, self.loginCB))
	end
end

function NetFunc:loginCB(code)
	if self.linkCB then
		self.linkCB(code)
		self.linkCB = nil
	end
end

--断开网络连接
function NetFunc:disconnectNet()
	self.linkCB = nil

	if self.isLink then
		self.isLink = false
		myDisconnect()
	end
end

--判断当前网络连接是否连上
function NetFunc:isConnectedNet()
	return isConnected()
end

function NetFunc:submitForm(func, params)
	if notString(func) then printStack(func) return end
    if isNil(params) then printStack(params) return end
	self.form:submitForm(func, params)
end

cc.exports.NetFunc = NetFunc:create()
