local BaseMessageManager = require "BaseMessageManager"
local messageManager = BaseMessageManager.getInstance()
--notify 
--all mails data
function CMD.mails_data(data)
    if notTable(data) then printStack() return end
    MailData = data
 
    local name = GameMsg.GET_MAIL_DATA
    messageManager:dispatch(name)
end

-- notify
--unread mails exist :  1 exist, 0 not exist
function CMD.mails_exist_isread(data)
	if notTable(data) then printStack() return end
	if notNumber(data.exist) then printStack() return end
	MailData_unReadMailExist = data.exist
	
	--send msg : red dot on UI
    local name = GameMsg.GET_NEW_MAIL
    messageManager:dispatch(name)
end

--读邮件, 
function CMD.readMail(data)
	if notTable(data) then printStack() return end
	if isNil(data.mailID) then printStack() return end

end

--领取邮件奖励
function CMD.collectMailReward(data)
	if notTable(data) then printStack() return end
	if isNil(data.mailID) then printStack() return end

    local name = GameMsg.COLLECT_MAIL_REWARD
    messageManager:dispatch(name)
end