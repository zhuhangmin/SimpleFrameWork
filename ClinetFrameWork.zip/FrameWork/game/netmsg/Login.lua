local BaseMessageManager = require "BaseMessageManager"
local baseMessageManager = BaseMessageManager.getInstance()

local Login = class("Login")

function Login:ctor()
	self.loginCB = nil
	cmsg.on("login.auth_ack", handler(self, self.loginServerResp))
    cmsg.on("login.heartbeat_ack", handler(self, self.sendHeartResp))
	cmsg.on("login.timesync_resp", handler(self, self.timeSyncResp))
end

------------------------------------登录----------------------------------------
--登录服务器
function Login:loginServer(callback)
	self.loginCB = callback

	local pid = 1
	if device.platform == "ios" then
		pid = 2
	end
	local info = {
		bindaccount = gUserPlugin:getUserID(),--绑定账号
        platformid = 1,--SDKFunc.account:getPlatformChannel(),--//渠道ID，同城游为1
		ostype = pid,--//系统类型，1表示安卓，2表示IOS
		deviceid = gDeviceUtils:getMacAddress(),--//设备标识ID
        nickname = gUserPlugin:getNickName(),--//昵称
        sex = gUserPlugin:getUserSex(),--//性别
        version = 1,--SDKFunc.versionCode,--//客户端当前版本号
        accounttype = -1,--//账号类型，-1表示未绑定，0表示qq,1表示微信
		--time = tostring(math.floor(socket.gettime() * 1000)),
		--city = 0,
		fromid = 6,-- //单包安卓6,ios 8,zip包安卓66,ios 88
        
        imei = gDeviceUtils:getIMEI(),
        imsi = gDeviceUtils:getIMSI(),
       
        
	}
	if DEBUG_FLAG then
		info.bindaccount = os.time()
	end	
    -- dump(info)
	send_info("login.auth", info)
end

function Login:loginServerResp(resp)
	print("loginServerResp")
	dump(resp)
	local ret = 0
    FirstLogin = true
	if resp.status == 0 then
		-- GameData.serverID = resp.userid
		GameData.enterServerTime = tonumber(resp.server_time)

		--心跳包开启
		print("心跳包开启")
		self:sendHeart()

		ret = 0
	elseif resp.status == -8 then
		ret = -3

		NetFunc:disconnectNet()
	else
		ret = resp.status
	end

	if self.loginCB then
		self.loginCB(ret)
		self.loginCB = nil
	end
	print(ret)
end

---------------------------------与服务器时间同步----------------
--时间同步
function Login:timeSync()
	local info = {
		time = tostring(math.floor(socket.gettime() * 1000)),
	}
	send_info("login.timesync", info, FightServer.flag)
end

--时间同步回复
function Login:timeSyncResp(resp)
	if GameData.battleInfo.roleDataManager then
		GameData.battleInfo.roleDataManager.isSyncTime = true
	end

	local curTime = math.floor(socket.gettime() * 1000)
	local delta = math.floor((curTime - tonumber(resp.time)) / 2)
	GameData.syncTimeDelta = curTime - delta - tonumber(resp.servertime)
	GameData.netDelta = delta

	--时间同步回复确认
	local info = {
		time = tostring(curTime),
		servertime = resp.servertime,
	}
	send_info("login.timesyncresp_ack", info, FightServer.flag)
end


-----------------------心跳--------------------------------------
local heart_interval = 3
function Login:sendHeartResp()
    if self._ID then  return end 
    self:cancelHeartScheduler()
    self._ID = scheduleOnce(
        function()
            self._ID = nil
            self:sendHeart()
        end,heart_interval)
end 

function Login:sendHeart()
	local d_time = 0
	if self.send_time then
		d_time = os.time() - self.send_time
	end
	-- print("sendHeart==="..os.time()..";"..d_time)
	if d_time < HEART_DICONNECT_TIME then
	    self:startHeartScheduler()
	    local info = {
			--time = os.time()
		}
	    send_info("login.heartbeat", info)
	else
		self.send_time = nil
		self:cancelHeartScheduler()
		self._ID = scheduleOnce(
        function()
        	gScheduler:unscheduleScriptEntry( self._ID )
            self._ID = nil
            self:popReEnter()
        end,1)
	end
end 

function Login:startHeartScheduler()
	if not self.schedulerID then
		self.schedulerID = gScheduler:scheduleScriptFunc(handler(self, self.onHeartTime), heart_interval, false)
        self.count = 0
        self.send_time = os.time()
	end
end

function Login:cancelHeartScheduler()
	if self.schedulerID then
		gScheduler:unscheduleScriptEntry(self.schedulerID)
		self.schedulerID = nil
	end
end

function Login:okBtnClick()
	local name = BASE_MSG.RESET_APP
    baseMessageManager:dispatch(name)
	reConnectLogin()
end

function Login:onHeartTime()
    self.count  = self.count + 1
    if self.count > 1 then 
        self:cancelHeartScheduler()
        print("onHeartTime Reconnect")
        self:popReEnter()
        return
    end 
    self:sendHeart()
end 

function Login:popReEnter( ... )
    local data = {}
    data.param = {}
    data.param.modelParam = {}
    data.param.modelParam.contentStr = "网络异常请重新连接网络"
    data.param.modelParam.confirmCB = handler(self, self.okBtnClick)
    data.param.modelParam.cancelCB = handler(self, self.okBtnClick)
    local name = BASE_MSG.OPEN_MSGBOX_MVC
    local event = {}
    event.data = data
    baseMessageManager:dispatch(name, event)
end

function Login:showReConnectPanel()
    if not self._REConnectPanel or not self._REConnectPanel:isVisible() then
        self._REConnectPanel = require("src.app.game.Node.REConnectNode"):create(1) 
    end 
end 

function Login:hideReConnectPanel()
    if self._REConnectPanel then
        self._REConnectPanel:hide() 
    end  
end 

return Login
