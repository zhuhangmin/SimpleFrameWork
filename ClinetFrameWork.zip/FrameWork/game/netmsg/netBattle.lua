local netManager = require("battle.net.entityNetManager"):getInstance()
local netBattle = class("netBattle")
local BaseMessageManager = require "BaseMessageManager"
local messageManager = BaseMessageManager.getInstance()
local AIManager = require("battle.AIManager.AIManager"):getInstance()

  
function netBattle:ctor()

	self:registerProtocol()
end

function netBattle:registerProtocol()
	cmsg.on("battle.entity_notify", handler(self, self.stateNotify))
	-- cmsg.on("battle.leave_notiSfy", handler(self, self.leave_notify))
	-- cmsg.on("battle.skill_notify", handler(self, self.skill_notify))
	cmsg.on("battle.food_notify", handler(self, self.foodNotify))
	-- cmsg.on("battle.enter_notify", handler(self, self.entity_notiify))
	-- cmsg.on("battle.buff_notify", handler(self, self.buff_notiify))
	cmsg.on("battle.change_direct_resp", handler(self, self.changeDirResp))
	-- cmsg.on("battle.dead_notify", handler(self, self.deadNotify))
	cmsg.on("battle.property_notify", handler(self, self.propertyNotify))
	cmsg.on("battle.center_notify", handler(self, self.centerNotify))
	cmsg.on("battle.rank_notify", handler(self, self.rank_notify))
	cmsg.on("battle.eat_me_user_notify", handler(self, self.eat_me_user_notify))
	-- cmsg.on("battle.set_direct_ack", handler(self, self.set_direct_ack))
	-- cmsg.on("battle.use_skill_ack", handler(self, self.use_skill_ack))
	-- cmsg.on("battle.use_skill_notify", handler(self, self.use_skill_notify))
	cmsg.on("battle.check_pos_ack", handler(self, self.checkPosResp))
	cmsg.on("battle.dead_user_notify", handler(self, self.dead_user_notify))
	cmsg.on("battle.set_relive_ack", handler(self, self.reviveResp))
	cmsg.on("battle.bind_ai_notify", handler(self, self.bindAINotify))
	cmsg.on("battle.remove_ai_notify", handler(self, self.unbindAINotify))
	cmsg.on("battle.timesync_resp", handler(self, self.timeSyncResp))
	cmsg.on("battle.division_resp", handler(self, self.divideResp))
	cmsg.on("battle.jet_resp", handler(self, self.jetResp))
	cmsg.on("room.leave_room_ack", handler(self, self.exitBattleResp))
	cmsg.on("battle.balance_notify",handler(self,self.gameOverNotify))
	cmsg.on("battle.play_timesync_notify",handler(self,self.playTimeNotify))
	cmsg.on("battle.peer_user_notify",handler(self,self.peerUserNotify))
	cmsg.on("battle.upload_voice_info_notify",handler(self,self.voiceNotify))
end

-------------------------------战斗中各种通知-------------------------------------
function netBattle:stateNotify(resp)
	if GameData.battleInfo.roleDataManager then
		GameData.battleInfo.roleDataManager:stateNotify(resp)

		if resp.userid == GameData.battleInfo.userID then
			-- MsgManager:sendMsg(GameMsg.MSG_NOTIFY_STATE, resp)
			local scene = GameData.battleScene
			if scene then
				scene:stateNotify(resp.enter, resp.leave, resp.move, resp.dead)
			end
		end
	end
end

function netBattle:peerUserNotify( params )
	if GameData.battleInfo.roleDataManager then
		GameData.battleInfo.roleDataManager:peerNotify(params)

		if params.userid == GameData.battleInfo.userID then
			-- MsgManager:sendMsg(GameMsg.MSG_NOTIFY_STATE, resp)
			local scene = GameData.battleScene
			if scene then
				scene:peerNotify(params)
			end
		end
	end
end


function netBattle:bindAINotify(resp)
	-- print("bindAINotify=="..resp.type)
	-- print("AIManager=="..tostring(resp.userid))
	if resp.userid then
		AIManager:createAI(resp.userid, resp.type, true, true)
	end
end

function netBattle:unbindAINotify(resp)
	print("unbindAINotify=="..resp.userid)
	if resp.userid then
		AIManager:deleteAI(resp.userid)
	end
end


function netBattle:propertyNotify(resp)
	if GameData.battleInfo.roleDataManager then
		GameData.battleInfo.roleDataManager:propertyNotify(resp)
	end
end

--时间同步
function netBattle:timeSync()
	local info = {
		time = tostring(math.floor(socket.gettime() * 1000)),
	}
	send_info("battle.timesync", info )
end

--时间同步回复
function netBattle:timeSyncResp(resp)
	GameData.isSyncTime = true

	local curTime = math.floor(socket.gettime() * 1000)
	local delta = math.floor((curTime - tonumber(resp.time)) / 2)
	GameData.syncTimeDelta = curTime - delta - tonumber(resp.servertime)
	GameData.netDelta = delta

	--时间同步回复确认
	local info = {
		time = tostring(curTime),
		servertime = resp.servertime,
	}
	send_info("battle.timesync_resp_ack", info)
end


--改变移动方向
function netBattle:changeDir( userID,dir )
	-- print("changeDir "..userID..";"..dir)
	local info = {
		userid = userID,
		rotation = dir,
		time = tostring(math.floor(socket.gettime() * 1000)),
	}
	send_info( "battle.change_direct", info )
end

function netBattle:changeDirResp(resp)
	if resp.code == 0 then
		if GameData.battleInfo.roleDataManager then
			GameData.battleInfo.roleDataManager:changeDir(resp)
		end
	end
end

--分裂
function netBattle:divide(userID)
	print("divide")
	local info = {
		userid = userID,
	}
	send_info("battle.division", info)
end

function netBattle:divideResp(resp)
	print("divideResp resp")
	if resp.userid == GameData.battleInfo.userID then
		local scene = GameData.battleScene
		if scene then
			scene:overDivide()
		end
	end
end

--喷射
function netBattle:jet(userID)
	-- print("jet")
	local info = {
		userid = userID,
	}
	send_info("battle.jet", info)
end

function netBattle:jetResp(resp)
	-- print("jet resp")
	if resp.userid == GameData.battleInfo.userID then
		local scene = GameData.battleScene
		if scene then
			scene:overJet()
		end
	end
end



function netBattle:dead_user_notify(resp)
	print("dead_user_notify")
	if resp.userid == GameData.battleInfo.userID then
		GameData.battleInfo.isUserDie = true
		local name = BattleMsg.DEAD
		local event = {}
		messageManager:dispatch(name,event)
		self:revive()
	end
end

--复活
function netBattle:revive()
	print("revive")
	local info = {
		-- userid = GameData.battleInfo.userID,
	}
	send_info("battle.set_relive", info)
end

function netBattle:reviveResp(resp)
	-- dump(resp)
	-- print("revive ==="..resp.code)
	if resp.code == 0 then
		GameData.battleInfo.isUserDie = false
	end
end

--校验坐标
function netBattle:checkPos(checkList)
	-- dump(checkList)
	local info = {
		userid = GameData.battleInfo.userID,
		balls = checkList,
		time = tostring(math.floor(socket.gettime() * 1000)),
	}
	send_info("battle.check_pos", info)
end

function netBattle:checkPosResp(resp)
	if resp.status == 0 or resp.status == 2 then

		if GameData.battleInfo.roleDataManager then
			GameData.battleInfo.roleDataManager.isCheck = true

			if resp.status == 2 then
				-- print("roleDataManager check pos")
				GameData.battleInfo.roleDataManager:checkPosNotify(resp)
			end
		end
	end
end


function netBattle:rank_notify( params )
	if params == nil then return end
	local name = BattleMsg.RANK_NOTIFY
	local event = {}
	event.data = params
    messageManager:dispatch(name,event)
end

function netBattle:exitBattleResp( params )
	-- if params.code == 1 then
		local name = BattleMsg.EXIT
		local event = {}
		event.data = params
	    messageManager:dispatch(name,event)
	-- end
end


function netBattle:gameOverNotify(resp)
	local name = BattleMsg.OVER
	local event = {}
	event.data = resp
    messageManager:dispatch(name,event)
end



function netBattle:foodNotify(resp)
	if GameData.battleInfo.roleDataManager then
		GameData.battleInfo.roleDataManager:foodNotify(resp)

		if resp.userid == GameData.battleInfo.userID then
			-- MsgManager:sendMsg(GameMsg.MSG_NOTIFY_FOOD, resp)
			local scene = GameData.battleScene
			if scene then
				scene:foodNotify(resp.enter, resp.leave)
			end
		end
	end
end

function netBattle:centerNotify(resp)
	if GameData.battleInfo.roleDataManager then
		GameData.battleInfo.roleDataManager:centerNotify(resp)
	end
end

function netBattle:buff_notify(params)
  
  	messageManager:sendMsg("buff_notify",params)
end 

function netBattle:exitBattle(  )
	print("exitBattle")
	local info = {
		-- userid = GameData.battleInfo.userID,
	}
	send_info("room.leave_room", info)
end

function netBattle:playTimeNotify( params )
	-- print("params.continuedTime==="..params.continuedTime)
	GameData.battleInfo.leftTime = params.continuedTime
end

function netBattle:sendVoice( info )
	print("sendVoice")
	dump(info)
	send_info("battle.upload_voice_info", info)
end

function netBattle:voiceNotify( params )
	print("voiceNotify")
	dump(params)
	local name = GameMsg.MSG_RECEIVE_VOICE 
	local event = {}
	event.data = params
    messageManager:dispatch(name,event)
	
end


return netBattle
