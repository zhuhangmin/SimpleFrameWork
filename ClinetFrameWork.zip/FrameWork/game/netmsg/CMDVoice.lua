local BaseMessageManager = require "BaseMessageManager"
local messageManager = BaseMessageManager.getInstance()

-- [REQUEST] test only
-- send: data = {url = "http://www.baidu.com"}
-- recv: data = {url = "http://www.baidu.com"}
function CMD.uploadVoiceInfo(data)
    if notTable(data) then printStack() return end
    if notString(data.url) then printStack() return end
    print("uploadVoiceInfo success")
    -- TODO send msg

end

-- [NOTIFY] test only
function CMD.voiceInfoNoitfy(data)
	if notTable(data) then printStack() return end
    if notString(data.url) then printStack() return end
    -- if notString(data.nickname) then printStack() return end

    local name = GameMsg.MSG_RECEIVE_VOICE
    local event = {}
    event.data = data
    messageManager:dispatch(name,event) 	
end