function CMD.setGmCommand(data)
    if type(data) ~= "table" then  print("setGmCommand data not table type")return end 
    -- dump(data)
    print("Gm Success")
end
