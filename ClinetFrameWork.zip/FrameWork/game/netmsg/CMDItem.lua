local BaseMessageManager = require "BaseMessageManager"
local messageManager = BaseMessageManager.getInstance()

--notify 
--all items data
function CMD.items_data(data)
    if notTable(data) then printStack() return end
    ItemData = data
end

-- [REQUEST]
-- func : convertItem
-- params : {future_item_id = future_item_id}
-- [RECVER]
function CMD.convertItem(data)
	if notTable(data) then printStack() return end
	if notNumber(data.future_item_id) then printStack() return end

	-- dump(ItemData)
    local event = {}
    event.data = data
    local name = GameMsg.MSG_SKIN_MERGE_RET
    messageManager:dispatch(name,event)
end

-- [REQUEST]
-- func : purchaseShopItem
-- params : {shop_id = shop_id, index = index, item_count = item_count}
-- [RECVER]
function CMD.purchaseShopItem(data)
  if notTable(data) then printStack() return end
  if isNil(data.index) then printStack() end

  local name = GameMsg.MSG_NEWSHOP_BUY
  messageManager:dispatch(name)
end






-----------------------------------------
-- [REQUEST]
-- func : applyItem
-- params : {item_id = item_id}
-- [RECVER]
function CMD.applyItem(data)
  if notTable(data) then printStack() return end
  if isNil(data.item_id) then printStack() end

  local event = {}
  event.data = data
  local name = GameMsg.MSG_SKIN_CHANGE_RET
  messageManager:dispatch(name,event)
end


----------------------------------
-- [UI NOITFY]
-- data = {
  -- {item_id = 40001, star_num = 11},
  -- {item_id = 40002, star_num = 12}
-- }
function CMD.itemConvertStarNotify(data)
  if notTable(data) then printStack() return end
  print("$$$$$$$$$$$$$$$$$")
  dump(data)

  local event = {}
  event.data = data
  local name = GameMsg.MSG_SKIN_REPATE
  messageManager:dispatch(name,event) 
end

function CMD.useGiftPackNotify(data)
  if notTable(data) then printStack() return end

  local name = GameMsg.MSG_CONVERT_REWARD_RSP
  messageManager:dispatch(name,event) 
end
