local BaseMessageManager = require "BaseMessageManager"
local messageManager = BaseMessageManager.getInstance()

--[NOTIFY]
--首冲状态
function CMD.charge_state_data(data)
    if notTable(data) then printStack() return end
    ChargeData = data
	dump(ChargeData)   	
   	--send msg
    local name = GameMsg.MSG_GET_AWARD_SUCC
    messageManager:dispatch(name)
end

-- 发起RMB充值请求生成订单order
-- [REQUEST] placeOrder(data)
-- data = {exchangeid = 936}
-- [RESPONSE] placeOrder(data) 
-- data = {exchangeid = 936, orderid = 128938129038 }
function CMD.placeOrder(data)
	if notTable(data) then printStack() return end
	-- data.exchangeid = 976
	if notNumber(data.exchangeid) then printStack() return end
	if isNil(data.orderid) then printStack() return end
	-- dump(data)

	ChargeData_curOrderID = data.orderid

	--send msg
	local event = {}
	event.data = data
    local name = GameMsg.MSG_GET_PAY_ORDER_ID_RET
    messageManager:dispatch(name,event)
end

--[NOTIFY] 充值成功通知
function CMD.chargeResult(data)
	if notTable(data) then printStack() return end
	if notNumber(data.exchangeid) then printStack() return end

end

-- [REQUEST] buyStar
-- data = {index = 1}
--钻石买星星
function CMD.buyStar(data)
    if notTable(data) then printStack() return end
    if notNumber(data.index) then printStack() return end
    local name = GameMsg.BUY_STAR_SUCCESS
    messageManager:dispatch(name)
end

--[NOTIFY] 充值活动成功通知
function CMD.chargeActivityResult(data)
	if notTable(data) then printStack() return end
	if notNumber(data.activity_id) then printStack() return end

	local event = {}
	event.data = data
    local name = GameMsg.MSG_CHARGEACTIVITY_RESULT
    messageManager:dispatch(name,event)
end

--[NOTIFY] 限时充值活动通知
function CMD.chargeActivtyNotify(data)
	if notTable(data) then printStack() return end
	TimeChargeData = data

    local name = GameMsg.MSG_TIMECHARGEACTIVITY_INFO
    messageManager:dispatch(name,event)
end


-- [REQUEST] placeOrderActivity
-- send：data = {activity_id = 1, exchangeid = 975}
-- resp：data = {activity_id = 1, exchangeid = 975, orderid = 12893081290381290}
-- 生成充值活动定单
function CMD.placeOrderActivity(data)
    if notTable(data) then traceError() err = -5 return err end
	if isNil(data.activity_id) then traceError() err = -1 return err end
	if isNil(data.exchangeid) then traceError() err = -1 return err end
	if isNil(data.orderid) then traceError() err = -1 return err end

	local event = {}
	event.data = data
    local name = GameMsg.MSG_GET_PAY_ACTIVITY_ORDER_ID_RET
    messageManager:dispatch(name,event)
end
