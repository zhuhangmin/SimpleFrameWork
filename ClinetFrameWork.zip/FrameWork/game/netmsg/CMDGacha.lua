local BaseMessageManager = require "BaseMessageManager"
local messageManager = BaseMessageManager.getInstance()

-- [NOTIFY]
-- UI DATA global
-- STAR_ITEM_ID = 1000000,
-- DIAMOND_ITEM_ID = 2000000,
-- data = {
--   {item_id:1000000 , item_num:1000},
--   {item_id:40002   , item_num:1},
--   {item_id:40003   , item_num:1},
--   {item_id:40004   , item_num:1},
--   {item_id:55003   , item_num:1},
-- }
function CMD.gachaResultUINotify(data)
    if notTable(data) then printStack() return end
    dump(data)
   	-- print("9999999999999999999999")
   	local event = {}
   	event.data = data

	local name = GameMsg.MSG_DO_GACHA
	messageManager:dispatch(name,event)
end

-- [NOTIFY]
function CMD.gachaNextNotify(data)
	if notTable(data) then printStack() return end
	GachaData = data
	dump(GachaData)
    
end

-- [REQUEST]
-- func : executeGacha
-- params : {gacha_type = "STAR"}
-- [RECVER]
function CMD.executeGacha(data)
  if notTable(data) then printStack() return end
  if isNil(data.gacha_type) then printStack() end

end

-- [REQUEST]
-- func : gachaDouble
-- params : {}
-- [RECVER]
function CMD.gachaDouble(data)
  if notTable(data) then printStack() return end

  print("$$$$$$$$$$$$$$$$$ 2")
  dump(data)
end


