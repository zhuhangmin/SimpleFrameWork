local BaseMessageManager = require "BaseMessageManager"
local messageManager = BaseMessageManager.getInstance()

-- [NOTIFY]
-- UI DATA global
-- STAR_ITEM_ID = 1000000,
-- DIAMOND_ITEM_ID = 2000000,
-- data = {
--   {item_id:1000000 , item_num:1000},
--   {item_id:40002   , item_num:1},
--   {item_id:40003   , item_num:1},
--   {item_id:40004   , item_num:1},
--   {item_id:55003   , item_num:1},
-- }
function CMD.getNeSign(data)
    if notTable(data) then printStack() return end
    ActivityData.ne = data
    -- messageManager:dispatch(GameMsg.SIGN_UPDATE)
end

-- [NOTIFY]
function CMD.getAcSign(data)
	 if notTable(data) then printStack() return end
    ActivityData.ac = data
    -- messageManager:dispatch(GameMsg.SIGN_UPDATE)
end


function CMD.setNeSign(data)
  	if notTable(data) then printStack() return end
   	if isNil(data.signed) then printStack() end
  	if isNil(data.able) then printStack() end
  	if isNil(data.gift_id) then printStack() end
  	ActivityData.ne.signed = data.signed
  	ActivityData.ne.able = data.able
  	local name = GameMsg.SIGN_AWARD
  	event = {}
  	event.data = data.gift_id
    messageManager:dispatch(name,event)
end

function CMD.setAcSign(data)
  	if notTable(data) then printStack() return end
  	if isNil(data.signed) then printStack() end
  	if isNil(data.able) then printStack() end
  	if isNil(data.gift_id) then printStack() end
  	ActivityData.ac.signed = data.signed
  	ActivityData.ac.able = data.able

  	local name = GameMsg.SIGN_AWARD
  	event = {}
  	event.data = data.gift_id
    messageManager:dispatch(name,event)

  
end

function CMD.basic_exist_newbie_signed_time( data )
 	if notTable(data) then printStack() return end
   	if isNil(data.exist) then printStack() return end
   	ActivityData.ne_red = data.exist

end

function CMD.basic_exist_accum_signed_time( data )
 	if notTable(data) then printStack() return end
   	if isNil(data.exist) then printStack() return end
   	ActivityData.ac_red = data.exist

end



