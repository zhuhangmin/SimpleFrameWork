local BaseMessageManager = require "BaseMessageManager"
local messageManager = BaseMessageManager.getInstance()

function CMD.seasonNotify(data)
    if notTable(data) then printStack() return end
    RankData.season = data.season
end

function CMD.upStarsNotify(data)
	  if notTable(data) then printStack() return end
    if isNil(data.stars) then printStack() end
    if isNil(data.rank) then printStack() end

    local name = BattleMsg.UP_STAR
    event = {}
    event.data = data
    messageManager:dispatch(name,event)
end

function CMD.upRankNotify(data)
  	if notTable(data) then printStack() return end
   	if isNil(data.stars) then printStack() end
  	if isNil(data.rank) then printStack() end

  	local name = BattleMsg.UP_RANK
  	event = {}
  	event.data = data
    messageManager:dispatch(name,event)
end

function CMD.downRankNotify(data)
    if notTable(data) then printStack() return end
    if isNil(data.stars) then printStack() end
    if isNil(data.rank) then printStack() end


    local name = BattleMsg.DOWN_RANK
    event = {}
    event.data = data
    messageManager:dispatch(name,event)
end

function CMD.downStarsNotify(data)
    if notTable(data) then printStack() return end
    if isNil(data.stars) then printStack() end
    if isNil(data.rank) then printStack() end

    local name = BattleMsg.DOWN_STAR
    event = {}
    event.data = data
    messageManager:dispatch(name,event)
end

function CMD.noneStarsNotify( data )
    if notTable(data) then printStack() return end

    local name = BattleMsg.NONE_STAR
    event = {}
    messageManager:dispatch(name,event)
end




