local BaseMessageManager = require "BaseMessageManager"
local messageManager = BaseMessageManager.getInstance()
local Match = class("Match")

function Match:ctor()
	self:registerProtocol()
end

function Match:registerProtocol()
  	cmsg.on("match.enter_match_resp", handler(self, self.enterMatchRsp))
  	cmsg.on("match.exit_match_resp", handler(self, self.exitMatchRsp))
    cmsg.on("match.user_count_notify",handler(self,self.userCountNotify))
    cmsg.on("room.status_notify",handler(self,self.roomStatusNotify))
end

function Match:userCountNotify( data )
    print("userCountNotify")
    dump(data)
    local event = {}
    event.data = data
    messageManager:dispatch(BattleMsg.USER_COUNT_NOTIFY,event)
end


function Match:enterMatch()
  print("enterMatch")
    local info = {
	   }
    send_info("match.enter_match", info)
end 

function Match:exitMatch()
    -- print("exitMatch")
    local info = {
	  }
    send_info("match.exit_match", info)
end 

function Match:enterMatchPeer()
    print("enterMatch")
    local info = {
    }
    send_info("match.enter_match_peer", info)
end


function Match:enterMatchRsp(params)
  	GameData.matchData = params
    print("params.status==="..params.roomInfo.status..":"..params.roomInfo.type)
  	if params.roomInfo and type(params.roomInfo.type) == "number" then 
    		GameData.roomType = params.roomInfo.type
        GameData.mode = Utils:getRoomMode(GameData.roomType)
        if params.roomInfo.status == 1 then
           messageManager:dispatch(BattleMsg.MATCH_DATA)
        end
  	end
  
end 

function Match:roomStatusNotify( params )
    dump(params)
    if params.status == 1 then
       messageManager:dispatch(BattleMsg.MATCH_DATA)
    end
end

function Match:exitMatchRsp(params)
	-- messageManager:dispatch(BattleMsg.MATCH_DATA)
  	-- messageManager:sendMsg("eixtMatchRsp",params)
end 

return Match
