local BaseMessageManager = require "BaseMessageManager"
local messageManager = BaseMessageManager.getInstance()

--一个接受服务器返回,通知，以及发送消息给服务器的基础类

local CMDBase = class("CMDBase")

function CMDBase:ctor()
	cmsg.on("form.submit_form_resp",handler(self, self.formResp))
    cmsg.on("form.form_notify",handler(self, self.formNotify))
end

function CMDBase:formNotify(notify)
    if isNil(notify) then printStack() return end
    if isNil(notify.objStr) then printStack() return end


    local data  = json.decode(notify.objStr)
    if isNil(data) then printStack() return end
    if isNil(data.func) then printStack() return end
    if isNil(data.params) then printStack() return end
    if isNil(CMD) then printStack() return end
    if isNil(CMD[data.func]) then printStack(data.func .. " function does not exist in CMD") return end
    
    CMD[data.func](data.params)

    local name = BASE_MSG.CANCEL_WAITING_MVC
    messageManager:dispatch(name)
end 

function CMDBase:formResp(resp)
    if isNil(resp) then printStack() return end
    if isNil(resp.status) then printStack() return end
    if isNil(resp.code) then printStack() return end
    if isNil(resp.msg) then printStack() return end
    if isNil(resp.objStr) then printStack() return end

    -- print("[FORM RESP]")
    -- dump(resp)
    -- print("")

    if resp.status == MSG_STATE.FAIL then
        local name = BASE_MSG.CANCEL_WAITING_MVC
        messageManager:dispatch(name)    

        local name = BASE_MSG.NET_RESP_ERROR
        local event = {}
        event.data = {}
        event.data.code = resp.code
        event.data.msg = resp.msg
        messageManager:dispatch(name,event)
        return 
    end 
    
    if isEmptyString(resp.objStr) then

    else
        local data  = json.decode(resp.objStr)
        if isNil(data) then printStack() return end
        if isNil(data.func) then printStack() return end
        if isNil(data.params) then printStack() return end
        if isNil(CMD) then printStack() return end
        if isNil(CMD[data.func]) then printStack(data.func) return end
    
        CMD[data.func](data.params)

 
    end

        local name = BASE_MSG.CANCEL_WAITING_MVC
        messageManager:dispatch(name)    
end 

function CMDBase:submitForm(func, params)
    if notString(func) then printStack(func) return end
    if isNil(params) then printStack(params) return end

    local data = {}
    data.func = func
    data.params = params

    -- print("[SUBMIT FORM]")
    -- dump(data)
    -- print("")

    local sendStr = json.encode(data)
    local info = {
        sendStr = sendStr,
    }
    send_info("form.submit_form", info)
end 

return CMDBase