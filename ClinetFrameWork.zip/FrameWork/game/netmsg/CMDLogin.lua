local BaseMessageManager = require "BaseMessageManager"
local messageManager = BaseMessageManager.getInstance()
--notify 
function CMD.repeatLogin(data)
    if notTable(data) then printStack() return end
    local name = GameMsg.REPEAR_LOGIN
    messageManager:dispatch(name)
end

function CMD.gameContinueNotify(data)
    if notTable(data) then printStack() return end
    ReconnectData = data
    dump(ReconnectData)
end

