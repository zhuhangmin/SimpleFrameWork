local BaseMessageManager = require "BaseMessageManager"
local messageManager = BaseMessageManager.getInstance()

function CMD.notifyConfig(data)
    if notTable(data) then printStack() return end
    local name = BASE_MSG.NOTIFY_CONFIG
    local event = {}
    event.data = data
    messageManager:dispatch(name, event)
end