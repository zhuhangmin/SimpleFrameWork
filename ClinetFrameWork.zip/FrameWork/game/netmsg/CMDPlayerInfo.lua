local BaseMessageManager = require "BaseMessageManager"
local messageManager = BaseMessageManager.getInstance()

function CMD.system_data(data)
    if notTable(data) then printStack() return end
    PlayerDataSystem = data

    local name = GameMsg.GET_PLAYER_SYSTEM_DATA
    messageManager:dispatch(name)
end

function CMD.basic_data(data)
    if notTable(data) then printStack() return end
    PlayerDataBasic = data
    PlayerDataBasic.nickname = string.urldecode(PlayerDataBasic.nickname)
    local name = GameMsg.GET_PLAYER_DATA
    messageManager:dispatch(name)
end

--[REQUEST]
--params 
--params.gender 
--params.year 
--params.month 
--params.day 
--params.area 
function CMD.setPlayerInfoData(data)
    if notTable(data) then printStack() return end
    local name = GameMsg.SET_PLAYER_INFO_DATA
    messageManager:dispatch(name)
end

--[NOTIFY]
function CMD.basic_custom_data(data)
    if notTable(data) then printStack() return end
    local json = cc.load('json').json
    local customData     = json.decode(data.custom)
    PlayerDataCustom = customData

    --SEND MSG TODO
end

function CMD.setPlayerInfoData(data)
    if notTable(data) then printStack() return end
    local name = GameMsg.SET_PLAYER_INFO_DATA
    messageManager:dispatch(name)
end

--[REQUEST]
-- send: data = {nickname = nickname}
-- resp: data = {nickname = nickname}
function CMD.setPlayerNickName(data)
    if notTable(data) then printStack() return end
 
    --TODO SEND MSG
    local name = GameMsg.MSG_MODIFY_PLATFORM_NICKNAME
    messageManager:dispatch(name)
end

--[NOTIFY]
local STATUS_OPEN = 1
local STATUS_CLOSED = 0
function CMD.basic_custom_status(data)
    if notTable(data) then printStack() return end
    local ADManager = require("advertise.ADManager"):getInstance()
    if ADManager == nil then print("has no sdk") return end
    if ADManager:isAdValid() == 0 then print("has no ad") return end
    local AD_available_num = data.AD_available_num
    dump(data)    
    if AD_available_num == STATUS_OPEN then 
        print("显示广告模块")
        PlayerData_AD_show_look_btn = true
    elseif AD_available_num == STATUS_CLOSED then 
        print("隐藏广告模块")
        PlayerData_AD_show_look_btn = false
    end

    -- local name = GameMsg.SHOW_AD_LOOK_BTN
    -- messageManager:dispatch(name)

    local lottery_num = data.lottery_num
    if lottery_num == STATUS_OPEN then 
        print("可以抽奖")
        PlayerData_AD_show_loot_btn = true
    elseif lottery_num == STATUS_CLOSED then 
        print("无法抽奖")
        PlayerData_AD_show_loot_btn = false
    end
    local name = GameMsg.SHOW_AD_LOOT_BTN
    messageManager:dispatch(name)
   
    if lottery_num == STATUS_OPEN or AD_available_num == STATUS_OPEN then 
        PlayerData_AD_show_enter_btn = true
    else
        PlayerData_AD_show_enter_btn = false
    end
    local name = GameMsg.SHOW_AD_ENTER_BTN
    messageManager:dispatch(name)

    
end