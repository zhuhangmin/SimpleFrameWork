local BaseMessageManager = require "BaseMessageManager"
local messageManager = BaseMessageManager.getInstance()

-- [REQUEST] guideStep
-- send：data = {step = 1}
-- resp：data = {step = 1}
-- 记录新手引导步骤
function CMD.guideStep(data)
    if notTable(data) then traceError() err = -5 return err end
	if isNil(data.step) then traceError() err = -1 return err end
	-- TODO SEND MSG
    local name = GameMsg.MSG_GUIDE_STEP_RET
    messageManager:dispatch(name)
end
