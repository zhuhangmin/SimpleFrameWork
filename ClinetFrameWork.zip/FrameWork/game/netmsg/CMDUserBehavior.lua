function CMD.uploadUserBehavior(data)
    if notTable(data) then printStack() return end
   
   
end