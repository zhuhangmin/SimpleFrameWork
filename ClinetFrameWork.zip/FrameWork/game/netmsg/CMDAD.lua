local BaseMessageManager = require "BaseMessageManager"
local messageManager = BaseMessageManager.getInstance()

-- 广告播放正常结束
-- [REQUEST]
-- func : ADPlayEnd
-- send data = {}
-- recv data = {}
function CMD.ADPlayEnd(data)
	print("ADPlayEnd")
    if notTable(data) then printStack() return end
end

-- 转盘抽奖 
-- REQUEST
-- func : lottery
-- send data = {}
-- recv data = {index = 1} -- 抽中几号奖品
function CMD.lottery(data)
	print("lottery")
	dump(data)
	if notTable(data) then printStack() return end
  	if isNil(data.index) then printStack() return end
	local event = {}
   	event.data = data

	local name = GameMsg.DO_LOTTERY
	messageManager:dispatch(name,event)
end


-- 广告埋点
-- REQUEST
-- func : ADEventTracking
-- send data = {event_name = ""}
-- recv data = {event_name = ""}

-- event_name =  "open_ad"   	打开广告埋点
-- event_name =  "beg_ad"   	播放广告埋点
-- event_name =  "end_ad"  		结束广告埋点
-- event_name =  "ad_reward"  	领取广告奖励埋点

function CMD.ADEventTracking(data)
	if notTable(data) then printStack() return end
end
