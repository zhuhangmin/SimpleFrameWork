local BaseMessageManager = require "BaseMessageManager"
local messageManager = BaseMessageManager.getInstance()

-- [NOTIFY]
function CMD.culturesNotify(data)
    if notTable(data) then printStack() return end
    CultureData = data
    dump(CultureData)

    local name = GameMsg.MSG_CULTURE_UPDATE
    messageManager:dispatch(name)
end

-- [NOTIFY]
function CMD.new_culturesNotify(data)
	if notTable(data) then printStack() return end
	dump(data)

	local event = {}
	event.data = data
    local name = GameMsg.MSG_GET_CULTURE_RET
    messageManager:dispatch(name,event)
end

function CMD.startCulture(data)
    if notTable(data) then printStack() return end
    dump(data)

    local name = GameMsg.MSG_START_CULTURE_RET
    messageManager:dispatch(name)
end

function CMD.fastCulture(data)
    if notTable(data) then printStack() return end
    dump(data)

end

function CMD.receiveReward(data)
    if notTable(data) then printStack() return end
    dump(data)
    
    local event = {}
    event.data = data
    local name = GameMsg.MSG_GET_CULTURE_REWARD_RET
    messageManager:dispatch(name,event)
end