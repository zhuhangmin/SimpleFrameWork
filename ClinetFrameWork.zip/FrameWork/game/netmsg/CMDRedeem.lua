local BaseMessageManager = require "BaseMessageManager"
local messageManager = BaseMessageManager.getInstance()

-- [REQUEST] redeem
-- send: data = {code = "234jnosd9"}
-- recv: data = {code = "234jnosd9"}
--兑换码
function CMD.redeem(data)
	dump(data)
    if notTable(data) then printStack() return end
    if notString(data.code) then printStack() return end
    if notNumber(data.gift_id) then printStack() return end
    -- TODO send msg

    local event = {}
    event.data = data
    local name = GameMsg.MSG_GET_REDEEM_REWARD_RET
    messageManager:dispatch(name,event)
end

