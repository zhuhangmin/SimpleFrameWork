local BaseMessageManager = require "BaseMessageManager"
local messageManager = BaseMessageManager.getInstance()

function CMD.doPraise(data)
	print("data doPraise")
    if notTable(data) then printStack() return end
    local name = GameMsg.DO_PRAISE
    local event = {}
    event.data = data
    messageManager:dispatch(name, event)
end