local EngineView = require "EngineView"
local ChargeShopView = class("ChargeShopView", EngineView)

local csbFilePath = "Shop.csb"
-- RICH_NODE = 2000

function ChargeShopView:ctor(node)
	ChargeShopView.super.ctor(self, node)
end

function ChargeShopView:onCreate(param)
	ChargeShopView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	if isNil(csbNode) then printStack() return end
	
	self:getNode():addChild(csbNode)

end

return ChargeShopView





