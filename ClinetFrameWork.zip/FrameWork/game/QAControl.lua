local EngineControl = require  "EngineControl"
local QAControl = class("QAControl", EngineControl)
local TEST_URL = "http://mboard.tcy365.org:1505"
local GET_KEY_API = "/api/Guest/GetGuestKeyId"
local SEND_API = "/api/TalkMessageBoard/LeaveMessage"
local GET_TALK_API = "/api/Message/GetTalkMessage"
local Config_sourceId = 14
local ONLINE_URL = "https://mboard.tcy365.com"
local ITEM_LIST = { "res/Help_dialog1.csb","res/Help_dialog2.csb","res/Help_notice.csb"}
-- local ITEM_LIST = { "res/MailItem.csb","res/MailItem.csb","res/MailItem.csb"}

local LISTVIEW = "ListView_1"

--LUA MSGS
local LUA_MSGS = {
    GameMsg.SIGN_AWARD,
    GameMsg.SIGN_UPDATE,
    GameMsg.MSG_CONVERT_REWARD_RSP,
    GameMsg.MSG_GET_REDEEM_REWARD_RET
}

--SYSTEM MSGS
local BTN_RETURN 	= "Button_return"
local BTN_QA 		= "Button_QA"
local BTN_CS 		= "Button_CS"
local BTN_SEND 		= "Button_send"
local PANELS = {"Panel_QA","Panel_CS"}

local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_QA,
	BTN_CS,
	BTN_SEND,
}


local KEY_REWARD = "reward%d"
local KEY_NUM = "num%d"

function QAControl:ctor(model, view)
	QAControl.super.ctor(self, model, view,LUA_MSGS,SYSTEM_MSGS)
	-- self:setLuaMsgs(LUA_MSGS)
	-- self:setSystemMsgs(SYSTEM_MSGS)
end

function QAControl:onCreate(param)
	QAControl.super.onCreate(self, param)
	
end

function QAControl:onEnter( param )
	self.deviceUtils = DeviceUtils:getInstance()
	if DEBUG == 1 or DEBUG == 2 then
		self.useUrl = TEST_URL
	else
		self.useUrl = ONLINE_URL
	end

	self:sendGetKey()
	self:initUI()
end


function QAControl:initUI( ... )
	self:setTagBtn(1)

	
	self:setEditText()

	local function callback( ... )
		self:getQuestion()
	end

    local delay = cc.DelayTime:create(10)
    local callfunc = cc.CallFunc:create(callback)
    local sequence = cc.Sequence:create(delay, callfunc)
    local action = cc.RepeatForever:create(sequence)
    self:getNode():runAction(action)
end

function QAControl:setTagBtn( tag )
	local btnList = {BTN_QA,BTN_CS} 
	self.model.curTag = tag
	for i = 1, #btnList, 1 do
		local btn = self:getChildNode(btnList[i])
		setButtonEnable(btn,i ~= tag)
		if i == tag then
			self:getChildNode(PANELS[i]):setVisible(true)
		else
			self:getChildNode(PANELS[i]):setVisible(false)
		end
	end
end

function QAControl:setListView( list )
	local listView = self:getChildNode(LISTVIEW)
	local content = listView:getContentSize()
	local itemNodes = {}
	local height = 50
	local x, y = 50,-110
	if #list == self.listCount then return end
	listView:removeAllChildren()
	print("tostring."..tostring(cc.CSLoader:createNode("res/Help_dialog1.csb")))
	for i=1,(#list+1) do
		local item = ccui.Widget:create()
		item:setContentSize(cc.size(content.width,110))
		height = height + y
		dump(list)
		if list[i] then 
			local item_type = math.floor(list[i].Sender / 10)

			local node = cc.CSLoader:createNode(ITEM_LIST[item_type])
			if item_type == 1 then
				node:setPosition(x,50)
			else
				node:setPosition(content.width-x,50)
			end

			local label_q = node:getChildByName("Text_question")
			-- label_q:setMaxLineWidth(0)
			-- label_q:setLineBreakWithoutSpace(true)
			local str = list[i].MessageContent.Text
			local size = self:getLabelSize(str)
			label_q:setContentSize(size)
			label_q:setString(str)
			local scale_img = node:getChildByName("Image_question_bg")


			local l_size = label_q:getContentSize()
			scale_img:setContentSize(size)

			print("l_size==="..l_size.width..";"..tostring(l_size.height))
			item:addChild(node)
			local send_time = list[i].SentTime
		 	local t = os.date("%Y-%m-%d %H:%M:%S",send_time)
		 	local time_label = node:getChildByName("Text_time")
		 	if time_label then
		 		time_label:setString(t)
		 	end
		else
			local node = cc.CSLoader:createNode(ITEM_LIST[3])
			print("node==="..i..";"..tostring(node))
			node:setPosition(content.width/2,50)
			item:addChild(node)
		end

		print("height==="..height)

		listView:pushBackCustomItem(item)

	end
	-- listView:setContentSize(cc.size(content.width, math.abs(height)+100))
	-- listView:setInnerContainerSize(cc.size(content.width, math.abs(height)+1000))
	listView:jumpToBottom()
end

function QAControl:getLabelSize( text )
	local count = 0  
	for uchar in string.gfind(text, "([%z\1-\127\194-\244][\128-\191]*)") do   
		if #uchar ~= 1 then  
		    count = count +1.7 
		else  
		    count = count +1  
		end  
	end  
	return cc.size( 40 + count * 15 , 53 )
end


function QAControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:send(BASE_MSG.GOHOME)
	end

	if senderName == BTN_QA then
		self:setTagBtn(1)
	end

	if senderName == BTN_CS then
		self:setTagBtn(2)
	end

	if senderName == BTN_SEND then
		self:sendQuestion()	
	end
end

function QAControl:recv(event)
	if isNil(event) then printStack() end
	if isNil(event.name) then printStack() end
	if isNil(event.data) then printStack() end
	print("QAControl:recv name = " .. tostring(event.name))
	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

function QAControl:setEditText( ... )
 	local TextField_input = self:getChildNode("TextField_input")
	if TextField_input then
		TextField_input:setVisible(false)
		self._IntPutBox = ccui.EditBox:create(TextField_input:getContentSize(), "js/js_bg4.png")
		self._IntPutBox:setPosition(TextField_input:getPosition())
		self._IntPutBox:setAnchorPoint(0,1)
		self._IntPutBox.setTextColor = TextField_input.setFontColor
		self._IntPutBox:setFontColor(display.COLOR_BLACK)
		self._IntPutBox:setFontSize(TextField_input:getFontSize())
		self._IntPutBox:setPlaceHolder(TextField_input:getPlaceHolder())
		self._IntPutBox:setPlaceholderFontSize(TextField_input:getFontSize())
		self._IntPutBox:setPlaceholderFontColor(display.COLOR_BLACK)
		self._IntPutBox:setFontName(TextField_input:getFontName())
        -- self._IntPutBox:setMaxLength(DConfig.MAX_DECLARATION_LENGTH)
        self._IntPutBox:setContentSize(TextField_input:getContentSize())
        self._IntPutBox:registerScriptEditBoxHandler(handler(self, self.onEditEvent)) 
        -- if self._Declaration ~= "" then
        --    -- local str = self:getEditboxString(self._Declaration)--获取处理后的字符串
        --     self._IntPutBox:setText(self._Declaration)
        -- end
         
       --  self._IntPutBox:setText("sdnhaklnd".."\nss是ass\nssda\nssss")
		self:getChildNode("Panel_CS"):addChild(self._IntPutBox,0)
	end
end

function QAControl:onEditEvent(name, sender)
	print("name ==="..tostring(name)..":"..tostring(sender))
	if name == "changed" then
		self.model.sendText = sender:getText()

		if self.model.sendText ~= "" then
            sender:setText(self.model.sendText)
			-- if Utils:getIsHideName(self.sendText) then
			--  	self:addTip("内容包含非法字符！")
			-- end
		end
	end
end

function QAControl:getQuestion( ... )
	if self.model.GuestKeyId and self.model.SecurityCode then
	
		local messageInfo = {}
		-- messageInfo.time = self.model.enterTime
		-- messageInfo.guestKeyId = self.model.GuestKeyId

		local function netBack( resp )
			dump(resp.response)
			if resp.response then
				local data = json.decode(resp.response)
				if data.StatusCode == 0 then
					local list = data.Data
					self:setListView(list)
				else
					if data.Message ~= "无信息" then
						self:addTip(data.Message)
					end
				end
			end
		end 
		local head = {guestKeyId=self.model.GuestKeyId,securityCode=self.model.SecurityCode}
		local api = GET_TALK_API .."?guestKeyId="..self.model.GuestKeyId.."&".."time="..self.model.enterTime
		HttpUtils.httpPost(self.useUrl, messageInfo, netBack, api,head)
	
	else
		self:addTip("客服连接失败,请稍后再尝试")
	end
end

function QAControl:sendQuestion( ... )
	if self.model.GuestKeyId and self.model.SecurityCode then
		local _,count = string.gsub(self.model.sendText, "[^\128-\193]", "")  
		print("count==="..count)
		if self.model.sendText == "" then
			self:addTip("请输入您的问题")
		elseif count < 8 then
			self:addTip("请输入至少8个字符")
		else
			local messageInfo = {}
			messageInfo.messageContent = {imageUrl = {} , text = self.model.sendText}
			messageInfo.contentType = 1
			messageInfo.sentTime = 0
			messageInfo.Sender = 1
			messageInfo.guestKeyId = self.model.GuestKeyId

			local function netBack( resp )
				if resp.response then
					local data = json.decode(resp.response)
					if data.StatusCode == 0 then
						self:getQuestion()
					else
						self:addTip(data.Message)
					end
				end
			end 
			local head = {guestKeyId=self.model.GuestKeyId,securityCode=self.model.SecurityCode}

			HttpUtils.httpPost(self.useUrl, messageInfo, netBack, SEND_API,head)
		end
	else
		self:addTip("客服连接失败,请稍后再尝试")
	end
end

function QAControl:sendGetKey( ... )
 	local userPlugin = plugin.AgentManager:getInstance():getUserPlugin()
	local info = {}
	info.sourceId = Config_sourceId
	info.channelId = BusinessUtils:getInstance():getClientChannelId()
	info.gameId = Constant.GAME_ID
	info.appId = Constant.GAME_ID
	info.appVersion = self:getGameVersion()
	info.hardsign = self:getHardSign()
	info.mobileBrand = self.deviceUtils:getPhoneBrand()
	info.mobileModel = self.deviceUtils:getPhoneModel()
	info.userId = userPlugin:getUserID() or 0
	info.userName = PlayerDataBasic.nickname or ""
	info.classId = PlayerDataBasic.id or ""
	info.osVersion = self.deviceUtils:getSystemVersion()
	info.mobileOS = self:getSysytem()
	info.userIp = "192.168.1.1"
	self:sendNet(GET_KEY_API,info)
end



--获取系统信息
function QAControl:getSysytem()
	if device.platform == "ios" then
		return "IOS"
	elseif device.platform == "android" then
		return "Android"
	elseif device.platform == "windows" then
		return "Simulator"
	else
		return "Unknown"
	end
end


--获取游戏版本
function QAControl:getGameVersion()
	local data = cc.FileUtils:getInstance():getStringFromFile("AppConfig.json")
	data = json.decode(data)
	return data.version
end

function QAControl:getHardSign()
	local imeiID = self.deviceUtils:getIMEI()
	local systemID = self.deviceUtils:getSystemId()
	local wifiID = self.deviceUtils:getMacAddress()
	wifiID = wifiID .. string.rep("0", 31 - string.len(wifiID))
	local hardSignStr = string.format("%s%s%s", imeiID, systemID, wifiID)
	local hardSign = MCCrypto:md5(hardSignStr, string.len(hardSignStr))
	print("hardSign==="..tostring(hardSign))
	return hardSign
end

function QAControl:sendNet( api,params )
	local function netBack( resp )
		if resp and resp.response then
			dump(json.decode(resp.response))
			local data = json.decode(resp.response)
			if data.StatusCode == 0 then
				self.model.GuestKeyId = data.Data.GuestKeyId
				self.model.SecurityCode = data.Data.SecurityCode
				self:getQuestion()
			else
				self:addTip("客服连接失败")
			end
		end
	end 

	HttpUtils.httpPost(self.useUrl, params, netBack, api)
end



return QAControl;