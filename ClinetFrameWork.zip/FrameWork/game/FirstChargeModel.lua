local EngineModel = require "EngineModel"
local FirstChargeModel = class("FirstChargeModel", EngineModel)

function FirstChargeModel:ctor(data)
	FirstChargeModel.super.ctor(self, data)
end

function FirstChargeModel:onCreate(param)
	FirstChargeModel.super.onCreate(self, param)

	self:setCallback(param.callback)
end

function FirstChargeModel:getCallback()
	return self.callback
end

function FirstChargeModel:setCallback(callback)
	self.callback = callback
end

return FirstChargeModel

