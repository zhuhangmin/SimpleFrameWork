local EngineModel = require "EngineModel"
local BattleOverModel = class("BattleOverModel", EngineModel)

function BattleOverModel:onCreate( data )
	BattleOverModel.super.onCreate(self, data)
end


function BattleOverModel:ctor(data)
	BattleOverModel.super.ctor(self, data)
end

function BattleOverModel:onEnter( data )
	self.netData = data
end


return BattleOverModel; 