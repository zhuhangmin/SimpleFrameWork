local EngineModel = require "EngineModel"
local QAModel = class("QAModel", EngineModel)

function QAModel:onCreate( data )
	QAModel.super.onCreate(self, data)
	self.curTag = 1
end


function QAModel:ctor(data)
	QAModel.super.ctor(self, data)
end

function QAModel:onEnter( data )
	self.listCount = 0
	self.count = 0
	self.GuestKeyId = nil
	self.SecurityCode = nil
	self.sendText = ""
	self.enterTime = os.time() - 86400
end

return QAModel; 