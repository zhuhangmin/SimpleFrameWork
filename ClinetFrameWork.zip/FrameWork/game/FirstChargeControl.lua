local EngineControl = require  "EngineControl"
local FirstChargeControl = class("FirstChargeControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	GameMsg.MSG_GET_PAY_ACTIVITY_ORDER_ID_RET,
}

--SYSTEM MSGS
local BTN_RETURN = "Button_close"
local BTN_BUY = "Button_buy"
local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_BUY
}

--OTHER NODE
local IMG_SKIN = "Image_skin"
local IMG_REWARD = "Node_reward%d"
local TEXT_NUM = "reward_amount"
local TEXT_NAME = "Text_skin_name"
local KEY_REWARD = "reward%d"
local KEY_NUM = "num%d"
local ACTIVITY_ID = 1

function FirstChargeControl:ctor(model, view)
	FirstChargeControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function FirstChargeControl:onCreate(param)
	FirstChargeControl.super.onCreate(self, param)
	if isNil(param) then printStack() end

	local action = cc.CSLoader:createTimeline("res/FirstCharge.csb")
	self:getNode():runAction(action)
	action:gotoFrameAndPlay(0, 24, true)

	self:initRewards()
end

function FirstChargeControl:initRewards()
	local chargeActivityInfo = self:getConfigRecord("chargeActivty", ACTIVITY_ID)
	if isNil(chargeActivityInfo) then printStack() end

	local giftInfo = self:getConfigRecord("giftPack", chargeActivityInfo.gift_id)
	if isNil(giftInfo) then printStack() end	

	local index = 1
	for i=1,5 do
		local keyReward = string.format(KEY_REWARD,i)
		if notNumber(giftInfo[keyReward]) then printStack() return end

		local keyNum = string.format(KEY_NUM,i)
		if notNumber(giftInfo[keyNum]) then printStack() return end

		local itemID = giftInfo[keyReward]
		local itemNum = giftInfo[keyNum]

		local isItem = (itemID~=0 and itemNum~=0)
		if isItem then
	        local itemConfig= self:getTable("item")
	        if isNil(itemConfig) then printStack() end	

	        local itemInfo = itemConfig[itemID]
	        if itemInfo and itemInfo.type == "SKIN" then
				local image_skin = self:getChildNode(IMG_SKIN)
				if isNil(image_skin) then printStack() end
				image_skin:setScale(1.5)

				setImgIconById(image_skin, itemID )
				image_skin:setTouchEnabled(true)

				local text_skin_name = self:getChildNode(TEXT_NAME)
				if isNil(text_skin_name) then printStack() end

				text_skin_name:ignoreContentAdaptWithSize(false)
				text_skin_name:setString(itemInfo.name)
	        else
				local imgReward = self:getChildNode(string.format(IMG_REWARD,index))
				if isNil(imgReward) then printStack() end

				addItmeNode(imgReward,itemID,itemNum)
				index = index + 1
			end
		end
	end
end

function FirstChargeControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		local callback = self:getModel():getCallback()
		if callback then
			callback()
		end

		self:detachFromParent()
	end

	if senderName == BTN_BUY then
		local chargeActivityInfo = self:getConfigRecord("chargeActivty", ACTIVITY_ID)
		if isNil(chargeActivityInfo) then printStack() end

		local exchangeid = 0
		if PlayerDataSystem.device_type == 1 then --ANDROID
			exchangeid = chargeActivityInfo.android_exchangeid
		elseif PlayerDataSystem.device_type == 2 then --IOS
			exchangeid = chargeActivityInfo.apple_exchangeid
		end

		--@zhuhangmin 20180530 任意第一次充值都会触发首冲，不用记录活动id
		local name = "game.ChargeShop"
		local modelParam = {pageIndex = 2}
		local data = buildMsgData(name, modelParam)
		self:send(BASE_MSG.PUSH, data)
	end
end

function FirstChargeControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

return FirstChargeControl


