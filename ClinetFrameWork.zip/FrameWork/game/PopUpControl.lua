local EngineControl = require  "EngineControl"
local PopUpControl = class("PopUpControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
}

--SYSTEM MSGS
local BTN_CANCEL = "Button_cancel"
local BTN_CONFIRM = "Button_confirm"
local SYSTEM_MSGS = {
	BTN_CANCEL,
	BTN_CONFIRM,
}

--LABLES
local LBL_CONTENT = "Text_content"


function PopUpControl:ctor(model, view)
	PopUpControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)
end

function PopUpControl:onCreate(param)
	PopUpControl.super.onCreate(self, param)
	if isNil(param) then printStack() end

	local csbNode = self:getChildNode(POP_CSB_NODE)
	if isNil(csbNode) then printStack() return end
	
	local content = self:getChildNode(LBL_CONTENT)
	if isNil(content) then printStack() return end

	local model = self:getModel()
	local contentStr = model:getContentStr()
	if isNil(contentStr) then printStack() return end
	content:setString(contentStr)

	local cancelBtnTitle = model:getCancelBtnTitle()
	local cancelBtn = self:getChildNode(BTN_CANCEL)
	cancelBtn:setTitleText(cancelBtnTitle)
	if isEmptyString(cancelBtnTitle) then
		cancelBtn:setVisible(false)
		confirmBtn:setPositionX(contentSize.width / 2)
	end

	local confirmBtnTitle = model:getConfirmBtnTitle()
	local confirmBtn = self:getChildNode(BTN_CONFIRM)
	confirmBtn:setTitleText(confirmBtnTitle)
	if isEmptyString(confirmBtnTitle) then
		confirmBtn:setVisible(false)
		cancelBtn:setPositionX(contentSize.width / 2)
	end
end

function PopUpControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	local model = self:getModel()
	local csbNode = self:getChildNode(POP_CSB_NODE)

	if senderName == BTN_CANCEL then		
		local cancelCB = model:getCancelCB()
		if isNil(cancelCB) then printStack() return end
		cancelCB()	
		self:detachFromParent()
	end

	if senderName == BTN_CONFIRM then
		local confirmCB = model:getConfitmCB()
		if isNil(confirmCB) then printStack() return end
		confirmCB()	
		self:detachFromParent()
	end
end

function PopUpControl:recv(event)
	self.super.recv(self, event)
	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

return PopUpControl


