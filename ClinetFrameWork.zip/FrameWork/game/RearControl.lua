local EngineControl = require  "EngineControl"
local RearControl = class("RearControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
}

--SYSTEM MSGS
local SYSTEM_MSGS = {
}

function RearControl:ctor(model, view)
	RearControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)
end

function RearControl:recv(event)
	
end

return RearControl


