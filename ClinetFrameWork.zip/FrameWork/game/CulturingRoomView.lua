local EngineView = require "EngineView"
local CulturingRoomView = class("CulturingRoomView", EngineView)

local csbFilePath = "res/CulturingRoom.csb"
CULTURINGROOM_CSB_NODE = 1000

function CulturingRoomView:ctor(node)
	CulturingRoomView.super.ctor(self, node)
end

function CulturingRoomView:onCreate(param)
	CulturingRoomView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	csbNode:setTag(CULTURINGROOM_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return CulturingRoomView





