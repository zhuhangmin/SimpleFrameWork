local EngineModel = require "EngineModel"
local BattleModel = class("BattleModel",EngineModel)
local Queue = require "Queue"

function BattleModel:ctor( data )
	BattleModel.super.ctor(self, data)
	self.gridList = nil
	self.fieldScale = 1
	self.queue = {}
end

function BattleModel:onEnter(  )
	BattleModel.super.onEnter(self, param)
end

function BattleModel:onCreate(param)
	BattleModel.super.onCreate(self, param)
	local queue = Queue.create()
	self:setQueue(queue)
end

function BattleModel:getQueue()
	return self.queue
end

function BattleModel:setQueue(queue)
	self.queue = queue
end

function BattleModel:getGridList( ... )
	return self.gridList 
end

function BattleModel:setGridList( parameter )
	if type(parameter) ~= "table" then return end
	self.gridList = parameter
end

function BattleModel:getFieldScale( ... )
	return self.fieldScale
end

function BattleModel:setFieldScale( parameter )
	if type(parameter) ~= "number" then return end
	self.fieldScale = parameter
end


return BattleModel