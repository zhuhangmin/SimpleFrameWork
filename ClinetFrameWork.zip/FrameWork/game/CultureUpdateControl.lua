local EngineControl = require  "EngineControl"
local CultureUpdateControl = class("CultureUpdateControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
}

--SYSTEM MSGS
local BTN_RETURN = "Button_close"
local BTN_UPDATE = "Button_Update"
local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_UPDATE
}

function CultureUpdateControl:ctor(model, view)
	CultureUpdateControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function CultureUpdateControl:onCreate(param)
	CultureUpdateControl.super.onCreate(self, param)
	if isNil(param) then printStack() end

	self:setUpdateInfo()
end

function CultureUpdateControl:setUpdateInfo()
	local itemConfig = self:getTable("item")
	if isNil(itemConfig) then printStack() return end

	local itemID = self:getModel():getItemID()
	if isNil(itemID) then printStack() return end

	local itemInfo = itemConfig[itemID]
	if isNil(itemInfo) then printStack() return end

	local nextItemID = itemInfo.post_order
	self:getModel():setNextItemID(nextItemID)
	local nextItemInfo = itemConfig[nextItemID]
	if isNil(nextItemInfo) then printStack() return end

	local compound = nextItemInfo.compound
	local synthesisConfig = self:getTable("synthesis")
	local synthesisInfo = synthesisConfig[compound]
	local text_Count = self:getChildNode("Text_Count")
	local id = synthesisInfo.item1
	local needNum = synthesisInfo.num1
	local curNum = getItemCountById(id)
	text_Count:setString(curNum.."/"..needNum)

	local btn_update = self:getChildNode(BTN_UPDATE)
	setButtonEnable(btn_update,curNum>=needNum)

	local text_Name_Before = self:getChildNode("Text_Name_Before")
	if isNil(text_Name_Before) then printStack() return end
	text_Name_Before:setString(itemInfo.name)

	local text_Name_After = self:getChildNode("Text_Name_After")
	if isNil(text_Name_After) then printStack() return end
	text_Name_After:setString(nextItemInfo.name)
	
	local node_item = self:getChildNode("Node_item")
	if isNil(node_item) then printStack() return end
	addItmeNode(node_item,id)

	local node_before = self:getChildNode("Node_Culture_Before")
	if isNil(node_before) then printStack() return end

	local armature = ccs.Armature:create("lingyexunhuan")
	armature:getAnimation():play(itemInfo.img, -1, 1)
	node_before:addChild(armature)

	local node_after = self:getChildNode("Node_Culture_After")
	if isNil(node_after) then printStack() return end

	local armature = ccs.Armature:create("lingyexunhuan")
	armature:getAnimation():play(nextItemInfo.img, -1, 1)
	node_after:addChild(armature)
end

function CultureUpdateControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:detachFromParent()
	end

	if senderName == BTN_UPDATE then
		local nextItemID = self:getModel():getNextItemID()
		if isNil(nextItemID) then printStack() return end

		local index = self:getModel():getIndex()
		if isNil(index) then printStack() return end

		self:submitFormWait("convertItem", {index = index,future_item_id = nextItemID})

		self:detachFromParent()
	end
end

function CultureUpdateControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

return CultureUpdateControl


