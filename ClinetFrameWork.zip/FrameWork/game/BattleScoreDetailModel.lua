local EngineModel = require "EngineModel"
local BattleScoreDetailModel = class("BattleScoreDetailModel", EngineModel)

function BattleScoreDetailModel:onCreate( data )
	BattleScoreDetailModel.super.onCreate(self, data)
end


function BattleScoreDetailModel:ctor(data)
	BattleScoreDetailModel.super.ctor(self, data)
end


return BattleScoreDetailModel; 