local EngineModel = require "EngineModel"
local SkinLevelModel = class("SkinLevelModel", EngineModel)

function SkinLevelModel:ctor(data)
	SkinLevelModel.super.ctor(self, data)

	self.leftskinindex = 0
	self.leftskindata = {}
end

function SkinLevelModel:onCreate(param)
	SkinLevelModel.super.onCreate(self, param)

	if notNumber(param.leftskinindex) then printStack() return end
	self:setLeftskinindex(param.leftskinindex)

	if isNil(param.leftskindata) then printStack() return end
	self:setLeftskindata(param.leftskindata)
end

function SkinLevelModel:getLeftskinindex()
	return self.leftskinindex
end

function SkinLevelModel:setLeftskinindex(leftskinindex)
	self.leftskinindex = leftskinindex
end

function SkinLevelModel:getLeftskindata()
	return self.leftskindata
end

function SkinLevelModel:setLeftskindata(leftskindata)
	self.leftskindata = leftskindata
end

return SkinLevelModel