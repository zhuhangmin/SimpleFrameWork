local EngineControl = require  "EngineControl"
local GachaRewardControl = class("GachaRewardControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
	GameMsg.MSG_SKIN_REPATE
}

--SYSTEM MSGS
local BTN_RETURN = "Panel_1"
local BTN_AGAIN = "Button_again"
local BTN_DOUBLE = "Button_double"
local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_AGAIN,
	BTN_DOUBLE
}

--OTHER NODE
local SPRITE_DIAMONE = "Sprite_diamond"
local SPRITE_TITLESKIN2 = "Sprite_title_skin2"
local TEXT_AGAIN = "Text_again"
local TITLE_LUCKY = "本次必得皮肤"
local TITLE_VERYLUCKY = "本次必得珍稀皮肤"
local STR_TIP = GachaRewardControl:getConfigField("tips", "STAR_INVERT", "content")
local IMG_DOWN = "Image_bg_down"

function GachaRewardControl:ctor(model, view)
	GachaRewardControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function GachaRewardControl:onCreate(param)
	GachaRewardControl.super.onCreate(self, param)
	if isNil(param) then printStack() end

	self:init()
	local action = addCommonAnime(self:getNode(),"mj_huojiang1_1")
	action:gotoFrameAndPlay(0, 23, false)
	SoundManager:playEffect("draw_result.mp3")
	local action1 = cc.DelayTime:create(1)
	local action2 = cc.CallFunc:create(function()
		self:getModel():setCloseFlag(true)
	end)
	local action3 = cc.Sequence:create(action1, action2)
	self:getNode():runAction(action3)

	local Image_bg_down = self:getChildNode(IMG_DOWN)
	if isNil(Image_bg_down) then printStack() return end
	Image_bg_down:setTouchEnabled(true)
end

function GachaRewardControl:init()
    local itemConfig = self:getTable("item")
    if isNil(itemConfig) then printStack() return end

    local paramsData = self:getModel():getRewardData()
    if isNil(paramsData) then printStack() return end

    local gachaType = self:getModel():getGachaType()
    if isNil(gachaType) then printStack() return end

	if isNil(GachaData[gachaType]) then printStack() return end

    local type = self:getModel():getType()
    if isNil(type) then printStack() return end

	--添加动画法杖
	local sprAnime = self:getChildNode(SPRITE_TITLESKIN2)
	if isNil(sprAnime) then printStack() return end

	local action,anime = addCommonAnime(sprAnime,"mj_huojiang1_2")
	action:gotoFrameAndPlay(0, 23, true)

	local btnAgain = self:getChildNode(BTN_AGAIN)
	if isNil(btnAgain) then printStack() return end

	local sprAgain = btnAgain:getChildByName(SPRITE_DIAMONE)
	if isNil(sprAgain) then printStack() return end

	if type == 1 then
		sprAgain:setSpriteFrame("home/icon_star.png")
	else
		sprAgain:setSpriteFrame("home/icon_zuanshi.png")
	end
	local againPrice = btnAgain:getChildByName(TEXT_AGAIN)
	if isNil(againPrice) then printStack() return end

	local couponID = GachaData[gachaType].coupon
	local count = getItemCountById(couponID)
	if count>0 then
		againPrice:setString("1")
		setIconById(sprAgain, couponID )
	else
		againPrice:setString(GachaData[gachaType].cost)
	end

    local viewsize = gDirector:getWinSize()
	local btnDouble =self:getChildNode(BTN_DOUBLE)
	if isNil(btnDouble) then printStack() return end

	if GachaData[gachaType].double == 1 then
		btnDouble:setVisible(true)
	elseif GachaData[gachaType].double == 0 then
		btnDouble:setVisible(false)
		btnAgain:setPositionX(viewsize.width/2)
	end
	local sprDouble = btnDouble:getChildByName(SPRITE_DIAMONE)
	if isNil(sprDouble) then printStack() return end

	if type == 1 then
		sprDouble:setSpriteFrame("home/icon_star.png")
	else
		sprDouble:setSpriteFrame("home/icon_zuanshi.png")
	end
	local douPrice = btnDouble:getChildByName("Text_double")
	if isNil(douPrice) then printStack() return end

	douPrice:setString(GachaData[gachaType].cost)

	local luckSpr= self:getChildNode("Sprite_tag_lucky")
	if isNil(luckSpr) then printStack() return end

	if luckSpr then
		if GachaData[gachaType].des == TITLE_LUCKY or GachaData[gachaType].des == TITLE_VERYLUCKY then
			luckSpr:setVisible(true)
		else
			luckSpr:setVisible(false)
		end
	end

	for i=1,5 do
		local panel = self:getChildNode("Panel_award_"..i) 
		if isNil(panel) then printStack() return end

		panel:setVisible(false)
	end

	local len = table.nums(paramsData)
	if len > 5 then len = 5 end
	for i=1,len do
		local panel = self:getChildNode("Panel_award_"..i) 
		if isNil(panel) then printStack() return end

		local awardSpr = panel:getChildByName("Node_reward")
		if isNil(awardSpr) then printStack() return end

		if paramsData[i].item_num then
			addItmeNode(awardSpr,paramsData[i].item_id,paramsData[i].item_num)
			local action1 = cc.DelayTime:create(0.1*i)
			local action2 = cc.CallFunc:create(function()
				panel:setVisible(true)
			end)
			local action3 = cc.Sequence:create(action1, action2)
			panel:runAction(action3)

			panel:setPositionX(760/(len+1)*i)

			self:addSpecialAnime(paramsData[i].item_id,panel)
		end		
	end

	for i = 1, len do
		if itemConfig[paramsData[i].item_id] and itemConfig[paramsData[i].item_id].type == "SKIN" then
			local action1 = cc.DelayTime:create(0.1*i)
			local action2 = cc.CallFunc:create(function()
				local bestLayer = require("FrameWork.game.GachaBestLayer"):create(paramsData[i].item_id)
				self:getNode():addChild(bestLayer)
			end)
			local action3 = cc.Sequence:create(action1, action2)
			self:getNode():runAction(action3)
		end
	end
end


function GachaRewardControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		local closeFlag = self:getModel():getCloseFlag()
		if isNil(closeFlag) then printStack() return end
		
		if closeFlag then
			self:detachFromParent()
		end
	end

	if senderName == BTN_AGAIN then
		self:clickAgain()
	end

	if senderName == BTN_DOUBLE then
		self:clickDouble()
	end

end

function GachaRewardControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

	if name == GameMsg.MSG_SKIN_REPATE then
	    local itemConfig = self:getTable("item")
	    if isNil(itemConfig) then printStack() return end

	    local str = ""
	    for i,v in ipairs(data) do
	    	local itemInfo = itemConfig[v.item_id]
	    	if isNil(itemInfo) then printStack() return end

	    	local name = itemInfo.name
	    	str = str..string.format(STR_TIP,name,v.star_num)
	    end
	    
		self:addTip(str)
		return
	end
end

function GachaRewardControl:addSpecialAnime( id,panel )
	if id == nil then return end
	if panel == nil then return end
	local special = getIsRare(id)
	
	if special  then
		local action,anime = addCommonAnime(panel,"mj_jl_1")
		action:gotoFrameAndPlay(0, 19, true)
		anime:setPosition(cc.p(75,82))
	end
end

function GachaRewardControl:clickAgain()
	self:send(GameMsg.MSG_DO_GACHA_AGAIN)
	self:detachFromParent()
end

function GachaRewardControl:clickDouble()
    local type = self:getModel():getType()
    if isNil(type) then printStack() return end

    local gachaType = self:getModel():getGachaType()
    if isNil(gachaType) then printStack() return end

    if type == 3 then
    	type = 2
    end
    
	local flag = buyJudgement(type , GachaData[gachaType].cost)

	if flag then
		self:send(GameMsg.MSG_DO_GACHA_DOUBLE)
		self:detachFromParent()
	end
end


return GachaRewardControl


