local EngineModel = require "EngineModel"
local BrandModel = class("BrandModel", EngineModel)

function BrandModel:ctor(data)
	BrandModel.super.ctor(self, data)
end

return BrandModel

