local EngineView = require "EngineView"
local RenameView = class("RenameView", EngineView)

local csbFilePath = "res/Rename.csb"
RENAME_CSB_NODE = 1000

function RenameView:ctor(node)
	RenameView.super.ctor(self, node)
end

function RenameView:onCreate(param)
	RenameView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	if isNil(csbNode) then printStack() return end
	csbNode:setTag(RENAME_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return RenameView





