local EngineModel = require "EngineModel"
local FrontModel = class("FrontModel", EngineModel)

function FrontModel:ctor(data)
	FrontModel.super.ctor(self, data)
end

return FrontModel

