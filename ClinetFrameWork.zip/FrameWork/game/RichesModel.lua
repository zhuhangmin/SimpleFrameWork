local EngineModel = require "EngineModel"
local RichesModel = class("RichesModel", EngineModel)

function RichesModel:ctor(data)
	RichesModel.super.ctor(self, data)
end



return RichesModel

