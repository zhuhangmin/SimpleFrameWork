local EngineView = require "EngineView"
local RearView = class("RearView", EngineView)

function RearView:ctor(node)
	RearView.super.ctor(self, node)
end

return RearView





