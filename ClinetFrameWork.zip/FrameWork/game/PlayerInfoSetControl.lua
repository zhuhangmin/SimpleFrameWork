local EngineControl = require  "EngineControl"
local PlayerInfoSetControl = class("PlayerInfoSetControl", EngineControl)

local  MODIFY_SUCCESS = PlayerInfoSetControl:getConfigField("tips", "SAVE_SUCCESS", "content")

--LUA MSGS
local LUA_MSGS = {
	GameMsg.SET_PLAYER_INFO_DATA,
    GameMsg.MSG_MODIFY_PLATFORM_NICKNAME
}

--SYSTEM MSGS
local BTN_RETURN = "Button_close"
local BTN_SURE = "Button_sure"
local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_SURE,
}

local BORN_DATE_ERROR = PlayerInfoSetControl:getConfigField("tips", "BORN_DATE_ERROR", "content")

function PlayerInfoSetControl:ctor(model, view)
	PlayerInfoSetControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function PlayerInfoSetControl:onCreate(param)
	PlayerInfoSetControl.super.onCreate(self, param)
	if isNil(param) then printStack() end

	  --数据
    local year                      = os.date("%Y") 
    local day                       = os.date("%d") 
    local month                     = os.date("%m") 

    if not PlayerDataBasic.year or PlayerDataBasic.year == 0 then
        self._Year                      = tonumber( year)
    else
        self._Year                      = PlayerDataBasic.year 
    end 

    if not PlayerDataBasic.month or  PlayerDataBasic.month == 0 then
        self._Month                      = tonumber( month)
    else
        self._Month                      = PlayerDataBasic.month 
    end 

    if not PlayerDataBasic.day or  PlayerDataBasic.day == 0 then
        self._Day                      =  tonumber(day)
    else
        self._Day                      = PlayerDataBasic.day 
    end 

    self._Address                   = PlayerDataBasic.area or 2--浙江省 
    self._NickName                  = PlayerDataBasic.nickname or ""
    self._Sex                       = PlayerDataBasic.gender or 0--女
    self._Declaration               = PlayerDataBasic.intro or ""
    self._ItemYearNode              = {}
    self._ItemMonthNode             = {}
    self._ItemDayNode               = {}
    self._ItemAddressNode           = {}



	local csbNode = self:getChildNode(PLAYERINFOSET_CSB_NODE)
    --资源
    self._LayerPlayerInfoSet = csbNode

    --关闭按钮
    -- self._LayerPlayerInfoSet:getChildByName("Button_close"):addClickEventListener(handler(self, self.onCloseBtn))

    --保存按钮
    -- self._LayerPlayerInfoSet:getChildByName("Button_sure"):addClickEventListener(handler(self, self.onSaveBtn))

    self.nicknameLabel = self._LayerPlayerInfoSet:getChildByName("Text_name_set")
    self.nicknameLabel:setString(PlayerDataBasic.nickname)

    local editBtn = self._LayerPlayerInfoSet:getChildByName("Button_name_set")
    editBtn:addClickEventListener(handler(self, self.onNickNameEditEvent))
    self:setEditBtnVisible()

     --宣言
    local TextField_input = self._LayerPlayerInfoSet:getChildByName("TextField_declaration")
	if TextField_input then
		TextField_input:setVisible(false)
		self._IntPutBoxDeclaration = ccui.EditBox:create(TextField_input:getContentSize(), "js/js_bg4.png")
		self._IntPutBoxDeclaration:setPosition(TextField_input:getPosition())
		self._IntPutBoxDeclaration:setAnchorPoint(0,1)
		self._IntPutBoxDeclaration.setTextColor = TextField_input.setFontColor
		self._IntPutBoxDeclaration:setFontColor(display.COLOR_BLACK)
		self._IntPutBoxDeclaration:setFontSize(TextField_input:getFontSize())
		self._IntPutBoxDeclaration:setPlaceHolder(TextField_input:getPlaceHolder())
		self._IntPutBoxDeclaration:setPlaceholderFontSize(TextField_input:getFontSize())
		self._IntPutBoxDeclaration:setPlaceholderFontColor(display.COLOR_BLACK)
		self._IntPutBoxDeclaration:setFontName(TextField_input:getFontName())
        -- self._IntPutBoxDeclaration:setMaxLength(DConfig.MAX_DECLARATION_LENGTH)
        self._IntPutBoxDeclaration:setContentSize(TextField_input:getContentSize())
        self._IntPutBoxDeclaration:registerScriptEditBoxHandler(handler(self, self.onDeclarationEditEvent)) 
        if self._Declaration ~= "" then
           -- local str = self:getEditboxString(self._Declaration)--获取处理后的字符串
            self._IntPutBoxDeclaration:setText(self._Declaration)
        end
         
       --  self._IntPutBoxDeclaration:setText("sdnhaklnd".."\nss是ass\nssda\nssss")
		self._LayerPlayerInfoSet:addChild(self._IntPutBoxDeclaration,0)
	end
    
    --年
    self._TextYear = self._LayerPlayerInfoSet:getChildByName("Panel_age_year"):getChildByName("TextField_year")
    self._TextYear:setString(PlayerDataBasic.year)
    self._LayerPlayerInfoSet:getChildByName("Panel_age_year"):getChildByName("Button_dropdown"):addClickEventListener(handler(self, self.onYearBtn))
    self._ScrollViewYear = self._LayerPlayerInfoSet:getChildByName("Panel_age_year"):getChildByName("ScrollView_year")
    self._LayerPlayerInfoSet:getChildByName("Panel_age_year"):setLocalZOrder(200)
    self._TextYear:setTouchEnabled(false)

    --月
    self._TextMonth = self._LayerPlayerInfoSet:getChildByName("Panel_age_month"):getChildByName("TextField_month")
    self._TextMonth:setString(PlayerDataBasic.month)
    self._LayerPlayerInfoSet:getChildByName("Panel_age_month"):getChildByName("Button_dropdown"):addClickEventListener(handler(self, self.onMonthBtn))
    self._ScrollViewMonth = self._LayerPlayerInfoSet:getChildByName("Panel_age_month"):getChildByName("ScrollView_month")
    self._LayerPlayerInfoSet:getChildByName("Panel_age_month"):setLocalZOrder(201)
    self._TextMonth:setTouchEnabled(false)

    --日
    self._TextDay = self._LayerPlayerInfoSet:getChildByName("Panel_age_day"):getChildByName("TextField_day")
    self._TextDay:setString(PlayerDataBasic.day)
    self._LayerPlayerInfoSet:getChildByName("Panel_age_day"):getChildByName("Button_dropdown"):addClickEventListener(handler(self, self.onDayBtn))
    self._ScrollViewDay = self._LayerPlayerInfoSet:getChildByName("Panel_age_day"):getChildByName("ScrollView_day")
    self._LayerPlayerInfoSet:getChildByName("Panel_age_day"):setLocalZOrder(202)
    self._TextDay:setTouchEnabled(false)

    --地区
    self._TextAddress = self._LayerPlayerInfoSet:getChildByName("Panel_district"):getChildByName("TextField_district")
    local areaText = self:getConfigField("city", PlayerDataBasic.area, "name")
    self._TextAddress:setString(areaText)
    self._LayerPlayerInfoSet:getChildByName("Panel_district"):getChildByName("Button_dropdown"):addClickEventListener(handler(self, self.onAddressBtn))
    self._ScrollViewAddress = self._LayerPlayerInfoSet:getChildByName("Panel_district"):getChildByName("ScrollView_district")
    self._LayerPlayerInfoSet:getChildByName("Panel_district"):setLocalZOrder(199)
    self._TextAddress:setTouchEnabled(false)

    --性别
    self._WomanBg = self._LayerPlayerInfoSet:getChildByName("Panel_sex_woman"):getChildByName("Image_circle_bg")
    self._WomanChoose = self._LayerPlayerInfoSet:getChildByName("Panel_sex_woman"):getChildByName("Image_choose")
    self._WomanBg:setTouchEnabled(true)
    self._WomanBg:addClickEventListener(handler(self, self.onWomanImg))

    self._ManBg = self._LayerPlayerInfoSet:getChildByName("Panel_sex_man"):getChildByName("Image_circle_bg")
    self._ManChoose = self._LayerPlayerInfoSet:getChildByName("Panel_sex_man"):getChildByName("Image_choose")
    self._ManBg:setTouchEnabled(true)
    self._ManBg:addClickEventListener(handler(self, self.onManImg))

    if PlayerDataBasic.gender == 0 then
        self._WomanChoose:setVisible(true)
        self._ManChoose:setVisible(false)
    else
        self._WomanChoose:setVisible(false)
        self._ManChoose:setVisible(true)
    end

    self:showScrollViewVisible(-1)

end

function PlayerInfoSetControl:onEnter(param)
	PlayerInfoSetControl.super.onEnter(self, param)

end

function PlayerInfoSetControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:detachFromParent()
	end

	if senderName == BTN_SURE then
        local data_time = os.time({year=self._Year,month=self._Month,day = self._Day,hour = 0,min = 0,sec = 0})
        if data_time>os.time() then
            self:addTip(BORN_DATE_ERROR)    
        else
            local func = "setPlayerInfoData"
            local params = {
             gender = self._Sex,
             year = self._Year,
             month = self._Month,
             day = self._Day,
             area = self._Address,
           } 
           self:submitFormWait(func, params)
        end
	end

end

function PlayerInfoSetControl:recv(event)
	self.super.recv(self, event)
	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

	if name == GameMsg.SET_PLAYER_INFO_DATA then
		self:addTip(MODIFY_SUCCESS)
		return
	end

    if name == GameMsg.MSG_MODIFY_PLATFORM_NICKNAME then
        local nicknameLabel = self:getChildNode("Text_name_set")
        nicknameLabel:setString(PlayerDataBasic.nickname)

        local editBtn = self:getChildNode("Button_name_set")
        editBtn:setVisible(false)
    end
end

function PlayerInfoSetControl:isVisible()
    if self._LayerPlayerInfoSet then
        return true
    else
        return false
    end
end

function PlayerInfoSetControl:onNickNameEditEvent()
    gUserPlugin:modifyNickName()
end

function PlayerInfoSetControl:onYearBtn()
    if self._ScrollViewYear:isVisible() or self._isScrollView == 1 then
        self._ScrollViewYear:setVisible(false)
    else
        for i = 1, 50 do
            if not self._ItemYearNode[i] then 

                self._ItemYearNode[i] =  require("FrameWork.game.node.PlayerInfoSetItem"):create(i,1)
                self._ItemYearNode[i]:setAnchorPoint(0,0)
			    local function YearItemNodeClickEvent(sender, touchEventType)
				    self:YearItemNodeClickEvent(sender, touchEventType,i)
			    end

			    self._ScrollViewYear:addChild(self._ItemYearNode[i])
			    self._ItemYearNode[i]:setPositionY( (self._ItemYearNode[i]._PlayerInfoSetItemNode:getChildByName("Panel_PlayerInfoItem"):getContentSize().height) *  (i-1) ) 
			    self._ItemYearNode[i]._PlayerInfoSetItemNode:getChildByName("Panel_PlayerInfoItem"):addTouchEventListener(YearItemNodeClickEvent)
			    self._ItemYearNode[i]._PlayerInfoSetItemNode:getChildByName("Panel_PlayerInfoItem"):setSwallowTouches(false)
            end 
        end 
        local height = (self._ItemYearNode[1]._PlayerInfoSetItemNode:getChildByName("Panel_PlayerInfoItem"):getContentSize().height) * 50
		local content = self._ScrollViewYear:getContentSize()
		self._ScrollViewYear:setInnerContainerSize(cc.size(content.width, height))
        
        self:showScrollViewVisible(1)
    end 
end

function PlayerInfoSetControl:onMonthBtn()
    if self._ScrollViewMonth:isVisible() or self._isScrollView == 2 then
        self._ScrollViewMonth:setVisible(false)
    else
        for i = 1, 12 do
            if not self._ItemMonthNode[i] then

                self._ItemMonthNode[i] =  require("FrameWork.game.node.PlayerInfoSetItem"):create(i,2)
                self._ItemMonthNode[i]:setAnchorPoint(0,0)
			    local function MonthItemNodeClickEvent(sender, touchEventType)
				    self:MonthItemNodeClickEvent(sender, touchEventType,i)
			    end

			    self._ScrollViewMonth:addChild(self._ItemMonthNode[i])
			    self._ItemMonthNode[i]:setPositionY( (self._ItemMonthNode[i]._PlayerInfoSetItemNode:getChildByName("Panel_PlayerInfoItem"):getContentSize().height) *  (i-1) ) 
			    self._ItemMonthNode[i]._PlayerInfoSetItemNode:getChildByName("Panel_PlayerInfoItem"):addTouchEventListener(MonthItemNodeClickEvent)
			    self._ItemMonthNode[i]._PlayerInfoSetItemNode:getChildByName("Panel_PlayerInfoItem"):setSwallowTouches(false)
            end 
        end 
        local height = (self._ItemMonthNode[1]._PlayerInfoSetItemNode:getChildByName("Panel_PlayerInfoItem"):getContentSize().height) * 12
		local content = self._ScrollViewMonth:getContentSize()
		self._ScrollViewMonth:setInnerContainerSize(cc.size(content.width, height))
        self:showScrollViewVisible(2)
    end 
end

function PlayerInfoSetControl:getDayNumOfMonth()
    local year  = self._Year 
    local month = self._Month
    local time1 = os.time({day=0, month=month, year=year, hour=0, minute=0, second=0})
    if month == 12 then
        year = year + 1
        month = 1
    else
        month = month +1
    end  
    local time2 = os.time({day=0, month=month, year=year, hour=0, minute=0, second=0})
    local time3  = time2 - time1
    local daynum = time3/3600/24
    return daynum or 28
end

function PlayerInfoSetControl:onDayBtn()
    if self._ScrollViewDay:isVisible() or self._isScrollView == 3 then
        self._ScrollViewDay:setVisible(false)
    else
        local daynum = self:getDayNumOfMonth()
        for i = 1, daynum do
            if not self._ItemDayNode[i] then
                self._ItemDayNode[i] =  require("FrameWork.game.node.PlayerInfoSetItem"):create(i,3)
                self._ItemDayNode[i]:setAnchorPoint(0,0)
			    local function DayItemNodeClickEvent(sender, touchEventType)
				    self:DayItemNodeClickEvent(sender, touchEventType,i)
			    end

			    self._ScrollViewDay:addChild(self._ItemDayNode[i])
			    self._ItemDayNode[i]:setPositionY( (self._ItemDayNode[i]._PlayerInfoSetItemNode:getChildByName("Panel_PlayerInfoItem"):getContentSize().height) *  (i-1) ) 
			    self._ItemDayNode[i]._PlayerInfoSetItemNode:getChildByName("Panel_PlayerInfoItem"):addTouchEventListener(DayItemNodeClickEvent)
			    self._ItemDayNode[i]._PlayerInfoSetItemNode:getChildByName("Panel_PlayerInfoItem"):setSwallowTouches(false)
            end 
        end 
        local height = (self._ItemDayNode[1]._PlayerInfoSetItemNode:getChildByName("Panel_PlayerInfoItem"):getContentSize().height) * daynum
		local content = self._ScrollViewDay:getContentSize()
		self._ScrollViewDay:setInnerContainerSize(cc.size(content.width, height))
        self:showScrollViewVisible(3)
    end 
end

function PlayerInfoSetControl:onAddressBtn()
    if self._ScrollViewAddress:isVisible() or self._isScrollView == 4 then
        self._ScrollViewAddress:setVisible(false)
    else
        for i = 1, 34 do
            if  not self._ItemAddressNode[i] then
                self._ItemAddressNode[i] =  require("FrameWork.game.node.PlayerInfoSetItem"):create(i,4)
                self._ItemAddressNode[i]:setAnchorPoint(0,0)
			    local function AddressItemNodeClickEvent(sender, touchEventType)
				    self:AddressItemNodeClickEvent(sender, touchEventType,i)
			    end

			    self._ScrollViewAddress:addChild(self._ItemAddressNode[i])
			    self._ItemAddressNode[i]:setPositionY( (self._ItemAddressNode[i]._PlayerInfoSetItemNode:getChildByName("Panel_PlayerInfoItem"):getContentSize().height) *  (i-1) ) 
			    self._ItemAddressNode[i]._PlayerInfoSetItemNode:getChildByName("Panel_PlayerInfoItem"):addTouchEventListener(AddressItemNodeClickEvent)
			    self._ItemAddressNode[i]._PlayerInfoSetItemNode:getChildByName("Panel_PlayerInfoItem"):setSwallowTouches(false)
            end 
        end 
        local height = (self._ItemAddressNode[1]._PlayerInfoSetItemNode:getChildByName("Panel_PlayerInfoItem"):getContentSize().height) * 34
		local content = self._ScrollViewAddress:getContentSize()
		self._ScrollViewAddress:setInnerContainerSize(cc.size(content.width, height))
        self:showScrollViewVisible(4)
    end 
end

function PlayerInfoSetControl:showScrollViewVisible(index)
    if index == 1 then
        self._ScrollViewAddress:setVisible(false)
        self._ScrollViewYear:setVisible(true)
        self._ScrollViewMonth:setVisible(false)
        self._ScrollViewDay:setVisible(false)
    elseif index == 2 then
        self._ScrollViewAddress:setVisible(false)
        self._ScrollViewYear:setVisible(false)
        self._ScrollViewMonth:setVisible(true)
        self._ScrollViewDay:setVisible(false)
    elseif index == 3 then
        self._ScrollViewAddress:setVisible(false)
        self._ScrollViewYear:setVisible(false)
        self._ScrollViewMonth:setVisible(false)
        self._ScrollViewDay:setVisible(true)
    elseif index == 4 then
        self._ScrollViewAddress:setVisible(true)
        self._ScrollViewYear:setVisible(false)
        self._ScrollViewMonth:setVisible(false)
        self._ScrollViewDay:setVisible(false)
    else
        self._ScrollViewAddress:setVisible(false)
        self._ScrollViewYear:setVisible(false)
        self._ScrollViewMonth:setVisible(false)
        self._ScrollViewDay:setVisible(false)
    end
end 

function PlayerInfoSetControl:onWomanImg()
    self._WomanChoose:setVisible(true)
    self._ManChoose:setVisible(false)
    self._Sex = 0 
end

function PlayerInfoSetControl:onManImg()
    self._WomanChoose:setVisible(false)
    self._ManChoose:setVisible(true)
    self._Sex = 1
end

function PlayerInfoSetControl:isItemNodeClickEvent(sender, touchEventType,index)
    if touchEventType == ccui.TouchEventType.began then
		self.flag = true
        self.isEnd = false
        self.beginTouchPoint= sender:convertToWorldSpace(cc.p(sender:getPositionX(), sender:getPositionY()))
		return true
	elseif touchEventType == ccui.TouchEventType.moved then
        local offsetPexil = 10
        local movedPoint =  sender:convertToWorldSpace(cc.p(sender:getPositionX(), sender:getPositionY()))
        local offset = (movedPoint.y -self.beginTouchPoint.y) * (movedPoint.y - self.beginTouchPoint.y)
        if offset * offset >= offsetPexil * offsetPexil then
           self.flag = false
        end
		return true
    elseif touchEventType == ccui.TouchEventType.ended then
        self.isEnd = true
	end

	if self.flag == false or self.isEnd == false then
		return true
	end
    return false
end 
function PlayerInfoSetControl:isClickInScrollView(ScrollView)
    local position = cc.p(ScrollView:getParent():getPosition())
    local  s = ScrollView:getContentSize()
    local touchRect = cc.rect( position.x+10, -s.height + position.y, s.width, s.height)
    local b = cc.rectContainsPoint(touchRect, cc.p(self.pointx,self.pointy))
    return b
end 

function PlayerInfoSetControl:YearItemNodeClickEvent(sender, touchEventType,index)
	if self:isItemNodeClickEvent(sender, touchEventType,index) then return end
    -- if not self:isClickInScrollView(self._ScrollViewYear) then return end
    SoundManager:playEffect("button.mp3")
    self._Year = os.date("%Y") -50+ index
    self._TextYear:setString(self._Year)
    if self:getDayNumOfMonth() < self._Day then
        self._Day = self:getDayNumOfMonth()
        self._TextDay:setString(self._Day)
    end 
    self:showScrollViewVisible(-1)
end

function PlayerInfoSetControl:MonthItemNodeClickEvent(sender, touchEventType,index)
	if self:isItemNodeClickEvent(sender, touchEventType,index) then return end 
    -- if not self:isClickInScrollView(self._ScrollViewMonth) then return end
    SoundManager:playEffect("button.mp3")
    self._Month =  index
    self._TextMonth:setString(self._Month)
    if self:getDayNumOfMonth() < self._Day then
        self._Day = self:getDayNumOfMonth()
        self._TextDay:setString(self._Day)
    end 
    self:showScrollViewVisible(-1)
end

function PlayerInfoSetControl:DayItemNodeClickEvent(sender, touchEventType,index)
	if self:isItemNodeClickEvent(sender, touchEventType,index) then return end 
    -- if not self:isClickInScrollView(self._ScrollViewDay) then return end
    SoundManager:playEffect("button.mp3")
    self._Day =  index
    self._TextDay:setString(self._Day)
    self:showScrollViewVisible(-1)
end

function PlayerInfoSetControl:AddressItemNodeClickEvent(sender, touchEventType,index)
	if self:isItemNodeClickEvent(sender, touchEventType,index) then return end 
    -- if not self:isClickInScrollView(self._ScrollViewAddress) then return end
    SoundManager:playEffect("button.mp3")
    self._Address = index
    local areaText = self:getConfigField("city", self._Address, "name")
    self._TextAddress:setString(areaText)
    self:showScrollViewVisible(-1)
end
function PlayerInfoSetControl:onDeclarationEditEvent(name, sender)

	if name == "changed" then
		self._Declaration = sender:getText()
        --self._Declaration  = self:getEditboxString(self.str)--获取处理后的字符串
		if self._Declaration ~= "" then
            sender:setText(self._Declaration)
			if Utils:getIsHideName(self._Declaration) then
				UIManager:showGameMsgTips("内容包含非法字符，修改失败！", 2)
			end
		end
	end
end

function PlayerInfoSetControl:getEditboxString(s) 
   local str = {"","","",""}  
   local temp = 0
   local str1 = ""
   local pos = 1
   local j = 1
   local count = 0
   s = string.gsub(s,"\n","")
   local bool = string.find(s,"\n")
   for i = 1, string.len(s) do--utf8len
        local dropping = string.byte(s, i)    
        if dropping >= 128 then    
            if temp == 0 then
                count = count + 2  
                temp = 3
            end 
        temp = temp - 1
        else
             count = count + 1
	    end 
        if count >=40*j and temp == 0 then
            str1 = string.sub(s,pos,i)
            pos = i+1
            str[j] = str1
            j = j + 1
           -- table.insert(str,str1)
        end 
    end 
    if count <40*j then
        str1 = string.sub(s,pos,string.len(s))
        str[j] = str1
    end 
    return table.concat(str,"\n")
end

function PlayerInfoSetControl:CountStringOfBGK(s, n)
  local count = 0
  local temp = 0

	for i = 1, string.len(s) do--utf8len
        local dropping = string.byte(s, i)
        if dropping > 128 then
            if temp == 0 then
                count = count + 1
                temp = 3
            end
         temp = temp - 1
	    end
    end

    return count
end

function PlayerInfoSetControl:onCloseBtn()
	SoundManager:playEffect("button.mp3")
	self._LayerPlayerInfoSet:removeSelf()
    self._LayerPlayerInfoSet = nil
    self.WaitingLayer:removeSelf()
    self.WaitingLayer = nil
end

function PlayerInfoSetControl:onSaveBtn()
	SoundManager:playEffect("button.mp3")
    if Utils:getIsHideName(self._Declaration) then
		UIManager:showGameMsgTips("内容包含非法字符，修改失败！", 2)
        return
	end
    self:sendData()
	self._LayerPlayerInfoSet:removeSelf()
    self._LayerPlayerInfoSet = nil
    self.WaitingLayer:removeSelf()
    self.WaitingLayer = nil
end

function PlayerInfoSetControl:sendData()
    -- self._NickName = gUserPlugin:getNickName()
    -- self._Declaration = self._IntPutBoxDeclaration:getText()
 
    -- local data = {
    --     userid = GameData.serverID,
    --     nickname = self._NickName,
    --     sex = PlayerDataBasic.gender,
    --     year = self._Year,
    --     month = self._Month,
    --     day = self._Day,
    --     area = self._Address,
    --     intro = self._Declaration
    -- }
    -- NetFunc.social:changePlayerInfo(data)
end 

function PlayerInfoSetControl:addTouchEvent()
	local listener = cc.EventListenerTouchOneByOne:create()
    self.WaitingLayer  = cc.LayerColor:create(cc.c4b(0, 0, 0, 0))
    gDirector:getRunningScene():addChild(self.WaitingLayer,199)

    listener:setSwallowTouches(false)
    local node = self:getNode()
	listener:registerScriptHandler(handler(node, self.onTouchBegan), cc.Handler.EVENT_TOUCH_BEGAN)
	listener:registerScriptHandler(handler(node, self.onTouchMoved), cc.Handler.EVENT_TOUCH_MOVED)
	listener:registerScriptHandler(handler(node, self.onTouchEnded), cc.Handler.EVENT_TOUCH_ENDED)
	gEventDispatcher:addEventListenerWithSceneGraphPriority(listener,self.WaitingLayer)
end

function PlayerInfoSetControl:onTouchBegan(touch, event)
	self.pointx = touch:getLocation().x
    self.pointy = touch:getLocation().y

    local ScrollView = nil
    self._isScrollView = 0

    local temp = 0
    if self._ScrollViewYear:isVisible() then
        ScrollView = self._ScrollViewYear
        temp = 1
    elseif self._ScrollViewMonth:isVisible() then
        ScrollView = self._ScrollViewMonth
        temp = 2
    elseif self._ScrollViewDay:isVisible() then
        ScrollView = self._ScrollViewDay
        temp = 3
    elseif self._ScrollViewAddress:isVisible() then
        ScrollView = self._ScrollViewAddress
        temp = 4
    end

    if ScrollView then
         if not self:isClickInScrollView(ScrollView) then 
            self:showScrollViewVisible(-1)
            self._isScrollView = temp
         end
    end

    return true
end

function PlayerInfoSetControl:onTouchMoved(touch, event)

end

function PlayerInfoSetControl:onTouchEnded(touch, event)

end

function PlayerInfoSetControl:setEditBtnVisible()
    local editBtn = self:getChildNode("Button_name_set")
    if isNil(editBtn) then printStack() end

    if type(gUserPlugin.modifyNickName) ~= 'function' then
        editBtn:setVisible(false)
        return
    end

    if gUserPlugin.getUserDetailInfo then
        gUserPlugin:getUserDetailInfo(function(code, msg, detail)
            dump(detail)
            if code == 0 then -- OK
                editBtn:setVisible(detail.supportNickModify)
                return
            else
                editBtn:setVisible(false)
                return
            end
        end)
    else
        editBtn:setVisible(false)
        return
    end
end

return PlayerInfoSetControl


