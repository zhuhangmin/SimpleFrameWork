local EngineControl = require  "EngineControl"
local UpdateTipControl = class("UpdateTipControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
}

--SYSTEM MSGS
local BTN_RETURN = "Button_cancel"
local BTN_CONFIRM ="Button_confirm"
local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_CONFIRM,
}

--GAME LABLES
local LBL_NICKNAME = "Text_name"


function UpdateTipControl:ctor(model, view)
	UpdateTipControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function UpdateTipControl:onCreate(param)
	UpdateTipControl.super.onCreate(self, param)
	if isNil(param) then printStack() return end

	self:setConvertAwards()
end

function UpdateTipControl:setConvertAwards()
	local giftInfo = self:getConfigRecord("giftPack", 19)
	if isNil(giftInfo) then printStack() return end

	for i=1,4 do
		local node = self:getChildNode("Node_"..i)
		if isNil(node) then printStack() return end

		local itemID = giftInfo["reward"..i]
		if notNumber(itemID) then printStack() return end

		local itemNum = giftInfo["num"..i]
		if notNumber(itemNum) then printStack() return end

		if itemID~=0 and itemNum~=0 then
			addItmeNode(node,itemID,itemNum)
		end
	end
end

function UpdateTipControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:detachFromParent()
	end

	if senderName == BTN_CONFIRM then
		local userConvert = require('src.app.userconvert.UserConvertCtrl'):getInstance()
		userConvert:onOptionConvertLogin()
	end

end

function UpdateTipControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

return UpdateTipControl


