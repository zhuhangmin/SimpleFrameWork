local EngineShaderManager = require "EngineShaderManager"
local ShaderManager = class("ShaderManager", EngineShaderManager)
ShaderManager.instance = nil

local SHADER_PATH = "FrameWork/game/shader/"

local SHADER_TBL = {
	["DEFAULT"] = {"",""},
    ["GRAY"] 		= {SHADER_PATH.."gray.vsh", 				SHADER_PATH.."gray.fsh"},
    ["BLOOM"] 		= {SHADER_PATH.."default.vsh",			 	SHADER_PATH.."example_bloom.fsh"}, 
}

function ShaderManager.getInstance()
    if not ShaderManager.instance then
        ShaderManager.instance = ShaderManager.new()
    end
    return ShaderManager.instance
end

function ShaderManager:ctor()
	print("ShaderManager ctor")
	ShaderManager.super.ctor(self)
	self:setShaderTbl(SHADER_TBL)
end


return ShaderManager
