local GuideClipLayer = class("GuideClipLayer",function()
    return cc.Layer:create()
end)

GuideClipLayer.__index = GuideClipLayer --用于访问  
  
-------------------------------------------------------------  
GuideClipLayer._nodef      = nil -- 模板(可以响应触摸事件)  
GuideClipLayer._cutSprite  = nil-- 挖掉的那个图(可以响应触摸事件)  
GuideClipLayer._enableClick = true -- 响应点击事件
GuideClipLayer._ResPath = "tongyong/tk_m_bg1.png"
  
function GuideClipLayer:create(node,block) 
    if needlisten == nil then 
        needlisten = true
    end

    if block == nil then
        block = true
    end

    local layer = GuideClipLayer.new()  
    layer:ctor()  
    layer:addChild(layer:createClip(node,block),1)  
    if block then
        layer:addChild(layer:createistenLayer())
    end

    return layer  
end  
  
function GuideClipLayer:ctor()  
    self._nodef      = nil  
    self._cutSprite    = nil
end  
  
function GuideClipLayer:createClip(node,block)  
    if isNil(node) then printStack() return end

    local clip = cc.ClippingNode:create()--创建裁剪节点    
    clip:setInverted(true)--设置底板可见    
    clip:setAlphaThreshold(0.0)--设置透明度Alpha值为0    
  
    if block then
        local layerColor = cc.LayerColor:create(cc.c4b(0,0,0,150))  
        clip:addChild(layerColor,8)
    end
  
    self._nodef = cc.Node:create()
    self._cutSprite = ccui.Scale9Sprite:createWithSpriteFrameName(self._ResPath)
    local Pos = cc.p(node:getParent():convertToWorldSpace(cc.p(node:getPosition())))
    if Pos.y>gScreenSize.height then
        Pos.y = Pos.y-gScreenSize.height
    end
    self._cutSprite:setPosition(Pos)
    self._cutSprite:setContentSize(node:getContentSize())
    self._nodef:addChild(self._cutSprite)

    self:addFinger(Pos.x,Pos.y)

    local Pos = cc.p(0,0)
    self._nodef:setPosition(Pos)
    clip:setStencil(self._nodef)-- 设置模版

    return clip  
end 

function GuideClipLayer:addFinger(posX,posY)
    if isNil(posX) then printStack() return end
    if isNil(posY) then printStack() return end

    local armature = ccs.Armature:create("dj") --增加手指按钮
    if isNil(armature) then printStack() return end
    armature:getAnimation():play("dianji", -1, 1)
    armature:setPosition(posX,posY)
    armature:setLocalZOrder(2)
    armature:setScale(0.5)
    self:addChild(armature)
end

function GuideClipLayer:addDialogView(message,posX,posY)
    if isNil(message) then printStack() return end
    if isNil(posX) then printStack() return end
    if isNil(posY) then printStack() return end

    local dialog = cc.CSLoader:createNode("res/Guide.csb") --增加对话
    if isNil(dialog) then printStack() return end
    dialog:setPosition(posX,posY)
    dialog:setLocalZOrder(2)
    self:addChild(dialog)

    local text_guide = dialog:getChildByName("Text_guide_1")
    if isNil(text_guide) then printStack() return end
    text_guide:setString(message)
end

--按键监听
function GuideClipLayer:createistenLayer()  
    local listen_layer = cc.Layer:create()
    -- 注册单点触摸
    local dispatcher = cc.Director:getInstance():getEventDispatcher()
    local listener = cc.EventListenerTouchOneByOne:create()--创建一个触摸监听(单点触摸）  
    
     -- 触摸开始
    local function onTouchBegan(touch, event)
        if not self._enableClick then 
            listener:setSwallowTouches(true)
            return true         
        end
        local pos = touch:getLocation() -- 获取触点的位置
        local posnodef = cc.p(self._nodef:getPosition())
        
        local enableSwTc = false

        local rect = self._cutSprite:getBoundingBox()
        rect= {y = rect.y+posnodef.y, x = rect.x + posnodef.x, height = rect.height, width=rect.width}
        if cc.rectContainsPoint(rect,pos) then   
            enableSwTc = true
        end
        
        if enableSwTc then   
            listener:setSwallowTouches(false)  -- 如果触点处于rect中 则事件向下透传 
        else  
            listener:setSwallowTouches(true)  
        end
        
        return true                     -- 必须返回true 后边move end才会被处理
    end
        
    -- 触摸移动
    local function onTouchMoved(touch, event)
        -- print("Touch Moved")
    end

    -- 触摸结束
    local function onTouchEnded(touch, event)
        -- print("Touch Ended")
    end 

    listener:registerScriptHandler(onTouchBegan, cc.Handler.EVENT_TOUCH_BEGAN)
    listener:registerScriptHandler(onTouchMoved, cc.Handler.EVENT_TOUCH_MOVED)
    listener:registerScriptHandler(onTouchEnded, cc.Handler.EVENT_TOUCH_ENDED)

    dispatcher:addEventListenerWithSceneGraphPriority(listener, listen_layer)-- 将listener和listen_layer绑定，放入事件委托中  

    return listen_layer
    
end 

return GuideClipLayer