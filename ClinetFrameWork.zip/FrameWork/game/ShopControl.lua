local EngineControl = require  "EngineControl"
local ShopControl = class("ShopControl", EngineControl)

--LUA MSGS
local LUA_MSGS = {
	-- GameMsg.MSG_EXIT_GAME_RET,
	GameMsg.MSG_NEWSHOP_BUY
}

--SYSTEM MSGS
local BTN_RETURN = "Button_return"
local SYSTEM_MSGS = {
	BTN_RETURN,
}

local LIST_GOOS = "ListView_1"
local SUCCESS_STR = ShopControl:getConfigField("tips", "PURCHASE_SUCCESS", "content")

function ShopControl:ctor(model, view)
	ShopControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function ShopControl:onCreate(param)
	ShopControl.super.onCreate(self, param)
	if isNil(param) then printStack() end

	local name = "game.Riches"
	self:addPanel(name)

	--添加动画法杖
	local sprAnime = self:getChildNode("Sprite_decorate3")
	if isNil(sprAnime) then printStack() return end

	local action,anime = addCommonAnime(sprAnime,"mj_huojiang1_2")
	action:gotoFrameAndPlay(0, 23, true)

	self:updateShopGoods()
end

function ShopControl:updateShopGoods()
	local shopConfig = self:getTable("shop")
	if isNil(shopConfig) then printStack() return end

	local shopInfo = shopConfig[1]
	if isNil(shopInfo) then printStack() return end	

	local shopList = self:getChildNode(LIST_GOOS)
	shopList:removeAllChildren()

	local temp = {}
	local len = table.nums(shopInfo)
	for i=1,len do
		local key = "shop_item_"..i
		if shopInfo[key] and shopInfo[key]~=0 then
			temp[#temp + 1] = i

			local isCan = false

	        if i % 4 == 0 then
	            isCan = true
	        end	

	        if isCan then
	            local item = require("FrameWork.game.ShopItem"):create(temp,self)
	            shopList:pushBackCustomItem(item)

	            isCan = false
	            temp = {}
	        end	
		end
	end

	if table.nums(temp)>0 then
        local item = require("FrameWork.game.ShopItem"):create(temp,self)
        shopList:pushBackCustomItem(item)

        temp = {}
	end
end

function ShopControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:send(BASE_MSG.POP)
	end

end

function ShopControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

	if name == GameMsg.MSG_NEWSHOP_BUY then
		self:updateShopGoods()
		self:addTip(SUCCESS_STR)
		return
	end
end

return ShopControl


