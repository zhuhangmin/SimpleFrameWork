local EngineView = require "EngineView"
local ShopBuyView = class("ShopBuyView", EngineView)

local csbFilePath = "res/Giftbuy.csb"
SHOPBUYVIEW_CSB_NODE = 1000

function ShopBuyView:ctor(node)
	ShopBuyView.super.ctor(self, node)
end

function ShopBuyView:onCreate(param)
	ShopBuyView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	if isNil(csbNode) then printStack() return end
	
	csbNode:setTag(SHOPBUYVIEW_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return ShopBuyView





