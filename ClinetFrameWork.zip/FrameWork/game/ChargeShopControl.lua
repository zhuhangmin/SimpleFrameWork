local EngineControl = require  "EngineControl"
local ChargeShopControl = class("ChargeShopControl", EngineControl)

--SYSTEM MSGS
local BTN_RETURN = "Button_return"
local BTN_DIAMOND = "Button_diamond"
local BTN_STAR = "Button_star"
local BTN_BUY = "Button_bug"

local PANEL_DIAMOND = "Panel_diamond"
local PANEL_STAR = "Panel_star"

local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_DIAMOND,
	BTN_STAR,
}

local LUA_MSGS = {
--star
	GameMsg.BUY_STAR_SUCCESS,
--diamond
	GameMsg.MSG_GET_PAY_ORDER_ID_RET, 
	GameMsg.MSG_PAY_SUCC_NOTIFY, 
	GameMsg.MSG_PLATFORM_PAY_RET,
	GameMsg.MSG_GET_AWARD_SUCC,
	GameMsg.MSG_PAY_SUCC_AWARD,
}
 
local PAGE_STAR = 1
local PAGE_DIAMOND = 2

local RICH_BTN_DIAMOND = "Button_add"
local RICH_BTN_STAR = "Button_add_star"

local STAR_TAG = 10000
local DIAMOND_TAG = 20000

local SUCCESS_STR = ChargeShopControl:getConfigField("tips", "PURCHASE_SUCCESS", "content")
local BUY_STAR = ChargeShopControl:getConfigField("tips", "BUY_STAR", "content")

function ChargeShopControl:ctor(model, view)
	ChargeShopControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
end

function ChargeShopControl:onCreate(param)
	ChargeShopControl.super.onCreate(self, param)

	-- PrintNodeTree(self:getNode())
	-- local name = "game.Riches"
	-- local alias1 = "1"
	-- self:addPanel(name, nil, alias1)

	-- local name = "game.Riches"
	-- local alias2 = "2"
	-- self:addPanel(name, nil, alias2)

	-- local richControl = self:getChildControlByAlias(name, alias1)
	-- richControl:getNode():setPosition(-100, -100)
	-- local richControl = self:getChildControlByAlias(name, alias2)
	-- richControl:getNode():setPosition(-200, -200)

	local name = "game.Riches"
	self:addPanel(name)
	self:getChildNode(RICH_BTN_DIAMOND):setVisible(false)
	self:getChildNode(RICH_BTN_STAR):setVisible(false)
	
    local panelStar = self:getChildNode(PANEL_STAR)

    local node = self:getNode()
    -- PrintNodeTree(node)

    self:updateDiamondInfo()
    
    --星星界面
    self._StarItem = {}
    for i = 1, 6 do
        self._StarItem[i] = panelStar:getChildByName("Panel_item"..i)
        local btnBuy = self._StarItem[i]:getChildByName("Button_bug")
        btnBuy:addTouchEventListener(handler(self, self.touchCB))
        btnBuy:setTag(STAR_TAG + i)

        local diamondCost = self:getConfigField("diamondStar", i, "diamond")
		local starReward = self:getConfigField("diamondStar", i, "star")

        local lblStar = self._StarItem[i]:getChildByName("Text_star_amount")
 		local str = "X" .. tostring(starReward) .. "星星"
        lblStar:setString(str)

        local lblDiamond = self._StarItem[i]:getChildByName("Text_amount")
        lblDiamond:setString(tostring(diamondCost))
    end 
 

	local pageIndex = self:getModel():getPageIndex()
	self:tabBtn(pageIndex)
end


function ChargeShopControl:updateDiamondInfo()
	local panelDiamond = self:getChildNode(PANEL_DIAMOND)
    --钻石界面
	local chargeConfig = self:getTable("chargeConfig")
	if isNil(chargeConfig) then printStack() return end

	local chargeGive = self:getTable("chargeGive")
	if isNil(chargeGive) then printStack() return end

	if isNil(ChargeData) then printStack() return end
	for i = 1, 6 do
		if isNil(chargeConfig[i]) then printStack() return end
		if isNil(chargeGive[i]) then printStack() return end

		local panel = panelDiamond:getChildByName("Panel_item"..i)
		local buyBtn = panel:getChildByName("Button_bug")
		buyBtn:setTag(DIAMOND_TAG + i)
		buyBtn:addTouchEventListener(handler(self, self.touchCB))

		local img_double = panel:getChildByName("Image_double")
		if isNil(img_double) then printStack() return end

		local text_amount = panel:getChildByName("Text_diamond_amount")
		if isNil(text_amount) then printStack() return end

		local text_giveAmount = panel:getChildByName("Text_give_amount")
		if isNil(text_giveAmount) then printStack() return end

		local text_price = panel:getChildByName("Text_price")
		if isNil(text_price) then printStack() return end

		local index = i
		-- if PlayerDataSystem.device_type == 2 then --IOS
		-- 	index = i+6
		-- end

		if ChargeData["ex"..index] == 0 then
			img_double:setVisible(true)
			text_giveAmount:setString(string.format("送%d钻",(chargeGive[index].extra+chargeGive[index].first)))
		else
			img_double:setVisible(false)
			text_giveAmount:setString(string.format("送%d钻",chargeGive[index].extra))
		end
		text_amount:setString(string.format("%d钻石",chargeGive[index].diamond))
		text_price:setString(string.format("%d元",chargeConfig[index].money))
	end
end

function ChargeShopControl:cancelBtnClick()
end

function ChargeShopControl:okBtnClick()
	local func = "buyStar"
	local index = self:getModel():getStarSelectedIndex()
	params = {index = index}
	self:submitFormWait(func, params)	
end

function ChargeShopControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:send(BASE_MSG.POP)
	end

	if senderName == BTN_DIAMOND then
		self:tabBtn(PAGE_DIAMOND)
	end

	if senderName == BTN_STAR then
		self:tabBtn(PAGE_STAR)
	end

	if senderName == BTN_BUY then
		local tag = sender:getTag()
		-- print("tag = " .. tostring(tag))
		local buyPage = math.floor(tag / STAR_TAG)

		-- print("buyPage = " .. buyPage)
		if buyPage == PAGE_DIAMOND then
			local i = tag - DIAMOND_TAG
			-- if device.platform == "ios" then
			-- 	i = i+6
			-- end
			local exchangeid = self:getConfigField("chargeConfig", i, "exchangeid")
			if isNil(exchangeid) then printStack() return end

			local data ={}
			data.func = "placeOrder"
			data.params = {exchangeid = exchangeid}
			self:send(BASE_MSG.NET_FORM_WAIT, data)
			return
		end

		if buyPage == PAGE_STAR then
			local i = tag - STAR_TAG
			local model = self:getModel()
			model:setStarSelectedIndex(i)
			local diamondCost = self:getConfigField("diamondStar", i, "diamond")
			local starReward = self:getConfigField("diamondStar", i, "star")
			local contentStr = string.format(BUY_STAR,diamondCost,starReward)
			local confirmCB = function()
				buyJudgement(2 , diamondCost , handler(self, self.okBtnClick) )
			end
			local cancelCB = handler(self, self.cancelBtnClick)
			self:addMsgBox(contentStr, confirmCB, cancelCB)
			return
		end
	end
end

function ChargeShopControl:recv(event)
	self.super.recv(self, event)
	if isNil(event) then printStack() end
	if isNil(event.name) then printStack() end
	if isNil(event.data) then printStack() end
	local name = event.name
	local data = event.data
	print("ChargeShopControl:recv(event)")

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

	

	if name == GameMsg.BUY_STAR_SUCCESS then
		self:addTip(SUCCESS_STR)	
	end

	if name == GameMsg.MSG_GET_PAY_ORDER_ID_RET then
		--第三方支付
		-- if device.platform ~= "windows" then

			print("SDKFunc.pay:pay beg")
			SDKFunc.pay:pay(data.exchangeid, data.orderid)
			print("SDKFunc.pay:pay end")
		-- end
	end

	-- if value.type  == GameMsg.MSG_PLATFORM_PAY_RET then
		-- local str  = ""

		-- if value.params == 0 then
		-- 	str = "支付已完成，成功后会有消息通知。\n请在消息通知界面查看！"
		-- elseif value.params == -1 then
		-- 	str = "充值异常，以实际扣款为准。\n成功后会有消息通知，请注意查看！"
		-- elseif value.params == -2 then
		-- 	str = "支付已被取消！"
		-- else
		-- 	str = "支付失败，请稍候重试！"
		-- end

		-- local modelParam = {}
		-- modelParam.contentStr = str
		-- modelParam.confirmCB = handler(self, self.okBtnClick)
		-- modelParam.confirmBtnTitle = "确定"
		-- local name = "game.PopUp"
		-- local param = {modelParam = modelParam}
		-- self:addPop(name, param)

	-- end

	if name == GameMsg.MSG_PAY_SUCC_NOTIFY then
		-- --支付成功
  --       if cc.exports.BUY_TYPE == 1 then--充值成功成功埋点
  --           SDKFunc.log:logEventCount(Constant.LogEventName[39])
  --       elseif cc.exports.BUY_TYPE == 2 then
  --           SDKFunc.log:logEventCount(Constant.LogEventName[41])
  --       elseif cc.exports.BUY_TYPE == 3 then
  --           SDKFunc.log:logEventCount(Constant.LogEventName[43])
  --       end 
    end

	if name == GameMsg.MSG_GET_AWARD_SUCC then
		-- --支付成功后更新UI
		-- local shopLayer = self:getChildByTag(Constant.ShopSceneLayerTag.TAG_SHOP_LAYER)
		-- shopLayer:setInfo()
		self:updateDiamondInfo()
	end

	if name == GameMsg.MSG_PAY_SUCC_AWARD then

		-- --奖励界面弹出
		-- -- --弹出领取界面
		-- local info = value.params
		-- if info.diamond > 0  or info.star > 0 or info.skinCount > 0 then
		-- 	local layer = require("src.app.game.Scene.RewardLayer"):create(info.diamond,info.star,info.skinID,info.skinCount)
		-- 	self:addChild(layer,200)
		-- end
	end
end

function ChargeShopControl:tabBtn( index)
	if notNumber(index) then printStack() return end

	local panelDiamond = self:getChildNode(PANEL_DIAMOND)
    local panelStar = self:getChildNode(PANEL_STAR)
    local Button_diamond = self:getChildNode(BTN_DIAMOND)
    local Button_star = self:getChildNode(BTN_STAR)
    
    if index == PAGE_DIAMOND then
        panelDiamond:setVisible(true)
        panelStar:setVisible(false)
        Button_diamond:setBright(false)
        Button_diamond:setEnabled(false)
        Button_diamond:setTitleColor(display.COLOR_WHITE)
        Button_star:setBright(true)
        Button_star:setEnabled(true)
        Button_star:setTitleColor(display.COLOR_WHITE)
        Button_star:setTitleColor(cc.c3b(197, 222, 255))
        return
    end

    if index == PAGE_STAR then
        panelDiamond:setVisible(false)
        panelStar:setVisible(true)
        Button_diamond:setBright(true)
        Button_diamond:setEnabled(true)
        Button_diamond:setTitleColor(display.COLOR_WHITE)
        Button_diamond:setTitleColor(cc.c3b(197, 222, 255))
        Button_star:setBright(false)
        Button_star:setEnabled(false)
        Button_star:setTitleColor(display.COLOR_WHITE)
        return
	end
end

return ChargeShopControl


