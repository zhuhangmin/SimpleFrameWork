local EngineView = require "EngineView"
local CultureUpdateView = class("CultureUpdateView", EngineView)

local csbFilePath = "res/CultureUpdate.csb"
CULTUREUPDATE_CSB_NODE = 1000

function CultureUpdateView:ctor(node)
	CultureUpdateView.super.ctor(self, node)
end

function CultureUpdateView:onCreate(param)
	CultureUpdateView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	csbNode:setTag(CULTUREUPDATE_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return CultureUpdateView





