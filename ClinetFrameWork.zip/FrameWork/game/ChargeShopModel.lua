local EngineModel = require "EngineModel"
local ChargeShopModel = class("ChargeShopModel", EngineModel)

function ChargeShopModel:ctor(data)
	ChargeShopModel.super.ctor(self, data)
	self.pageIndex = 1
	self.starSelectedIndex = 0
end

function ChargeShopModel:onCreate(param)
	ChargeShopModel.super.onCreate(self, param)
	if notNumber(param.pageIndex) then printStack() return end
	self:setPageIndex(param.pageIndex)
end

function ChargeShopModel:getPageIndex()
	return self.pageIndex
end

function ChargeShopModel:setPageIndex(pageIndex)
	self.pageIndex = pageIndex
end

function ChargeShopModel:getStarSelectedIndex()
	return self.starSelectedIndex
end

function ChargeShopModel:setStarSelectedIndex(starSelectedIndex)
	self.starSelectedIndex = starSelectedIndex
end


return ChargeShopModel

