local EngineControl = require  "EngineControl"
local RootControl = class("RootControl", EngineControl)

local GlobalStatus = require "GlobalStatus"
local GuideMgr = require "GuideMgr"

--LUA MSGS
local LUA_MSGS = {
    GameMsg.MSG_SWITCH_BGM,
    GameMsg.MSG_CHARGEACTIVITY_RESULT,
    GameMsg.REPEAR_LOGIN,
}

function RootControl:ctor(model, view)
	RootControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)
end

function RootControl:onCreate(param)
	RootControl.super.onCreate(self, param)
	local node = self:getNode()

	local eventDispatcher = node:getEventDispatcher()

    local function onTouchBegan(touch, event)
        local target = event:getCurrentTarget()
        local locationInNode = target:convertToNodeSpace(touch:getLocation())
        local s = target:getContentSize()
        local rect = cc.rect(0, 0, s.width, s.height)
        
        if cc.rectContainsPoint(rect, locationInNode) then
            -- print(string.format("sprite began... x = %f, y = %f", locationInNode.x, locationInNode.y))
        end
        return false
    end

    local listener = cc.EventListenerTouchOneByOne:create()
    -- node._listener = listener
    listener:setSwallowTouches(false)
	listener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN )
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, node)

    --播放音乐
    GlobalStatus.getInstance():setMusicName(DEFAULT_MUSIC)
    SoundManager:playMusic(DEFAULT_MUSIC)

    self:startScheduler()

    if DEBUG_FLAG then
        local test = {"@diamond,10000","@star,10000","@item,40001,1000","@item,40002,1000"
                    ,"@item,55001,1000","@item,55002,1000","@item,40003,1000","@item,55003,1000"
                    ,"@item,40004,1000","@item,55004,1000"}

        for k,v in pairs(test) do
            local gmStr = v
            local func = "setGmCommand"
            local params = {gmStr = gmStr}
            self:submitForm(func, params)
        end
    end

    GuideMgr.getInstance():addGuideQueue()
end

function RootControl:onUpdate(dt)
    local model = self:getModel()
    local count = model:getCount()
    count = count + 1
    model:setCount(count)
    local interval = model:getInterval()

    if count % interval == 0 then
        model:setCount(0)
        local memoryInfo = DeviceUtils:getInstance():getRuntimeMemoryInfo()
        GlobalStatus.getInstance():setMemoryInfo(memoryInfo)
        if memoryInfo.lowMemory then
            print('low memory, texture cache will be cleared')
            EngineControlManager.getInstance():freeMemory()
        end
        -- dump(GlobalStatus.getInstance():getMemoryInfo())
    end
end

function RootControl:recv(event)
    self.super.recv(self, event)

    local name = event.name
    local data = event.data

    if name == GameMsg.MSG_SWITCH_BGM then    
        local music = GlobalStatus.getInstance():getMusicName()
        SoundManager:playMusic(music)
    end

    if name == GameMsg.MSG_CHARGEACTIVITY_RESULT then
        local activity_id = data.activity_id
        local chargeActivityInfo = self:getConfigRecord("chargeActivty", activity_id)
        if isNil(chargeActivityInfo) then printStack() end

        local giftInfo = self:getConfigRecord("giftPack", chargeActivityInfo.gift_id)
        if isNil(giftInfo) then printStack() end    

        local rewardData = {}
        for i=1,5 do
            local itemID = giftInfo["reward"..i]
            local itemNum = giftInfo["num"..i]
            if itemID~=0 and itemNum~=0 then
                table.insert(rewardData,{item_id=itemID ,item_num=itemNum})
            end
        end

        local popActivityIDs = self:getModel():getPopActivityIDs()
        local priority = nil
        if popActivityIDs[activity_id] then
            priority = POP_PRIORITY.NONPREEMPTIVE
        end
        popActivityIDs[activity_id] = activity_id
        self:getModel():setPopActivityIDs(popActivityIDs)

        local name = "game.GetAwards"
        local param = {modelParam = {rewardData = rewardData,priority = priority}}
        self:addPop(name,param)
        return
    end

    if name == GameMsg.REPEAR_LOGIN then
        local contentStr = "您的账号已在其他设备登录，\n请妥善保护好你的账号安全。"
        local confirmCB = function()
            SDKFunc.state:unregister()
            MCAgent:getInstance():endToLua()
        end

        local cancelCB = function()
            SDKFunc.state:unregister()
            MCAgent:getInstance():endToLua()
        end
        self:addMsgBox(contentStr, confirmCB, cancelCB)
    end
end

return RootControl


