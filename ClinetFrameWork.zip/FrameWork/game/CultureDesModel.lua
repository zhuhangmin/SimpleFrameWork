local EngineModel = require "EngineModel"
local CultureDesModel = class("CultureDesModel", EngineModel)

function CultureDesModel:ctor(data)
	CultureDesModel.super.ctor(self, data)

	self.dropType = 0
end

function CultureDesModel:onCreate(param)
	CultureDesModel.super.onCreate(self, param)

	if isNil(param.dropType) then printStack() return end
	self:setDropType(param.dropType)
end

function CultureDesModel:setDropType(dropType)
	self.dropType = dropType
end

function CultureDesModel:getDropType()
	return self.dropType
end

return CultureDesModel

