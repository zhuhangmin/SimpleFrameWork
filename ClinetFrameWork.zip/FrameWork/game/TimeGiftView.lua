local EngineView = require "EngineView"
local TimeGiftView = class("TimeGiftView", EngineView)

local csbFilePath = "res/TimeGift.csb"
TIMEGIFT_CSB_NODE = 1000

function TimeGiftView:ctor(node)
	TimeGiftView.super.ctor(self, node)
end

function TimeGiftView:onCreate(param)
	TimeGiftView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	csbNode:setTag(TIMEGIFT_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return TimeGiftView





