local EngineView = require "EngineView"
local SettingView = class("SettingView", EngineView)

local csbFilePath = "res/SetupMain.csb"
SETTING_CSB_NODE = 1000

function SettingView:ctor(node)
	SettingView.super.ctor(self, node)
end

function SettingView:onCreate(param)
	SettingView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	if isNil(csbNode) then printStack() return end
	
	csbNode:setTag(SETTING_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return SettingView





