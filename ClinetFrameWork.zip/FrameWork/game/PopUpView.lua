local EngineView = require "EngineView"
local PopUpView = class("PopUpView", EngineView)

local csbFilePath = "res/Popup.csb"
POP_CSB_NODE = 1000

function PopUpView:ctor(node)
	PopUpView.super.ctor(self, node)
end

function PopUpView:onCreate(param)
	PopUpView.super.onCreate(self, param)
	local csbNode = cc.CSLoader:createNode(csbFilePath)
	csbNode:setTag(POP_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return PopUpView





