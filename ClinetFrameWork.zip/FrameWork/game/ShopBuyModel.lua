local EngineModel = require "EngineModel"
local ShopBuyModel = class("ShopBuyModel", EngineModel)

function ShopBuyModel:ctor(data)
	ShopBuyModel.super.ctor(self, data)

	self.index = 1
	self.name = ""
	self.buyNum = 1
	self.shopItemInfo = {}
end

function ShopBuyModel:onCreate(param)
	ShopBuyModel.super.onCreate(self, param)

	if notNumber(param.index) then printStack() return end
	self:setIndex(param.index)

	if isNil(param.name) then printStack() return end
	self:setName(param.name)
	
	if isNil(param.shopItemInfo) then printStack() return end
	self:setShopItemInfo(param.shopItemInfo)
end

function ShopBuyModel:getIndex()
	return self.index
end

function ShopBuyModel:setIndex(index)
	self.index = index
end

function ShopBuyModel:getName()
	return self.name
end

function ShopBuyModel:setName(name)
	self.name = name
end

function ShopBuyModel:getBuyNum()
	return self.buyNum
end

function ShopBuyModel:setBuyNum(buyNum)
	self.buyNum = buyNum
end

function ShopBuyModel:getShopItemInfo()
	return self.shopItemInfo
end

function ShopBuyModel:setShopItemInfo(shopItemInfo)
	self.shopItemInfo = shopItemInfo
end


return ShopBuyModel

