local EngineModel = require "EngineModel"
local BattleScoreHelpModel = class("BattleScoreHelpModel", EngineModel)

function BattleScoreHelpModel:onCreate( data )
	BattleScoreHelpModel.super.onCreate(self, data)
end


function BattleScoreHelpModel:ctor(data)
	BattleScoreHelpModel.super.ctor(self, data)
end


return BattleScoreHelpModel; 