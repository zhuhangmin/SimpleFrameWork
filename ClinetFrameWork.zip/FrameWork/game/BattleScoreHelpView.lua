local EngineView = require "EngineView"
local BattleScoreHelpView = class("BattleScoreHelpView", EngineView)

function BattleScoreHelpView:ctor(node)
	BattleScoreHelpView.super.ctor(self, node)
end

function BattleScoreHelpView:onCreate(param)
	BattleScoreHelpView.super.onCreate(self, param)
	local csbNode = cc.CSLoader:createNode("res/RankRule.csb")
	if isNil(csbNode) then printStack() return end
	self:getNode():addChild(csbNode)
	csbNode:setPosition(0, gScreenSize.height)
	UIManager:runPopupEnterAction(csbNode)
end


return BattleScoreHelpView;
