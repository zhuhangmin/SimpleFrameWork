local EngineControl = require  "EngineControl"
local LoadingControl = class("LoadingControl", EngineControl)
local ResourceManager = require "ResourceManager"

--LUA MSGS
local LUA_MSGS = {
	ENGINE_MSG.LOAD_PROGRESS
}

--SYSTEM MSGS
-- local BTN_RETURN = "Button_return"
local SYSTEM_MSGS = {
	-- BTN_RETURN,
}

--NODE TAG
local IMG_BG = "Image_bg"
local REVERSE_LB1 = "Text_info2"
local REVERSE_LB2 = "Text_info1"  
local BTN_HELP = "Button_Help"
local BTN_RETURN = "Button_return"
local PANEL_START = "Panel_start"
local PANEL_LOADING = "Panel_loading"
local LOADING_BAR = "LoadingBar"
local LBL_PROGRESS = "Text_detail"
local LBL_HINT = "Text_6"

function LoadingControl:ctor(model, view)
	LoadingControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)
end

function LoadingControl:onCreate(param)
	LoadingControl.super.onCreate(self, param)

	local bgImage = self:getChildNode(IMG_BG)
	if isNil(bgImage) then printStack() return end

	local exitBtn = self:getChildNode(BTN_RETURN)
	if isNil(exitBtn) then printStack() return end
	exitBtn:setVisible(false)

	--版署版号
	local info = GameSwitch:getReverseInfo()
	if isNil(info) then printStack() return end

	local reverseLabel1 = self:getChildNode(REVERSE_LB1)
	if isNil(reverseLabel1) then printStack() return end
	reverseLabel1:setString(info[1])

	local reverseLabel2 = self:getChildNode(REVERSE_LB2)
	if isNil(reverseLabel2) then printStack() return end
	reverseLabel2:setString(info[2])

	local helpBtn = self:getChildNode(BTN_HELP)
	if isNil(reverseLabel2) then printStack() return end
	helpBtn:setVisible(false)

	local startPanel = self:getChildNode(PANEL_START)
	if isNil(startPanel) then printStack() return end
	startPanel:setVisible(false)

	local LBL_HINT = self:getChildNode(LBL_HINT)
	if isNil(LBL_HINT) then printStack() return end
	LBL_HINT:setVisible(false)

	--进度panel
	local progressPanel = self:getChildNode(PANEL_LOADING)
	if isNil(progressPanel) then printStack() return end
	progressPanel:setVisible(true)

	--startload
    local preloadPlist = self:TABLE(PRELOAD_PLIST)
    local preloadArmature = self:TABLE(PRELOAD_ARMATURE)
    self:loadBatchFrame(preloadPlist)
    self:loadBatchArmature(preloadArmature)
    self:startTask()

end

function LoadingControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

end

function LoadingControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

	if name == ENGINE_MSG.LOAD_PROGRESS then
		local msgWorkID = data.id
		local workerID = self:getWorkerID()
		print(msgWorkID, workerID)
		if msgWorkID == workerID then
			local taskNum = data.taskNum
			local taskIndex = data.taskIndex
			local percent = math.ceil(100 * taskIndex / taskNum)

			local progressPanel = self:getChildNode(LOADING_BAR)
			if isNil(progressPanel) then printStack() return end
			progressPanel:setPercent(percent)

			local progressLbl = self:getChildNode(LBL_PROGRESS)
			if isNil(progressLbl) then printStack() return end
			progressLbl:setString(percent .. "%")
			print(percent)
			
		end
	end

	if name == ENGINE_MSG.LOAD_PROGRESS then
		local msgWorkID = data.id
		local manager = ResourceManager.getInstance()
		local workerID = manager:getWorkerID()
		if msgWorkID == workerID then
			local taskNum = data.taskNum
			local taskIndex = data.taskIndex
			local percent = math.ceil(100 * taskIndex / taskNum)

			local progressPanel = self:getChildNode(LOADING_BAR)
			if isNil(progressPanel) then printStack() return end
			progressPanel:setPercent(percent)

			local progressLbl = self:getChildNode(LBL_PROGRESS)
			if isNil(progressLbl) then printStack() return end
			progressLbl:setString(percent .. "%")
			print(percent)
			
		end
	end

end

return LoadingControl