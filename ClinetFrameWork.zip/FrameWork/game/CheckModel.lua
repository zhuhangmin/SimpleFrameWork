local EngineModel = require "EngineModel"
local CheckModel = class("CheckModel", EngineModel)

function CheckModel:ctor(data)
	CheckModel.super.ctor(self, data)
end

return CheckModel

