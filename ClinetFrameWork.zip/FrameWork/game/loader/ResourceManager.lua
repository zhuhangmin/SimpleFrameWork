local FrameTaskMixin = require "FrameTaskMixin"
local BaseObject = require "BaseObject"
local ResourceManager = class("ResourceManager", BaseObject)
ResourceManager.instance = nil
ResourceManager:include(FrameTaskMixin)

function ResourceManager.getInstance()
    if not ResourceManager.instance then
        ResourceManager.instance = ResourceManager.new()
    end
    return ResourceManager.instance
end

function ResourceManager:ctor()
	ResourceManager.super.ctor(self)
end

return ResourceManager
