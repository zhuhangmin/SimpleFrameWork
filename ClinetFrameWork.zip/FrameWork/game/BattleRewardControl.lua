local EngineControl = require  "EngineControl"
local BattleRewardControl = class("BattleRewardControl", EngineControl)

--测试动画打开例子
-- local panel_name = "game.BattleReward"
-- local params = {}
-- params.modelParam = {anime = BattleMsg.UP_STAR,data = {stars= 1,rank = 1},num =23}
-- self:addPanel(panel_name,params) 

--LUA MSGS
local NODE_ANIME = "Node_rank_animation"
local PANEL = "Panel_1"
local PANEL_RANK = "Panel_rank"
local RANK_BG = "Image_rank_bg"
local TEXT_RANK = "text_rank"
local TEXT_NOW = "Text_season_now"
local RANK_ITEM = "Sprite_rank_item"
local Panel_star2 = "Panel_star2"
local Panel_star3 = "Panel_star3"
local Panel_star4 = "Panel_star4"
local Panel_star5 = "Panel_star5"
local Panel_star999 = "Panel_star999"
local STAR_TABLE = {Panel_star999,Panel_star2,Panel_star3,Panel_star4,Panel_star5}
local STAR_NODE = "Node_Star"
local RANK_FORMAT = "第%s名"
local LUA_MSGS = {
}

--SYSTEM MSGS

function BattleRewardControl:ctor(model, view)
	BattleRewardControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)
end

function BattleRewardControl:onCreate(param)
	BattleRewardControl.super.onCreate(self, param)

	self:init()
end

function BattleRewardControl:init(  )
	local panel = self:getChildNode(PANEL)
	panel:addTouchEventListener(handler(self, self.closePanel))
	panel:setTouchEnabled(false)
	self.panel = panel
	
	self:getChildNode(STAR_NODE):setVisible(false)
	self:getChildNode(PANEL_RANK):setVisible(false)
	self:playFirstAnime()
	

end

function BattleRewardControl:playFirstAnime(  )
	local node = self:getChildNode(NODE_ANIME)
	local anime = self.model:getAnime()
	if anime == BattleMsg.UP_STAR or anime == BattleMsg.UP_RANK then
		local anime = ccs.Armature:create("jiesuanmingci1")
		anime:getAnimation():setMovementEventCallFunc(function(armature, type, movementID)
			if type == ccs.MovementEventType.complete then
				anime:getAnimation():play("xunhuan", -1, 1)
				self.panel:setTouchEnabled(true)
			end
		end)
		anime:getAnimation():play("kaishi", -1, 0)
		node:addChild(anime)
		local num = string.format(RANK_FORMAT,self.model:getStringNum())
		local num_lable = cc.Label:createWithTTF(num, "res/font/font1.ttf", 60)
		node:addChild(num_lable)
		self.firstAnime = anime
		self.firstLabel = num_lable
	else
		local anime = ccs.Armature:create("jiesuanmingci")
		anime:getAnimation():setMovementEventCallFunc(function(armature, type, movementID)
			if type == ccs.MovementEventType.complete then
				anime:getAnimation():play("xunhuan", -1, 1)
				self.panel:setTouchEnabled(true)
			end
		end)
		anime:getAnimation():play("kaishi", -1, 0)
		node:addChild(anime)
		local num = string.format(RANK_FORMAT,self.model:getStringNum())
		local num_lable = cc.Label:createWithTTF(num, "res/font/font1.ttf", 60)
		num_lable:setColor(display.COLOR_BLACK)
		node:addChild(num_lable)
		self.firstAnime = anime
		self.firstLabel = num_lable
	end
end

function BattleRewardControl:getConfigScore( score )
	return Utils:getConfigScore(score)
end

function BattleRewardControl:playSecondAnime(  )
	self.panel:setTouchEnabled(false)
	self.firstAnime:removeFromParent()
	self.firstLabel:removeFromParent()
	self:getChildNode(PANEL_RANK):setVisible(true)
	self:getChildNode(RANK_BG):setVisible(false)
	self:getChildNode(RANK_ITEM):setVisible(false)
	self:getChildNode(TEXT_NOW):setVisible(false)
	-- self:updateRankShow()
	local score = PlayerDataBasic.score
	local cfg_1 = self:getConfigScore((score-1))
	local cfg_2 = self:getConfigScore((score+1))
	local cfg = self:getConfigScore(score)
	self:getChildNode(TEXT_RANK):setString(cfg.des)
	-- self:getChildNode(RANK_ITEM):setVisible(true)
	-- self:getChildNode(RANK_ITEM):setSpriteFrame(cfg.icon)
	local node = self:getChildNode(NODE_ANIME)
	local anime = self.model:getAnime()
	if anime == BattleMsg.UP_STAR then
		local anime = ccs.Armature:create("shengduanwei")
		anime:getAnimation():setMovementEventCallFunc(function(armature, type, movementID)
			if type == ccs.MovementEventType.complete then
				anime:getAnimation():play("shengduan_xunhuan", -1, 1)
				self:updateRankShow()
			end
		end)
		anime:getAnimation():play("shengduan_chuxian2", -1, 0)
		node:addChild(anime,-1,-1)
		local bone = anime:getBone("Layer5")
		local pSprite = cc.Sprite:createWithSpriteFrameName(cfg.icon) 
		bone:addDisplay(pSprite, 1)
		bone:changeDisplayWithIndex(1,true) 
	end

	if anime == BattleMsg.UP_RANK then
		local anime = ccs.Armature:create("shengduanwei")
		anime:getAnimation():setMovementEventCallFunc(function(armature, type, movementID)
			-- print("type =-=="..tostring(type)..";"..movementID)
			if type == ccs.MovementEventType.complete then
				anime:getAnimation():play("shengduan_xunhuan", -1, 1)
				self:updateRankShow()
			end
		end)
		local bone = anime:getBone("Layer5")
		local pSprite = cc.Sprite:createWithSpriteFrameName(cfg_1.icon) --生成需要显示的Node
		bone:addDisplay(pSprite, 1) --将新生成的Node添加到Bone中
		bone:changeDisplayWithIndex(1,true) --修改Bone的Display为索引15的Display
		anime:getAnimation():play("shengduan_chuxian", -1, 0)
		node:addChild(anime,-1,-1)
		local function onFrameEvent(bone, evt, originFrameIndex, currentFrameIndex) 
			-- print("bon==="..tostring(bone)..";evt==="..evt)
			if tostring(evt) == "100" then 
				local bone = anime:getBone("Layer5")
				local pSprite = cc.Sprite:createWithSpriteFrameName(cfg.icon) 
				bone:addDisplay(pSprite, 1) 
				bone:changeDisplayWithIndex(1,true) 
			end
		end
	 	anime:getAnimation():setFrameEventCallFunc( onFrameEvent )
	end

	if anime == BattleMsg.DOWN_RANK then
		local anime = ccs.Armature:create("diaoduanwei")
		anime:getAnimation():setMovementEventCallFunc(function(armature, type, movementID)
			if type == ccs.MovementEventType.complete then
				self.panel:setTouchEnabled(true)
				anime:getAnimation():play("diaoduanwei_xunhuan", -1, 1)
				self:updateRankShow()
			end
		end)
		anime:getAnimation():play("diaoduanwei_chuxian", -1, 0)
		node:addChild(anime,-1,-1)
		local bone = anime:getBone("Layer4")
		local pSprite = cc.Sprite:createWithSpriteFrameName(cfg_2.icon) --生成需要显示的Node
		bone:addDisplay(pSprite, 1) --将新生成的Node添加到Bone中
		bone:changeDisplayWithIndex(1,true) --修改Bone的Display为索引15的Display
		local function onFrameEvent(bone, evt, originFrameIndex, currentFrameIndex) 
			-- print("bon==="..tostring(bone)..";evt==="..evt)
			if tostring(evt) == "100" then 
				local bone = anime:getBone("Layer4")
				local pSprite2 = cc.Sprite:createWithSpriteFrameName(cfg.icon) 
				bone:addDisplay(pSprite2, 1) 
				bone:changeDisplayWithIndex(1,true) 
			end
		end
	 	anime:getAnimation():setFrameEventCallFunc( onFrameEvent )
		-- local anime2 = ccs.Armature:create("diaoxing")
		-- anime2:getAnimation():setMovementEventCallFunc(function(armature, type, movementID)
		-- 	if type == ccs.MovementEventType.complete then
		-- 		self.panel:setTouchEnabled(true)
		-- 		anime2:removeFromParent()
		-- 	end
		-- end)
		-- anime2:getAnimation():play("diaoxing", -1, 0)
		-- self.next_star:addChild(anime2)
	end

	if anime == BattleMsg.DOWN_STAR then
		local anime = ccs.Armature:create("diaoduanwei")
		anime:getAnimation():setMovementEventCallFunc(function(armature, type, movementID)
			if type == ccs.MovementEventType.complete then
				anime:getAnimation():play("diaoduanwei_xunhuan", -1, 1)
				self:updateRankShow()
			end
		end)
		anime:getAnimation():play("diaoduanwei_chuxian2", -1, 0)
		node:addChild(anime,-1,-1)
		local bone = anime:getBone("Layer4")
		local pSprite = cc.Sprite:createWithSpriteFrameName(cfg.icon) 
		bone:addDisplay(pSprite, 1)
		bone:changeDisplayWithIndex(1,true) 
	end

	if anime == BattleMsg.NONE_STAR then
		local anime = ccs.Armature:create("shengduan_xunhuan")
		self.panel:setTouchEnabled(true)
		anime:getAnimation():play("shengduan_xunhuan", -1, 1)
		node:addChild(anime,-1,-1)
		self:updateRankShow()
		self:getChildNode(RANK_ITEM):setVisible(true)
		self:getChildNode(RANK_ITEM):setSpriteFrame(cfg.icon)
	end
end

function BattleRewardControl:updateRankShow(  )
	local score = PlayerDataBasic.score

	self:getChildNode(STAR_NODE):setVisible(true)
	local cfg = self:getConfigScore(score)
	if isNil(cfg) then printStack() return end
	if isNil(cfg.stars_sum) then printStack() return end
	if isNil(cfg.stars) then printStack() return end

	local stars_sum = cfg.stars_sum
	local stars = cfg.stars
	if stars_sum == 0 then stars_sum = 1 end
	for k , v in ipairs(STAR_TABLE) do
		local panel = self:getChildNode(v)
		if tostring(k) == tostring(stars_sum) then
			panel:setVisible(true)
			self:updateStar(cfg,panel)
		else
			panel:setVisible(false)
		end
	end
end

function BattleRewardControl:updateStar( cfg, panel )
	if isNil(panel) then printStack() return end
	if cfg.stars_sum ~= 0 then
		for i = 1, cfg.stars_sum, 1 do
			local star = panel:getChildByName("Image_star"..i.."")
			if i <= cfg.stars then
				star:setVisible(true)
			else
				star:setVisible(false)
			end

			if i == cfg.stars then
				self.now_star = star
			end

			if i == (cfg.stars+1) then
				self.next_star = panel:getChildByName("Image_star"..i.."_bg")
			end
			
		end
	end

	if cfg.stars_sum == 0 then
		local label = panel:getChildByName("Text_star_num")
		label:setString(cfg.stars)
	end

	local anime = self.model:getAnime()
	if anime == BattleMsg.UP_RANK or anime == BattleMsg.UP_STAR then
		local anime2 = ccs.Armature:create("shengxing")
		anime2:getAnimation():setMovementEventCallFunc(function(armature, type, movementID)
			if type == ccs.MovementEventType.complete then
				self.panel:setTouchEnabled(true)
				anime2:removeFromParent()
			end
		end)
		anime2:getAnimation():play("shengxing", -1, 0)
		anime2:setAnchorPoint(cc.p(0.5, 0.5))
		if self.now_star then
			local size = self.now_star:getContentSize()
			anime2:setPosition(size.width/2,size.height/2)
			self.now_star:addChild(anime2)
		else
			self.panel:setTouchEnabled(true)
		end
	elseif anime == BattleMsg.DOWN_STAR then
		local anime2 = ccs.Armature:create("diaoxing")
		anime2:getAnimation():setMovementEventCallFunc(function(armature, type, movementID)
			if type == ccs.MovementEventType.complete then
				self.panel:setTouchEnabled(true)
				anime2:removeFromParent()
			end
		end)
		anime2:getAnimation():play("jiangxing", -1, 0)
		anime2:setAnchorPoint(cc.p(0.5, 0.5))
		if self.next_star then
			local size = self.next_star:getContentSize()
			anime2:setPosition(size.width/2,size.height/2)
			self.next_star:addChild(anime2)
		else
			self.panel:setTouchEnabled(true)
		end
	end 
end

	

function BattleRewardControl:closePanel(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended then
	    if self.model.click == 1 then
	    	self.model.click = 2
	    	self:playSecondAnime()
	    elseif self.model.click == 2 then

			print("detachFromParent")
			-- SoundManager:playEffect("button.mp3")
			self:detachFromParent()
		end
	end
end

function BattleRewardControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()
	print("BattleRewardControl:recv name = " .. tostring(senderName))
	if senderName == BTN_CLOSE then
		self:detachFromParent()
	end
end

function BattleRewardControl:recv(event)
	if isNil(event) then printStack() end
	if isNil(event.name) then printStack() end
	if isNil(event.data) then printStack() end
	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

return BattleRewardControl;