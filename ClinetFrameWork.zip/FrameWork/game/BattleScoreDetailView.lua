local EngineView = require "EngineView"
local BattleScoreDetailView = class("BattleScoreDetailView", EngineView)

function BattleScoreDetailView:ctor(node)
	BattleScoreDetailView.super.ctor(self, node)
end

function BattleScoreDetailView:onCreate(param)
	BattleScoreDetailView.super.onCreate(self, param)
	local csbNode = cc.CSLoader:createNode("res/RankReward.csb")
	if isNil(csbNode) then printStack() return end
	self:getNode():addChild(csbNode)
	csbNode:setPosition(0, gScreenSize.height)
	UIManager:runPopupEnterAction(csbNode)
end


return BattleScoreDetailView;
