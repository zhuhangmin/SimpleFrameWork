local EngineControl = require  "EngineControl"
local HomeControl = class("HomeControl", EngineControl)
local GlobalStatus = require "GlobalStatus"
local UserConvertAdapter = require('src.app.userconvert.UserConvertAdapter')

--LUA MSGS
local LUA_MSGS = {
	GameMsg.MSG_EXIT_GAME_RET,
	GameMsg.GET_NEW_MAIL,
	GameMsg.MSG_CHARGEACTIVITY_RESULT,
	GameMsg.MSG_TIMECHARGEACTIVITY_INFO,
	GameMsg.MSG_GET_CULTURE_RET,
	GameMsg.MSG_GOTO_CULTUREROOM,
	BattleMsg.MATCH_DATA,
	GameMsg.GET_PLAYER_DATA,
	GameMsg.MSG_CULTURE_UPDATE,
	GameMsg.SHOW_AD_ENTER_BTN,
}

--SYSTEM MSGS
local BTN_PLAYER_INFO = "Panel_player"
local BTN_RETURN = "Button_return"
local BTN_CHARGE = "Button_charge"
local BTN_ROLE = "Button_mode1"
local BTN_SHOP = "Button_mode2"
local BTN_GACHA = "Button_lottery"
local BTN_GACHA2 = "Button_gacha"
local BTN_TIMECHARGE = "Button_discount"
local TEXT_RANK = "text_rank"
local RANK_ITEM = "Sprite_rank_item"
local BTN_CULTURE = "Button_lab"
local BTN_TEAM  = "Button_CulturingRoom"
--Menu
local BTN_ACTIVE = "Button_active"
local BTN_MAIL = "Button_mail"
local BTN_SET = "Button_setup"
local BTN_BATTLE = "Button_start"
local ANIME_BATTLE = "Node_mode3"
local NODE_ANIME = "Node_draw_tips"
local BTN_AD = "Button_ad"

local SYSTEM_MSGS = {
	BTN_PLAYER_INFO,
	BTN_RETURN,
	BTN_CHARGE,
	BTN_ROLE,
	BTN_SHOP,
	BTN_GACHA,
	BTN_ACTIVE,
	BTN_MAIL,
	BTN_SET,
	BTN_BATTLE,
	BTN_TIMECHARGE,
	BTN_CULTURE,
	BTN_GACHA2,
	BTN_TEAM,
	BTN_AD,
}

--GAME LABLES
local LBL_NICKNAME = "Text_name"

--OTHER NODE
local CHARGE_ANIM_NODE = "FileNode_2"
local IMG_HEAD = "Image_head"
local PANEL_BUTTON = "Panel_button"
local RECONNECT_GAME = HomeControl:getConfigField("tips", "TIPS_RECONNECT", "content")

function HomeControl:ctor(model, view)
	HomeControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)
end

function HomeControl:addAnime( ... )
	local parent = self:getChildNode(NODE_ANIME)
	local armature = ccs.Armature:create("MengJun_DaTing")
	local size = armature:getBoundingBox()
	armature:getAnimation():play("Animation01", -1, 1)
	parent:addChild(armature)

	local armHint = ccs.Armature:create("MengJun_DaTing_tanchuang")
	local size = armHint:getBoundingBox()
	armHint:getAnimation():play("Animation01", -1, 1)
	parent:addChild(armHint)
end

function HomeControl:onCreate(param)
	HomeControl.super.onCreate(self, param)

	local name = "game.Riches"
	self:addPanel(name)

	self:addAnime()

	local nickNameLbl = self:getChildNode(LBL_NICKNAME)
	if isNil(nickNameLbl) then printStack() return end
	nickNameLbl:setString(PlayerDataBasic.nickname)

	--播放音乐
	local musicName = GlobalStatus.getInstance():getMusicName()
	if isNil(musicName) then printStack() return end
	if musicName ~= DEFAULT_MUSIC then
		GlobalStatus.getInstance():setMusicName(DEFAULT_MUSIC)
		self:send(GameMsg.MSG_SWITCH_BGM)
	end

	local imgHead = self:getChildNode(IMG_HEAD)
	local data = PlayerDataBasic
	setImgIconById(imgHead, data.cur_skin )


	self:setStar()

	self:updateChargeState()

	local panel_button = self:getChildNode(PANEL_BUTTON)
	if isNil(panel_button) then printStack() return end
	panel_button:setLocalZOrder(1)
	self:updateRedPoint()

	--用户转化入口
	local exitBtn = self:getChildNode(BTN_RETURN)
	-- Utils:checkUserConvert(cc.p(500, exitBtn:getPositionY() - 5))

	local btn_gacha = self:getChildNode(BTN_GACHA)
	if isNil(btn_gacha) then printStack() return end
	btn_gacha:setContentSize(cc.size(390, 450))
	btn_gacha:setPosition(415,295)
	-- PrintNodeTree(self:getNode())


	local armature = ccs.Armature:create("kaishizhandou")
	armature:getAnimation():play("kaishizhandou", -1, 1)
	armature:setPosition(-18,7)
	self:getChildNode(ANIME_BATTLE):addChild(armature)



	-- self:getChildNode(BTN_AD):setVisible(true)
	self:getChildNode(BTN_AD):setVisible(PlayerData_AD_show_enter_btn)
	self:getChildNode(BTN_TIMECHARGE):setVisible(false)
	self:setTimeActivity()
	
	self:getActivityData()

	local action1 = cc.DelayTime:create(0.2)
	local action2 = cc.CallFunc:create(function()
		if ReconnectData.roomid then
			local contentStr = RECONNECT_GAME
			local confirmCB = function()
				send_info("room.enter_room", {})
				ReconnectData.roomid = nil
			end
			local cancelCB = function()
				send_info("room.leave_room", {})
				ReconnectData.roomid = nil
			end
			self:addMsgBox(contentStr, confirmCB, cancelCB)
		end
	end)
	local action3 = cc.Sequence:create(action1, action2)
	self:getNode():runAction(action3)

	----广告接口例子
	-- print("start adsssss=====")
	-- printLog("luaTestScene", "ADPlugin Lua Callback")
	-- local function adTestCallback( code, msg )
		
	-- 	print("luaTestScene ".."code="..code..", msg="..msg)
	-- end
	-- local AdPlugin = plugin.AgentManager:getInstance():getAdsPlugin()
	-- AdPlugin:setCallback(1,"")
	-- AdPlugin:loadChannelAd(1, {})
	-- AdPlugin:showChannelAd(1, {})
	-- AdPlugin:setCallback( adTestCallback )
	-- AdPlugin:destroyChannelAd(1, {})
	-- AdPlugin:exitAdSDK()

	-- print("start adsssss===== end")

	-- local panel_name = "game.BattleReward"
	-- local params = {}
	-- params.modelParam = {anime = BattleMsg.DOWN_STAR,data = {stars= 1,rank = 1},num =23}
	-- self:addPanel(panel_name,params) 

	print("HardID = ",UserConvertAdapter.getHardID())


	
end

function HomeControl:setStar( ... )
	local score = PlayerDataBasic.score
	local cfg = Utils:getConfigScore(score)
	self:getChildNode(TEXT_RANK):setString(cfg.des)
	self:getChildNode(RANK_ITEM):setSpriteFrame(cfg.icon)
	for i = 1, 5, 1 do
		local star = self:getChildNode("Image_star"..i.."_bg")
		local star2 = self:getChildNode("Image_star"..i.."")
		if i <= cfg.stars_sum then
			star:setVisible(true)
			star2:setVisible(true)
		else
			star:setVisible(false)
			star2:setVisible(false)
		end
	end

	for i = 1, cfg.stars_sum, 1 do
		local star = self:getChildNode("Image_star"..i.."")
		if i <= cfg.stars then
			star:setVisible(true)
		else
			star:setVisible(false)
		end
	end
end

function HomeControl:setTimeActivity()
	local timeActivityBtn = self:getChildNode(BTN_TIMECHARGE)
	if TimeChargeData and TimeChargeData.timeout and TimeChargeData.timeout > 0 then
		local deltaTime = os.time()-GlobalStatus.getInstance():getLoginTime()
		if TimeChargeData.timeout - deltaTime > 0  then
			timeActivityBtn:setVisible(true)
			self:startScheduler(0.1)
		else
			timeActivityBtn:setVisible(false)
		end
	else
		timeActivityBtn:setVisible(false)
	end
end

function HomeControl:onUpdate()
	local deltaTime = os.time()-GlobalStatus.getInstance():getLoginTime()
	local time = TimeChargeData.timeout - deltaTime
	if notNumber(time) then printStack() end

	local timeActivityBtn = self:getChildNode(BTN_TIMECHARGE)
	if isNil(timeActivityBtn) then printStack() return end

	local text_discount = timeActivityBtn:getChildByName("Text_discount")
	if isNil(text_discount) then printStack() return end

	local hour = math.floor(time/3600)
	local min = math.floor((time%3600)/60)
	local sec = math.floor((time%3600)%60)

	text_discount:setString(string.format("%02d",hour)..":"..string.format("%02d",min)..":"..string.format("%02d",sec))

	if time <= 0 then
		timeActivityBtn:setVisible(false)

		self:cancelScheduler()
	end
end

function HomeControl:getActivityData(  )
	local data ={}
	data.func = "getAcSign"
	self:send(BASE_MSG.NET_FORM, data)

	local data ={}
	data.func = "getNeSign"
	self:send(BASE_MSG.NET_FORM, data)
end


function HomeControl:clickStart( )
	-- if touchEventType == ccui.TouchEventType.ended then
		--每天弹出一次转换界面
		local canConvert = canUserConvert()
		if canConvert then
			local userDefault = cc.UserDefault:getInstance()
			local convertTime = userDefault:getIntegerForKey("CONVERT_TIME", 0)
			local lastday = math.floor(convertTime/86400)
			local cur_time = os.time()
			local curday = math.floor(cur_time/86400)
			print(curday,lastday,PlayerDataSystem.total_online_time)
			if PlayerDataSystem.total_online_time>=900 and curday>lastday then
				userDefault:setIntegerForKey("CONVERT_TIME", cur_time)
				self:addPop("game.UpdateTip")
				return
			end
		end

		if table.nums(CultureData) == 4 then
			local userDefault = cc.UserDefault:getInstance()
			local tipTime = userDefault:getIntegerForKey("SHOW_CULTURETIPS_TIME", 0)
			local lastday = math.floor(tipTime/86400)
			local cur_time = os.time()
			local curday = math.floor(cur_time/86400)
			if curday>lastday then
				self:addPop("game.CultureTip")
				return
			end
		end
		
		SoundManager:playEffect("button.mp3")

		self:addPop("game.BattleMatch")
		--第一次进入点击快速开始埋点
		local firstClick = GlobalStatus.getInstance():getFirstClick()
		if PlayerDataSystem.login_count == 1 and firstClick then
			SDKFunc.log:logEventCount(Constant.LogEventName[11])
			GlobalStatus.getInstance():setFirstClick(false)
		end
	-- end
end

function HomeControl:updateChargeState()
	--首充奖励
	local action = cc.CSLoader:createTimeline("res/Charge.csb")
	action:gotoFrameAndPlay(0, 100, true)
	local firstChargeNode = self:getChildNode(CHARGE_ANIM_NODE)
	firstChargeNode:runAction(action)

	if PlayerDataBasic.charge_activity1 ~= 0 then
		if PlayerDataBasic.charge_activity2 == 0 then
			local btn_charge = self:getChildNode(BTN_CHARGE)
			btn_charge:loadTextureNormal("home_new/btn_zklb1.png", ccui.TextureResType.plistType)
			btn_charge:loadTexturePressed("home_new/btn_zklb2.png", ccui.TextureResType.plistType)
		else
			firstChargeNode:setVisible(false)
		end
	end

	--显示首充活动
	local showCharge = self:getModel():getShowCharge()
	if isNil(showCharge) then printStack() return end
	if PlayerDataSystem.login_count>1 and showCharge then
		local action1 = cc.DelayTime:create(0.1)
		local action2 = cc.CallFunc:create(function()
			self:onChargeBtnClick(function()--关闭回调
				if TimeChargeData and TimeChargeData.timeout and TimeChargeData.timeout > 0 then
					local deltaTime = os.time()-GlobalStatus.getInstance():getLoginTime()
					if TimeChargeData.timeout - deltaTime > 0  then
						local name = "game.TimeGift"
						self:addPop(name)
					end
				end
			end)
			self:getModel():setShowCharge(false)
		end)
		local action3 = cc.Sequence:create(action1, action2)
		self:getNode():runAction(action3)
	end
end

function HomeControl:systemRecv(event)
	local name = event.name
	local data = event.data

	local sender = data
	local senderName = sender:getName()
	

	if senderName == BTN_PLAYER_INFO then
		local data = {}
		data.name = "game.PlayerInfo"
		self:send(BASE_MSG.PUSH, data)
	end

	if senderName == BTN_RETURN then
		-- if device.platform == "windows" then
		-- 	self:addExitUI()
		-- else
		-- 	LoginManager:exit()
		-- end
		self:send(GameMsg.MSG_TRY_EXIT_GAME)
	end

	if senderName == BTN_CHARGE then
		self:onChargeBtnClick()
	end

	if senderName == BTN_ROLE then
	-- self:addPop("game.BattleMatch")

		local data = {}
		data.name = "game.Character"
		self:send(BASE_MSG.PUSH, data)

		--第一次进入点击角色埋点
		local firstClick = GlobalStatus.getInstance():getFirstClick()
		if PlayerDataSystem.login_count == 1 and firstClick then
			SDKFunc.log:logEventCount(Constant.LogEventName[12])
		end
	end

	if senderName == BTN_SHOP then
		local data = {}
		data.name = "game.Shop"
		self:send(BASE_MSG.PUSH, data)

		--第一次进入点击商城埋点
		local firstClick = GlobalStatus.getInstance():getFirstClick()
		if PlayerDataSystem.login_count == 1 and firstClick then
			SDKFunc.log:logEventCount(Constant.LogEventName[13])
		end
	end

	if senderName == BTN_GACHA then
		local data = {}
		data.name = "game.Gacha"
		self:send(BASE_MSG.PUSH, data)

		--第一次进入点击扭蛋埋点
		local firstClick = GlobalStatus.getInstance():getFirstClick()
		if PlayerDataSystem.login_count == 1 and firstClick then
			SDKFunc.log:logEventCount(Constant.LogEventName[14])
		end
	end

	if senderName == BTN_GACHA2 then
		local data = {}
		data.name = "game.Gacha"
		self:send(BASE_MSG.PUSH, data)

		--第一次进入点击扭蛋埋点
		local firstClick = GlobalStatus.getInstance():getFirstClick()
		if PlayerDataSystem.login_count == 1 and firstClick then
			SDKFunc.log:logEventCount(Constant.LogEventName[14])
		end
	end

	if senderName == BTN_ACTIVE then
	    local name = "game.Activity"
	    local modelParam = {}
	    local data = buildMsgData(name, modelParam)
	    self:send(BASE_MSG.PUSH, data)		
	end

	if senderName == BTN_AD then
		local data ={}
		data.func = "ADEventTracking"
		data.params = {event_name = "open_ad"}
		self:send(BASE_MSG.NET_FORM, data)
		self:addPop("game.Ad")
	end

	if senderName == BTN_MAIL then
	    local name = "game.Mail"
	    local modelParam = {curIndex = table.nums(MailData)}
	    local data = buildMsgData(name, modelParam)
	    self:send(BASE_MSG.PUSH, data)
	end

	if senderName == BTN_SET then
		local name = "game.Setting"
		
		local music = GameData.settingInfo.musicEnable
		local effect = GameData.settingInfo.effectEnable
		local quality = GameData.settingInfo.qualityValue

		local data = {}
		data.modelParam = {music = music,effect = effect ,quality = quality}

		self:addPop(name,data)
	end

	if senderName == BTN_TIMECHARGE then
		local name = "game.TimeGift"
		self:addPop(name)
	end

	if senderName == BTN_BATTLE then
		self:clickStart()
	end

	if senderName == BTN_CULTURE then
	  	local data = {}
		data.name = "game.CulturingRoom"
		self:send(BASE_MSG.PUSH, data)
	end

	if senderName == BTN_TEAM then
		self:addPop("game.BattleMatchPeer")
	end


	GlobalStatus.getInstance():setFirstClick(false)
end

function HomeControl:recv(event)

	self.super.recv(self, event)
	-- if isNil(event) then printStack() end
	-- if isNil(event.name) then printStack() end
	-- if isNil(event.data) then printStack() end
	print("HomeControl:recv name = " .. tostring(event.name))
	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

	-- if name == GameMsg.MSG_EXIT_GAME_RET then
	-- 	self:addExitUI()
	-- 	return
	-- end	 

	if name == GameMsg.GET_NEW_MAIL then
		self:updateRedPoint()
		return
	end

	if name == GameMsg.MSG_CHARGEACTIVITY_RESULT then
		local firstChargeNode = self:getChildNode(CHARGE_ANIM_NODE)
		if PlayerDataBasic.charge_activity1 ~= 0 then
			if PlayerDataBasic.charge_activity2 == 0 then
				local btn_charge = self:getChildNode(BTN_CHARGE)
				btn_charge:loadTextureNormal("home_new/btn_zklb1.png", ccui.TextureResType.plistType)
				btn_charge:loadTexturePressed("home_new/btn_zklb2.png", ccui.TextureResType.plistType)
			else
				firstChargeNode:setVisible(false)
			end
		end
	end

	if name == GameMsg.MSG_TIMECHARGEACTIVITY_INFO then
		self:setTimeActivity()
	end

	if name == GameMsg.MSG_GET_CULTURE_RET then
		local name = "game.CultureGet"
		local param = {modelParam = {item_id = data[1].item_id}}
		self:addPop(name,param)
	end

	if name == GameMsg.MSG_GOTO_CULTUREROOM then
	    local data = {}
		data.name = "game.CulturingRoom"
		self:send(BASE_MSG.PUSH, data)
	end

	if name == BattleMsg.MATCH_DATA then
		if GameData.matchData then
			self:send(BASE_MSG.PUSH, {name = "game.Battle"})
		end
	end

	if name == GameMsg.GET_PLAYER_DATA then
		self:setStar()
	end

	if name == GameMsg.MSG_CULTURE_UPDATE then
		GlobalStatus.getInstance():setCultureTime(os.time())
	end

	if name == GameMsg.SHOW_AD_ENTER_BTN then
		self:getChildNode(BTN_AD):setVisible(PlayerData_AD_show_enter_btn)
	end
end

function HomeControl:onChargeBtnClick(callback)
	if PlayerDataBasic.charge_activity1 == 0 then
		local name = "game.FirstCharge"
		local param = {modelParam = {callback = callback}}
		self:addPop(name,param)
	elseif PlayerDataBasic.charge_activity2 == 0 then
		local name = "game.Discount"
		local param = {modelParam = {callback = callback}}
		self:addPop(name,param)
	end
end

function HomeControl:updateRedPoint()
	local btn_list = {BTN_ACTIVE,BTN_MAIL,BTN_SET}
	local len = table.nums(btn_list)

	for i=1,len do
		local btn = self:getChildNode(btn_list[i])
		if isNil(btn) then printStack() end

		local red_other = btn:getChildByName("Image_redpoint")
		if isNil(red_other) then printStack() end

		local isVisible = self:getRedPointVisible(i)
		red_other:setVisible(isVisible)
	end
end

function HomeControl:getRedPointVisible(index)
	local isVisible = false

	if index == 1 then
		--活动
		isVisible = self:getActivityRedVisible()
	elseif index == 2 then
		--邮件
		isVisible = self:getMailRedVisible()
	elseif index == 3 then
		--设置
	end

	return isVisible
end

function HomeControl:getActivityRedVisible()
	local isVisible = false
	if ActivityData.ne_red == 0 or ActivityData.ac_red == 0 or canUserConvert() then
		isVisible = true
	end
	return isVisible
end

function HomeControl:getMailRedVisible()
	if MailData_unReadMailExist == 1 then
		return true
	else--已读但是未领取奖励邮件
		for k,v in pairs(MailData) do
			local rewardID = v.reward
			if haveReward(rewardID) then
				if v.rewardstate == 0 then
					return true
				end
			end
		end
	end

	return false
end

return HomeControl


