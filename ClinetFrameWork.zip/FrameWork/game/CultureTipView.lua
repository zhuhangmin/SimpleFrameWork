local EngineView = require "EngineView"
local CultureTipView = class("CultureTipView", EngineView)

local csbFilePath = "res/CultureTip.csb"
CULTURETIP_CSB_NODE = 1000

function CultureTipView:ctor(node)
	CultureTipView.super.ctor(self, node)
end

function CultureTipView:onCreate(param)
	CultureTipView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	csbNode:setTag(CULTURETIP_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return CultureTipView





