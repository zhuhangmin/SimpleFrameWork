local EngineControl = require  "EngineControl"
local TimeGiftControl = class("TimeGiftControl", EngineControl)

local GlobalStatus = require "GlobalStatus"

--LUA MSGS
local LUA_MSGS = {
	GameMsg.MSG_CHARGEACTIVITY_RESULT,
	GameMsg.MSG_GET_PAY_ORDER_ID_RET,
	GameMsg.MSG_GET_PAY_ACTIVITY_ORDER_ID_RET,
}

--SYSTEM MSGS
local BTN_RETURN = "Button_close"
local BTN_CHARGE = "Button_charge"
local SYSTEM_MSGS = {
	BTN_RETURN,
	BTN_CHARGE,
}

local PANEL_REWARD = "Panel_gift_%d"
local TEXT_NUM = "text_amount"
local IMG_REWARD = "Node_gift"
local KEY_REWARD = "reward%d"
local KEY_NUM = "num%d"
local TEXT_NAME = "Text_name"
local TEXT_PRICEORI= "text_price_original"
local TEXT_PRICENOW= "text_price_now"
local TEXT_HOUR= "text_hour"
local TEXT_MINUTE = "text_minute"
local TEXT_SECOND = "text_second"
local IMAGE_TITLE = "Image_title_text1"
 
local ACTIVITY_ID = TimeChargeData.index
if isNil(ACTIVITY_ID) then printStack() return end

function TimeGiftControl:ctor(model, view)
	TimeGiftControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
	
end

function TimeGiftControl:onCreate(param)
	TimeGiftControl.super.onCreate(self, param)
	if isNil(param) then printStack() end

	self:setGiftInfo()
end

function TimeGiftControl:setGiftInfo()
	local chargeActivityInfo = self:getConfigRecord("chargeActivty", ACTIVITY_ID)
	if isNil(chargeActivityInfo) then printStack() return end

	if chargeActivityInfo.title and chargeActivityInfo.title~="null" then
		local image_title = self:getChildNode(IMAGE_TITLE)
		if isNil(image_title) then printStack() end
		image_title:loadTexture(chargeActivityInfo.title..".png", ccui.TextureResType.plistType)
	end

	local price_original = self:getChildNode(TEXT_PRICEORI)
	if isNil(price_original) then printStack() end
	
	local price_now = self:getChildNode(TEXT_PRICENOW)
	if isNil(price_now) then printStack() end

	price_original:setString(chargeActivityInfo.old_price)
	price_now:setString(chargeActivityInfo.new_price)

	self:setAwards()

	self:startScheduler(0.1)
end

function TimeGiftControl:setAwards()
	local chargeActivityInfo = self:getConfigRecord("chargeActivty", ACTIVITY_ID)
	if isNil(chargeActivityInfo) then printStack() return end

	local giftInfo = self:getConfigRecord("giftPack", chargeActivityInfo.gift_id)
	if isNil(giftInfo) then printStack() return end	

	local itemConfig = self:getTable("item")
	if isNil(itemConfig) then printStack() return end

    local starID = self:getConfigField("global",1,"STAR_ITEM_ID")
    if isNil(starID) then printStack() return end

    local diamondID = self:getConfigField("global",1,"DIAMOND_ITEM_ID")
    if isNil(diamondID) then printStack() return end

    local lolipopID = self:getConfigField("global",1,"LOLLIPOP_ITEM_ID")
    if isNil(lolipopID) then printStack() return end

	for i=1,4 do
		local keyReward = string.format(KEY_REWARD,i)
		if notNumber(giftInfo[keyReward]) then printStack() return end

		local keyNum = string.format(KEY_NUM,i)
		if notNumber(giftInfo[keyNum]) then printStack() return end

		local itemID = giftInfo[keyReward]
		local itemNum = giftInfo[keyNum]

		local isItem = (itemID~=0 and itemNum~=0)
		if isItem then
			local itemName = ""
			if itemID==starID then
				itemName = "星星"
			elseif itemID==diamondID then
				itemName = "钻石"
			elseif itemID==lolipopID then
				itemName = "棒棒糖"
			else
				if isNil(itemConfig[itemID]) then printStack() end
				itemName = itemConfig[itemID].name
			end
			local panelReward = self:getChildNode(string.format(PANEL_REWARD,i))
			if isNil(panelReward) then printStack() end

			local imgReward = panelReward:getChildByName(IMG_REWARD)
			if isNil(imgReward) then printStack() end

			local text_name = panelReward:getChildByName(TEXT_NAME)
			if isNil(text_name) then printStack() end

			addItmeNode(imgReward,itemID,itemNum)
			text_name:setString(itemName)
		end
	end
end

function TimeGiftControl:onUpdate()
	local text_hour = self:getChildNode(TEXT_HOUR)
	if isNil(text_hour) then printStack() end

	local text_minute = self:getChildNode(TEXT_MINUTE)
	if isNil(text_minute) then printStack() end

	local text_second = self:getChildNode(TEXT_SECOND)
	if isNil(text_second) then printStack() end

	local deltaTime = os.time()-GlobalStatus.getInstance():getLoginTime()
	local time = TimeChargeData.timeout - deltaTime
	if notNumber(time) then printStack() end

	local hour = math.floor(time/3600)
	local min = math.floor((time%3600)/60)
	local sec = math.floor((time%3600)%60)

	text_hour:setString(string.format("%02d",hour))
	text_minute:setString(string.format("%02d",min))
	text_second:setString(string.format("%02d",sec))

	if time <= 0 then
		self:detachFromParent()
	end
end

function TimeGiftControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_RETURN then
		self:detachFromParent()
	end

	if senderName == BTN_CHARGE then
		local chargeActivityInfo = self:getConfigRecord("chargeActivty", ACTIVITY_ID)
		if isNil(chargeActivityInfo) then printStack() end

		local exchangeid = 0
		if PlayerDataSystem.device_type == 1 then --ANDROID
			exchangeid = chargeActivityInfo.android_exchangeid
		elseif PlayerDataSystem.device_type == 2 then --IOS
			exchangeid = chargeActivityInfo.apple_exchangeid
		end

		--@zhuhangmin 执行placeOrderActiviy 不使用二段式
		local data ={}
		data.func = "placeOrderActivity"
		data.params = {activity_id = ACTIVITY_ID, exchangeid = exchangeid}
		self:send(BASE_MSG.NET_FORM_WAIT, data)
	end
end

function TimeGiftControl:recv(event)
	self.super.recv(self, event)

	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

	if name == GameMsg.MSG_GET_PAY_ACTIVITY_ORDER_ID_RET then
		--第三方支付
		local chargeActivityInfo = self:getConfigRecord("chargeActivty", ACTIVITY_ID)
		if isNil(chargeActivityInfo) then printStack() end
		if data.activity_id == ACTIVITY_ID then
			if device.platform ~= "windows" then
				SDKFunc.pay:pay(data.exchangeid, data.orderid,chargeActivityInfo)
			else
				print("need test on device")
			end
		end
	end

	if name == GameMsg.MSG_CHARGEACTIVITY_RESULT then
		self:detachFromParent()
	end

end

return TimeGiftControl


