local EngineView = require "EngineView"
local PlayerInfoSetView = class("PlayerInfoSetView", EngineView)

local csbFilePath = "res/PlayerSet.csb"
PLAYERINFOSET_CSB_NODE = 1000

function PlayerInfoSetView:ctor(node)
	PlayerInfoSetView.super.ctor(self, node)
end

function PlayerInfoSetView:onCreate(param)
	PlayerInfoSetView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	csbNode:setTag(PLAYERINFOSET_CSB_NODE)
	self:getNode():addChild(csbNode)

end

return PlayerInfoSetView





