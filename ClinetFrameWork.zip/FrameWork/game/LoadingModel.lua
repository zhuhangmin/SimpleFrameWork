local EngineModel = require "EngineModel"
local LoadingModel = class("LoadingModel", EngineModel)

function LoadingModel:ctor(data)
	LoadingModel.super.ctor(self, data)
end

return LoadingModel

