local EngineControl = require  "EngineControl"
local ActivityControl = class("ActivityControl", EngineControl)
--LUA MSGS
local LUA_MSGS = {
}

--SYSTEM MSGS
local BTN_CLOSE 	= "Button_close"

local SYSTEM_MSGS = {
	BTN_CLOSE,
}


local KEY_REWARD = "reward%d"
local KEY_NUM = "num%d"

function ActivityControl:ctor(model, view)
	ActivityControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)

	
end

function ActivityControl:onCreate(param)
	ActivityControl.super.onCreate(self, param)
	
end

function ActivityControl:onEnter( param )


	-- self.tabIndex = - 1
	self:initUI()
end

function ActivityControl:initUI( ... )


	local can_receive = self.model:getCanReceive()
	self:getChildNode(BTN_GET):setEnabled(can_receive)
	self:getChildNode(BTN_GET):setBright(can_receive)
end


function ActivityControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()

	if senderName == BTN_CLOSE then
		self:backEventExt()
	end


end


function ActivityControl:recv(event)
	if isNil(event) then printStack() end
	if isNil(event.name) then printStack() end
	if isNil(event.data) then printStack() end
	print("ActivityControl:recv name = " .. tostring(event.name))
	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end

	if name == GameMsg.SIGN_AWARD then
		self:rewardAnimePop(data)
		self:updateUI()
		return
	end	

	if name == GameMsg.SIGN_UPDATE then
		self:updateUI()
	end
end

return ActivityControl;