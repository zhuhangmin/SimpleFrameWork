local EngineModel = require "EngineModel"
local ActivityModel = class("ActivityModel", EngineModel)

function ActivityModel:onCreate( data )
	ActivityModel.super.onCreate(self, data)

end


function ActivityModel:ctor(data)
	ActivityModel.super.ctor(self, data)
end

function ActivityModel:onEnter( data )
	-- self.netData = data
end


return ActivityModel; 