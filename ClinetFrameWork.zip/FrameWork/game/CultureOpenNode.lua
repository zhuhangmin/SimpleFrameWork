local CultureOpenNode = class("CultureOpenNode", function()
	return cc.CSLoader:createNode("res/CultureOpen.csb")
end)
local ConfigManager = require "ConfigManager"
local GlobalStatus = require "GlobalStatus"

function CultureOpenNode:ctor(ctrl,index)
	self.ctrl = ctrl
	self.index = index
	self.info = nil

	self:updateInfo()
end

function CultureOpenNode:updateInfo(info)
	self.info = info

	local panel_Empty = self:getChildByName("Panel_Empty")
	if isNil(panel_Empty) then printStack() return end

	local panel_Culture = self:getChildByName("Panel_Culture")
	if isNil(panel_Culture) then printStack() return end
	panel_Culture:addTouchEventListener(handler(self, self.clickCulture))

	toggleNodesVisible(panel_Culture,panel_Empty,info~=nil)

	if info then
		local panel_State_Get = panel_Culture:getChildByName("Panel_State_Get")
		if isNil(panel_State_Get) then printStack() return end

		local panel_State_Culturing = panel_Culture:getChildByName("Panel_State_Culturing")
		if isNil(panel_State_Culturing) then printStack() return end

		local panel_State_Finish = panel_Culture:getChildByName("Panel_State_Finish")
		if isNil(panel_State_Finish) then printStack() return end

		local btn_update = panel_State_Get:getChildByName("Button_Update")--升级
		if isNil(btn_update) then printStack() return end
		btn_update:addTouchEventListener(handler(self, self.clickUpdate))

		local btn_start = panel_State_Get:getChildByName("Button_Start")--开始
		if isNil(btn_start) then printStack() return end
		btn_start:addTouchEventListener(handler(self, self.clickStart))

		local btn_speedup = panel_State_Culturing:getChildByName("Button_SpeedUp")--加速
		if isNil(btn_speedup) then printStack() return end
		btn_speedup:addTouchEventListener(handler(self, self.clickSpeedUp))

		local btn_finish = panel_State_Finish:getChildByName("Button_Finish")--领取
		if isNil(btn_finish) then printStack() return end
		btn_finish:addTouchEventListener(handler(self, self.clickFinish))

		local itemConfig = ConfigManager.getInstance():getTable("item")
		if isNil(itemConfig) then printStack() return end

		local itemInfo = itemConfig[info.item_id]
		if isNil(itemInfo) then printStack() return end
		local aniName = itemInfo.img

		local text_Title = panel_Culture:getChildByName("Text_Title")
		if isNil(text_Title) then printStack() return end
		text_Title:setString(itemInfo.name)

		if info.isStart == 0 then
			panel_State_Get:setVisible(true)
			panel_State_Culturing:setVisible(false)
			panel_State_Finish:setVisible(false)

			local nextID = itemInfo.post_order
			local nextItemInfo = itemConfig[nextID]
			if nextItemInfo then
				local compound = nextItemInfo.compound
				local synthesisConfig = ConfigManager.getInstance():getTable("synthesis")
				local synthesisInfo = synthesisConfig[compound]
				local text_Update_Count = btn_update:getChildByName("Text_Update_Count")
				local id = synthesisInfo.item1
				local needNum = synthesisInfo.num1
				local curNum = getItemCountById(id)
				text_Update_Count:setString(curNum.."/"..needNum)

				local image_UpdateItem = btn_update:getChildByName("Image_UpdateItem")
				image_UpdateItem:loadTexture("tiehua/"..id..".png",ccui.TextureResType.plistType)
			else
				btn_update:setVisible(false)
			end
			local text_Culture_Time = panel_State_Get:getChildByName("Text_Culture_Time")
			text_Culture_Time:setString(string.format("（培育需%d小时）",itemInfo.open_time/3600))
		elseif info.isStart == 1 and info.timeout>0 then
			local deltaTime = os.time()-GlobalStatus.getInstance():getLoginTime()
			local time = info.timeout - deltaTime
			if notNumber(time) then printStack() end
			if time > 0 then
				panel_State_Get:setVisible(false)
				panel_State_Culturing:setVisible(true)
				panel_State_Finish:setVisible(false)

				local text_SpeedUp_Count = btn_speedup:getChildByName("Text_SpeedUp_Count")
				local lolipopCost = self:getLolipopCost()
				text_SpeedUp_Count:setString(lolipopCost)

				self:updateTime()
				self.ctrl:cancelScheduler() 
				self.ctrl:startScheduler(0.1) 
			else
				panel_State_Get:setVisible(false)
				panel_State_Culturing:setVisible(false)
				panel_State_Finish:setVisible(true)

				aniName = string.split(aniName,"_")[1]
			end
		else
			panel_State_Get:setVisible(false)
			panel_State_Culturing:setVisible(false)
			panel_State_Finish:setVisible(true)

			aniName = string.split(aniName,"_")[1]
		end

		local node_Culture = panel_Culture:getChildByName("Image_CultureBg2"):getChildByName("Node_Culture")
		if isNil(node_Culture) then printStack() return end
		node_Culture:removeAllChildren()

		local armature = ccs.Armature:create("lingyexunhuan")
		armature:getAnimation():play(aniName, -1, 1)
		node_Culture:addChild(armature)
	end
end

function CultureOpenNode:updateTime()
	local panel_Culture = self:getChildByName("Panel_Culture")
	if isNil(panel_Culture) then printStack() end

	local panel_State_Culturing = panel_Culture:getChildByName("Panel_State_Culturing")
	if isNil(panel_State_Culturing) then printStack() end

	local text_time = panel_State_Culturing:getChildByName("BitmapFontLabel_Remain_Time")
	if isNil(text_time) then printStack() end

	local deltaTime = os.time()-GlobalStatus.getInstance():getCultureTime()
	local time = self.info.timeout - deltaTime
	if notNumber(time) then printStack() end

	local hour = math.floor(time/3600)
	local min = math.floor((time%3600)/60)
	local sec = math.floor((time%3600)%60)

	text_time:setString(string.format("%02d",hour)..":"..string.format("%02d",min)..":"..string.format("%02d",sec))

	--刷新加速钻石数量
	local btn_speedup = panel_State_Culturing:getChildByName("Button_SpeedUp")--加速
	if isNil(btn_speedup) then printStack() return end
	local text_SpeedUp_Count = btn_speedup:getChildByName("Text_SpeedUp_Count")
	local lolipopCost = self:getLolipopCost()
	text_SpeedUp_Count:setString(lolipopCost)

	if time <= 0 then
		self.ctrl:cancelScheduler() 

		self:updateInfo(self.info)
	end
end

function CultureOpenNode:clickCulture(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended then
		local cultureType = {"JUNIOR_CULTURE","MEDIUM_CULTURE","SENIOR_CULTURE","SUPER_CULTURE"}

		local dropType = cultureType[(self.info.item_id-60000)]
		if isNil(dropType) then printStack() return end

		local param = {modelParam = {dropType = dropType}}
		self.ctrl:addPop("game.CultureDes",param)

		SoundManager:playEffect("button.mp3")
	end
end

function CultureOpenNode:clickUpdate(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended then
		local param = {modelParam = {index = self.index, item_id = self.info.item_id}}
		self.ctrl:addPop("game.CultureUpdate",param)

		SoundManager:playEffect("button.mp3")
	end
end

function CultureOpenNode:clickStart(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended then
		print("开始培育")
		self.ctrl:submitFormWait("startCulture", {index = self.index})

		SoundManager:playEffect("button.mp3")
	end
end

function CultureOpenNode:getLolipopCost()
	local lolipopCost = 999
	local timeValueConfig = self.ctrl:getTable("timeValue")
	if isNil(timeValueConfig) then printStack() end

	local deltaTime = os.time()-GlobalStatus.getInstance():getCultureTime()
	local time = self.info.timeout - deltaTime

	local timeInfo = nil
	for k,v in pairs(timeValueConfig) do
		if time>=v.min_time and time<=v.max_time then
			timeInfo = v
			break
		end
	end
	if timeInfo then
		lolipopCost = math.floor((timeInfo.variable_a / 10000) * (time/ timeInfo.variable_c) + timeInfo.variable_b)
	else
		print("no timeValue info")
	end

	return lolipopCost
end

function CultureOpenNode:clickSpeedUp(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended then
		local lolipopCost = self:getLolipopCost()
		-- buyJudgement(3 , lolipopCost , function()
		-- 	print("加速")
		-- 	self.ctrl:submitFormWait("fastCulture", {index = self.index})
		-- end )
		buyJudgement(2 , lolipopCost , function()--暂时改为消耗钻石
			print("加速")
			self.ctrl:submitFormWait("fastCulture", {index = self.index})
		end )

		SoundManager:playEffect("button.mp3")
	end
end

function CultureOpenNode:clickFinish(sender, touchEventType)
	if touchEventType == ccui.TouchEventType.ended then
		print("立即领取",self.index,self.info.item_id)
		self.ctrl:submitFormWait("applyItem", {index  = self.index,item_id = self.info.item_id})

		SoundManager:playEffect("button.mp3")
	end
end


return CultureOpenNode
