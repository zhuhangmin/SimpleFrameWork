local EngineModel = require "EngineModel"
local BattleRewardModel = class("BattleRewardModel", EngineModel)

function BattleRewardModel:onCreate( data )
	BattleRewardModel.super.onCreate(self, data)
	dump(data)
	if type(data.data) ~= "table" then printStack() return end

	self:setAnime(data.anime)
	self:setRank(data.data.rank)
	self:setStar(data.data.stars)
	self:setNum(data.num)

	self.click = 1
end

function BattleRewardModel:setAnime( anime )
	if type(anime) ~= "string" then printStack() return end
	self.anime = anime
end

function BattleRewardModel:setStar( star )
	if type(star) ~= "number" then printStack() return end
	self.star = star
end

function BattleRewardModel:setRank( rank )
	if type(rank) ~= "number" then printStack() return end
	self.rank = rank
end

function BattleRewardModel:setNum( num )
	if type(num) ~= "number" then printStack() return end
	self.num = num
end

function BattleRewardModel:getAnime(  )
	return self.anime 
end

function BattleRewardModel:getNum(  )
	return self.num 
end

function BattleRewardModel:getStringNum(  )
	return tostring(self:getNum())
end

function BattleRewardModel:getStar(  )
	return self.star
end

function BattleRewardModel:getRank(  )
	return self.rank
end




function BattleRewardModel:ctor(data)
	BattleRewardModel.super.ctor(self, data)
end


return BattleRewardModel; 