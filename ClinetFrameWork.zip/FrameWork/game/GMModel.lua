local EngineModel = require "EngineModel"
local GMModel = class("GMModel", EngineModel)

function GMModel:ctor(data)
	GMModel.super.ctor(self, data)
	self.lastBackTime = 0.5
	self.backTimeInterval = 1000 -- ms
end

function GMModel:onCreate(param)
	GMModel.super.onCreate(self, param)
end

function GMModel:getLastBackTime()
	return self.lastBackTime
end

function GMModel:setLastBackTime(lastBackTime)
	self.lastBackTime = lastBackTime
end

function GMModel:getBackTimeInterval()
	return self.backTimeInterval
end

function GMModel:setBackTimeInterval(backTimeInterval)
	self.backTimeInterval = backTimeInterval
end

return GMModel

