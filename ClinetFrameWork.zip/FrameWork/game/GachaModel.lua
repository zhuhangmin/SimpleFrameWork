local EngineModel = require "EngineModel"
local GachaModel = class("GachaModel", EngineModel)

function GachaModel:ctor(data)
	GachaModel.super.ctor(self, data)

	self.UIList = {}
	self.boxAnime = {}
	self.boxAnime1 = {}
	self.boxAnime2 = {}
	self.gachaTag = 1
	self.canFlag = true
	self.again = false
end

function GachaModel:onCreate(param)
	GachaModel.super.onCreate(self, param)
end

function GachaModel:setUIList(UIList)
	self.UIList = UIList
end

function GachaModel:getUIList()
	return self.UIList
end

function GachaModel:setBoxAnime(boxAnime)
	self.boxAnime = boxAnime
end

function GachaModel:getBoxAnime()
	return self.boxAnime
end

function GachaModel:setBoxAnime1(boxAnime1)
	self.boxAnime1 = boxAnime1
end

function GachaModel:getBoxAnime1()
	return self.boxAnime1
end

function GachaModel:setBoxAnime2(boxAnime2)
	self.boxAnime2 = boxAnime2
end

function GachaModel:getBoxAnime2()
	return self.boxAnime2
end

function GachaModel:setGachaTag(gachaTag)
	self.gachaTag = gachaTag
end

function GachaModel:getGachaTag()
	return self.gachaTag
end

function GachaModel:setCanFlag(canFlag)
	self.canFlag = canFlag
end

function GachaModel:getCanFlag()
	return self.canFlag
end

function GachaModel:setAgain(again)
	self.again = again
end

function GachaModel:getAgain()
	return self.again
end




return GachaModel

