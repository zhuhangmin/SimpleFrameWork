local EngineControl = require  "EngineControl"
local BattleScoreHelpControl = class("BattleScoreHelpControl", EngineControl)
--LUA MSGS
local LUA_MSGS = {
}

--SYSTEM MSGS
local BTN_CLOSE = "Button_close"

local SYSTEM_MSGS = {
	BTN_CLOSE,
}




function BattleScoreHelpControl:ctor(model, view)
	BattleScoreHelpControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)
end

function BattleScoreHelpControl:onCreate(param)
	BattleScoreHelpControl.super.onCreate(self, param)

	self:init()
end

function BattleScoreHelpControl:init( ... )
	
end

function BattleScoreHelpControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()
	print("BattleScoreHelpControl:recv name = " .. tostring(senderName))
	if senderName == BTN_CLOSE then
		self:detachFromParent()
	end
end

function BattleScoreHelpControl:recv(event)
	if isNil(event) then printStack() end
	if isNil(event.name) then printStack() end
	if isNil(event.data) then printStack() end
	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

return BattleScoreHelpControl;