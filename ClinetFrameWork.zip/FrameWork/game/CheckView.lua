local EngineView = require "EngineView"
local CheckView = class("CheckView", EngineView)

local csbFilePath = "res/Loading.csb"

function CheckView:ctor(node)
	CheckView.super.ctor(self, node)
end

function CheckView:onCreate(param)
	CheckView.super.onCreate(self, param)

	local csbNode = cc.CSLoader:createNode(csbFilePath)
	if isNil(csbNode) then printStack() return end

	local node = self:getNode()
	if isNil(node) then printStack() return end	
	
	node:addChild(csbNode)

end

return CheckView





