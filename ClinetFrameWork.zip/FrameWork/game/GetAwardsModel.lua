local EngineModel = require "EngineModel"
local GetAwardsModel = class("GetAwardsModel", EngineModel)

function GetAwardsModel:ctor(data)
	GetAwardsModel.super.ctor(self, data)

	self.rewardData = {}
end

function GetAwardsModel:onCreate(param)
	GetAwardsModel.super.onCreate(self, param)

	if isNil(param.rewardData) then printStack() return end
	self:setRewardData(param.rewardData)
end

function GetAwardsModel:setRewardData(rewardData)
	self.rewardData = rewardData
end

function GetAwardsModel:getRewardData()
	return self.rewardData
end


return GetAwardsModel

