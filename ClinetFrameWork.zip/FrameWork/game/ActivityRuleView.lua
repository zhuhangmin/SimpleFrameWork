local EngineView = require "EngineView"
local ActivityView = class("ActivityView", EngineView)

function ActivityView:ctor(node)
	ActivityView.super.ctor(self, node)
end

function ActivityView:onCreate(param)
	ActivityView.super.onCreate(self, param)
	local csbNode = cc.CSLoader:createNode("res/ActivityRule.csb")
	if isNil(csbNode) then printStack() return end
	self:getNode():addChild(csbNode)
	csbNode:setName("csbNode")
end


return ActivityView;