local EngineModel = require "EngineModel"
local ShopModel = class("ShopModel", EngineModel)

function ShopModel:ctor(data)
	ShopModel.super.ctor(self, data)
end

function ShopModel:onCreate(param)
	ShopModel.super.onCreate(self, param)
end

return ShopModel

