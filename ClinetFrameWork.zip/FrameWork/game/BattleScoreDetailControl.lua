local EngineControl = require  "EngineControl"
local BattleScoreDetailControl = class("BattleScoreDetailControl", EngineControl)
--LUA MSGS
local LUA_MSGS = {
}

--SYSTEM MSGS
local BTN_CLOSE = "Button_close"
local RANK_LIST = "ListView_1"
local RANK_ICON = "Image_rank_item"
local SYSTEM_MSGS = {
	BTN_CLOSE,
}




function BattleScoreDetailControl:ctor(model, view)
	BattleScoreDetailControl.super.ctor(self, model, view, LUA_MSGS, SYSTEM_MSGS)
end

function BattleScoreDetailControl:onCreate(param)
	BattleScoreDetailControl.super.onCreate(self, param)
	local action1 = cc.DelayTime:create(0.2)
	local action2 = cc.CallFunc:create(function()
		self:init()
	end)
	local action3 = cc.Sequence:create(action1, action2)
	self:getNode():runAction(action3)
	
end

function BattleScoreDetailControl:init( ... )
	local cfg = self:getTable("scoreChange")
	local list = self:getChildNode(RANK_LIST)
	if isNil(cfg) then printStack() return end 
	if isNil(list) then printStack() return end 
	
	local len = #cfg
	local rank = cfg[len].rank+1
	-- for i, v in ipairs( cfg ) do
	for i = len , 1 , -1 do
		local v = cfg[i]
		local rank_new = v.rank
		if rank_new < rank then
			local item = self:createRankListItem( i, v )
			list:pushBackCustomItem(item)
			rank = rank_new
		end
	end
	list:jumpToTop()
end

function BattleScoreDetailControl:createRankListItem( key, data )
	local node = ccui.Widget:create()
	local csbNode = cc.CSLoader:createNode("res/RankRewardItem.csb")
	if isNil(data.des) then printStack() return end 
	local text_rank = csbNode:getChildByName("text_rank")
	text_rank:setString(data.des)

	local text_rank_my = csbNode:getChildByName("Text_rank_new")
	local flag = (key == PlayerDataBasic.score)
	text_rank_my:setVisible(flag)	

	node:addChild(csbNode)
	node:setContentSize(csbNode:getContentSize())

	local gift_id = data.end_gift
	local reward = self:getConfigRecord("giftPack", gift_id)
	for i = 1, 4, 1 do
		local imgReward = csbNode:getChildByName("Node_reward"..i)
		if reward["reward"..i] ~= 0 then
			addItmeNode(imgReward,reward["reward"..i],reward["num"..i])
		else
			imgReward:setVisible(false)
		end
	end
	csbNode:getChildByName(RANK_ICON):loadTexture(data.icon, ccui.TextureResType.plistType)

	-- self:setTouchEnabled(false)
	return node
end


function BattleScoreDetailControl:systemRecv(event)
	local name = event.name
	local data = event.data
	local sender = data
	local senderName = sender:getName()
	print("BattleScoreDetailControl:recv name = " .. tostring(senderName))
	if senderName == BTN_CLOSE then
		self:detachFromParent()
	end
end

function BattleScoreDetailControl:recv(event)
	if isNil(event) then printStack() end
	if isNil(event.name) then printStack() end
	if isNil(event.data) then printStack() end
	local name = event.name
	local data = event.data

	if name == BASE_MSG.NODE_TOUCH then
		self:systemRecv(event)
		return
	end
end

return BattleScoreDetailControl;