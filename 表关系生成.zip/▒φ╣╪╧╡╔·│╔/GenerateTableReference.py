import json
import os
import os.path
import pyexcel as pe

DATABASE = {}

def printRefTable(base_dir,fileName):
    
    spreadsheet = pe.get_sheet(file_name=os.path.join(base_dir, fileName + ".xlsx"))
    # row_range() gives [0 .. number of rows]
    index = 1

    for r in spreadsheet.row_range():

        # column_range() gives [0 .. number of ranges]
        if (index == 4):

            for c in spreadsheet.column_range():
                cellValue = spreadsheet.cell_value(r, c)        
                refTag = cellValue[0:4]
                if (refTag == "ref:"):
                    refTable = cellValue[4:]
                    findParenIndex = refTable.find('(',0,len(refTable))
                    if(findParenIndex != -1):
                        refTable = refTable[0:findParenIndex]
                    
                    findSlashIndex = refTable.find('-',0,len(refTable))
                    refKey = refTable[0:findSlashIndex]
                    refValue = refTable[findSlashIndex+1: ]
                    fieldCellValue = spreadsheet.cell_value(r-2, c)        

                    
                    if (refTable !=  fileName):
                        print("\t" + refKey + ":" + refValue)
                        DATABASE[fileName][fieldCellValue] = {}
                        DATABASE[fileName][fieldCellValue]["dstTbl"] = refKey
                        DATABASE[fileName][fieldCellValue]["dstKey"] = refValue
                        
                    

        index = index + 1
    



def main(base_dir):
    for name in os.listdir(base_dir):
        if name.endswith(".xlsx"):
            print (name)
            xlsxIndex = name.index('.',0,len(name))
            tblname = name[0:xlsxIndex]
            DATABASE[tblname] = {}
            printRefTable(base_dir,tblname)
            print("")
    print(DATABASE)

    with open("ConfigTableReference.json", 'w') as f:
        json.dump(DATABASE, f,indent=4)

    


if __name__ == '__main__':

    main(os.getcwd())

